import { a as e, c as t, i as n, n as r, o as i, r as a, s as o, t as s } from "@bgparty/sdk/_/chunks/middleware-BVjMCqJq.js";
//#region .bgparty/cache/release-runs/1f5a47a8-baec-4943-8cb1-9592fe4afaec/sdk-entry/zustand_middleware.js
var c = n, l = s, u = r, d = a, f = e, p = i, m = t, h = o;
//#endregion
export { l as combine, u as createJSONStorage, c as default, d as devtools, f as persist, p as redux, m as subscribeWithSelector, h as unstable_ssrSafe };
