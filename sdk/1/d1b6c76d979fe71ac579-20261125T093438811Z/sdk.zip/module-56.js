import { n as e, t } from "@bgparty/sdk/_/chunks/vanilla-C5IeD8Y7.js";
//#region .bgparty/cache/release-runs/1f5a47a8-baec-4943-8cb1-9592fe4afaec/sdk-entry/zustand_vanilla.js
var n = e, r = t;
//#endregion
export { r as createStore, n as default };
