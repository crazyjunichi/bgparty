import { a as e, i as t, n, r, t as i } from "@bgparty/sdk/_/chunks/canvas-confetti-DBH0hOm6.js";
export { n as create, i as default, r as reset, t as shapeFromPath, e as shapeFromText };
