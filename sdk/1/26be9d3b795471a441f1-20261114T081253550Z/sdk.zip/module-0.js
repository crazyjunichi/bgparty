//#region packages/sdk/src/assets.ts
function e(e) {
	if (!globalThis.__bgpartyAssetUrl) throw Error("Game runtime is not ready");
	return globalThis.__bgpartyAssetUrl(e);
}
var t = e;
async function n(t) {
	return globalThis.__bgpartyLoadAssetUrl ? globalThis.__bgpartyLoadAssetUrl(t) : e(t);
}
//#endregion
export { e as gameAssetUrl, n as loadGameAssetUrl, t as sharedAssetUrl };
