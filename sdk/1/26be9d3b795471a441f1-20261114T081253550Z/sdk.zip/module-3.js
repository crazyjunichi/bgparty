import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { o as n } from "@bgparty/sdk/_/chunks/i18n-DpqvG1FM.js";
import { o as r } from "@bgparty/sdk/_/chunks/icons-COizFkul.js";
import { t as i } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { n as a, t as o } from "@bgparty/sdk/_/chunks/back-handlers-BElCi7Gn.js";
//#region src/shared/bottom-sheet.css
var s = /* @__PURE__ */ e(t(), 1), c = /* @__PURE__ */ e(i(), 1), l = 200;
function u({ open: e, onClose: t, label: i, title: u, headerAction: d, children: f, footer: p, keepMounted: m = !1, compact: h = !1, tall: g = !1, preparing: _ = !1, side: v = "right" }) {
	let y = n(), b = a(e, () => t?.(), 0, !1, !0), [x, S] = (0, s.useState)(e), [C, w] = (0, s.useState)(!1), [T, E] = (0, s.useState)(e);
	if (e !== T && (E(e), w(!1), e && S(!0)), (0, s.useEffect)(() => {
		if (e) {
			let e = 0, t = requestAnimationFrame(() => {
				e = requestAnimationFrame(() => w(!0));
			});
			return () => {
				cancelAnimationFrame(t), cancelAnimationFrame(e);
			};
		}
		if (!x) return;
		let t = window.setTimeout(() => S(!1), l);
		return () => window.clearTimeout(t);
	}, [e, x]), !x && !m && !_) return null;
	let D = `absolute inset-0 bg-ink/40 transition-opacity duration-150 ${C ? "opacity-100" : "opacity-0"}`;
	return /* @__PURE__ */ (0, c.jsx)(o, {
		scope: b,
		children: /* @__PURE__ */ (0, c.jsxs)("div", {
			className: `bottom-sheet fixed inset-0 z-30 flex flex-col justify-end ${x || _ ? "" : "hidden"}`,
			role: _ ? void 0 : "dialog",
			"aria-modal": !_ || void 0,
			"aria-label": i,
			"data-side": v,
			"data-preparing": _ || void 0,
			"aria-hidden": _ || void 0,
			inert: _,
			children: [t ? /* @__PURE__ */ (0, c.jsx)("button", {
				"aria-label": y("common.qr.close"),
				className: D,
				onClick: t
			}) : /* @__PURE__ */ (0, c.jsx)("div", {
				"aria-hidden": !0,
				className: D
			}), /* @__PURE__ */ (0, c.jsxs)("div", {
				"data-entered": C,
				className: `bottom-sheet__panel card relative flex min-w-0 ${g ? "max-h-[92%]" : "max-h-[80%]"} flex-col overflow-hidden rounded-b-none border-b-0 shadow-none transition duration-200 ${C ? "ease-out opacity-100" : "ease-in opacity-0"}`,
				children: [
					u && /* @__PURE__ */ (0, c.jsxs)("div", {
						className: "flex min-h-14 flex-none items-center gap-2 border-b-2 border-ink/15 bg-surface px-4",
						children: [
							/* @__PURE__ */ (0, c.jsx)("h2", {
								className: "min-w-0 flex-1 truncate font-display text-lg font-extrabold",
								children: u
							}),
							d,
							t && /* @__PURE__ */ (0, c.jsx)("button", {
								type: "button",
								className: "grid min-h-11 min-w-11 place-items-center rounded-lg",
								"aria-label": y("common.close"),
								onClick: t,
								children: /* @__PURE__ */ (0, c.jsx)(r, { size: 19 })
							})
						]
					}),
					/* @__PURE__ */ (0, c.jsx)("div", {
						className: `bottom-sheet__content flex min-h-0 min-w-0 flex-1 flex-col overflow-y-auto ${h ? "gap-1.5 p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]" : "gap-3 p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]"}`,
						children: f
					}),
					p
				]
			})]
		})
	});
}
//#endregion
export { u as BottomSheet };
