import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { n as r } from "@bgparty/sdk/_/chunks/back-handlers-BElCi7Gn.js";
//#region src/shared/confirm-button.tsx
var i = /* @__PURE__ */ e(t(), 1), a = /* @__PURE__ */ e(n(), 1), o = 3e3;
function s({ label: e, confirmLabel: t, onConfirm: n, className: s, compact: c, ariaLabel: l }) {
	let [u, d] = (0, i.useState)(!1), f = (0, i.useRef)(null);
	r(u, () => {
		f.current && clearTimeout(f.current), d(!1);
	}, 50), (0, i.useEffect)(() => () => {
		f.current && clearTimeout(f.current);
	}, []);
	let p = () => {
		d(!0), f.current && clearTimeout(f.current), f.current = setTimeout(() => d(!1), o);
	}, m = () => {
		if (!u) {
			p();
			return;
		}
		f.current && clearTimeout(f.current), d(!1), n();
	}, h = c ? "flex min-h-9 cursor-pointer items-center justify-center gap-1 rounded-xl border-2 border-ink px-2 text-xs font-bold whitespace-nowrap" : "btn-base";
	return /* @__PURE__ */ (0, a.jsx)("button", {
		type: "button",
		"aria-label": l,
		onClick: m,
		className: u ? `${h} danger-stripes text-white ${s ?? ""}` : `${h} bg-surface text-ink ${s ?? ""}`,
		children: u ? t : e
	});
}
//#endregion
export { s as ConfirmButton };
