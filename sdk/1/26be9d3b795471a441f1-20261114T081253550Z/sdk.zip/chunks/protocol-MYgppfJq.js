import { An as e, Dt as t, Ft as n, Kt as r, Nn as i, Wn as a, _n as o, an as s, ar as c, fn as l, gn as u, ir as d, jn as f, jt as p, nr as m, wt as h, zn as g } from "@bgparty/sdk/_/chunks/schemas-BpsPIIob.js";
//#region src/shared/protocol/envelope.ts
var _ = u(() => m([
	a(),
	e(),
	n(),
	t(),
	p(_),
	g(a(), _)
])), v = h(["lobby", "game"]), y = f({
	kind: a().min(1),
	rid: a().optional(),
	data: _.optional(),
	for: p(a()).optional(),
	secret: _.optional(),
	with: n().optional(),
	ephemeral: n().optional()
});
f({
	v: s(),
	kind: v,
	rid: a().min(1),
	seq: s().nonnegative(),
	hello: n(),
	data: _,
	relay: n().optional(),
	hb: n().optional()
}), r("ok", [f({
	v: s(),
	ok: o(!0),
	view: _,
	fx: p(y).optional()
}), f({
	v: s(),
	ok: o(!1),
	reason: a().optional(),
	params: g(a(), m([a(), e()])).optional()
})]);
//#endregion
//#region src/game-packs/format.ts
var b = "bgparty.pack@1", x = "bgparty.source@1", S = {
	compressedBytes: 100663296,
	unpackedBytes: 268435456,
	fileBytes: 67108864,
	files: 4096
}, C = a().regex(/^[a-f0-9]{64}$/), w = a().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100), T = a().regex(/^[a-zA-Z0-9][a-zA-Z0-9.+_-]{0,99}$/);
function E(e) {
	return e.length > 0 && e.length <= 300 && !/[\\%?#:]/.test(e) && !Array.from(e).some((e) => e.charCodeAt(0) < 32) && e.split("/").every((e) => e.length > 0 && e !== "." && e !== "..");
}
var D = a().refine(E), O = f({
	sha256: C,
	bytes: e().int().min(0).max(S.fileBytes),
	mime: a().max(100).regex(/^[a-z0-9.+-]+\/[a-z0-9.+-]+(?:;charset=utf-8)?$/)
}).passthrough(), k = f({
	name: a().min(1).max(150),
	desc: a().max(1e3),
	rules: a().max(1e5)
}).passthrough(), A = f({
	id: w,
	uuid: c().optional(),
	labels: f({
		zh: k,
		en: k
	}).passthrough(),
	icon: a().max(30),
	iconPath: D.optional(),
	minPlayers: e().int().min(1).max(128),
	maxPlayers: e().int().min(1).max(128),
	bestPlayers: p(e().int().min(1).max(128)).max(128).optional(),
	rulesUrl: i(h([
		"zh",
		"en",
		"de",
		"fr",
		"es",
		"it",
		"ru",
		"ja"
	]), d().refine((e) => e.startsWith("https://"))).optional(),
	botDelayMs: e().int().min(0).max(6e4).optional(),
	accent: a().regex(/^#[a-fA-F0-9]{6}$/),
	hotseat: h([
		"open",
		"cover",
		"off"
	]),
	tier: h([
		"dev",
		"alpha",
		"beta",
		"released"
	]),
	releasedAt: a().max(40),
	mechanics: p(w).max(32),
	interactionTags: p(w).max(16),
	search: f({
		py: a().max(1e3),
		init: a().max(100)
	}).passthrough(),
	capabilities: f({
		bot: n(),
		ai: n(),
		options: n(),
		guide: n()
	}).passthrough()
}).passthrough().refine((e) => e.maxPlayers >= e.minPlayers), j = f({
	url: a().min(1).max(2048),
	sha256: C,
	bytes: e().int().positive().max(S.compressedBytes),
	id: w,
	version: T,
	sdkMajor: e().int().positive(),
	sdkApi: e().int().min(1).max(1e5).optional()
}).catchall(l());
f({
	format: o(b),
	kind: h([
		"game",
		"sdk",
		"resource"
	]),
	id: w,
	version: T,
	bridge: o(1),
	sdkMajor: e().int().min(1).max(1e3),
	sdkApi: e().int().min(1).max(1e5).optional(),
	platformApi: e().int().min(1).max(1e5).optional(),
	assetLoading: o("deferred-images").optional(),
	entry: D,
	exports: g(a().max(200), D),
	assets: g(a().max(500), D),
	css: p(D).max(128),
	files: g(D, O),
	dependencies: p(j).max(32).default([]),
	game: A.optional(),
	equivalentTo: p(C).max(100).optional()
}).passthrough().superRefine((e, t) => {
	e.equivalentTo && (e.kind !== "game" || new Set(e.equivalentTo).size !== e.equivalentTo.length) && t.addIssue({
		code: "custom",
		message: "Invalid equivalent game package references"
	}), e.assetLoading && (e.kind !== "game" || (e.sdkApi ?? 1) < 4) && t.addIssue({
		code: "custom",
		message: "Deferred images require a game using SDK API 4"
	});
	let n = Object.keys(e.files);
	(n.length === 0 || n.length > S.files || !e.files[e.entry]) && t.addIssue({
		code: "custom",
		message: "Invalid package entry or file count"
	}), Object.values(e.files).reduce((e, t) => e + t.bytes, 0) > S.unpackedBytes && t.addIssue({
		code: "custom",
		message: "Package is too large"
	});
	for (let n of [
		...Object.values(e.exports),
		...Object.values(e.assets),
		...e.css,
		...e.game?.iconPath ? [e.game.iconPath] : []
	]) e.files[n] || t.addIssue({
		code: "custom",
		message: "Missing package file"
	});
	e.kind === "game" && (!e.game || e.game.id !== e.id) && t.addIssue({
		code: "custom",
		message: "Missing game metadata"
	});
	for (let n of Object.keys(e.exports)) e.kind === "game" && !n.startsWith("@bgparty/game/") && t.addIssue({
		code: "custom",
		message: "Reserved module namespace"
	});
	e.kind === "resource" && (Object.keys(e.exports).length || e.dependencies.length || e.css.length) && t.addIssue({
		code: "custom",
		message: "Resource packages cannot contain executable modules or dependencies"
	});
}), f({
	format: o("bgparty.sdk@1"),
	releases: p(j).max(1e4)
}).passthrough();
var M = f({
	source: a().max(2048),
	game: j,
	sdk: j,
	uuid: c().optional()
}).catchall(l());
f({
	format: o(x),
	name: a().min(1).max(150),
	games: p(f({
		metadata: A,
		release: j,
		releaseRevision: s().positive().optional()
	}).passthrough()).max(1e4)
}).passthrough().superRefine((e, t) => {
	let n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set();
	for (let i of e.games) if ((n.has(i.metadata.id) || i.metadata.id !== i.release.id) && t.addIssue({
		code: "custom",
		message: "Duplicate or inconsistent game identity"
	}), n.add(i.metadata.id), i.metadata.uuid) {
		let e = i.metadata.uuid.toLowerCase();
		r.has(e) && t.addIssue({
			code: "custom",
			message: "Duplicate game UUID"
		}), r.add(e);
	}
});
//#endregion
//#region src/lobby/protocol.ts
var N = r("type", [
	f({
		type: o("join"),
		name: a().max(64),
		avatar: s().nonnegative()
	}),
	f({ type: o("leave") }),
	f({
		type: o("autopilot"),
		on: n()
	})
]), P = f({
	rid: a(),
	name: a(),
	colorIndex: s().nonnegative(),
	avatar: s().nonnegative(),
	online: n(),
	autopilot: n().optional()
}), F = "bot:", I = "aibot:", L = (e, t = "rule") => `${t === "ai" ? I : F}${e}`, R = (e) => {
	let t = e.startsWith(I) ? I : e.startsWith(F) ? F : null;
	if (t === null) return null;
	let n = Number(e.slice(t.length));
	return Number.isInteger(n) && n >= 0 ? n : null;
}, z = (e) => R(e) !== null, B = (e) => e.startsWith(I) && R(e) !== null, V = "local:", H = (e) => `${V}${e}`, U = (e) => {
	if (!e.startsWith(V)) return null;
	let t = Number(e.slice(6));
	return Number.isInteger(t) && t >= 0 ? t : null;
}, W = (e) => U(e) !== null, G = f({
	winner: p(a()),
	ranking: p(a()),
	scores: g(a(), e()).optional(),
	autopilot: g(a(), e()).optional()
}), K = f({
	lobby: f({
		phase: h(["lobby", "playing"]),
		gameId: a().nullable(),
		runtime: M.optional(),
		members: p(P)
	}),
	game: _.optional(),
	analyticsMatchId: a().regex(/^[a-z0-9]{32}$/).optional()
});
//#endregion
export { z as a, N as c, K as d, B as i, U as l, L as n, W as o, G as r, P as s, R as t, H as u };
