import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/shared/back-handlers.tsx
var r = /* @__PURE__ */ e(t(), 1), i = /* @__PURE__ */ e(n(), 1), a = (0, r.createContext)(null), o = (0, r.createContext)(null);
function s({ scope: e, children: t }) {
	return /* @__PURE__ */ (0, i.jsx)(o, {
		value: e,
		children: t
	});
}
function c(e, t, n = 0, i = !1, s = !1) {
	let c = (0, r.useContext)(a), l = (0, r.useContext)(o), u = (0, r.useMemo)(() => ({
		parent: l,
		order: 0,
		active: !1
	}), [l]), d = (0, r.useRef)(t);
	return (0, r.useLayoutEffect)(() => {
		d.current = t;
	}), (0, r.useLayoutEffect)(() => {
		if (e && c) return c.register(() => d.current(), n, i, s ? u : l, s);
	}, [
		e,
		c,
		l,
		u,
		n,
		i,
		s
	]), u;
}
//#endregion
export { c as n, s as t };
