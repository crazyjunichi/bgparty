import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { a as n, o as r } from "@bgparty/sdk/_/chunks/i18n-DpqvG1FM.js";
import { O as i, a, c as o } from "@bgparty/sdk/_/chunks/icons-COizFkul.js";
import { t as s } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { BottomSheet as c } from "@bgparty/sdk/_/module-3.js";
//#region src/game-packs/version.ts
var l = /* @__PURE__ */ e(t(), 1);
function u(e) {
	let t = /^[a-f0-9]{20}-(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(\d{3})Z$/.exec(e);
	if (!t) return;
	let [, n, r, i, a, o, s, c] = t, l = `${n}-${r}-${i}T${a}:${o}:${s}.${c}Z`, u = new Date(l);
	return Number.isFinite(u.getTime()) && u.toISOString() === l ? l : void 0;
}
function d(e, t, n = !1) {
	return new Intl.DateTimeFormat(t, {
		...n ? {} : { year: "numeric" },
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		hour12: !1
	}).format(new Date(e));
}
//#endregion
//#region src/game-packs/version-info.tsx
var f = /* @__PURE__ */ e(s(), 1);
function p({ label: e, reference: t, compact: i = !1 }) {
	let a = r(), o = n((e) => e.locale), s = u(t.version);
	return /* @__PURE__ */ (0, f.jsxs)("div", {
		className: i ? "flex min-w-0 items-baseline gap-1.5 whitespace-nowrap text-xs leading-4 text-ink/60" : "min-w-0 break-words text-xs leading-relaxed text-ink/70",
		children: [/* @__PURE__ */ (0, f.jsxs)("span", { children: [
			e,
			" ",
			/* @__PURE__ */ (0, f.jsx)("code", {
				title: t.sha256,
				children: t.sha256.slice(0, 10)
			})
		] }), s && /* @__PURE__ */ (0, f.jsxs)("span", {
			className: i ? "min-w-0" : "block",
			children: [i ? "· " : `${a("packs.versionBuiltAt")} `, /* @__PURE__ */ (0, f.jsx)("time", {
				dateTime: s,
				title: s,
				"aria-label": `${a("packs.versionBuiltAt")} ${d(s, o)}`,
				children: d(s, o, i)
			})]
		})]
	});
}
function m({ runtime: e, name: t }) {
	let n = r(), [i, s] = (0, l.useState)(null), c = document.querySelector("meta[name=\"bgparty-version\"]")?.content, d = document.querySelector("meta[name=\"bgparty-build-time\"]")?.content, m = [
		...e ? [
			`${n("packs.versionGameName")}: ${t ?? e.game.id} (${e.game.id})`,
			`${n("packs.versionSource")}: ${e.source}`,
			...[e.game, e.sdk].flatMap((e, t) => [
				`${n(t === 0 ? "packs.versionMatchGame" : "packs.versionRuntime")}: ${e.version}`,
				`SHA-256: ${e.sha256}`,
				...u(e.version) ? [`${n("packs.versionBuiltAt")}: ${u(e.version)}`] : []
			])
		] : [],
		...c ? [`${n("packs.versionPlatform")}: ${c}`] : [],
		...d ? [`${n("packs.versionPlatformTime")}: ${d}`] : []
	].join("\n"), h = i?.text === m && i.ok, g = n(h ? "packs.versionCopied" : "packs.versionCopy");
	return /* @__PURE__ */ (0, f.jsxs)("div", {
		className: "max-h-[45vh] flex-none overflow-y-auto px-3 pt-1 pb-[calc(0.5rem+env(safe-area-inset-bottom))]",
		children: [
			/* @__PURE__ */ (0, f.jsxs)("div", {
				className: "flex min-w-0 items-center gap-2",
				children: [/* @__PURE__ */ (0, f.jsx)("div", {
					className: "min-w-0 flex-1",
					children: e ? /* @__PURE__ */ (0, f.jsxs)(f.Fragment, { children: [/* @__PURE__ */ (0, f.jsx)(p, {
						compact: !0,
						label: n("packs.versionMatchGame"),
						reference: e.game
					}), /* @__PURE__ */ (0, f.jsx)(p, {
						compact: !0,
						label: n("packs.versionRuntime"),
						reference: e.sdk
					})] }) : c && /* @__PURE__ */ (0, f.jsxs)("p", {
						className: "break-words text-xs text-ink/60",
						children: [
							n("packs.versionPlatform"),
							" ",
							c
						]
					})
				}), !!m && /* @__PURE__ */ (0, f.jsx)("button", {
					type: "button",
					"aria-label": g,
					title: g,
					className: "grid size-8 flex-none cursor-pointer place-items-center rounded-lg text-ink/60 hover:bg-surface",
					onClick: () => {
						Promise.resolve().then(() => navigator.clipboard.writeText(m)).then(() => s({
							text: m,
							ok: !0
						})).catch(() => s({
							text: m,
							ok: !1
						}));
					},
					children: h ? /* @__PURE__ */ (0, f.jsx)(a, { size: 17 }) : /* @__PURE__ */ (0, f.jsx)(o, { size: 17 })
				})]
			}),
			/* @__PURE__ */ (0, f.jsx)("span", {
				role: "status",
				className: "sr-only",
				children: h ? g : ""
			}),
			i?.text === m && !i.ok && /* @__PURE__ */ (0, f.jsxs)("div", {
				className: "space-y-1",
				children: [/* @__PURE__ */ (0, f.jsx)("p", {
					role: "status",
					className: "text-xs text-warn-ink",
					children: n("packs.versionCopyFailed")
				}), /* @__PURE__ */ (0, f.jsx)("textarea", {
					readOnly: !0,
					"aria-label": n("packs.versionCopy"),
					value: m,
					className: "h-24 w-full rounded-lg border border-ink/30 bg-paper p-2 text-xs",
					onFocus: (e) => e.currentTarget.select()
				})]
			})
		]
	});
}
//#endregion
//#region src/shared/game-menu.tsx
function h({ children: e, notice: t, quickAction: n, attention: a, headerAction: o, runtime: s, gameName: u }) {
	let d = r(), [p, h] = (0, l.useState)(!1), g = () => h(!1);
	return /* @__PURE__ */ (0, f.jsxs)(f.Fragment, { children: [
		t && /* @__PURE__ */ (0, f.jsx)("div", {
			className: "pointer-events-none fixed top-[calc(env(safe-area-inset-top)+6px)] left-[calc(env(safe-area-inset-left)+6px)] z-[19] max-w-[calc(100vw-72px)]",
			children: t
		}),
		n && /* @__PURE__ */ (0, f.jsx)("div", {
			className: "fixed top-[calc(env(safe-area-inset-top)+54px)] right-[calc(env(safe-area-inset-right)+6px)] z-[19]",
			children: n
		}),
		/* @__PURE__ */ (0, f.jsxs)("button", {
			type: "button",
			"aria-label": `${d(p ? "session.menu.close" : "session.menu.open")}${a ? ` · ${a}` : ""}`,
			"aria-expanded": p,
			className: "fixed top-[calc(env(safe-area-inset-top)+4px)] right-[calc(env(safe-area-inset-right)+4px)] z-[19] grid size-11 cursor-pointer place-items-center rounded-xl bg-transparent text-ink",
			onClick: () => h((e) => !e),
			children: [/* @__PURE__ */ (0, f.jsx)(i, {
				size: 22,
				className: "drop-shadow-[0_1px_1px_white]"
			}), a && /* @__PURE__ */ (0, f.jsx)("span", {
				"aria-hidden": !0,
				className: "absolute -top-1 -left-1 size-3 rounded-full border border-ink bg-warn"
			})]
		}),
		/* @__PURE__ */ (0, f.jsx)(c, {
			open: p,
			onClose: g,
			label: d("session.menu.open"),
			title: d("session.menu.open"),
			headerAction: o,
			keepMounted: !0,
			compact: !0,
			footer: /* @__PURE__ */ (0, f.jsx)(m, {
				runtime: s,
				name: u
			}),
			children: e(g)
		})
	] });
}
function g({ icon: e, label: t, onClick: n, danger: r, pressed: i }) {
	return /* @__PURE__ */ (0, f.jsxs)("button", {
		type: "button",
		"aria-pressed": i,
		className: `flex min-h-11 w-full cursor-pointer items-center gap-3 rounded-xl border-2 px-3 text-left text-sm font-bold ${r ? "border-danger bg-danger-soft text-danger-ink" : i ? "border-ink bg-pop text-white" : "border-ink bg-paper text-ink"}`,
		onClick: n,
		children: [e, /* @__PURE__ */ (0, f.jsx)("span", {
			className: "min-w-0 flex-1",
			children: t
		})]
	});
}
//#endregion
export { h as GameMenu, g as GameMenuAction };
