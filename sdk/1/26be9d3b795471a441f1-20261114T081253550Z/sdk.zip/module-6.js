import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { o as n } from "@bgparty/sdk/_/chunks/i18n-DpqvG1FM.js";
import { t as r } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { CANVAS_SIZE as i, PALETTE as a, STROKE_WIDTHS as o } from "@bgparty/sdk/_/module-7.js";
import { StrokePath as s } from "@bgparty/sdk/_/module-8.js";
//#region src/shared/drawing/canvas.tsx
var c = /* @__PURE__ */ e(t(), 1), l = /* @__PURE__ */ e(r(), 1);
function u({ children: e }) {
	let t = (0, c.useRef)(null), [n, r] = (0, c.useState)(0);
	return (0, c.useEffect)(() => {
		let e = t.current;
		if (!e) return;
		let n = new ResizeObserver(() => {
			let t = e.getBoundingClientRect();
			r(Math.floor(Math.min(t.width, t.height)));
		});
		return n.observe(e), () => n.disconnect();
	}, []), /* @__PURE__ */ (0, l.jsx)("div", {
		ref: t,
		className: "flex min-h-0 min-w-0 flex-1 items-center justify-center",
		children: /* @__PURE__ */ (0, l.jsx)("div", {
			className: "relative",
			style: n > 0 ? {
				width: n,
				height: n
			} : { visibility: "hidden" },
			children: n > 0 && e
		})
	});
}
var d = 200, f = 500;
function p({ value: e, onChange: t }) {
	let r = n(), u = (0, c.useRef)(null), [p, _] = (0, c.useState)(null), [v, y] = (0, c.useState)(0), [b, x] = (0, c.useState)(1), [S, C] = (0, c.useState)(null), w = (e) => {
		let t = u.current?.getBoundingClientRect();
		if (!t) return [0, 0];
		let n = Math.round((e.clientX - t.left) / t.width * i), r = Math.round((e.clientY - t.top) / t.height * i);
		return [Math.max(0, Math.min(i, n)), Math.max(0, Math.min(i, r))];
	}, T = (t) => {
		if (p || e.length >= d) return;
		t.currentTarget.setPointerCapture(t.pointerId);
		let [n, r] = w(t);
		_({
			c: v,
			w: b,
			pts: [n, r]
		});
	}, E = (e) => {
		if (!p) return;
		let [t, n] = w(e), r = p.pts.length;
		if (r >= f * 2) return;
		let i = t - p.pts[r - 2], a = n - p.pts[r - 1];
		i * i + a * a < 64 || _({
			...p,
			pts: [
				...p.pts,
				t,
				n
			]
		});
	}, D = () => {
		p && (t([...e, p]), _(null));
	};
	return /* @__PURE__ */ (0, l.jsxs)("div", {
		className: "flex h-full min-h-0 w-full flex-col gap-2",
		children: [/* @__PURE__ */ (0, l.jsx)("div", {
			className: "frame min-h-0 flex-1 overflow-hidden p-1",
			children: /* @__PURE__ */ (0, l.jsxs)("svg", {
				ref: u,
				viewBox: `0 0 ${i} ${i}`,
				className: "h-full w-full touch-none rounded-lg bg-white",
				onPointerDown: T,
				onPointerMove: E,
				onPointerUp: D,
				onPointerCancel: D,
				children: [e.map((e, t) => /* @__PURE__ */ (0, l.jsx)(s, { stroke: e }, t)), p && /* @__PURE__ */ (0, l.jsx)(s, { stroke: p })]
			})
		}), /* @__PURE__ */ (0, l.jsxs)("div", {
			className: "flex flex-none items-center gap-1.5",
			children: [
				/* @__PURE__ */ (0, l.jsx)("div", {
					className: "flex min-w-0 flex-1 items-center gap-1.5 overflow-x-auto py-1 max-sm:hidden",
					children: a.map((e, t) => /* @__PURE__ */ (0, l.jsx)(m, {
						hex: e,
						n: t + 1,
						active: t === v,
						onPick: () => y(t)
					}, e))
				}),
				/* @__PURE__ */ (0, l.jsxs)("div", {
					className: "relative flex-none sm:hidden",
					children: [/* @__PURE__ */ (0, l.jsx)("button", {
						type: "button",
						"aria-label": r("common.draw.colorAria", { n: v + 1 }),
						"aria-expanded": S === "color",
						onClick: () => C(S === "color" ? null : "color"),
						className: "block size-11 cursor-pointer rounded-full border-2 border-ink",
						style: { backgroundColor: a[v] }
					}), S === "color" && /* @__PURE__ */ (0, l.jsx)(g, {
						onClose: () => C(null),
						children: /* @__PURE__ */ (0, l.jsx)("div", {
							className: "flex w-max max-w-56 flex-wrap gap-1.5",
							children: a.map((e, t) => /* @__PURE__ */ (0, l.jsx)(m, {
								hex: e,
								n: t + 1,
								active: t === v,
								onPick: () => {
									y(t), C(null);
								}
							}, e))
						})
					})]
				}),
				/* @__PURE__ */ (0, l.jsxs)("div", {
					className: "relative flex-none sm:hidden",
					children: [/* @__PURE__ */ (0, l.jsx)(h, {
						w: o[b],
						n: b + 1,
						active: !1,
						expanded: S === "width",
						onPick: () => C(S === "width" ? null : "width")
					}), S === "width" && /* @__PURE__ */ (0, l.jsx)(g, {
						onClose: () => C(null),
						children: /* @__PURE__ */ (0, l.jsx)("div", {
							className: "flex gap-1.5",
							children: o.map((e, t) => /* @__PURE__ */ (0, l.jsx)(h, {
								w: e,
								n: t + 1,
								active: t === b,
								onPick: () => {
									x(t), C(null);
								}
							}, e))
						})
					})]
				}),
				/* @__PURE__ */ (0, l.jsx)("span", { className: "flex-1 sm:hidden" }),
				/* @__PURE__ */ (0, l.jsx)("div", {
					className: "flex items-center gap-1.5 max-sm:hidden",
					children: o.map((e, t) => /* @__PURE__ */ (0, l.jsx)(h, {
						w: e,
						n: t + 1,
						active: t === b,
						onPick: () => x(t)
					}, e))
				}),
				/* @__PURE__ */ (0, l.jsx)("button", {
					type: "button",
					className: "btn-quiet min-h-11 flex-none cursor-pointer px-3",
					disabled: e.length === 0,
					onClick: () => t(e.slice(0, -1)),
					children: r("common.draw.undo")
				}),
				/* @__PURE__ */ (0, l.jsx)("button", {
					type: "button",
					className: "btn-quiet min-h-11 flex-none cursor-pointer px-3",
					disabled: e.length === 0,
					onClick: () => t([]),
					children: r("common.draw.clear")
				})
			]
		})]
	});
}
function m({ hex: e, n: t, active: r, onPick: i }) {
	let a = n();
	return /* @__PURE__ */ (0, l.jsx)("button", {
		type: "button",
		"aria-label": a("common.draw.colorAria", { n: t }),
		onClick: i,
		className: `size-8 flex-none cursor-pointer rounded-full border-2 border-ink ${r ? "ring-2 ring-ink ring-offset-2 ring-offset-surface" : "opacity-70"}`,
		style: { backgroundColor: e }
	});
}
function h({ w: e, n: t, active: r, expanded: i, onPick: a }) {
	let o = n();
	return /* @__PURE__ */ (0, l.jsx)("button", {
		type: "button",
		"aria-label": o("common.draw.widthAria", { n: t }),
		"aria-expanded": i,
		onClick: a,
		className: `grid size-11 flex-none cursor-pointer place-items-center rounded-full border-2 border-ink ${r ? "bg-ink/10" : "bg-surface"}`,
		children: /* @__PURE__ */ (0, l.jsx)("svg", {
			viewBox: "0 0 24 24",
			className: "size-6",
			"aria-hidden": !0,
			children: /* @__PURE__ */ (0, l.jsx)("path", {
				d: "M4 15 C 8 7, 13 19, 20 9",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: e / 4,
				strokeLinecap: "round"
			})
		})
	});
}
function g({ onClose: e, children: t }) {
	let r = n();
	return /* @__PURE__ */ (0, l.jsxs)(l.Fragment, { children: [/* @__PURE__ */ (0, l.jsx)("button", {
		"aria-label": r("common.qr.close"),
		className: "fixed inset-0 z-30 cursor-default",
		onClick: e
	}), /* @__PURE__ */ (0, l.jsx)("div", {
		className: "frame absolute bottom-full left-0 z-40 mb-2 p-2",
		children: t
	})] });
}
//#endregion
export { p as DrawingPad, u as SquareBox };
