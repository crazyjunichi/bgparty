import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { AVATARS as t } from "@bgparty/sdk/_/module-1.js";
import { a as n, o as r, t as i } from "@bgparty/sdk/_/chunks/i18n-DpqvG1FM.js";
import { a, i as o, l as s } from "@bgparty/sdk/_/chunks/icons-COizFkul.js";
import { t as c } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { useFxAnchor as l } from "@bgparty/sdk/_/module-10.js";
import { PLAYER_COLORS as u } from "@bgparty/sdk/_/module-22.js";
import { t as d } from "@bgparty/sdk/_/chunks/protocol-MYgppfJq.js";
//#region src/games/ui/player-strip.tsx
var f = /* @__PURE__ */ e(c(), 1);
function p({ members: e, myRid: t, variant: i = "plate", status: a, trailing: o, action: s, onPick: c, picked: l, anchorOf: u, dimmed: d, scroll: p, adaptive: h = !1 }) {
	let g = r(), _ = n((e) => e.locale), v = {
		you: g("lobby.you"),
		offline: g("lobby.offline"),
		bot: g("lobby.bot"),
		thinking: g("lobby.thinking"),
		done: g("lobby.done")
	}, y = x[i], b = e.map((e) => /* @__PURE__ */ (0, f.jsx)(y, {
		m: e,
		myRid: t,
		anchorName: u?.(e.rid) ?? null,
		status: a?.(e.rid),
		trailing: i === "plate" ? o?.(e.rid) : void 0,
		action: s?.(e.rid) ?? null,
		onPick: c,
		picked: l?.(e.rid) ?? !1,
		dimmed: d?.(e.rid) ?? !1,
		labels: v,
		locale: _,
		adaptive: h
	}, e.rid));
	return p ? /* @__PURE__ */ (0, f.jsx)("div", {
		className: `overflow-x-auto pt-2.5 pr-1 pb-1 pl-2.5${h ? " game-player-scroll" : ""}`,
		children: /* @__PURE__ */ (0, f.jsx)("ul", {
			className: `mx-auto w-max ${m[i]}${h ? " game-player-strip" : ""}`,
			children: b
		})
	}) : /* @__PURE__ */ (0, f.jsx)("ul", {
		className: `${m[i]}${h ? " game-player-strip" : ""}`,
		children: b
	});
}
var m = {
	medal: "flex flex-wrap gap-x-2 gap-y-1",
	plate: "grid grid-cols-[repeat(auto-fill,minmax(10rem,1fr))] gap-1.5",
	mini: "flex flex-wrap gap-x-2 gap-y-1"
};
function h(e, t) {
	return d(e.rid) === null ? e.name : i(t, e.avatar);
}
function g({ m: e, box: n, img: r, isMe: i, bot: c, action: d, labels: p, anchorName: m }) {
	let { ref: h } = l(m), g = u[e.colorIndex % u.length];
	return /* @__PURE__ */ (0, f.jsxs)("span", {
		ref: h,
		className: "relative flex-none",
		children: [
			e.online ? i ? /* @__PURE__ */ (0, f.jsx)("span", {
				className: "absolute -top-1 -right-1 z-20 rounded-md border border-ink bg-info-soft px-1 text-[10px] leading-3.5 font-bold text-info-ink",
				children: p.you
			}) : c && /* @__PURE__ */ (0, f.jsx)("span", {
				role: "img",
				"aria-label": p.bot,
				className: "absolute -top-1 -right-1 z-20 grid size-5 place-items-center rounded-full border-2 border-ink bg-warn-soft text-warn-ink",
				children: /* @__PURE__ */ (0, f.jsx)(o, {
					size: 12,
					"aria-hidden": !0
				})
			}) : /* @__PURE__ */ (0, f.jsx)("span", {
				role: "img",
				"aria-label": p.offline,
				className: "absolute -top-1 -right-1 z-20 grid size-5 place-items-center rounded-full border-2 border-ink bg-ink text-surface",
				children: /* @__PURE__ */ (0, f.jsx)(s, {
					size: 12,
					"aria-hidden": !0
				})
			}),
			d === "done" && /* @__PURE__ */ (0, f.jsx)("span", {
				role: "img",
				"aria-label": p.done,
				className: "absolute -top-2 -left-2 z-20 grid size-6 place-items-center rounded-full border-2 border-ink bg-done text-white shadow-[1px_1px_0_var(--color-ink)]",
				children: /* @__PURE__ */ (0, f.jsx)(a, {
					size: 15,
					strokeWidth: 3.5,
					"aria-hidden": !0
				})
			}),
			d === "pending" && /* @__PURE__ */ (0, f.jsx)("span", {
				role: "status",
				"aria-label": p.thinking,
				className: "absolute -top-1.5 -left-1.5 z-20 flex h-5 items-center gap-0.5 rounded-full border-2 border-ink bg-surface px-1.5 shadow-[1px_1px_0_var(--color-ink)]",
				children: [
					0,
					1,
					2
				].map((e) => /* @__PURE__ */ (0, f.jsx)("span", {
					className: "thinking-dot size-1 rounded-full bg-ink",
					style: { animationDelay: `${e * 150}ms` }
				}, e))
			}),
			/* @__PURE__ */ (0, f.jsx)("span", {
				className: `grid ${n} place-items-center rounded-full border-3 border-ink shadow-[2px_2px_0_var(--color-ink)]`,
				style: { backgroundColor: g.hex },
				children: /* @__PURE__ */ (0, f.jsx)("img", {
					src: t[e.avatar % t.length],
					alt: "",
					draggable: !1,
					className: `${r} object-contain`
				})
			})
		]
	});
}
function _({ m: e, myRid: t, action: n, anchorName: i, box: a, img: o }) {
	let s = r(), c = {
		you: s("lobby.you"),
		offline: s("lobby.offline"),
		bot: s("lobby.bot"),
		thinking: s("lobby.thinking"),
		done: s("lobby.done")
	};
	return /* @__PURE__ */ (0, f.jsx)("span", {
		className: e.online ? "" : "opacity-45",
		children: /* @__PURE__ */ (0, f.jsx)(g, {
			m: e,
			box: a,
			img: o,
			isMe: e.rid === t,
			bot: d(e.rid) !== null,
			action: n,
			labels: c,
			anchorName: i
		})
	});
}
function v({ m: e, myRid: t, anchorName: n, status: r, action: i, onPick: a, picked: o, dimmed: s, labels: c, locale: l }) {
	return /* @__PURE__ */ (0, f.jsxs)("li", {
		role: a ? "button" : void 0,
		onClick: a ? () => a(e.rid) : void 0,
		className: `relative flex w-16 flex-col items-center ${e.online ? "" : "opacity-45"} ${s ? "opacity-50" : ""} ${a ? "cursor-pointer" : ""}`,
		children: [
			/* @__PURE__ */ (0, f.jsx)(g, {
				m: e,
				box: "size-12",
				img: "size-10",
				isMe: e.rid === t,
				bot: d(e.rid) !== null,
				action: i,
				labels: c,
				anchorName: n
			}),
			/* @__PURE__ */ (0, f.jsx)("span", {
				className: `z-10 -mt-3 max-w-full truncate rounded-full border-2 border-ink bg-surface px-1.5 text-xs leading-4.5 font-bold shadow-[1px_1px_0_var(--color-ink)] ${o ? "ring-3 ring-ink ring-offset-1 ring-offset-paper" : ""}`,
				children: h(e, l)
			}),
			/* @__PURE__ */ (0, f.jsx)("span", {
				className: "mt-0.5 flex min-h-5 flex-wrap items-center justify-center gap-0.5",
				children: r
			})
		]
	});
}
function y({ m: e, myRid: t, anchorName: n, status: r, trailing: i, action: a, onPick: o, picked: s, dimmed: c, labels: l, locale: u }) {
	return /* @__PURE__ */ (0, f.jsxs)("li", {
		role: o ? "button" : void 0,
		onClick: o ? () => o(e.rid) : void 0,
		className: `relative flex items-center gap-2 rounded-xl border-3 border-ink bg-surface p-2 shadow-[2px_2px_0_var(--color-ink)] ${e.online ? "" : "opacity-45"} ${c ? "opacity-50" : ""} ${o ? "cursor-pointer" : ""} ${s ? "ring-3 ring-ink ring-offset-1 ring-offset-paper" : ""}`,
		children: [
			/* @__PURE__ */ (0, f.jsx)(g, {
				m: e,
				box: "size-11",
				img: "size-9",
				isMe: e.rid === t,
				bot: d(e.rid) !== null,
				action: a,
				labels: l,
				anchorName: n
			}),
			/* @__PURE__ */ (0, f.jsxs)("span", {
				className: "flex min-w-0 flex-1 flex-col gap-0.5",
				children: [/* @__PURE__ */ (0, f.jsx)("span", {
					className: "flex items-center gap-1 text-xs leading-4.5 font-bold",
					children: /* @__PURE__ */ (0, f.jsx)("span", {
						className: "truncate",
						children: h(e, u)
					})
				}), /* @__PURE__ */ (0, f.jsx)("span", {
					className: "flex min-h-5 flex-wrap items-center gap-x-1 gap-y-0.5",
					children: r
				})]
			}),
			i
		]
	});
}
function b({ m: e, myRid: t, anchorName: n, status: r, action: i, onPick: a, picked: o, dimmed: s, labels: c, locale: l, adaptive: u }) {
	return /* @__PURE__ */ (0, f.jsxs)("li", {
		role: a ? "button" : void 0,
		onClick: a ? () => a(e.rid) : void 0,
		"data-picked": u ? o : void 0,
		className: `relative flex w-14 flex-col items-center ${u ? "game-player-mini" : ""} ${e.online ? "" : "opacity-45"} ${s ? "opacity-50" : ""} ${a ? "cursor-pointer" : ""}`,
		children: [
			/* @__PURE__ */ (0, f.jsx)(g, {
				m: e,
				box: "size-10",
				img: "size-8",
				isMe: e.rid === t,
				bot: d(e.rid) !== null,
				action: i,
				labels: c,
				anchorName: n
			}),
			/* @__PURE__ */ (0, f.jsx)("span", {
				className: `z-10 -mt-2.5 max-w-full truncate rounded-full border-2 border-ink bg-surface px-1 text-[10px] leading-4 font-bold shadow-[1px_1px_0_var(--color-ink)] ${u ? "game-player-name" : ""} ${o ? "ring-2 ring-ink ring-offset-1 ring-offset-paper" : ""}`,
				children: h(e, l)
			}),
			u && /* @__PURE__ */ (0, f.jsx)("span", {
				className: "game-player-status hidden",
				children: r
			})
		]
	});
}
var x = {
	medal: v,
	plate: y,
	mini: b
};
//#endregion
export { p as PlayerStrip, _ as SeatBadgedAvatar, h as seatName };
