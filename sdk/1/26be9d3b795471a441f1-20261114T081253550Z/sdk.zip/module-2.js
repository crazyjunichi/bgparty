//#region src/shared/bot-personality.ts
var e = {
	warrior: {
		risk: .9,
		greed: .5,
		aggression: .8,
		herd: .3,
		cunning: .3,
		patience: .5,
		compete: .7,
		noise: .4
	},
	sage: {
		risk: .15,
		greed: .4,
		aggression: .2,
		herd: .6,
		cunning: .5,
		patience: .9,
		compete: .4,
		noise: .2
	},
	miser: {
		risk: .45,
		greed: .95,
		aggression: .4,
		herd: .4,
		cunning: .6,
		patience: .7,
		compete: .6,
		noise: .3
	},
	schemer: {
		risk: .5,
		greed: .6,
		aggression: .6,
		herd: .3,
		cunning: .95,
		patience: .7,
		compete: .7,
		noise: .3
	},
	follower: {
		risk: .4,
		greed: .4,
		aggression: .2,
		herd: .95,
		cunning: .2,
		patience: .5,
		compete: .4,
		noise: .5
	},
	jester: {
		risk: .7,
		greed: .5,
		aggression: .5,
		herd: .5,
		cunning: .5,
		patience: .2,
		compete: .3,
		noise: .95
	},
	balanced: {
		risk: .5,
		greed: .5,
		aggression: .5,
		herd: .5,
		cunning: .5,
		patience: .5,
		compete: .5,
		noise: .35
	}
}, t = /* @__PURE__ */ "follower.warrior.sage.warrior.warrior.miser.jester.sage.miser.follower.balanced.schemer.sage.schemer.balanced.sage.miser.balanced.balanced.warrior.schemer.sage.jester.miser.miser.follower.jester.schemer.follower.follower.warrior.jester.jester.sage.jester.schemer.sage.follower.balanced.warrior.warrior.warrior.schemer.sage.miser.schemer.miser.balanced".split(".");
function n(e) {
	let t = 2166136261;
	for (let n = 0; n < e.length; n += 1) t ^= e.charCodeAt(n), t = Math.imul(t, 16777619);
	return (t >>> 0) / 4294967295;
}
var r = Object.keys(e.balanced);
function i(i) {
	let a = e[i === null ? "balanced" : t[i] ?? "balanced"], o = {};
	for (let e of r) o[e] = Math.min(1, Math.max(0, a[e] + (n(`${i}:${e}`) - .5) * .3));
	return o;
}
//#endregion
export { i as botPersonality };
