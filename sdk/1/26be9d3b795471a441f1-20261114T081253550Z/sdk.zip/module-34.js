import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { usePrefersReducedMotion as n } from "@bgparty/sdk/_/module-16.js";
import { PLAYER_COLORS as r } from "@bgparty/sdk/_/module-22.js";
import { t as i } from "@bgparty/sdk/_/chunks/canvas-confetti-DGbPgBuF.js";
//#region src/games/ui/confetti.tsx
var a = /* @__PURE__ */ e(t(), 1), o = r.map((e) => e.hex);
function s() {
	let e = n();
	return (0, a.useEffect)(() => {
		if (e) return;
		let t = {
			colors: o,
			disableForReducedMotion: !0
		};
		i({
			...t,
			particleCount: 60,
			angle: 60,
			spread: 62,
			startVelocity: 68,
			gravity: .85,
			drift: 1.2,
			origin: {
				x: 0,
				y: 1
			}
		}), i({
			...t,
			particleCount: 60,
			angle: 120,
			spread: 62,
			startVelocity: 68,
			gravity: .85,
			drift: -1.2,
			origin: {
				x: 1,
				y: 1
			}
		});
	}, [e]), null;
}
//#endregion
export { s as Confetti };
