import { n as e, t } from "@bgparty/sdk/_/chunks/vanilla-C5IeD8Y7.js";
//#region .bgparty/cache/release-runs/d3903730-b765-4e1b-b91e-4a92c6beb47d/sdk-entry/zustand_vanilla.js
var n = e, r = t;
//#endregion
export { r as createStore, n as default };
