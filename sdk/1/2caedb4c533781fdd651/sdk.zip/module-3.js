import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { o as n } from "@bgparty/sdk/_/chunks/i18n-BrDyMwni.js";
import { o as r } from "@bgparty/sdk/_/chunks/icons-DzpZGOit.js";
import { t as i } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/shared/bottom-sheet.css
var a = /* @__PURE__ */ e(t(), 1), o = /* @__PURE__ */ e(i(), 1), s = 200;
function c({ open: e, onClose: t, label: i, title: c, headerAction: l, children: u, footer: d, keepMounted: f = !1, compact: p = !1, tall: m = !1, preparing: h = !1 }) {
	let g = n(), [_, v] = (0, a.useState)(e), [y, b] = (0, a.useState)(!1), [x, S] = (0, a.useState)(e);
	if (e !== x && (S(e), b(!1), e && v(!0)), (0, a.useEffect)(() => {
		if (e) {
			let e = 0, t = requestAnimationFrame(() => {
				e = requestAnimationFrame(() => b(!0));
			});
			return () => {
				cancelAnimationFrame(t), cancelAnimationFrame(e);
			};
		}
		if (!_) return;
		let t = window.setTimeout(() => v(!1), s);
		return () => window.clearTimeout(t);
	}, [e, _]), !_ && !f && !h) return null;
	let C = `absolute inset-0 bg-ink/40 transition-opacity duration-150 ${y ? "opacity-100" : "opacity-0"}`;
	return /* @__PURE__ */ (0, o.jsxs)("div", {
		className: `bottom-sheet fixed inset-0 z-30 flex flex-col justify-end ${_ || h ? "" : "hidden"}`,
		role: h ? void 0 : "dialog",
		"aria-modal": !h || void 0,
		"aria-label": i,
		"data-preparing": h || void 0,
		"aria-hidden": h || void 0,
		inert: h,
		children: [t ? /* @__PURE__ */ (0, o.jsx)("button", {
			"aria-label": g("common.qr.close"),
			className: C,
			onClick: t
		}) : /* @__PURE__ */ (0, o.jsx)("div", {
			"aria-hidden": !0,
			className: C
		}), /* @__PURE__ */ (0, o.jsxs)("div", {
			"data-entered": y,
			className: `bottom-sheet__panel card relative flex min-w-0 ${m ? "max-h-[92%]" : "max-h-[80%]"} flex-col overflow-hidden rounded-b-none border-b-0 shadow-none transition duration-200 ${y ? "ease-out opacity-100" : "ease-in opacity-0"}`,
			children: [
				c && /* @__PURE__ */ (0, o.jsxs)("div", {
					className: "flex min-h-14 flex-none items-center gap-2 border-b-2 border-ink/15 bg-surface px-4",
					children: [
						/* @__PURE__ */ (0, o.jsx)("h2", {
							className: "min-w-0 flex-1 truncate font-display text-lg font-extrabold",
							children: c
						}),
						l,
						t && /* @__PURE__ */ (0, o.jsx)("button", {
							type: "button",
							className: "grid min-h-11 min-w-11 place-items-center rounded-lg",
							"aria-label": g("common.close"),
							onClick: t,
							children: /* @__PURE__ */ (0, o.jsx)(r, { size: 19 })
						})
					]
				}),
				/* @__PURE__ */ (0, o.jsx)("div", {
					className: `bottom-sheet__content flex min-h-0 min-w-0 flex-1 flex-col overflow-y-auto ${p ? "gap-1.5 p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]" : "gap-3 p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]"}`,
					children: u
				}),
				d
			]
		})]
	});
}
//#endregion
export { c as BottomSheet };
