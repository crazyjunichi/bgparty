import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/react-B1TUhMyJ.js";
import { a as r } from "@bgparty/sdk/_/chunks/middleware-BVjMCqJq.js";
//#region src/shared/sfx.ts
var i = /* @__PURE__ */ e(t(), 1), a = null;
function o() {
	if (typeof window > "u") return null;
	if (!a) {
		let e = window.AudioContext;
		if (!e) return null;
		a = new e();
	}
	return a.state === "suspended" && a.resume().catch(() => {}), a;
}
typeof window < "u" && window.addEventListener("pointerdown", () => o(), { once: !0 });
function s(e, t, n, r) {
	for (let [i, a] of [
		[1, 1],
		[2.76, .55],
		[5.4, .28]
	]) {
		let o = e.createOscillator(), s = e.createGain();
		o.type = "sine", o.frequency.value = t * i, s.gain.setValueAtTime(r * a, n), s.gain.exponentialRampToValueAtTime(1e-4, n + .7 / Math.sqrt(i)), o.connect(s).connect(e.destination), o.start(n), o.stop(n + .8);
	}
}
var c = n()(r((e) => ({
	turn: "soft",
	muted: !1,
	setTurn: (t) => e({ turn: t }),
	setMuted: (t) => e({ muted: t })
}), { name: "bgparty:sfx" }));
function l(e, t, n, r, i, a = .01) {
	for (let [o, s] of [[1, 1], [2, .25]]) {
		let c = e.createOscillator(), l = e.createGain();
		c.type = "sine", c.frequency.value = t * o, l.gain.setValueAtTime(0, n), l.gain.linearRampToValueAtTime(r * s, n + a), l.gain.exponentialRampToValueAtTime(1e-4, n + i / Math.sqrt(o)), c.connect(l).connect(e.destination), c.start(n), c.stop(n + i + .05);
	}
}
function u(e, t) {
	let n = e.createOscillator(), r = e.createGain();
	n.type = "triangle", n.frequency.value = 700, r.gain.setValueAtTime(0, t), r.gain.linearRampToValueAtTime(.16, t + .005), r.gain.exponentialRampToValueAtTime(1e-4, t + .12), n.connect(r).connect(e.destination), n.start(t), n.stop(t + .17);
}
function d(e, t) {
	let n = e.createOscillator(), r = e.createGain();
	n.type = "sine", n.frequency.setValueAtTime(500, t), n.frequency.exponentialRampToValueAtTime(900, t + .07), r.gain.setValueAtTime(0, t), r.gain.linearRampToValueAtTime(.14, t + .008), r.gain.exponentialRampToValueAtTime(1e-4, t + .16), n.connect(r).connect(e.destination), n.start(t), n.stop(t + .2);
}
var f = {
	soft: (e, t) => l(e, 660, t, .13, .45),
	wood: (e, t) => u(e, t),
	pop: (e, t) => d(e, t),
	chime: (e, t) => s(e, 1568, t, .18)
};
function p() {
	if (c.getState().muted) return null;
	let e = o();
	return e && e.state === "running" ? e : null;
}
function m(e) {
	let t = p();
	t && f[e](t, t.currentTime);
}
function h() {
	let e = p();
	e && f[c.getState().turn](e, e.currentTime);
}
function g() {
	let e = p();
	if (!e) return;
	let t = e.currentTime;
	s(e, 1319, t, .16), s(e, 1760, t + .1, .18);
}
function _() {
	let e = p();
	if (!e) return;
	let t = e.currentTime;
	s(e, 1047, t, .18), s(e, 1319, t + .14, .18), s(e, 1568, t + .28, .2);
}
function v() {
	let e = p();
	if (!e) return;
	let t = e.currentTime;
	s(e, 2093, t, .22), s(e, 2093, t + .18, .16);
}
function y(e, t) {
	let n = (0, i.useRef)(!1);
	(0, i.useEffect)(() => {
		e && !n.current && t(), n.current = e;
	}, [e, t]);
}
//#endregion
export { v as playBell, _ as playGameOver, g as playSettle, h as playTurn, m as previewTurn, c as useSfxSettings, y as useSoundEdge };
