import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/client-Dxrn1NRL.js";
var n = (/* @__PURE__ */ e(t())).default, r = n.createRoot, i = n.hydrateRoot, a = n.version;
//#endregion
export { r as createRoot, n as default, i as hydrateRoot, a as version };
