import { n as e, t } from "@bgparty/sdk/_/chunks/vanilla-C5IeD8Y7.js";
//#region .bgparty/cache/sdk-entry/zustand_vanilla.js
var n = e, r = t;
//#endregion
export { r as createStore, n as default };
