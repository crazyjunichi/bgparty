import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { AVATARS as t } from "@bgparty/sdk/_/module-1.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { PLAYER_COLORS as r } from "@bgparty/sdk/_/module-22.js";
//#region src/shared/team-medal.tsx
var i = /* @__PURE__ */ e(n(), 1);
function a({ member: e, rid: n, editable: a = !1, dragging: o = !1, floating: s = !1, crowned: c = !1, onStartDrag: l }) {
	let u = r[(e?.colorIndex ?? 0) % r.length];
	return /* @__PURE__ */ (0, i.jsxs)("div", {
		onPointerDown: a && l ? (e) => l(n, e) : void 0,
		className: `relative flex items-center gap-1 rounded-full border-2 border-ink bg-surface py-0.5 pr-2 pl-0.5 shadow-[2px_2px_0_var(--color-ink)] ${a ? "touch-none select-none" : ""} ${o ? "opacity-30" : ""} ${s ? "scale-110" : ""}`,
		children: [
			/* @__PURE__ */ (0, i.jsx)("span", {
				className: "grid size-8 flex-none place-items-center rounded-full border-2 border-ink",
				style: { backgroundColor: u.hex },
				children: e && /* @__PURE__ */ (0, i.jsx)("img", {
					src: t[e.avatar % t.length],
					alt: "",
					draggable: !1,
					className: "size-6 object-contain"
				})
			}),
			/* @__PURE__ */ (0, i.jsx)("span", {
				className: "max-w-16 truncate text-xs font-bold",
				children: e?.name ?? n
			}),
			c && /* @__PURE__ */ (0, i.jsx)("span", {
				"aria-hidden": !0,
				className: "absolute -top-2.5 -right-1 text-sm",
				children: "👑"
			})
		]
	});
}
//#endregion
export { a as TeamMedal };
