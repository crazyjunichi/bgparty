import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/games/ui/game-screen.tsx
var n = /* @__PURE__ */ e(t(), 1);
function r({ banner: e, actions: t, actionsHeight: r, overlay: i, scroll: a = !0, adaptive: o = !1, className: s, children: c }) {
	let l = /* @__PURE__ */ (0, n.jsxs)("div", {
		className: `flex h-full min-h-0 flex-col gap-2${o ? " game-screen-layout" : ""}${!o && s ? ` ${s}` : ""}`,
		children: [
			e && /* @__PURE__ */ (0, n.jsx)("div", {
				className: "flex-none",
				children: e
			}),
			/* @__PURE__ */ (0, n.jsxs)("div", {
				className: "relative min-h-0 flex-1",
				children: [/* @__PURE__ */ (0, n.jsx)("div", {
					className: `h-full min-h-0 ${a ? "overflow-y-auto" : "overflow-hidden"}`,
					children: c
				}), i && /* @__PURE__ */ (0, n.jsx)("div", {
					className: "pointer-events-none absolute inset-x-0 bottom-0 z-10",
					children: i
				})]
			}),
			r && /* @__PURE__ */ (0, n.jsx)("div", {
				className: `flex-none overflow-hidden ${r}`,
				children: t
			})
		]
	});
	return o ? /* @__PURE__ */ (0, n.jsx)("div", {
		className: `game-screen-adaptive${s ? ` ${s}` : ""}`,
		children: l
	}) : l;
}
//#endregion
export { r as GameScreen };
