import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
var n = (/* @__PURE__ */ e(t())).default, r = n.Fragment, i = n.jsx, a = n.jsxs;
//#endregion
export { r as Fragment, n as default, i as jsx, a as jsxs };
