import { r as e, t } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
//#region node_modules/react/cjs/react-jsx-dev-runtime.production.js
var n = /* @__PURE__ */ t(((e) => {
	e.Fragment = Symbol.for("react.fragment"), e.jsxDEV = void 0;
})), r = (/* @__PURE__ */ e((/* @__PURE__ */ t(((e, t) => {
	t.exports = n();
})))())).default, i = r.Fragment, a = r.jsxDEV;
//#endregion
export { i as Fragment, r as default, a as jsxDEV };
