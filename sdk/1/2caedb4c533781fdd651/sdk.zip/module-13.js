import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { AVATARS as t } from "@bgparty/sdk/_/module-1.js";
import { t as n } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as r } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { D6_SLOT as i, DiceCube as a, diceFaceContent as o } from "@bgparty/sdk/_/module-12.js";
import { PLAYER_COLORS as s } from "@bgparty/sdk/_/module-22.js";
import { DICE_ROLL_MS as c } from "@bgparty/sdk/_/module-14.js";
import { FlySprite as l } from "@bgparty/sdk/_/module-15.js";
//#region src/shared/fx/dice-roll.tsx
var u = /* @__PURE__ */ e(n(), 1), d = /* @__PURE__ */ e(r(), 1), f = (e) => typeof e == "number" ? { value: e } : null;
function p(e) {
	return e <= 3 ? 64 : e <= 5 ? 52 : e <= 7 ? 44 : 36;
}
var m = 6;
function h(e, t, n) {
	let r = e.map((e) => t * (e.scale ?? 1)), i = (r.reduce((e, t) => e + t, 0) + m * (e.length - 1)) / n, a = i > 1 ? 1 / i : 1;
	return r.map((e) => Math.max(16, e * a));
}
function g(e, t) {
	let n = h(t, Math.min(e.h, 48), e.w), r = n.reduce((e, t) => e + t, 0) + m * (t.length - 1), i = e.x + (e.w - r) / 2;
	return n.map((t) => {
		let n = {
			x: i,
			y: e.y + (e.h - t) / 2,
			w: t,
			h: t
		};
		return i += t + m, n;
	});
}
function _({ dice: e, faces: t, slotOf: n, tint: r, target: i, fast: o }) {
	let s = o ? 350 : c.tumble, l = h(e, Math.min(i.h, 44), i.w);
	return /* @__PURE__ */ (0, d.jsx)("div", {
		className: "absolute flex items-center justify-center gap-1.5",
		style: {
			left: i.x,
			top: i.y,
			width: i.w,
			height: i.h
		},
		children: e.map((e, i) => /* @__PURE__ */ (0, d.jsx)(a, {
			face: n(e.value),
			faces: t,
			faceBg: r,
			size: l[i] ?? 24,
			ms: s,
			delay: i * (o ? 40 : c.stagger)
		}, i))
	});
}
function v({ dice: e, faces: n, slotOf: r, tint: i, member: f, target: m }) {
	let h = (0, u.useRef)(null), _ = (0, u.useRef)([]), v = (e.length - 1) * c.stagger + c.tumble + c.hold, [y, b] = (0, u.useState)(null), x = y !== null;
	(0, u.useEffect)(() => {
		let t = window.setTimeout(() => {
			let t = h.current;
			if (!t) {
				b(e.map(() => null));
				return;
			}
			let n = t.getBoundingClientRect();
			b(e.map((e, t) => {
				let r = _.current[t];
				if (!r) return null;
				let i = r.getBoundingClientRect();
				return {
					x: i.left - n.left,
					y: i.top - n.top,
					w: i.width,
					h: i.height
				};
			}));
		}, v);
		return () => window.clearTimeout(t);
	}, [v, e]);
	let S = p(e.length), C = e.length > 5 ? 8 : 12, w = f ? s[f.colorIndex % s.length].hex : void 0;
	return /* @__PURE__ */ (0, d.jsxs)("div", {
		ref: h,
		className: "absolute inset-0",
		children: [
			/* @__PURE__ */ (0, d.jsx)("div", { className: `absolute inset-0 bg-ink/25 transition-opacity duration-300 ${x ? "opacity-0" : "opacity-100"}` }),
			/* @__PURE__ */ (0, d.jsx)("div", {
				className: "absolute inset-0 grid place-items-center",
				children: /* @__PURE__ */ (0, d.jsxs)("div", {
					className: `card flex max-w-[94vw] items-center gap-4 px-5 py-4 transition-opacity duration-300 ${x ? "opacity-0" : "opacity-100"}`,
					children: [f && /* @__PURE__ */ (0, d.jsxs)("span", {
						className: "flex flex-none flex-col items-center gap-1",
						children: [/* @__PURE__ */ (0, d.jsx)("span", {
							className: "grid size-14 place-items-center rounded-full border-2 border-ink",
							style: { backgroundColor: w },
							children: /* @__PURE__ */ (0, d.jsx)("img", {
								src: t[f.avatar % t.length],
								alt: "",
								draggable: !1,
								className: "size-12 object-contain"
							})
						}), /* @__PURE__ */ (0, d.jsx)("span", {
							className: "max-w-24 truncate text-sm font-extrabold",
							children: f.name
						})]
					}), /* @__PURE__ */ (0, d.jsx)("span", {
						className: "flex flex-wrap items-center justify-center",
						style: { gap: C },
						children: e.map((e, t) => {
							let o = Math.round(S * (e.scale ?? 1));
							return /* @__PURE__ */ (0, d.jsx)("span", {
								ref: (e) => {
									_.current[t] = e;
								},
								className: "block flex-none",
								style: { visibility: x ? "hidden" : void 0 },
								children: /* @__PURE__ */ (0, d.jsx)(a, {
									face: r(e.value),
									faces: n,
									faceBg: i,
									size: o,
									ms: c.tumble,
									delay: t * c.stagger
								})
							}, t);
						})
					})]
				})
			}),
			x && m && e.map((t, a) => {
				let s = y[a];
				return s ? /* @__PURE__ */ (0, d.jsx)(l, {
					from: s,
					to: g(m, e)[a] ?? s,
					ms: c.fly,
					children: /* @__PURE__ */ (0, d.jsx)("span", {
						className: "block overflow-hidden rounded-[16%] border-3 border-ink bg-surface",
						style: {
							width: s.w,
							height: s.h,
							background: i
						},
						children: o(r(t.value), n, i !== void 0)
					})
				}, a) : null;
			})
		]
	});
}
function y(e) {
	let t = e?.slotOf ?? ((e) => i[e] ?? 0), n = e?.parse ?? f;
	return (r, i) => {
		let a = r.data;
		if (!Array.isArray(a?.dice)) return null;
		let o = a.dice;
		if (!o.length) return null;
		let l = o.map(n);
		if (l.some((e) => e === null)) return null;
		let u = l, f = typeof a?.target == "string" ? a.target : "dice", p = i.anchor(f), m = i.queued > 0, h = r.rid ? i.member(r.rid) : void 0, g = e?.tintByPlayer && h ? s[h.colorIndex % s.length].hex : void 0;
		return a?.banner === !0 && !m ? {
			ms: c.banner(u.length),
			hide: p ? [f] : void 0,
			node: /* @__PURE__ */ (0, d.jsx)(v, {
				dice: u,
				faces: e?.faces,
				slotOf: t,
				tint: g,
				member: h,
				target: p
			})
		} : p ? {
			ms: m ? 500 : c.inplace(u.length),
			hide: m ? void 0 : [f],
			node: /* @__PURE__ */ (0, d.jsx)(_, {
				dice: u,
				faces: e?.faces,
				slotOf: t,
				tint: g,
				target: p,
				fast: m
			})
		} : null;
	};
}
//#endregion
export { c as DICE_ROLL_MS, y as createDiceRollRenderer };
