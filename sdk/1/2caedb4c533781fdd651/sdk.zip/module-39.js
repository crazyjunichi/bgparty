import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { o as n } from "@bgparty/sdk/_/chunks/i18n-BrDyMwni.js";
import { D as r, o as i } from "@bgparty/sdk/_/chunks/icons-DzpZGOit.js";
import { t as a } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/games/ui/log-sheet.tsx
var o = /* @__PURE__ */ e(t(), 1), s = /* @__PURE__ */ e(a(), 1), c = "", l = "";
function u(e, t, n) {
	let r = {};
	n.forEach(([e], t) => {
		r[e] = `${c}${t}${l}`;
	});
	let i = e(t, r), a = RegExp(`${c}(\\d+)${l}`, "g"), o = [], u = 0;
	for (let e of i.matchAll(a)) e.index > u && o.push(i.slice(u, e.index)), o.push(n[Number(e[1])][1]), u = e.index + e[0].length;
	return u < i.length && o.push(i.slice(u)), o.map((e, t) => /* @__PURE__ */ (0, s.jsx)("span", { children: e }, t));
}
function d({ log: e, line: t }) {
	let i = n(), [a, c] = (0, o.useState)(!1), l = e[e.length - 1];
	return /* @__PURE__ */ (0, s.jsxs)(s.Fragment, { children: [/* @__PURE__ */ (0, s.jsxs)("button", {
		type: "button",
		"aria-label": i("common.log.title"),
		onClick: () => c(!0),
		className: "frame flex min-h-8 w-full cursor-pointer items-center gap-1.5 px-2 py-1 text-left",
		children: [/* @__PURE__ */ (0, s.jsx)(r, {
			size: 14,
			className: "flex-none opacity-60"
		}), /* @__PURE__ */ (0, s.jsx)("span", {
			className: `min-w-0 flex-1 truncate text-xs ${l ? "" : "opacity-50"}`,
			children: l ? t(l, e.length - 1) : i("common.log.empty")
		})]
	}), a && /* @__PURE__ */ (0, s.jsx)(f, {
		log: e,
		line: t,
		onClose: () => c(!1)
	})] });
}
function f({ log: e, line: t, onClose: a, rowClassName: c }) {
	let l = n(), u = (0, o.useRef)(null);
	return (0, o.useEffect)(() => {
		let e = u.current;
		e && (e.scrollTop = e.scrollHeight);
	}, [e.length]), /* @__PURE__ */ (0, s.jsx)("div", {
		className: "absolute inset-0 z-20 flex items-end justify-center bg-ink/40 p-3",
		onClick: a,
		children: /* @__PURE__ */ (0, s.jsxs)("div", {
			className: "card flex max-h-[70%] w-full max-w-sm flex-col p-3",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, s.jsxs)("div", {
				className: "flex flex-none items-center gap-2",
				children: [
					/* @__PURE__ */ (0, s.jsx)(r, { size: 16 }),
					/* @__PURE__ */ (0, s.jsx)("p", {
						className: "flex-1 text-sm font-extrabold",
						children: l("common.log.title")
					}),
					/* @__PURE__ */ (0, s.jsx)("button", {
						type: "button",
						"aria-label": l("common.qr.close"),
						onClick: a,
						className: "grid size-11 cursor-pointer place-items-center",
						children: /* @__PURE__ */ (0, s.jsx)(i, { size: 18 })
					})
				]
			}), e.length === 0 ? /* @__PURE__ */ (0, s.jsx)("p", {
				className: "py-4 text-center text-xs opacity-70",
				children: l("common.log.empty")
			}) : /* @__PURE__ */ (0, s.jsx)("ul", {
				ref: u,
				className: "mt-1 min-h-0 flex-1 overflow-y-auto text-xs leading-5",
				children: e.map((e, n) => /* @__PURE__ */ (0, s.jsx)("li", {
					className: c ?? "border-b border-ink/5 py-0.5 last:border-0",
					children: t(e, n)
				}, n))
			})]
		})
	});
}
//#endregion
export { f as LogSheet, d as LogTicker, u as rich };
