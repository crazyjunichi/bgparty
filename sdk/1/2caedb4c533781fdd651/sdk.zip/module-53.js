import { n as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { $ as t, $a as n, $c as r, $i as i, $n as a, $o as o, $r as s, $s as c, $t as l, A as u, Aa as d, Ac as f, Ai as p, An as m, Ao as ee, Ar as h, As as te, At as ne, B as re, Ba as ie, Bc as ae, Bi as oe, Bn as se, Bo as ce, Br as le, Bs as ue, Bt as de, C as fe, Ca as pe, Cc as me, Ci as he, Cn as ge, Co as _e, Cr as ve, Cs as ye, Ct as be, D as xe, Da as Se, Dc as Ce, Di as we, Dn as Te, Do as Ee, Dr as De, Ds as Oe, Dt as ke, E as Ae, Ea as je, Ec as Me, Ei as Ne, En as Pe, Eo as Fe, Er as Ie, Es as Le, Et as Re, F as ze, Fa as Be, Fc as Ve, Fi as He, Fn as Ue, Fo as We, Fr as Ge, Fs as Ke, Ft as qe, G as Je, Ga as Ye, Gi as Xe, Gn as Ze, Go as Qe, Gr as $e, Gs as et, Gt as tt, H as nt, Ha as rt, Hc as it, Hi as at, Hn as ot, Ho as st, Hr as ct, Hs as lt, Ht as ut, I as dt, Ia as ft, Ic as pt, Ii as mt, In as ht, Io as gt, Ir as _t, Is as vt, It as yt, J as bt, Ja as xt, Jc as St, Ji as Ct, Jn as wt, Jo as Tt, Jr as Et, Js as Dt, Jt as Ot, K as kt, Ka as At, Kc as jt, Ki as Mt, Kn as Nt, Ko as Pt, Kr as Ft, Ks as It, Kt as Lt, L as Rt, La as zt, Lc as Bt, Li as Vt, Ln as Ht, Lo as Ut, Lr as Wt, Ls as Gt, Lt as Kt, M as g, Ma as _, Mc as qt, Mi as v, Mn as Jt, Mo as Yt, Mr as Xt, Ms as Zt, Mt as Qt, N as y, Na as $t, Nc as en, Ni as tn, Nn as nn, No as rn, Nr as an, Ns as on, Nt as sn, O as cn, Oa as ln, Oc as un, Oi as b, On as dn, Oo as fn, Or as pn, Os as mn, Ot as hn, P as gn, Pa as _n, Pc as vn, Pi as yn, Pn as bn, Po as xn, Pr as Sn, Ps as Cn, Pt as wn, Q as Tn, Qa as En, Qc as x, Qi as Dn, Qn as On, Qo as kn, Qr as An, Qs as jn, Qt as Mn, R as Nn, Ra as Pn, Rc as Fn, Ri as In, Rn as Ln, Ro as Rn, Rr as zn, Rs as Bn, Rt as Vn, S as Hn, Sa as Un, Sc as Wn, Si as Gn, Sn as Kn, So as qn, Sr as Jn, Ss as Yn, St as Xn, T as Zn, Ta as Qn, Tc as $n, Ti as er, Tn as tr, To as nr, Tr as rr, Ts as ir, Tt as S, U as ar, Ua as or, Uc as C, Ui as sr, Un as cr, Uo as lr, Ur as ur, Us as dr, Ut as fr, V as pr, Va as mr, Vc as hr, Vi as gr, Vn as _r, Vo as vr, Vr as yr, Vs as br, Vt as xr, W as Sr, Wa as Cr, Wc as wr, Wi as w, Wn as Tr, Wo as Er, Wr as Dr, Ws as Or, Wt as kr, X as Ar, Xa as jr, Xc as Mr, Xi as Nr, Xn as Pr, Xo as Fr, Xr as Ir, Xs as Lr, Xt as Rr, Y as zr, Ya as Br, Yc as T, Yi as Vr, Yn as Hr, Yo as Ur, Yr as Wr, Ys as Gr, Yt as Kr, Z as qr, Za as Jr, Zc as Yr, Zi as Xr, Zn as Zr, Zo as Qr, Zr as $r, Zs as ei, Zt as ti, _ as ni, _a as ri, _c as ii, _i as ai, _n as oi, _o as si, _r as ci, _s as li, _t as ui, a as di, aa as fi, ac as pi, ai as mi, an as hi, ao as gi, ar as _i, as as vi, at as yi, b as bi, ba as xi, bc as Si, bi as Ci, bn as wi, bo as Ti, br as Ei, bs as Di, bt as Oi, c as ki, ca as Ai, cc as ji, ci as Mi, cn as Ni, co as Pi, cr as Fi, cs as Ii, ct as Li, d as Ri, da as zi, dc as Bi, di as Vi, dn as Hi, do as Ui, dr as Wi, ds as Gi, dt as Ki, ea as qi, ec as Ji, ei as Yi, el as E, en as Xi, eo as Zi, er as Qi, es as $i, et as ea, f as ta, fa as na, fc as ra, fi as D, fn as ia, fo as aa, fr as oa, fs as sa, ft as ca, g as la, ga as ua, gc as da, gi as fa, gn as pa, go as ma, gr as ha, gs as ga, gt as _a, h as va, ha as ya, hc as ba, hi as xa, hn as Sa, ho as Ca, hr as wa, hs as Ta, ht as Ea, i as Da, ia as O, ic as Oa, ii as ka, il as Aa, in as ja, io as Ma, ir as Na, is as Pa, it as Fa, j as k, ja as Ia, jc as La, ji as A, jn as Ra, jo as za, jr as Ba, js as Va, jt as Ha, k as Ua, ka as Wa, kc as Ga, ki as Ka, kn as qa, ko as Ja, kr as Ya, ks as Xa, kt as Za, l as Qa, la as j, lc as $a, li as eo, ln as to, lo as no, lr as ro, ls as io, lt as ao, m as oo, ma as so, mc as co, mi as M, mn as lo, mo as uo, mr as fo, ms as po, mt as mo, n as ho, na as N, nc as go, ni as _o, nl as P, nn as vo, no as yo, nr as bo, ns as xo, nt as So, o as Co, oa as wo, oc as To, oi as F, on as Eo, oo as Do, or as Oo, os as ko, ot as Ao, p as jo, pa as I, pc as Mo, pi as No, pn as Po, po as Fo, pr as Io, ps as Lo, pt as Ro, q as zo, qa as Bo, qc as L, qi as Vo, qn as Ho, qo as Uo, qr as Wo, qs as Go, qt as Ko, r as qo, ra as Jo, rc as Yo, ri as Xo, rl as Zo, rn as Qo, ro as $o, rr as es, rs as ts, rt as ns, s as rs, sa as is, sc as as, si as os, sn as ss, so as cs, sr as ls, ss as us, st as ds, t as fs, ta as ps, tc as ms, ti as hs, tl as gs, tn as _s, to as vs, tr as ys, ts as bs, tt as xs, u as Ss, ua as Cs, uc as ws, ui as Ts, un as Es, uo as Ds, ur as Os, us as ks, ut as As, v as js, va as Ms, vc as Ns, vi as Ps, vn as Fs, vo as Is, vr as Ls, vs as Rs, vt as zs, w as Bs, wa as R, wc as Vs, wi as Hs, wn as Us, wo as Ws, wr as Gs, ws as Ks, wt as qs, x as Js, xa as z, xc as Ys, xi as Xs, xn as Zs, xo as Qs, xr as $s, xs as ec, xt as tc, y as nc, ya as rc, yc as ic, yi as ac, yn as oc, yo as sc, yr as cc, ys as lc, yt as uc, z as dc, za as fc, zc as pc, zi as mc, zn as hc, zo as gc, zr as _c, zs as vc, zt as yc } from "@bgparty/sdk/_/chunks/schemas-BpsPIIob.js";
//#region node_modules/zod/v4/locales/ar.js
var bc = () => {
	let e = {
		string: {
			unit: "حرف",
			verb: "أن يحوي"
		},
		file: {
			unit: "بايت",
			verb: "أن يحوي"
		},
		array: {
			unit: "عنصر",
			verb: "أن يحوي"
		},
		set: {
			unit: "عنصر",
			verb: "أن يحوي"
		},
		map: {
			unit: "عنصر",
			verb: "أن يحوي"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "مدخل",
		email: "بريد إلكتروني",
		url: "رابط",
		emoji: "إيموجي",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "تاريخ ووقت بمعيار ISO",
		date: "تاريخ بمعيار ISO",
		time: "وقت بمعيار ISO",
		duration: "مدة بمعيار ISO",
		ipv4: "عنوان IPv4",
		ipv6: "عنوان IPv6",
		mac: "عنوان MAC",
		cidrv4: "مدى عناوين بصيغة IPv4",
		cidrv6: "مدى عناوين بصيغة IPv6",
		base64: "نَص بترميز base64-encoded",
		base64url: "نَص بترميز base64url-encoded",
		json_string: "نَص على هيئة JSON",
		e164: "رقم هاتف بمعيار E.164",
		credit_card: "رقم بطاقة الائتمان",
		jwt: "JWT",
		template_literal: "مدخل"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `مدخلات غير مقبولة: يفترض إدخال instanceof ${e.expected}، ولكن تم إدخال ${i}` : `مدخلات غير مقبولة: يفترض إدخال ${t}، ولكن تم إدخال ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `مدخلات غير مقبولة: يفترض إدخال ${P(e.values[0])}` : `اختيار غير مقبول: يتوقع انتقاء أحد هذه الخيارات: ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? ` أكبر من اللازم: يفترض أن تكون ${e.origin ?? "القيمة"} ${n} ${e.maximum.toString()} ${r.unit ?? "عنصر"}` : `أكبر من اللازم: يفترض أن تكون ${e.origin ?? "القيمة"} ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `أصغر من اللازم: يفترض لـ ${e.origin} أن يكون ${n} ${e.minimum.toString()} ${r.unit}` : `أصغر من اللازم: يفترض لـ ${e.origin} أن يكون ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `نَص غير مقبول: يجب أن يبدأ بـ "${e.prefix}"` : t.format === "ends_with" ? `نَص غير مقبول: يجب أن ينتهي بـ "${t.suffix}"` : t.format === "includes" ? `نَص غير مقبول: يجب أن يتضمَّن "${t.includes}"` : t.format === "regex" ? `نَص غير مقبول: يجب أن يطابق النمط ${t.pattern}` : `${n[t.format] ?? e.format} غير مقبول`;
			}
			case "not_multiple_of": return `رقم غير مقبول: يجب أن يكون من مضاعفات ${e.divisor}`;
			case "unrecognized_keys": return `معرف${e.keys.length > 1 ? "ات" : ""} غريب${e.keys.length > 1 ? "ة" : ""}: ${x(e.keys, "، ")}`;
			case "invalid_key": return `معرف غير مقبول في ${e.origin}`;
			case "invalid_union": return "مدخل غير مقبول";
			case "invalid_element": return `مدخل غير مقبول في ${e.origin}`;
			default: return "مدخل غير مقبول";
		}
	};
};
function xc() {
	return { localeError: bc() };
}
//#endregion
//#region node_modules/zod/v4/locales/az.js
var Sc = () => {
	let e = {
		string: {
			unit: "simvol",
			verb: "olmalıdır"
		},
		file: {
			unit: "bayt",
			verb: "olmalıdır"
		},
		array: {
			unit: "element",
			verb: "olmalıdır"
		},
		set: {
			unit: "element",
			verb: "olmalıdır"
		},
		map: {
			unit: "element",
			verb: "olmalıdır"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		credit_card: "kredit kartı nömrəsi",
		jwt: "JWT",
		template_literal: "input"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Yanlış dəyər: gözlənilən instanceof ${e.expected}, daxil olan ${i}` : `Yanlış dəyər: gözlənilən ${t}, daxil olan ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Yanlış dəyər: gözlənilən ${P(e.values[0])}` : `Yanlış seçim: aşağıdakılardan biri olmalıdır: ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Çox böyük: gözlənilən ${e.origin ?? "dəyər"} ${n}${e.maximum.toString()} ${r.unit ?? "element"}` : `Çox böyük: gözlənilən ${e.origin ?? "dəyər"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Çox kiçik: gözlənilən ${e.origin} ${n}${e.minimum.toString()} ${r.unit}` : `Çox kiçik: gözlənilən ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Yanlış mətn: "${t.prefix}" ilə başlamalıdır` : t.format === "ends_with" ? `Yanlış mətn: "${t.suffix}" ilə bitməlidir` : t.format === "includes" ? `Yanlış mətn: "${t.includes}" daxil olmalıdır` : t.format === "regex" ? `Yanlış mətn: ${t.pattern} şablonuna uyğun olmalıdır` : `Yanlış ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Yanlış ədəd: ${e.divisor} ilə bölünə bilən olmalıdır`;
			case "unrecognized_keys": return `Tanınmayan açar${e.keys.length > 1 ? "lar" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} daxilində yanlış açar`;
			case "invalid_union": return "Yanlış dəyər";
			case "invalid_element": return `${e.origin} daxilində yanlış dəyər`;
			default: return "Yanlış dəyər";
		}
	};
};
function Cc() {
	return { localeError: Sc() };
}
//#endregion
//#region node_modules/zod/v4/locales/be.js
function wc(e, t, n, r) {
	let i = Math.abs(e), a = i % 10, o = i % 100;
	return o >= 11 && o <= 19 ? r : a === 1 ? t : a >= 2 && a <= 4 ? n : r;
}
var Tc = () => {
	let e = {
		string: {
			unit: {
				one: "сімвал",
				few: "сімвалы",
				many: "сімвалаў"
			},
			verb: "мець"
		},
		array: {
			unit: {
				one: "элемент",
				few: "элементы",
				many: "элементаў"
			},
			verb: "мець"
		},
		set: {
			unit: {
				one: "элемент",
				few: "элементы",
				many: "элементаў"
			},
			verb: "мець"
		},
		map: {
			unit: {
				one: "элемент",
				few: "элементы",
				many: "элементаў"
			},
			verb: "мець"
		},
		file: {
			unit: {
				one: "байт",
				few: "байты",
				many: "байтаў"
			},
			verb: "мець"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "увод",
		email: "email адрас",
		url: "URL",
		emoji: "эмодзі",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO дата і час",
		date: "ISO дата",
		time: "ISO час",
		duration: "ISO працягласць",
		ipv4: "IPv4 адрас",
		ipv6: "IPv6 адрас",
		mac: "MAC адрас",
		cidrv4: "IPv4 дыяпазон",
		cidrv6: "IPv6 дыяпазон",
		base64: "радок у фармаце base64",
		base64url: "радок у фармаце base64url",
		json_string: "JSON радок",
		e164: "нумар E.164",
		credit_card: "нумар крэдытнай карты",
		jwt: "JWT",
		template_literal: "увод"
	}, r = {
		nan: "NaN",
		number: "лік",
		array: "масіў"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Няправільны ўвод: чакаўся instanceof ${e.expected}, атрымана ${i}` : `Няправільны ўвод: чакаўся ${t}, атрымана ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Няправільны ўвод: чакалася ${P(e.values[0])}` : `Няправільны варыянт: чакаўся адзін з ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				if (r) {
					let t = wc(Number(e.maximum), r.unit.one, r.unit.few, r.unit.many);
					return `Занадта вялікі: чакалася, што ${e.origin ?? "значэнне"} павінна ${r.verb} ${n}${e.maximum.toString()} ${t}`;
				}
				return `Занадта вялікі: чакалася, што ${e.origin ?? "значэнне"} павінна быць ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				if (r) {
					let t = wc(Number(e.minimum), r.unit.one, r.unit.few, r.unit.many);
					return `Занадта малы: чакалася, што ${e.origin} павінна ${r.verb} ${n}${e.minimum.toString()} ${t}`;
				}
				return `Занадта малы: чакалася, што ${e.origin} павінна быць ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Няправільны радок: павінен пачынацца з "${t.prefix}"` : t.format === "ends_with" ? `Няправільны радок: павінен заканчвацца на "${t.suffix}"` : t.format === "includes" ? `Няправільны радок: павінен змяшчаць "${t.includes}"` : t.format === "regex" ? `Няправільны радок: павінен адпавядаць шаблону ${t.pattern}` : `Няправільны ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Няправільны лік: павінен быць кратным ${e.divisor}`;
			case "unrecognized_keys": return `Нераспазнаны ${e.keys.length > 1 ? "ключы" : "ключ"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Няправільны ключ у ${e.origin}`;
			case "invalid_union": return "Няправільны ўвод";
			case "invalid_element": return `Няправільнае значэнне ў ${e.origin}`;
			default: return "Няправільны ўвод";
		}
	};
};
function Ec() {
	return { localeError: Tc() };
}
//#endregion
//#region node_modules/zod/v4/locales/bg.js
var Dc = () => {
	let e = {
		string: {
			unit: "символа",
			verb: "да съдържа"
		},
		file: {
			unit: "байта",
			verb: "да съдържа"
		},
		array: {
			unit: "елемента",
			verb: "да съдържа"
		},
		set: {
			unit: "елемента",
			verb: "да съдържа"
		},
		map: {
			unit: "елемента",
			verb: "да съдържа"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "вход",
		email: "имейл адрес",
		url: "URL",
		emoji: "емоджи",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO време",
		date: "ISO дата",
		time: "ISO време",
		duration: "ISO продължителност",
		ipv4: "IPv4 адрес",
		ipv6: "IPv6 адрес",
		mac: "MAC адрес",
		cidrv4: "IPv4 диапазон",
		cidrv6: "IPv6 диапазон",
		base64: "base64-кодиран низ",
		base64url: "base64url-кодиран низ",
		json_string: "JSON низ",
		e164: "E.164 номер",
		credit_card: "номер на кредитна карта",
		jwt: "JWT",
		template_literal: "вход"
	}, r = {
		nan: "NaN",
		number: "число",
		array: "масив"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Невалиден вход: очакван instanceof ${e.expected}, получен ${i}` : `Невалиден вход: очакван ${t}, получен ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Невалиден вход: очакван ${P(e.values[0])}` : `Невалидна опция: очаквано едно от ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Твърде голямо: очаква се ${e.origin ?? "стойност"} да съдържа ${n}${e.maximum.toString()} ${r.unit ?? "елемента"}` : `Твърде голямо: очаква се ${e.origin ?? "стойност"} да бъде ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Твърде малко: очаква се ${e.origin} да съдържа ${n}${e.minimum.toString()} ${r.unit}` : `Твърде малко: очаква се ${e.origin} да бъде ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				if (t.format === "starts_with") return `Невалиден низ: трябва да започва с "${t.prefix}"`;
				if (t.format === "ends_with") return `Невалиден низ: трябва да завършва с "${t.suffix}"`;
				if (t.format === "includes") return `Невалиден низ: трябва да включва "${t.includes}"`;
				if (t.format === "regex") return `Невалиден низ: трябва да съвпада с ${t.pattern}`;
				let r = "Невалиден";
				return t.format === "emoji" && (r = "Невалидно"), t.format === "datetime" && (r = "Невалидно"), t.format === "date" && (r = "Невалидна"), t.format === "time" && (r = "Невалидно"), t.format === "duration" && (r = "Невалидна"), `${r} ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Невалидно число: трябва да бъде кратно на ${e.divisor}`;
			case "unrecognized_keys": return `Неразпознат${e.keys.length > 1 ? "и" : ""} ключ${e.keys.length > 1 ? "ове" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Невалиден ключ в ${e.origin}`;
			case "invalid_union": return "Невалиден вход";
			case "invalid_element": return `Невалидна стойност в ${e.origin}`;
			default: return "Невалиден вход";
		}
	};
};
function Oc() {
	return { localeError: Dc() };
}
//#endregion
//#region node_modules/zod/v4/locales/bn.js
var kc = () => {
	let e = {
		string: {
			unit: "অক্ষর",
			verb: "থাকতে হবে"
		},
		file: {
			unit: "বাইট",
			verb: "থাকতে হবে"
		},
		array: {
			unit: "আইটেম",
			verb: "থাকতে হবে"
		},
		set: {
			unit: "আইটেম",
			verb: "থাকতে হবে"
		},
		map: {
			unit: "এন্ট্রি",
			verb: "থাকতে হবে"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ইনপুট",
		email: "ইমেইল ঠিকানা",
		url: "URL",
		emoji: "ইমোজি",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO তারিখ ও সময়",
		date: "ISO তারিখ",
		time: "ISO সময়",
		duration: "ISO সময়কাল",
		ipv4: "IPv4 ঠিকানা",
		ipv6: "IPv6 ঠিকানা",
		mac: "MAC ঠিকানা",
		cidrv4: "IPv4 রেঞ্জ",
		cidrv6: "IPv6 রেঞ্জ",
		base64: "base64-এনকোডেড স্ট্রিং",
		base64url: "base64url-এনকোডেড স্ট্রিং",
		json_string: "JSON স্ট্রিং",
		e164: "E.164 নম্বর",
		credit_card: "ক্রেডিট কার্ড নম্বর",
		jwt: "JWT",
		template_literal: "ইনপুট"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input);
				return `অবৈধ ইনপুট: প্রত্যাশিত ${t}, প্রাপ্ত ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `অবৈধ ইনপুট: প্রত্যাশিত ${P(e.values[0])}` : `অবৈধ অপশন: ${x(e.values, " | ")} এর মধ্যে একটি প্রত্যাশিত`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `অনেক বড়: ${e.origin ?? "মান"} ${n}${e.maximum.toString()} ${r.unit ?? "এলিমেন্ট"} হতে হবে` : `অনেক বড়: ${e.origin ?? "মান"} ${n}${e.maximum.toString()} হতে হবে`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `অনেক ছোট: ${e.origin} ${n}${e.minimum.toString()} ${r.unit} হতে হবে` : `অনেক ছোট: ${e.origin} ${n}${e.minimum.toString()} হতে হবে`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `অবৈধ স্ট্রিং: "${t.prefix}" দিয়ে শুরু হতে হবে` : t.format === "ends_with" ? `অবৈধ স্ট্রিং: "${t.suffix}" দিয়ে শেষ হতে হবে` : t.format === "includes" ? `অবৈধ স্ট্রিং: "${t.includes}" অন্তর্ভুক্ত থাকতে হবে` : t.format === "regex" ? `অবৈধ স্ট্রিং: ${t.pattern} প্যাটার্ন মিলতে হবে` : `অবৈধ ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `অবৈধ নম্বর: ${e.divisor} এর গুণিতক হতে হবে`;
			case "unrecognized_keys": return `অচেনা কী${e.keys.length > 1 ? "গুলো" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} এ অবৈধ কী`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `অবৈধ ডিসক্রিমিনেটর মান। প্রত্যাশিত ${e.options.map((e) => `'${e}'`).join(" | ")}` : "অবৈধ ইনপুট";
			case "invalid_element": return `${e.origin} এ অবৈধ মান`;
			default: return "অবৈধ ইনপুট";
		}
	};
};
function Ac() {
	return { localeError: kc() };
}
//#endregion
//#region node_modules/zod/v4/locales/ca.js
var jc = () => {
	let e = {
		string: {
			unit: "caràcters",
			verb: "contenir"
		},
		file: {
			unit: "bytes",
			verb: "contenir"
		},
		array: {
			unit: "elements",
			verb: "contenir"
		},
		set: {
			unit: "elements",
			verb: "contenir"
		},
		map: {
			unit: "elements",
			verb: "contenir"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "entrada",
		email: "adreça electrònica",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "data i hora ISO",
		date: "data ISO",
		time: "hora ISO",
		duration: "durada ISO",
		ipv4: "adreça IPv4",
		ipv6: "adreça IPv6",
		mac: "adreça MAC",
		cidrv4: "rang IPv4",
		cidrv6: "rang IPv6",
		base64: "cadena codificada en base64",
		base64url: "cadena codificada en base64url",
		json_string: "cadena JSON",
		e164: "número E.164",
		credit_card: "número de targeta de crèdit",
		jwt: "JWT",
		template_literal: "entrada"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Tipus invàlid: s'esperava instanceof ${e.expected}, s'ha rebut ${i}` : `Tipus invàlid: s'esperava ${t}, s'ha rebut ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Valor invàlid: s'esperava ${P(e.values[0])}` : `Opció invàlida: s'esperava una de ${x(e.values, " o ")}`;
			case "too_big": {
				let n = e.inclusive ? "com a màxim" : "menys de", r = t(e.origin);
				return r ? `Massa gran: s'esperava que ${e.origin ?? "el valor"} contingués ${n} ${e.maximum.toString()} ${r.unit ?? "elements"}` : `Massa gran: s'esperava que ${e.origin ?? "el valor"} fos ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? "com a mínim" : "més de", r = t(e.origin);
				return r ? `Massa petit: s'esperava que ${e.origin} contingués ${n} ${e.minimum.toString()} ${r.unit}` : `Massa petit: s'esperava que ${e.origin} fos ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Format invàlid: ha de començar amb "${t.prefix}"` : t.format === "ends_with" ? `Format invàlid: ha d'acabar amb "${t.suffix}"` : t.format === "includes" ? `Format invàlid: ha d'incloure "${t.includes}"` : t.format === "regex" ? `Format invàlid: ha de coincidir amb el patró ${t.pattern}` : `Format invàlid per a ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Número invàlid: ha de ser múltiple de ${e.divisor}`;
			case "unrecognized_keys": return `Clau${e.keys.length > 1 ? "s" : ""} no reconeguda${e.keys.length > 1 ? "s" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Clau invàlida a ${e.origin}`;
			case "invalid_union": return "Entrada invàlida";
			case "invalid_element": return `Element invàlid a ${e.origin}`;
			default: return "Entrada invàlida";
		}
	};
};
function Mc() {
	return { localeError: jc() };
}
//#endregion
//#region node_modules/zod/v4/locales/ckb.js
var Nc = () => {
	let e = {
		string: {
			unit: "پیت",
			verb: "بێت"
		},
		file: {
			unit: "بایت",
			verb: "بێت"
		},
		array: {
			unit: "دانە",
			verb: "بێت"
		},
		set: {
			unit: "دانە",
			verb: "بێت"
		},
		map: {
			unit: "دانە",
			verb: "بێت"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "regex",
		email: "ئیمەیڵ",
		url: "بەستەر (URL)",
		emoji: "ئیمۆجی",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ڕێکەوت و کات",
		date: "ڕێکەوت",
		time: "کات",
		duration: "ماوە",
		ipv4: "ناونیشانی IPv4",
		ipv6: "ناونیشانی IPv6",
		mac: "ناونیشانی MAC",
		cidrv4: "مەودای IPv4",
		cidrv6: "مەودای IPv6",
		base64: "دەقی base64",
		base64url: "دەقی base64url",
		json_string: "دەقی JSON",
		e164: "ژمارەی E.164",
		credit_card: "ژمارەی کارتی کرێدیت",
		jwt: "JWT",
		template_literal: "تێکردە"
	}, r = {
		nan: "NaN",
		string: "نووسین",
		number: "ژمارە",
		boolean: "boolean",
		array: "array",
		object: "object",
		date: "ڕێکەوت",
		integer: "ژمارە",
		float: "ژمارە",
		null: "null",
		undefined: "undefined",
		function: "function",
		symbol: "symbol",
		unknown: "unknown",
		promise: "promise",
		void: "void",
		never: "never",
		map: "map",
		set: "set"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n, a = [
					"ا",
					"و",
					"ۆ",
					"وو",
					"ە",
					"ی",
					"ێ"
				].some((e) => i.endsWith(e)) ? "یە" : "ە", o = /^[a-zA-Z]+$/.test(i);
				return n === "null" || n === "undefined" ? "داواکراوە" : `چاوەڕوانکراوە ${t} بێت، بەڵام ${i}${o ? "" : a}`;
			}
			case "invalid_value": return e.values.length === 1 ? `بەهاکە نادرووستە: چاوەڕوانکراوە ${P(e.values[0])} بێت` : `هەڵبژاردەی نادروست: چاوەڕوانکراوە یەکێک بێت لە ${x(e.values, "|")}`;
			case "too_big": {
				let n = t(e.origin);
				return n ? `پێویستە بە لایەنی زۆرەوە ${e.maximum.toString()} ${n.unit} ${n.verb}` : `پێویستە بە لایەنی زۆرەوە ${e.maximum.toString()} بێت`;
			}
			case "too_small": {
				let n = t(e.origin);
				return n ? `پێویستە بە لایەنی کەمەوە ${e.minimum.toString()} ${n.unit} ${n.verb}` : `پێویستە بە لایەنی کەمەوە ${e.minimum.toString()} بێت`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `دەقی نادروست: پێویستە دەستپێبکات بە "${t.prefix}"` : t.format === "ends_with" ? `دەقی نادروست: پێویستە کۆتاییبێت بە "${t.suffix}"` : t.format === "includes" ? `دەقی نادروست: پێویستە "${t.includes}" لەخۆبگرێت` : t.format === "regex" ? `دەقی نادروست: پێویستە لەگەڵ پاتێرنی ${t.pattern} بگونجێت` : `بەهای ${n[t.format] ?? e.format} نادروستە`;
			}
			case "not_multiple_of": return `ژمارەی نادروست: دەبێت چەند هێندە بێت بۆ ${e.divisor}`;
			case "unrecognized_keys": return `کلیلی نەناسراو: ${x(e.keys, ", ")}`;
			case "invalid_key": return `کلیلی نادروست لە ${e.origin}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `بەهای نەناسراو هەیە. بەهای چاوەڕوانکراو: ${e.options.map((e) => `'${e}'`).join(" | ")}` : "یەکگرتنی نادروست";
			case "invalid_element": return `${e.origin} بەهاکە نادروستە`;
			default: return "تێکردەی نادروست";
		}
	};
};
function Pc() {
	return { localeError: Nc() };
}
//#endregion
//#region node_modules/zod/v4/locales/cs.js
var Fc = () => {
	let e = {
		string: {
			unit: "znaků",
			verb: "mít"
		},
		file: {
			unit: "bajtů",
			verb: "mít"
		},
		array: {
			unit: "prvků",
			verb: "mít"
		},
		set: {
			unit: "prvků",
			verb: "mít"
		},
		map: {
			unit: "prvků",
			verb: "mít"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "regulární výraz",
		email: "e-mailová adresa",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "datum a čas ve formátu ISO",
		date: "datum ve formátu ISO",
		time: "čas ve formátu ISO",
		duration: "doba trvání ISO",
		ipv4: "IPv4 adresa",
		ipv6: "IPv6 adresa",
		mac: "MAC adresa",
		cidrv4: "rozsah IPv4",
		cidrv6: "rozsah IPv6",
		base64: "řetězec zakódovaný ve formátu base64",
		base64url: "řetězec zakódovaný ve formátu base64url",
		json_string: "řetězec ve formátu JSON",
		e164: "číslo E.164",
		credit_card: "číslo kreditní karty",
		jwt: "JWT",
		template_literal: "vstup"
	}, r = {
		nan: "NaN",
		number: "číslo",
		string: "řetězec",
		function: "funkce",
		array: "pole"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Neplatný vstup: očekáváno instanceof ${e.expected}, obdrženo ${i}` : `Neplatný vstup: očekáváno ${t}, obdrženo ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Neplatný vstup: očekáváno ${P(e.values[0])}` : `Neplatná možnost: očekávána jedna z hodnot ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Hodnota je příliš velká: ${e.origin ?? "hodnota"} musí mít ${n}${e.maximum.toString()} ${r.unit ?? "prvků"}` : `Hodnota je příliš velká: ${e.origin ?? "hodnota"} musí být ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Hodnota je příliš malá: ${e.origin ?? "hodnota"} musí mít ${n}${e.minimum.toString()} ${r.unit ?? "prvků"}` : `Hodnota je příliš malá: ${e.origin ?? "hodnota"} musí být ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Neplatný řetězec: musí začínat na "${t.prefix}"` : t.format === "ends_with" ? `Neplatný řetězec: musí končit na "${t.suffix}"` : t.format === "includes" ? `Neplatný řetězec: musí obsahovat "${t.includes}"` : t.format === "regex" ? `Neplatný řetězec: musí odpovídat vzoru ${t.pattern}` : `Neplatný formát ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Neplatné číslo: musí být násobkem ${e.divisor}`;
			case "unrecognized_keys": return `Neznámé klíče: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Neplatný klíč v ${e.origin}`;
			case "invalid_union": return "Neplatný vstup";
			case "invalid_element": return `Neplatná hodnota v ${e.origin}`;
			default: return "Neplatný vstup";
		}
	};
};
function Ic() {
	return { localeError: Fc() };
}
//#endregion
//#region node_modules/zod/v4/locales/da.js
var Lc = () => {
	let e = {
		string: {
			unit: "tegn",
			verb: "havde"
		},
		file: {
			unit: "bytes",
			verb: "havde"
		},
		array: {
			unit: "elementer",
			verb: "indeholdt"
		},
		set: {
			unit: "elementer",
			verb: "indeholdt"
		},
		map: {
			unit: "elementer",
			verb: "indeholdt"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "e-mailadresse",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO dato- og klokkeslæt",
		date: "ISO-dato",
		time: "ISO-klokkeslæt",
		duration: "ISO-varighed",
		ipv4: "IPv4-adresse",
		ipv6: "IPv6-adresse",
		mac: "MAC-adresse",
		cidrv4: "IPv4-spektrum",
		cidrv6: "IPv6-spektrum",
		base64: "base64-kodet streng",
		base64url: "base64url-kodet streng",
		json_string: "JSON-streng",
		e164: "E.164-nummer",
		credit_card: "kreditkortnummer",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		string: "streng",
		number: "tal",
		boolean: "boolean",
		array: "liste",
		object: "objekt",
		set: "sæt",
		file: "fil"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ugyldigt input: forventede instanceof ${e.expected}, fik ${i}` : `Ugyldigt input: forventede ${t}, fik ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ugyldig værdi: forventede ${P(e.values[0])}` : `Ugyldigt valg: forventede en af følgende ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `For stor: forventede ${a ?? "value"} ${i.verb} ${n} ${e.maximum.toString()} ${i.unit ?? "elementer"}` : `For stor: forventede ${a ?? "value"} havde ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `For lille: forventede ${a} ${i.verb} ${n} ${e.minimum.toString()} ${i.unit}` : `For lille: forventede ${a} havde ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ugyldig streng: skal starte med "${t.prefix}"` : t.format === "ends_with" ? `Ugyldig streng: skal ende med "${t.suffix}"` : t.format === "includes" ? `Ugyldig streng: skal indeholde "${t.includes}"` : t.format === "regex" ? `Ugyldig streng: skal matche mønsteret ${t.pattern}` : `Ugyldig ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ugyldigt tal: skal være deleligt med ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Ukendte nøgler" : "Ukendt nøgle"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Ugyldig nøgle i ${e.origin}`;
			case "invalid_union": return "Ugyldigt input: matcher ingen af de tilladte typer";
			case "invalid_element": return `Ugyldig værdi i ${e.origin}`;
			default: return "Ugyldigt input";
		}
	};
};
function Rc() {
	return { localeError: Lc() };
}
//#endregion
//#region node_modules/zod/v4/locales/de.js
var zc = () => {
	let e = {
		string: {
			unit: "Zeichen",
			verb: "zu haben"
		},
		file: {
			unit: "Bytes",
			verb: "zu haben"
		},
		array: {
			unit: "Elemente",
			verb: "zu haben"
		},
		set: {
			unit: "Elemente",
			verb: "zu haben"
		},
		map: {
			unit: "Elemente",
			verb: "zu haben"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "Eingabe",
		email: "E-Mail-Adresse",
		url: "URL",
		emoji: "Emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO-Datum und -Uhrzeit",
		date: "ISO-Datum",
		time: "ISO-Uhrzeit",
		duration: "ISO-Dauer",
		ipv4: "IPv4-Adresse",
		ipv6: "IPv6-Adresse",
		mac: "MAC-Adresse",
		cidrv4: "IPv4-Bereich",
		cidrv6: "IPv6-Bereich",
		base64: "Base64-codierter String",
		base64url: "Base64-URL-codierter String",
		json_string: "JSON-String",
		e164: "E.164-Nummer",
		credit_card: "Kreditkartennummer",
		jwt: "JWT",
		template_literal: "Eingabe"
	}, r = {
		nan: "NaN",
		number: "Zahl",
		array: "Array"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ungültige Eingabe: erwartet instanceof ${e.expected}, erhalten ${i}` : `Ungültige Eingabe: erwartet ${t}, erhalten ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ungültige Eingabe: erwartet ${P(e.values[0])}` : `Ungültige Option: erwartet eine von ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Zu groß: erwartet, dass ${e.origin ?? "Wert"} ${n}${e.maximum.toString()} ${r.unit ?? "Elemente"} hat` : `Zu groß: erwartet, dass ${e.origin ?? "Wert"} ${n}${e.maximum.toString()} ist`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Zu klein: erwartet, dass ${e.origin} ${n}${e.minimum.toString()} ${r.unit} hat` : `Zu klein: erwartet, dass ${e.origin} ${n}${e.minimum.toString()} ist`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ungültiger String: muss mit "${t.prefix}" beginnen` : t.format === "ends_with" ? `Ungültiger String: muss mit "${t.suffix}" enden` : t.format === "includes" ? `Ungültiger String: muss "${t.includes}" enthalten` : t.format === "regex" ? `Ungültiger String: muss dem Muster ${t.pattern} entsprechen` : `Ungültig: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ungültige Zahl: muss ein Vielfaches von ${e.divisor} sein`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Unbekannte Schlüssel" : "Unbekannter Schlüssel"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Ungültiger Schlüssel in ${e.origin}`;
			case "invalid_union": return "Ungültige Eingabe";
			case "invalid_element": return `Ungültiger Wert in ${e.origin}`;
			default: return "Ungültige Eingabe";
		}
	};
};
function Bc() {
	return { localeError: zc() };
}
//#endregion
//#region node_modules/zod/v4/locales/el.js
var Vc = () => {
	let e = {
		string: {
			unit: "χαρακτήρες",
			verb: "να έχει"
		},
		file: {
			unit: "bytes",
			verb: "να έχει"
		},
		array: {
			unit: "στοιχεία",
			verb: "να έχει"
		},
		set: {
			unit: "στοιχεία",
			verb: "να έχει"
		},
		map: {
			unit: "καταχωρήσεις",
			verb: "να έχει"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "είσοδος",
		email: "διεύθυνση email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO ημερομηνία και ώρα",
		date: "ISO ημερομηνία",
		time: "ISO ώρα",
		duration: "ISO διάρκεια",
		ipv4: "διεύθυνση IPv4",
		ipv6: "διεύθυνση IPv6",
		mac: "διεύθυνση MAC",
		cidrv4: "εύρος IPv4",
		cidrv6: "εύρος IPv6",
		base64: "συμβολοσειρά κωδικοποιημένη σε base64",
		base64url: "συμβολοσειρά κωδικοποιημένη σε base64url",
		json_string: "συμβολοσειρά JSON",
		e164: "αριθμός E.164",
		credit_card: "αριθμός πιστωτικής κάρτας",
		jwt: "JWT",
		template_literal: "είσοδος"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return typeof e.expected == "string" && /^[A-Z]/.test(e.expected) ? `Μη έγκυρη είσοδος: αναμενόταν instanceof ${e.expected}, λήφθηκε ${i}` : `Μη έγκυρη είσοδος: αναμενόταν ${t}, λήφθηκε ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Μη έγκυρη είσοδος: αναμενόταν ${P(e.values[0])}` : `Μη έγκυρη επιλογή: αναμενόταν ένα από ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Πολύ μεγάλο: αναμενόταν ${e.origin ?? "τιμή"} να έχει ${n}${e.maximum.toString()} ${r.unit ?? "στοιχεία"}` : `Πολύ μεγάλο: αναμενόταν ${e.origin ?? "τιμή"} να είναι ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Πολύ μικρό: αναμενόταν ${e.origin} να έχει ${n}${e.minimum.toString()} ${r.unit}` : `Πολύ μικρό: αναμενόταν ${e.origin} να είναι ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Μη έγκυρη συμβολοσειρά: πρέπει να ξεκινά με "${t.prefix}"` : t.format === "ends_with" ? `Μη έγκυρη συμβολοσειρά: πρέπει να τελειώνει με "${t.suffix}"` : t.format === "includes" ? `Μη έγκυρη συμβολοσειρά: πρέπει να περιέχει "${t.includes}"` : t.format === "regex" ? `Μη έγκυρη συμβολοσειρά: πρέπει να ταιριάζει με το μοτίβο ${t.pattern}` : `Μη έγκυρο: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Μη έγκυρος αριθμός: πρέπει να είναι πολλαπλάσιο του ${e.divisor}`;
			case "unrecognized_keys": return `Άγνωστ${e.keys.length > 1 ? "α" : "ο"} κλειδ${e.keys.length > 1 ? "ιά" : "ί"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Μη έγκυρο κλειδί στο ${e.origin}`;
			case "invalid_union": return "Μη έγκυρη είσοδος";
			case "invalid_element": return `Μη έγκυρη τιμή στο ${e.origin}`;
			default: return "Μη έγκυρη είσοδος";
		}
	};
};
function Hc() {
	return { localeError: Vc() };
}
//#endregion
//#region node_modules/zod/v4/locales/eo.js
var Uc = () => {
	let e = {
		string: {
			unit: "karaktrojn",
			verb: "havi"
		},
		file: {
			unit: "bajtojn",
			verb: "havi"
		},
		array: {
			unit: "elementojn",
			verb: "havi"
		},
		set: {
			unit: "elementojn",
			verb: "havi"
		},
		map: {
			unit: "elementojn",
			verb: "havi"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "enigo",
		email: "retadreso",
		url: "URL",
		emoji: "emoĝio",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO-datotempo",
		date: "ISO-dato",
		time: "ISO-tempo",
		duration: "ISO-daŭro",
		ipv4: "IPv4-adreso",
		ipv6: "IPv6-adreso",
		mac: "MAC-adreso",
		cidrv4: "IPv4-rango",
		cidrv6: "IPv6-rango",
		base64: "64-ume kodita karaktraro",
		base64url: "URL-64-ume kodita karaktraro",
		json_string: "JSON-karaktraro",
		e164: "E.164-nombro",
		credit_card: "kreditkarta numero",
		jwt: "JWT",
		template_literal: "enigo"
	}, r = {
		nan: "NaN",
		number: "nombro",
		array: "tabelo",
		null: "senvalora"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Nevalida enigo: atendiĝis instanceof ${e.expected}, riceviĝis ${i}` : `Nevalida enigo: atendiĝis ${t}, riceviĝis ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Nevalida enigo: atendiĝis ${P(e.values[0])}` : `Nevalida opcio: atendiĝis unu el ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Tro granda: atendiĝis ke ${e.origin ?? "valoro"} havu ${n}${e.maximum.toString()} ${r.unit ?? "elementojn"}` : `Tro granda: atendiĝis ke ${e.origin ?? "valoro"} havu ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Tro malgranda: atendiĝis ke ${e.origin} havu ${n}${e.minimum.toString()} ${r.unit}` : `Tro malgranda: atendiĝis ke ${e.origin} estu ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Nevalida karaktraro: devas komenciĝi per "${t.prefix}"` : t.format === "ends_with" ? `Nevalida karaktraro: devas finiĝi per "${t.suffix}"` : t.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${t.includes}"` : t.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${t.pattern}` : `Nevalida ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Nevalida nombro: devas esti oblo de ${e.divisor}`;
			case "unrecognized_keys": return `Nekonata${e.keys.length > 1 ? "j" : ""} ŝlosilo${e.keys.length > 1 ? "j" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Nevalida ŝlosilo en ${e.origin}`;
			case "invalid_union": return "Nevalida enigo";
			case "invalid_element": return `Nevalida valoro en ${e.origin}`;
			default: return "Nevalida enigo";
		}
	};
};
function Wc() {
	return { localeError: Uc() };
}
//#endregion
//#region node_modules/zod/v4/locales/es.js
var Gc = () => {
	let e = {
		string: {
			unit: "caracteres",
			verb: "tener"
		},
		file: {
			unit: "bytes",
			verb: "tener"
		},
		array: {
			unit: "elementos",
			verb: "tener"
		},
		set: {
			unit: "elementos",
			verb: "tener"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "entrada",
		email: "dirección de correo electrónico",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "fecha y hora ISO",
		date: "fecha ISO",
		time: "hora ISO",
		duration: "duración ISO",
		ipv4: "dirección IPv4",
		ipv6: "dirección IPv6",
		mac: "dirección MAC",
		cidrv4: "rango IPv4",
		cidrv6: "rango IPv6",
		base64: "cadena codificada en base64",
		base64url: "URL codificada en base64",
		json_string: "cadena JSON",
		e164: "número E.164",
		credit_card: "número de tarjeta de crédito",
		jwt: "JWT",
		template_literal: "entrada"
	}, r = {
		nan: "NaN",
		string: "texto",
		number: "número",
		boolean: "booleano",
		array: "arreglo",
		object: "objeto",
		set: "conjunto",
		file: "archivo",
		date: "fecha",
		bigint: "número grande",
		symbol: "símbolo",
		undefined: "indefinido",
		null: "nulo",
		function: "función",
		map: "mapa",
		record: "registro",
		tuple: "tupla",
		enum: "enumeración",
		union: "unión",
		literal: "literal",
		promise: "promesa",
		void: "vacío",
		never: "nunca",
		unknown: "desconocido",
		any: "cualquiera"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Entrada inválida: se esperaba instanceof ${e.expected}, recibido ${i}` : `Entrada inválida: se esperaba ${t}, recibido ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Entrada inválida: se esperaba ${P(e.values[0])}` : `Opción inválida: se esperaba una de ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `Demasiado grande: se esperaba que ${a ?? "valor"} tuviera ${n}${e.maximum.toString()} ${i.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${a ?? "valor"} fuera ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `Demasiado pequeño: se esperaba que ${a} tuviera ${n}${e.minimum.toString()} ${i.unit}` : `Demasiado pequeño: se esperaba que ${a} fuera ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Cadena inválida: debe comenzar con "${t.prefix}"` : t.format === "ends_with" ? `Cadena inválida: debe terminar en "${t.suffix}"` : t.format === "includes" ? `Cadena inválida: debe incluir "${t.includes}"` : t.format === "regex" ? `Cadena inválida: debe coincidir con el patrón ${t.pattern}` : `Inválido ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Número inválido: debe ser múltiplo de ${e.divisor}`;
			case "unrecognized_keys": return `Llave${e.keys.length > 1 ? "s" : ""} desconocida${e.keys.length > 1 ? "s" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Llave inválida en ${r[e.origin] ?? e.origin}`;
			case "invalid_union": return "Entrada inválida";
			case "invalid_element": return `Valor inválido en ${r[e.origin] ?? e.origin}`;
			default: return "Entrada inválida";
		}
	};
};
function Kc() {
	return { localeError: Gc() };
}
//#endregion
//#region node_modules/zod/v4/locales/fa.js
var qc = () => {
	let e = {
		string: {
			unit: "کاراکتر",
			verb: "داشته باشد"
		},
		file: {
			unit: "بایت",
			verb: "داشته باشد"
		},
		array: {
			unit: "آیتم",
			verb: "داشته باشد"
		},
		set: {
			unit: "آیتم",
			verb: "داشته باشد"
		},
		map: {
			unit: "آیتم",
			verb: "داشته باشد"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ورودی",
		email: "آدرس ایمیل",
		url: "URL",
		emoji: "ایموجی",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "تاریخ و زمان ایزو",
		date: "تاریخ ایزو",
		time: "زمان ایزو",
		duration: "مدت زمان ایزو",
		ipv4: "IPv4 آدرس",
		ipv6: "IPv6 آدرس",
		mac: "MAC آدرس",
		cidrv4: "IPv4 دامنه",
		cidrv6: "IPv6 دامنه",
		base64: "base64-encoded رشته",
		base64url: "base64url-encoded رشته",
		json_string: "JSON رشته",
		e164: "E.164 عدد",
		credit_card: "شماره کارت اعتباری",
		jwt: "JWT",
		template_literal: "ورودی"
	}, r = {
		nan: "NaN",
		number: "عدد",
		array: "آرایه"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `ورودی نامعتبر: می‌بایست instanceof ${e.expected} می‌بود، ${i} دریافت شد` : `ورودی نامعتبر: می‌بایست ${t} می‌بود، ${i} دریافت شد`;
			}
			case "invalid_value": return e.values.length === 1 ? `ورودی نامعتبر: می‌بایست ${P(e.values[0])} می‌بود` : `گزینه نامعتبر: می‌بایست یکی از ${x(e.values, "|")} می‌بود`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `خیلی بزرگ: ${e.origin ?? "مقدار"} باید ${n}${e.maximum.toString()} ${r.unit ?? "عنصر"} باشد` : `خیلی بزرگ: ${e.origin ?? "مقدار"} باید ${n}${e.maximum.toString()} باشد`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `خیلی کوچک: ${e.origin} باید ${n}${e.minimum.toString()} ${r.unit} باشد` : `خیلی کوچک: ${e.origin} باید ${n}${e.minimum.toString()} باشد`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `رشته نامعتبر: باید با "${t.prefix}" شروع شود` : t.format === "ends_with" ? `رشته نامعتبر: باید با "${t.suffix}" تمام شود` : t.format === "includes" ? `رشته نامعتبر: باید شامل "${t.includes}" باشد` : t.format === "regex" ? `رشته نامعتبر: باید با الگوی ${t.pattern} مطابقت داشته باشد` : `${n[t.format] ?? e.format} نامعتبر`;
			}
			case "not_multiple_of": return `عدد نامعتبر: باید مضرب ${e.divisor} باشد`;
			case "unrecognized_keys": return `کلید${e.keys.length > 1 ? "های" : ""} ناشناس: ${x(e.keys, ", ")}`;
			case "invalid_key": return `کلید ناشناس در ${e.origin}`;
			case "invalid_union": return "ورودی نامعتبر";
			case "invalid_element": return `مقدار نامعتبر در ${e.origin}`;
			default: return "ورودی نامعتبر";
		}
	};
};
function Jc() {
	return { localeError: qc() };
}
//#endregion
//#region node_modules/zod/v4/locales/fi.js
var Yc = () => {
	let e = {
		string: {
			unit: "merkkiä",
			subject: "merkkijonon"
		},
		file: {
			unit: "tavua",
			subject: "tiedoston"
		},
		array: {
			unit: "alkiota",
			subject: "listan"
		},
		set: {
			unit: "alkiota",
			subject: "joukon"
		},
		map: {
			unit: "alkiota",
			subject: "kuvauksen"
		},
		number: {
			unit: "",
			subject: "luvun"
		},
		bigint: {
			unit: "",
			subject: "suuren kokonaisluvun"
		},
		int: {
			unit: "",
			subject: "kokonaisluvun"
		},
		date: {
			unit: "",
			subject: "päivämäärän"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "säännöllinen lauseke",
		email: "sähköpostiosoite",
		url: "URL-osoite",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO-aikaleima",
		date: "ISO-päivämäärä",
		time: "ISO-aika",
		duration: "ISO-kesto",
		ipv4: "IPv4-osoite",
		ipv6: "IPv6-osoite",
		mac: "MAC-osoite",
		cidrv4: "IPv4-alue",
		cidrv6: "IPv6-alue",
		base64: "base64-koodattu merkkijono",
		base64url: "base64url-koodattu merkkijono",
		json_string: "JSON-merkkijono",
		e164: "E.164-luku",
		credit_card: "luottokortin numero",
		jwt: "JWT",
		template_literal: "templaattimerkkijono"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${e.expected}, oli ${i}` : `Virheellinen tyyppi: odotettiin ${t}, oli ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Virheellinen syöte: täytyy olla ${P(e.values[0])}` : `Virheellinen valinta: täytyy olla yksi seuraavista: ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Liian suuri: ${r.subject} täytyy olla ${n}${e.maximum.toString()} ${r.unit}`.trim() : `Liian suuri: arvon täytyy olla ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Liian pieni: ${r.subject} täytyy olla ${n}${e.minimum.toString()} ${r.unit}`.trim() : `Liian pieni: arvon täytyy olla ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Virheellinen syöte: täytyy alkaa "${t.prefix}"` : t.format === "ends_with" ? `Virheellinen syöte: täytyy loppua "${t.suffix}"` : t.format === "includes" ? `Virheellinen syöte: täytyy sisältää "${t.includes}"` : t.format === "regex" ? `Virheellinen syöte: täytyy vastata säännöllistä lauseketta ${t.pattern}` : `Virheellinen ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Virheellinen luku: täytyy olla luvun ${e.divisor} monikerta`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return "Virheellinen avain tietueessa";
			case "invalid_union": return "Virheellinen unioni";
			case "invalid_element": return "Virheellinen arvo joukossa";
			default: return "Virheellinen syöte";
		}
	};
};
function Xc() {
	return { localeError: Yc() };
}
//#endregion
//#region node_modules/zod/v4/locales/fr.js
var Zc = () => {
	let e = {
		string: {
			unit: "caractères",
			verb: "avoir"
		},
		file: {
			unit: "octets",
			verb: "avoir"
		},
		array: {
			unit: "éléments",
			verb: "avoir"
		},
		set: {
			unit: "éléments",
			verb: "avoir"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "expression régulière",
		email: "adresse e-mail",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "date et heure ISO",
		date: "date ISO",
		time: "heure ISO",
		duration: "durée ISO",
		ipv4: "adresse IPv4",
		ipv6: "adresse IPv6",
		mac: "adresse MAC",
		cidrv4: "plage IPv4",
		cidrv6: "plage IPv6",
		base64: "chaîne de caractères encodée en base64",
		base64url: "chaîne de caractères encodée en base64url",
		json_string: "chaîne de caractères JSON",
		e164: "numéro au format E.164",
		credit_card: "numéro de carte de crédit",
		jwt: "JWT",
		template_literal: "entrée"
	}, r = {
		string: "chaîne de caractères",
		number: "nombre",
		int: "entier",
		boolean: "booléen",
		bigint: "grand entier",
		symbol: "symbole",
		undefined: "indéfini",
		null: "null",
		never: "jamais",
		void: "vide",
		date: "date",
		array: "tableau",
		object: "objet",
		tuple: "tuple",
		record: "record",
		map: "map",
		set: "ensemble",
		file: "fichier",
		nonoptional: "non optionnel",
		nan: "NaN",
		function: "fonction"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Entrée invalide : instance de ${e.expected} attendu, ${i} reçu` : `Entrée invalide : ${t} attendu, ${i} reçu`;
			}
			case "invalid_value": return e.values.length === 1 ? `Entrée invalide : ${P(e.values[0])} attendu` : `Option invalide : une valeur parmi ${x(e.values, "|")} attendue`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", i = t(e.origin);
				return i ? `Trop grand : ${r[e.origin] ?? "valeur"} doit ${i.verb} ${n}${e.maximum.toString()} ${i.unit ?? "élément(s)"}` : `Trop grand : ${r[e.origin] ?? "valeur"} doit être ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", i = t(e.origin);
				return i ? `Trop petit : ${r[e.origin] ?? "valeur"} doit ${i.verb} ${n}${e.minimum.toString()} ${i.unit}` : `Trop petit : ${r[e.origin] ?? "valeur"} doit être ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Chaîne de caractères invalide : doit commencer par "${t.prefix}"` : t.format === "ends_with" ? `Chaîne de caractères invalide : doit se terminer par "${t.suffix}"` : t.format === "includes" ? `Chaîne de caractères invalide : doit inclure "${t.includes}"` : t.format === "regex" ? `Chaîne de caractères invalide : doit correspondre au motif ${t.pattern}` : `${n[t.format] ?? e.format} invalide`;
			}
			case "not_multiple_of": return `Nombre invalide : doit être un multiple de ${e.divisor}`;
			case "unrecognized_keys": return `Clé${e.keys.length > 1 ? "s" : ""} non reconnue${e.keys.length > 1 ? "s" : ""} : ${x(e.keys, ", ")}`;
			case "invalid_key": return `Clé invalide dans ${e.origin}`;
			case "invalid_union": return "Entrée invalide";
			case "invalid_element": return `Valeur invalide dans ${e.origin}`;
			default: return "Entrée invalide";
		}
	};
};
function Qc() {
	return { localeError: Zc() };
}
//#endregion
//#region node_modules/zod/v4/locales/fr-CA.js
var $c = () => {
	let e = {
		string: {
			unit: "caractères",
			verb: "avoir"
		},
		file: {
			unit: "octets",
			verb: "avoir"
		},
		array: {
			unit: "éléments",
			verb: "avoir"
		},
		set: {
			unit: "éléments",
			verb: "avoir"
		},
		map: {
			unit: "éléments",
			verb: "avoir"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "entrée",
		email: "adresse courriel",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "date-heure ISO",
		date: "date ISO",
		time: "heure ISO",
		duration: "durée ISO",
		ipv4: "adresse IPv4",
		ipv6: "adresse IPv6",
		mac: "adresse MAC",
		cidrv4: "plage IPv4",
		cidrv6: "plage IPv6",
		base64: "chaîne encodée en base64",
		base64url: "chaîne encodée en base64url",
		json_string: "chaîne JSON",
		e164: "numéro E.164",
		credit_card: "numéro de carte de crédit",
		jwt: "JWT",
		template_literal: "entrée"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Entrée invalide : attendu instanceof ${e.expected}, reçu ${i}` : `Entrée invalide : attendu ${t}, reçu ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Entrée invalide : attendu ${P(e.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "≤" : "<", r = t(e.origin);
				return r ? `Trop grand : attendu que ${e.origin ?? "la valeur"} ait ${n}${e.maximum.toString()} ${r.unit}` : `Trop grand : attendu que ${e.origin ?? "la valeur"} soit ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? "≥" : ">", r = t(e.origin);
				return r ? `Trop petit : attendu que ${e.origin} ait ${n}${e.minimum.toString()} ${r.unit}` : `Trop petit : attendu que ${e.origin} soit ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Chaîne invalide : doit commencer par "${t.prefix}"` : t.format === "ends_with" ? `Chaîne invalide : doit se terminer par "${t.suffix}"` : t.format === "includes" ? `Chaîne invalide : doit inclure "${t.includes}"` : t.format === "regex" ? `Chaîne invalide : doit correspondre au motif ${t.pattern}` : `${n[t.format] ?? e.format} invalide`;
			}
			case "not_multiple_of": return `Nombre invalide : doit être un multiple de ${e.divisor}`;
			case "unrecognized_keys": return `Clé${e.keys.length > 1 ? "s" : ""} non reconnue${e.keys.length > 1 ? "s" : ""} : ${x(e.keys, ", ")}`;
			case "invalid_key": return `Clé invalide dans ${e.origin}`;
			case "invalid_union": return "Entrée invalide";
			case "invalid_element": return `Valeur invalide dans ${e.origin}`;
			default: return "Entrée invalide";
		}
	};
};
function el() {
	return { localeError: $c() };
}
//#endregion
//#region node_modules/zod/v4/locales/gu.js
var tl = () => {
	let e = {
		string: {
			unit: "અક્ષર",
			verb: "હોવા જોઈએ"
		},
		file: {
			unit: "બાયટ",
			verb: "હોવા જોઈએ"
		},
		array: {
			unit: "આઇટમ",
			verb: "હોવા જોઈએ"
		},
		set: {
			unit: "આઇટમ",
			verb: "હોવા જોઈએ"
		},
		map: {
			unit: "એન્ટ્રી",
			verb: "હોવા જોઈએ"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ઇનપુટ",
		email: "ઈમેઇલ એડ્રેસ",
		url: "URL",
		emoji: "ઇમોજી",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO તારીખ અને સમય",
		date: "ISO તારીખ",
		time: "ISO સમય",
		duration: "ISO અવધિ",
		ipv4: "IPv4 એડ્રેસ",
		ipv6: "IPv6 એડ્રેસ",
		mac: "MAC એડ્રેસ",
		cidrv4: "IPv4 શ્રેણી",
		cidrv6: "IPv6 શ્રેણી",
		base64: "base64-એન્કોડેડ સ્ટ્રિંગ",
		base64url: "base64url-એન્કોડેડ સ્ટ્રિંગ",
		json_string: "JSON સ્ટ્રિંગ",
		e164: "E.164 નંબર",
		credit_card: "ક્રેડિટ કાર્ડ નંબર",
		jwt: "JWT",
		template_literal: "ઇનપુટ"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input);
				return `અમાન્ય ઇનપુટ: અપેક્ષિત ${t}, પ્રાપ્ત ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `અમાન્ય ઇનપુટ: અપેક્ષિત ${P(e.values[0])}` : `અમાન્ય વિકલ્પ: ${x(e.values, " | ")} માધ્યમથી એક અપેક્ષિત`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ખૂબ મોટું: ${e.origin ?? "મૂલ્ય"} ${n}${e.maximum.toString()} ${r.unit ?? "એલિમેન્ટ"} હોવા જોઈએ` : `ખૂબ મોટું: ${e.origin ?? "મૂલ્ય"} ${n}${e.maximum.toString()} હોવું જોઈએ`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `ખૂબ નાનું: ${e.origin} ${n}${e.minimum.toString()} ${r.unit} હોવા જોઈએ` : `ખૂબ નાનું: ${e.origin} ${n}${e.minimum.toString()} હોવું જોઈએ`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `અમાન્ય સ્ટ્રિંગ: "${t.prefix}" થી શરૂ થવું જોઈએ` : t.format === "ends_with" ? `અમાન્ય સ્ટ્રિંગ: "${t.suffix}" પર સમાપ્ત થવું જોઈએ` : t.format === "includes" ? `અમાન્ય સ્ટ્રિંગ: "${t.includes}" શામેલ હોવું જોઈએ` : t.format === "regex" ? `અમાન્ય સ્ટ્રિંગ: પેટર્ન ${t.pattern} સાથે મેળ ખાવું જોઈએ` : `અમાન્ય ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `અમાન્ય નંબર: ${e.divisor} નો ગુણાંક હોવો જોઈએ`;
			case "unrecognized_keys": return `ઓળખી શકાતા નહીં તે કી${e.keys.length > 1 ? "ઓ" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} માં અમાન્ય કી`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `અમાન્ય ડિસ્ક્રિમિનેટર મૂલ્ય. અપેક્ષિત ${e.options.map((e) => `'${e}'`).join(" | ")}` : "અમાન્ય ઇનપુટ";
			case "invalid_element": return `${e.origin} માં અમાન્ય મૂલ્ય`;
			default: return "અમાન્ય ઇનપુટ";
		}
	};
};
function nl() {
	return { localeError: tl() };
}
//#endregion
//#region node_modules/zod/v4/locales/he.js
var rl = () => {
	let e = {
		string: {
			label: "מחרוזת",
			gender: "f"
		},
		number: {
			label: "מספר",
			gender: "m"
		},
		boolean: {
			label: "ערך בוליאני",
			gender: "m"
		},
		bigint: {
			label: "BigInt",
			gender: "m"
		},
		date: {
			label: "תאריך",
			gender: "m"
		},
		array: {
			label: "מערך",
			gender: "m"
		},
		object: {
			label: "אובייקט",
			gender: "m"
		},
		null: {
			label: "ערך ריק (null)",
			gender: "m"
		},
		undefined: {
			label: "ערך לא מוגדר (undefined)",
			gender: "m"
		},
		symbol: {
			label: "סימבול (Symbol)",
			gender: "m"
		},
		function: {
			label: "פונקציה",
			gender: "f"
		},
		map: {
			label: "מפה (Map)",
			gender: "f"
		},
		set: {
			label: "קבוצה (Set)",
			gender: "f"
		},
		file: {
			label: "קובץ",
			gender: "m"
		},
		promise: {
			label: "Promise",
			gender: "m"
		},
		NaN: {
			label: "NaN",
			gender: "m"
		},
		unknown: {
			label: "ערך לא ידוע",
			gender: "m"
		},
		value: {
			label: "ערך",
			gender: "m"
		}
	}, t = {
		string: {
			unit: "תווים",
			shortLabel: "קצר",
			longLabel: "ארוך"
		},
		file: {
			unit: "בייטים",
			shortLabel: "קטן",
			longLabel: "גדול"
		},
		array: {
			unit: "פריטים",
			shortLabel: "קטן",
			longLabel: "גדול"
		},
		set: {
			unit: "פריטים",
			shortLabel: "קטן",
			longLabel: "גדול"
		},
		number: {
			unit: "",
			shortLabel: "קטן",
			longLabel: "גדול"
		}
	}, n = (t) => t ? e[t] : void 0, r = (t) => {
		let r = n(t);
		return r ? r.label : t ?? e.unknown.label;
	}, i = (e) => `ה${r(e)}`, a = (e) => (n(e)?.gender ?? "m") === "f" ? "צריכה להיות" : "צריך להיות", o = (e) => e ? t[e] ?? null : null, s = {
		regex: {
			label: "קלט",
			gender: "m"
		},
		email: {
			label: "כתובת אימייל",
			gender: "f"
		},
		url: {
			label: "כתובת רשת",
			gender: "f"
		},
		emoji: {
			label: "אימוג'י",
			gender: "m"
		},
		uuid: {
			label: "UUID",
			gender: "m"
		},
		uuidv4: {
			label: "UUIDv4",
			gender: "m"
		},
		uuidv6: {
			label: "UUIDv6",
			gender: "m"
		},
		nanoid: {
			label: "nanoid",
			gender: "m"
		},
		guid: {
			label: "GUID",
			gender: "m"
		},
		cuid: {
			label: "cuid",
			gender: "m"
		},
		cuid2: {
			label: "cuid2",
			gender: "m"
		},
		ulid: {
			label: "ULID",
			gender: "m"
		},
		xid: {
			label: "XID",
			gender: "m"
		},
		ksuid: {
			label: "KSUID",
			gender: "m"
		},
		datetime: {
			label: "תאריך וזמן ISO",
			gender: "m"
		},
		date: {
			label: "תאריך ISO",
			gender: "m"
		},
		time: {
			label: "זמן ISO",
			gender: "m"
		},
		duration: {
			label: "משך זמן ISO",
			gender: "m"
		},
		ipv4: {
			label: "כתובת IPv4",
			gender: "f"
		},
		ipv6: {
			label: "כתובת IPv6",
			gender: "f"
		},
		mac: {
			label: "כתובת MAC",
			gender: "f"
		},
		cidrv4: {
			label: "טווח IPv4",
			gender: "m"
		},
		cidrv6: {
			label: "טווח IPv6",
			gender: "m"
		},
		base64: {
			label: "מחרוזת בבסיס 64",
			gender: "f"
		},
		base64url: {
			label: "מחרוזת בבסיס 64 לכתובות רשת",
			gender: "f"
		},
		json_string: {
			label: "מחרוזת JSON",
			gender: "f"
		},
		e164: {
			label: "מספר E.164",
			gender: "m"
		},
		credit_card: {
			label: "מספר כרטיס אשראי",
			gender: "m"
		},
		jwt: {
			label: "JWT",
			gender: "m"
		},
		template_literal: {
			label: "קלט",
			gender: "m"
		},
		ends_with: {
			label: "קלט",
			gender: "m"
		},
		includes: {
			label: "קלט",
			gender: "m"
		},
		lowercase: {
			label: "קלט",
			gender: "m"
		},
		starts_with: {
			label: "קלט",
			gender: "m"
		},
		uppercase: {
			label: "קלט",
			gender: "m"
		}
	}, c = { nan: "NaN" };
	return (t) => {
		switch (t.code) {
			case "invalid_type": {
				let n = t.expected, i = c[n ?? ""] ?? r(n), a = E(t.input), o = c[a] ?? e[a]?.label ?? a;
				return /^[A-Z]/.test(t.expected) ? `קלט לא תקין: צריך להיות instanceof ${t.expected}, התקבל ${o}` : `קלט לא תקין: צריך להיות ${i}, התקבל ${o}`;
			}
			case "invalid_value": {
				if (t.values.length === 1) return `ערך לא תקין: הערך חייב להיות ${P(t.values[0])}`;
				let e = t.values.map((e) => P(e));
				if (t.values.length === 2) return `ערך לא תקין: האפשרויות המתאימות הן ${e[0]} או ${e[1]}`;
				let n = e[e.length - 1];
				return `ערך לא תקין: האפשרויות המתאימות הן ${e.slice(0, -1).join(", ")} או ${n}`;
			}
			case "too_big": {
				let e = o(t.origin), n = i(t.origin ?? "value");
				if (t.origin === "string") return `${e?.longLabel ?? "ארוך"} מדי: ${n} צריכה להכיל ${t.maximum.toString()} ${e?.unit ?? ""} ${t.inclusive ? "או פחות" : "לכל היותר"}`.trim();
				if (t.origin === "number") return `גדול מדי: ${n} צריך להיות ${t.inclusive ? `קטן או שווה ל-${t.maximum}` : `קטן מ-${t.maximum}`}`;
				if (t.origin === "array" || t.origin === "set") return `גדול מדי: ${n} ${t.origin === "set" ? "צריכה" : "צריך"} להכיל ${t.inclusive ? `${t.maximum} ${e?.unit ?? ""} או פחות` : `פחות מ-${t.maximum} ${e?.unit ?? ""}`}`.trim();
				let r = t.inclusive ? "<=" : "<", s = a(t.origin ?? "value");
				return e?.unit ? `${e.longLabel} מדי: ${n} ${s} ${r}${t.maximum.toString()} ${e.unit}` : `${e?.longLabel ?? "גדול"} מדי: ${n} ${s} ${r}${t.maximum.toString()}`;
			}
			case "too_small": {
				let e = o(t.origin), n = i(t.origin ?? "value");
				if (t.origin === "string") return `${e?.shortLabel ?? "קצר"} מדי: ${n} צריכה להכיל ${t.minimum.toString()} ${e?.unit ?? ""} ${t.inclusive ? "או יותר" : "לפחות"}`.trim();
				if (t.origin === "number") return `קטן מדי: ${n} צריך להיות ${t.inclusive ? `גדול או שווה ל-${t.minimum}` : `גדול מ-${t.minimum}`}`;
				if (t.origin === "array" || t.origin === "set") {
					let r = t.origin === "set" ? "צריכה" : "צריך";
					return t.minimum === 1 && t.inclusive ? `קטן מדי: ${n} ${r} להכיל ${t.origin, "לפחות פריט אחד"}` : `קטן מדי: ${n} ${r} להכיל ${t.inclusive ? `${t.minimum} ${e?.unit ?? ""} או יותר` : `יותר מ-${t.minimum} ${e?.unit ?? ""}`}`.trim();
				}
				let r = t.inclusive ? ">=" : ">", s = a(t.origin ?? "value");
				return e?.unit ? `${e.shortLabel} מדי: ${n} ${s} ${r}${t.minimum.toString()} ${e.unit}` : `${e?.shortLabel ?? "קטן"} מדי: ${n} ${s} ${r}${t.minimum.toString()}`;
			}
			case "invalid_format": {
				let e = t;
				if (e.format === "starts_with") return `המחרוזת חייבת להתחיל ב "${e.prefix}"`;
				if (e.format === "ends_with") return `המחרוזת חייבת להסתיים ב "${e.suffix}"`;
				if (e.format === "includes") return `המחרוזת חייבת לכלול "${e.includes}"`;
				if (e.format === "regex") return `המחרוזת חייבת להתאים לתבנית ${e.pattern}`;
				let n = s[e.format];
				return `${n?.label ?? e.format} לא ${(n?.gender ?? "m") === "f" ? "תקינה" : "תקין"}`;
			}
			case "not_multiple_of": return `מספר לא תקין: חייב להיות מכפלה של ${t.divisor}`;
			case "unrecognized_keys": return `מפתח${t.keys.length > 1 ? "ות" : ""} לא מזוה${t.keys.length > 1 ? "ים" : "ה"}: ${x(t.keys, ", ")}`;
			case "invalid_key": return "שדה לא תקין באובייקט";
			case "invalid_union": return "קלט לא תקין";
			case "invalid_element": return `ערך לא תקין ב${i(t.origin ?? "array")}`;
			default: return "קלט לא תקין";
		}
	};
};
function il() {
	return { localeError: rl() };
}
//#endregion
//#region node_modules/zod/v4/locales/hi.js
var al = () => {
	let e = {
		string: {
			unit: "अक्षर",
			verb: "रखने के लिए"
		},
		file: {
			unit: "बाइट्स",
			verb: "रखने के लिए"
		},
		array: {
			unit: "तत्व",
			verb: "रखने के लिए"
		},
		set: {
			unit: "तत्व",
			verb: "रखने के लिए"
		},
		map: {
			unit: "प्रविष्टियाँ",
			verb: "रखने के लिए"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "इनपुट",
		email: "ईमेल पता",
		url: "URL",
		emoji: "इमोजी",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO तिथि और समय",
		date: "ISO तिथि",
		time: "ISO समय",
		duration: "ISO अवधि",
		ipv4: "IPv4 पता",
		ipv6: "IPv6 पता",
		mac: "MAC पता",
		cidrv4: "IPv4 श्रेणी",
		cidrv6: "IPv6 श्रेणी",
		base64: "Base64-एन्कोडेड स्ट्रिंग",
		base64url: "Base64URL-एन्कोडेड स्ट्रिंग",
		json_string: "JSON स्ट्रिंग",
		e164: "E.164 संख्या",
		credit_card: "क्रेडिट कार्ड संख्या",
		jwt: "JWT",
		template_literal: "इनपुट"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input);
				return `अमान्य इनपुट: अपेक्षित ${t}, प्राप्त ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `अमान्य इनपुट: अपेक्षित ${P(e.values[0])}` : `अमान्य विकल्प: अपेक्षित मानों में से एक ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `बहुत बड़ा: अपेक्षित था कि ${e.origin ?? "मान"} में ${n}${e.maximum} ${r.unit} हों` : `बहुत बड़ा: अपेक्षित था कि ${e.origin ?? "मान"} ${n}${e.maximum} हो`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `बहुत छोटा: अपेक्षित था कि ${e.origin} में ${n}${e.minimum} ${r.unit} हों` : `बहुत छोटा: अपेक्षित था कि ${e.origin} ${n}${e.minimum} हो`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `अमान्य स्ट्रिंग: "${t.prefix}" से शुरू होना चाहिए` : t.format === "ends_with" ? `अमान्य स्ट्रिंग: "${t.suffix}" पर समाप्त होना चाहिए` : t.format === "includes" ? `अमान्य स्ट्रिंग: इसमें "${t.includes}" शामिल होना चाहिए` : t.format === "regex" ? `अमान्य स्ट्रिंग: पैटर्न ${t.pattern} से मेल खाना चाहिए` : `अमान्य ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `अमान्य संख्या: यह ${e.divisor} का गुणज होना चाहिए`;
			case "unrecognized_keys": return `अपरिचित कुंजी${e.keys.length > 1 ? "याँ" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `अमान्य कुंजी: ${e.origin} में`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `अमान्य डिस्क्रिमिनेटर मान: अपेक्षित ${e.options.map((e) => `'${e}'`).join(" | ")}` : "अमान्य इनपुट";
			case "invalid_element": return `अमान्य मान: ${e.origin} में`;
			default: return "अमान्य इनपुट";
		}
	};
};
function ol() {
	return { localeError: al() };
}
//#endregion
//#region node_modules/zod/v4/locales/hr.js
var sl = () => {
	let e = {
		string: {
			unit: "znakova",
			verb: "imati"
		},
		file: {
			unit: "bajtova",
			verb: "imati"
		},
		array: {
			unit: "stavki",
			verb: "imati"
		},
		set: {
			unit: "stavki",
			verb: "imati"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "unos",
		email: "email adresa",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datum i vrijeme",
		date: "ISO datum",
		time: "ISO vrijeme",
		duration: "ISO trajanje",
		ipv4: "IPv4 adresa",
		ipv6: "IPv6 adresa",
		mac: "MAC adresa",
		cidrv4: "IPv4 raspon",
		cidrv6: "IPv6 raspon",
		base64: "base64 kodirani tekst",
		base64url: "base64url kodirani tekst",
		json_string: "JSON tekst",
		e164: "E.164 broj",
		credit_card: "broj kreditne kartice",
		jwt: "JWT",
		template_literal: "unos"
	}, r = {
		nan: "NaN",
		string: "tekst",
		number: "broj",
		boolean: "boolean",
		array: "niz",
		object: "objekt",
		set: "skup",
		file: "datoteka",
		date: "datum",
		bigint: "bigint",
		symbol: "simbol",
		undefined: "undefined",
		null: "null",
		function: "funkcija",
		map: "mapa"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Neispravan unos: očekuje se instanceof ${e.expected}, a primljeno je ${i}` : `Neispravan unos: očekuje se ${t}, a primljeno je ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Neispravna vrijednost: očekivano ${P(e.values[0])}` : `Neispravna opcija: očekivano jedno od ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `Preveliko: očekivano da ${a ?? "vrijednost"} ima ${n}${e.maximum.toString()} ${i.unit ?? "elemenata"}` : `Preveliko: očekivano da ${a ?? "vrijednost"} bude ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `Premalo: očekivano da ${a} ima ${n}${e.minimum.toString()} ${i.unit}` : `Premalo: očekivano da ${a} bude ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Neispravan tekst: mora započinjati s "${t.prefix}"` : t.format === "ends_with" ? `Neispravan tekst: mora završavati s "${t.suffix}"` : t.format === "includes" ? `Neispravan tekst: mora sadržavati "${t.includes}"` : t.format === "regex" ? `Neispravan tekst: mora odgovarati uzorku ${t.pattern}` : `Neispravna ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Neispravan broj: mora biti višekratnik od ${e.divisor}`;
			case "unrecognized_keys": return `Neprepoznat${e.keys.length > 1 ? "i ključevi" : " ključ"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Neispravan ključ u ${r[e.origin] ?? e.origin}`;
			case "invalid_union": return "Neispravan unos";
			case "invalid_element": return `Neispravna vrijednost u ${r[e.origin] ?? e.origin}`;
			default: return "Neispravan unos";
		}
	};
};
function cl() {
	return { localeError: sl() };
}
//#endregion
//#region node_modules/zod/v4/locales/hu.js
var ll = () => {
	let e = {
		string: {
			unit: "karakter",
			verb: "legyen"
		},
		file: {
			unit: "byte",
			verb: "legyen"
		},
		array: {
			unit: "elem",
			verb: "legyen"
		},
		set: {
			unit: "elem",
			verb: "legyen"
		},
		map: {
			unit: "elem",
			verb: "legyen"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "bemenet",
		email: "email cím",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO időbélyeg",
		date: "ISO dátum",
		time: "ISO idő",
		duration: "ISO időintervallum",
		ipv4: "IPv4 cím",
		ipv6: "IPv6 cím",
		mac: "MAC cím",
		cidrv4: "IPv4 tartomány",
		cidrv6: "IPv6 tartomány",
		base64: "base64-kódolt string",
		base64url: "base64url-kódolt string",
		json_string: "JSON string",
		e164: "E.164 szám",
		credit_card: "hitelkártyaszám",
		jwt: "JWT",
		template_literal: "bemenet"
	}, r = {
		nan: "NaN",
		number: "szám",
		array: "tömb"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Érvénytelen bemenet: a várt érték instanceof ${e.expected}, a kapott érték ${i}` : `Érvénytelen bemenet: a várt érték ${t}, a kapott érték ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Érvénytelen bemenet: a várt érték ${P(e.values[0])}` : `Érvénytelen opció: valamelyik érték várt ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Túl nagy: ${e.origin ?? "érték"} mérete túl nagy ${n}${e.maximum.toString()} ${r.unit ?? "elem"}` : `Túl nagy: a bemeneti érték ${e.origin ?? "érték"} túl nagy: ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Túl kicsi: a bemeneti érték ${e.origin} mérete túl kicsi ${n}${e.minimum.toString()} ${r.unit}` : `Túl kicsi: a bemeneti érték ${e.origin} túl kicsi ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Érvénytelen string: "${t.prefix}" értékkel kell kezdődnie` : t.format === "ends_with" ? `Érvénytelen string: "${t.suffix}" értékkel kell végződnie` : t.format === "includes" ? `Érvénytelen string: "${t.includes}" értéket kell tartalmaznia` : t.format === "regex" ? `Érvénytelen string: ${t.pattern} mintának kell megfelelnie` : `Érvénytelen ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Érvénytelen szám: ${e.divisor} többszörösének kell lennie`;
			case "unrecognized_keys": return `Ismeretlen kulcs${e.keys.length > 1 ? "s" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Érvénytelen kulcs ${e.origin}`;
			case "invalid_union": return "Érvénytelen bemenet";
			case "invalid_element": return `Érvénytelen érték: ${e.origin}`;
			default: return "Érvénytelen bemenet";
		}
	};
};
function ul() {
	return { localeError: ll() };
}
//#endregion
//#region node_modules/zod/v4/locales/hy.js
function dl(e, t, n) {
	return Math.abs(e) === 1 ? t : n;
}
function B(e) {
	if (!e) return "";
	let t = [
		"ա",
		"ե",
		"ը",
		"ի",
		"ո",
		"ու",
		"օ"
	], n = e[e.length - 1];
	return e + (t.includes(n) ? "ն" : "ը");
}
var fl = () => {
	let e = {
		string: {
			unit: {
				one: "նշան",
				many: "նշաններ"
			},
			verb: "ունենալ"
		},
		file: {
			unit: {
				one: "բայթ",
				many: "բայթեր"
			},
			verb: "ունենալ"
		},
		array: {
			unit: {
				one: "տարր",
				many: "տարրեր"
			},
			verb: "ունենալ"
		},
		set: {
			unit: {
				one: "տարր",
				many: "տարրեր"
			},
			verb: "ունենալ"
		},
		map: {
			unit: {
				one: "տարր",
				many: "տարրեր"
			},
			verb: "ունենալ"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "մուտք",
		email: "էլ. հասցե",
		url: "URL",
		emoji: "էմոջի",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO ամսաթիվ և ժամ",
		date: "ISO ամսաթիվ",
		time: "ISO ժամ",
		duration: "ISO տևողություն",
		ipv4: "IPv4 հասցե",
		ipv6: "IPv6 հասցե",
		mac: "MAC հասցե",
		cidrv4: "IPv4 միջակայք",
		cidrv6: "IPv6 միջակայք",
		base64: "base64 ձևաչափով տող",
		base64url: "base64url ձևաչափով տող",
		json_string: "JSON տող",
		e164: "E.164 համար",
		credit_card: "կրեդիտ քարտի համար",
		jwt: "JWT",
		template_literal: "մուտք"
	}, r = {
		nan: "NaN",
		number: "թիվ",
		array: "զանգված"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Սխալ մուտքագրում․ սպասվում էր instanceof ${e.expected}, ստացվել է ${i}` : `Սխալ մուտքագրում․ սպասվում էր ${t}, ստացվել է ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Սխալ մուտքագրում․ սպասվում էր ${P(e.values[1])}` : `Սխալ տարբերակ․ սպասվում էր հետևյալներից մեկը՝ ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				if (r) {
					let t = dl(Number(e.maximum), r.unit.one, r.unit.many);
					return `Չափազանց մեծ արժեք․ սպասվում է, որ ${B(e.origin ?? "արժեք")} կունենա ${n}${e.maximum.toString()} ${t}`;
				}
				return `Չափազանց մեծ արժեք․ սպասվում է, որ ${B(e.origin ?? "արժեք")} լինի ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				if (r) {
					let t = dl(Number(e.minimum), r.unit.one, r.unit.many);
					return `Չափազանց փոքր արժեք․ սպասվում է, որ ${B(e.origin)} կունենա ${n}${e.minimum.toString()} ${t}`;
				}
				return `Չափազանց փոքր արժեք․ սպասվում է, որ ${B(e.origin)} լինի ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Սխալ տող․ պետք է սկսվի "${t.prefix}"-ով` : t.format === "ends_with" ? `Սխալ տող․ պետք է ավարտվի "${t.suffix}"-ով` : t.format === "includes" ? `Սխալ տող․ պետք է պարունակի "${t.includes}"` : t.format === "regex" ? `Սխալ տող․ պետք է համապատասխանի ${t.pattern} ձևաչափին` : `Սխալ ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Սխալ թիվ․ պետք է բազմապատիկ լինի ${e.divisor}-ի`;
			case "unrecognized_keys": return `Չճանաչված բանալի${e.keys.length > 1 ? "ներ" : ""}. ${x(e.keys, ", ")}`;
			case "invalid_key": return `Սխալ բանալի ${B(e.origin)}-ում`;
			case "invalid_union": return "Սխալ մուտքագրում";
			case "invalid_element": return `Սխալ արժեք ${B(e.origin)}-ում`;
			default: return "Սխալ մուտքագրում";
		}
	};
};
function pl() {
	return { localeError: fl() };
}
//#endregion
//#region node_modules/zod/v4/locales/id.js
var ml = () => {
	let e = {
		string: {
			unit: "karakter",
			verb: "memiliki"
		},
		file: {
			unit: "byte",
			verb: "memiliki"
		},
		array: {
			unit: "item",
			verb: "memiliki"
		},
		set: {
			unit: "item",
			verb: "memiliki"
		},
		map: {
			unit: "item",
			verb: "memiliki"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "alamat email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "tanggal dan waktu format ISO",
		date: "tanggal format ISO",
		time: "jam format ISO",
		duration: "durasi format ISO",
		ipv4: "alamat IPv4",
		ipv6: "alamat IPv6",
		mac: "alamat MAC",
		cidrv4: "rentang alamat IPv4",
		cidrv6: "rentang alamat IPv6",
		base64: "string dengan enkode base64",
		base64url: "string dengan enkode base64url",
		json_string: "string JSON",
		e164: "angka E.164",
		credit_card: "nomor kartu kredit",
		jwt: "JWT",
		template_literal: "input"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Input tidak valid: diharapkan instanceof ${e.expected}, diterima ${i}` : `Input tidak valid: diharapkan ${t}, diterima ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Input tidak valid: diharapkan ${P(e.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Terlalu besar: diharapkan ${e.origin ?? "value"} memiliki ${n}${e.maximum.toString()} ${r.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${e.origin ?? "value"} menjadi ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Terlalu kecil: diharapkan ${e.origin} memiliki ${n}${e.minimum.toString()} ${r.unit}` : `Terlalu kecil: diharapkan ${e.origin} menjadi ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${t.prefix}"` : t.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${t.suffix}"` : t.format === "includes" ? `String tidak valid: harus menyertakan "${t.includes}"` : t.format === "regex" ? `String tidak valid: harus sesuai pola ${t.pattern}` : `${n[t.format] ?? e.format} tidak valid`;
			}
			case "not_multiple_of": return `Angka tidak valid: harus kelipatan dari ${e.divisor}`;
			case "unrecognized_keys": return `Kunci tidak dikenali ${e.keys.length > 1 ? "s" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Kunci tidak valid di ${e.origin}`;
			case "invalid_union": return "Input tidak valid";
			case "invalid_element": return `Nilai tidak valid di ${e.origin}`;
			default: return "Input tidak valid";
		}
	};
};
function hl() {
	return { localeError: ml() };
}
//#endregion
//#region node_modules/zod/v4/locales/is.js
var gl = () => {
	let e = {
		string: {
			unit: "stafi",
			verb: "að hafa"
		},
		file: {
			unit: "bæti",
			verb: "að hafa"
		},
		array: {
			unit: "hluti",
			verb: "að hafa"
		},
		set: {
			unit: "hluti",
			verb: "að hafa"
		},
		map: {
			unit: "hluti",
			verb: "að hafa"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "gildi",
		email: "netfang",
		url: "vefslóð",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO dagsetning og tími",
		date: "ISO dagsetning",
		time: "ISO tími",
		duration: "ISO tímalengd",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded strengur",
		base64url: "base64url-encoded strengur",
		json_string: "JSON strengur",
		e164: "E.164 tölugildi",
		credit_card: "kreditkortanúmer",
		jwt: "JWT",
		template_literal: "gildi"
	}, r = {
		nan: "NaN",
		number: "númer",
		array: "fylki"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Rangt gildi: Þú slóst inn ${i} þar sem á að vera instanceof ${e.expected}` : `Rangt gildi: Þú slóst inn ${i} þar sem á að vera ${t}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Rangt gildi: gert ráð fyrir ${P(e.values[0])}` : `Ógilt val: má vera eitt af eftirfarandi ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Of stórt: gert er ráð fyrir að ${e.origin ?? "gildi"} hafi ${n}${e.maximum.toString()} ${r.unit ?? "hluti"}` : `Of stórt: gert er ráð fyrir að ${e.origin ?? "gildi"} sé ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Of lítið: gert er ráð fyrir að ${e.origin} hafi ${n}${e.minimum.toString()} ${r.unit}` : `Of lítið: gert er ráð fyrir að ${e.origin} sé ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ógildur strengur: verður að byrja á "${t.prefix}"` : t.format === "ends_with" ? `Ógildur strengur: verður að enda á "${t.suffix}"` : t.format === "includes" ? `Ógildur strengur: verður að innihalda "${t.includes}"` : t.format === "regex" ? `Ógildur strengur: verður að fylgja mynstri ${t.pattern}` : `Rangt ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Röng tala: verður að vera margfeldi af ${e.divisor}`;
			case "unrecognized_keys": return `Óþekkt ${e.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Rangur lykill í ${e.origin}`;
			case "invalid_union": return "Rangt gildi";
			case "invalid_element": return `Rangt gildi í ${e.origin}`;
			default: return "Rangt gildi";
		}
	};
};
function _l() {
	return { localeError: gl() };
}
//#endregion
//#region node_modules/zod/v4/locales/it.js
var vl = () => {
	let e = {
		string: {
			unit: "caratteri",
			verb: "avere"
		},
		file: {
			unit: "byte",
			verb: "avere"
		},
		array: {
			unit: "elementi",
			verb: "avere"
		},
		set: {
			unit: "elementi",
			verb: "avere"
		},
		map: {
			unit: "elementi",
			verb: "avere"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "indirizzo email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "data e ora ISO",
		date: "data ISO",
		time: "ora ISO",
		duration: "durata ISO",
		ipv4: "indirizzo IPv4",
		ipv6: "indirizzo IPv6",
		mac: "indirizzo MAC",
		cidrv4: "intervallo IPv4",
		cidrv6: "intervallo IPv6",
		base64: "stringa codificata in base64",
		base64url: "URL codificata in base64",
		json_string: "stringa JSON",
		e164: "numero E.164",
		credit_card: "numero di carta di credito",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "numero",
		array: "vettore"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Input non valido: atteso instanceof ${e.expected}, ricevuto ${i}` : `Input non valido: atteso ${t}, ricevuto ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Input non valido: atteso ${P(e.values[0])}` : `Opzione non valida: atteso uno tra ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Troppo grande: ${e.origin ?? "valore"} deve avere ${n}${e.maximum.toString()} ${r.unit ?? "elementi"}` : `Troppo grande: ${e.origin ?? "valore"} deve essere ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Troppo piccolo: ${e.origin} deve avere ${n}${e.minimum.toString()} ${r.unit}` : `Troppo piccolo: ${e.origin} deve essere ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Stringa non valida: deve iniziare con "${t.prefix}"` : t.format === "ends_with" ? `Stringa non valida: deve terminare con "${t.suffix}"` : t.format === "includes" ? `Stringa non valida: deve includere "${t.includes}"` : t.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${t.pattern}` : `Input non valido: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Numero non valido: deve essere un multiplo di ${e.divisor}`;
			case "unrecognized_keys": return `Chiav${e.keys.length > 1 ? "i" : "e"} non riconosciut${e.keys.length > 1 ? "e" : "a"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Chiave non valida in ${e.origin}`;
			case "invalid_union": return "Input non valido";
			case "invalid_element": return `Valore non valido in ${e.origin}`;
			default: return "Input non valido";
		}
	};
};
function yl() {
	return { localeError: vl() };
}
//#endregion
//#region node_modules/zod/v4/locales/ja.js
var bl = () => {
	let e = {
		string: {
			unit: "文字",
			verb: "である"
		},
		file: {
			unit: "バイト",
			verb: "である"
		},
		array: {
			unit: "要素",
			verb: "である"
		},
		set: {
			unit: "要素",
			verb: "である"
		},
		map: {
			unit: "要素",
			verb: "である"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "入力値",
		email: "メールアドレス",
		url: "URL",
		emoji: "絵文字",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO日時",
		date: "ISO日付",
		time: "ISO時刻",
		duration: "ISO期間",
		ipv4: "IPv4アドレス",
		ipv6: "IPv6アドレス",
		mac: "MACアドレス",
		cidrv4: "IPv4範囲",
		cidrv6: "IPv6範囲",
		base64: "base64エンコード文字列",
		base64url: "base64urlエンコード文字列",
		json_string: "JSON文字列",
		e164: "E.164番号",
		credit_card: "クレジットカード番号",
		jwt: "JWT",
		template_literal: "入力値"
	}, r = {
		nan: "NaN",
		number: "数値",
		array: "配列"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `無効な入力: instanceof ${e.expected}が期待されましたが、${i}が入力されました` : `無効な入力: ${t}が期待されましたが、${i}が入力されました`;
			}
			case "invalid_value": return e.values.length === 1 ? `無効な入力: ${P(e.values[0])}が期待されました` : `無効な選択: ${x(e.values, "、")}のいずれかである必要があります`;
			case "too_big": {
				let n = e.inclusive ? "以下である" : "より小さい", r = t(e.origin);
				return r ? `大きすぎる値: ${e.origin ?? "値"}は${e.maximum.toString()}${r.unit ?? "要素"}${n}必要があります` : `大きすぎる値: ${e.origin ?? "値"}は${e.maximum.toString()}${n}必要があります`;
			}
			case "too_small": {
				let n = e.inclusive ? "以上である" : "より大きい", r = t(e.origin);
				return r ? `小さすぎる値: ${e.origin}は${e.minimum.toString()}${r.unit}${n}必要があります` : `小さすぎる値: ${e.origin}は${e.minimum.toString()}${n}必要があります`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `無効な文字列: "${t.prefix}"で始まる必要があります` : t.format === "ends_with" ? `無効な文字列: "${t.suffix}"で終わる必要があります` : t.format === "includes" ? `無効な文字列: "${t.includes}"を含む必要があります` : t.format === "regex" ? `無効な文字列: パターン${t.pattern}に一致する必要があります` : `無効な${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `無効な数値: ${e.divisor}の倍数である必要があります`;
			case "unrecognized_keys": return `認識されていないキー${e.keys.length > 1 ? "群" : ""}: ${x(e.keys, "、")}`;
			case "invalid_key": return `${e.origin}内の無効なキー`;
			case "invalid_union": return "無効な入力";
			case "invalid_element": return `${e.origin}内の無効な値`;
			default: return "無効な入力";
		}
	};
};
function xl() {
	return { localeError: bl() };
}
//#endregion
//#region node_modules/zod/v4/locales/ka.js
var Sl = () => {
	let e = {
		string: {
			unit: "სიმბოლო",
			verb: "უნდა შეიცავდეს"
		},
		file: {
			unit: "ბაიტი",
			verb: "უნდა შეიცავდეს"
		},
		array: {
			unit: "ელემენტი",
			verb: "უნდა შეიცავდეს"
		},
		set: {
			unit: "ელემენტი",
			verb: "უნდა შეიცავდეს"
		},
		map: {
			unit: "ელემენტი",
			verb: "უნდა შეიცავდეს"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "შეყვანა",
		email: "ელ-ფოსტის მისამართი",
		url: "URL",
		emoji: "ემოჯი",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "თარიღი-დრო",
		date: "თარიღი",
		time: "დრო",
		duration: "ხანგრძლივობა",
		ipv4: "IPv4 მისამართი",
		ipv6: "IPv6 მისამართი",
		mac: "MAC მისამართი",
		cidrv4: "IPv4 დიაპაზონი",
		cidrv6: "IPv6 დიაპაზონი",
		base64: "base64-კოდირებული ველი",
		base64url: "base64url-კოდირებული ველი",
		json_string: "JSON ველი",
		e164: "E.164 ნომერი",
		credit_card: "საკრედიტო ბარათის ნომერი",
		jwt: "JWT",
		template_literal: "შეყვანა"
	}, r = {
		nan: "NaN",
		number: "რიცხვი",
		string: "ველი",
		boolean: "ბულეანი",
		function: "ფუნქცია",
		array: "მასივი"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `არასწორი შეყვანა: მოსალოდნელი instanceof ${e.expected}, მიღებული ${i}` : `არასწორი შეყვანა: მოსალოდნელი ${t}, მიღებული ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `არასწორი შეყვანა: მოსალოდნელი ${P(e.values[0])}` : `არასწორი ვარიანტი: მოსალოდნელია ერთ-ერთი ${x(e.values, "|")}-დან`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ზედმეტად დიდი: მოსალოდნელი ${e.origin ?? "მნიშვნელობა"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit}` : `ზედმეტად დიდი: მოსალოდნელი ${e.origin ?? "მნიშვნელობა"} იყოს ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `ზედმეტად პატარა: მოსალოდნელი ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `ზედმეტად პატარა: მოსალოდნელი ${e.origin} იყოს ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `არასწორი ველი: უნდა იწყებოდეს "${t.prefix}"-ით` : t.format === "ends_with" ? `არასწორი ველი: უნდა მთავრდებოდეს "${t.suffix}"-ით` : t.format === "includes" ? `არასწორი ველი: უნდა შეიცავდეს "${t.includes}"-ს` : t.format === "regex" ? `არასწორი ველი: უნდა შეესაბამებოდეს შაბლონს ${t.pattern}` : `არასწორი ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `არასწორი რიცხვი: უნდა იყოს ${e.divisor}-ის ჯერადი`;
			case "unrecognized_keys": return `უცნობი გასაღებ${e.keys.length > 1 ? "ები" : "ი"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `არასწორი გასაღები ${e.origin}-ში`;
			case "invalid_union": return "არასწორი შეყვანა";
			case "invalid_element": return `არასწორი მნიშვნელობა ${e.origin}-ში`;
			default: return "არასწორი შეყვანა";
		}
	};
};
function Cl() {
	return { localeError: Sl() };
}
//#endregion
//#region node_modules/zod/v4/locales/km.js
var wl = () => {
	let e = {
		string: {
			unit: "តួអក្សរ",
			verb: "គួរមាន"
		},
		file: {
			unit: "បៃ",
			verb: "គួរមាន"
		},
		array: {
			unit: "ធាតុ",
			verb: "គួរមាន"
		},
		set: {
			unit: "ធាតុ",
			verb: "គួរមាន"
		},
		map: {
			unit: "ធាតុ",
			verb: "គួរមាន"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ទិន្នន័យបញ្ចូល",
		email: "អាសយដ្ឋានអ៊ីមែល",
		url: "URL",
		emoji: "សញ្ញាអារម្មណ៍",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "កាលបរិច្ឆេទ និងម៉ោង ISO",
		date: "កាលបរិច្ឆេទ ISO",
		time: "ម៉ោង ISO",
		duration: "រយៈពេល ISO",
		ipv4: "អាសយដ្ឋាន IPv4",
		ipv6: "អាសយដ្ឋាន IPv6",
		mac: "អាសយដ្ឋាន MAC",
		cidrv4: "ដែនអាសយដ្ឋាន IPv4",
		cidrv6: "ដែនអាសយដ្ឋាន IPv6",
		base64: "ខ្សែអក្សរអ៊ិកូដ base64",
		base64url: "ខ្សែអក្សរអ៊ិកូដ base64url",
		json_string: "ខ្សែអក្សរ JSON",
		e164: "លេខ E.164",
		credit_card: "លេខប័ណ្ណឥណទាន",
		jwt: "JWT",
		template_literal: "ទិន្នន័យបញ្ចូល"
	}, r = {
		nan: "NaN",
		number: "លេខ",
		array: "អារេ (Array)",
		null: "គ្មានតម្លៃ (null)"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ instanceof ${e.expected} ប៉ុន្តែទទួលបាន ${i}` : `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ ${t} ប៉ុន្តែទទួលបាន ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ ${P(e.values[0])}` : `ជម្រើសមិនត្រឹមត្រូវ៖ ត្រូវជាមួយក្នុងចំណោម ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ធំពេក៖ ត្រូវការ ${e.origin ?? "តម្លៃ"} ${n} ${e.maximum.toString()} ${r.unit ?? "ធាតុ"}` : `ធំពេក៖ ត្រូវការ ${e.origin ?? "តម្លៃ"} ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `តូចពេក៖ ត្រូវការ ${e.origin} ${n} ${e.minimum.toString()} ${r.unit}` : `តូចពេក៖ ត្រូវការ ${e.origin} ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវចាប់ផ្តើមដោយ "${t.prefix}"` : t.format === "ends_with" ? `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវបញ្ចប់ដោយ "${t.suffix}"` : t.format === "includes" ? `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវមាន "${t.includes}"` : t.format === "regex" ? `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវតែផ្គូផ្គងនឹងទម្រង់ដែលបានកំណត់ ${t.pattern}` : `មិនត្រឹមត្រូវ៖ ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `លេខមិនត្រឹមត្រូវ៖ ត្រូវតែជាពហុគុណនៃ ${e.divisor}`;
			case "unrecognized_keys": return `រកឃើញសោមិនស្គាល់៖ ${x(e.keys, ", ")}`;
			case "invalid_key": return `សោមិនត្រឹមត្រូវនៅក្នុង ${e.origin}`;
			case "invalid_union": return "ទិន្នន័យមិនត្រឹមត្រូវ";
			case "invalid_element": return `ទិន្នន័យមិនត្រឹមត្រូវនៅក្នុង ${e.origin}`;
			default: return "ទិន្នន័យមិនត្រឹមត្រូវ";
		}
	};
};
function Tl() {
	return { localeError: wl() };
}
//#endregion
//#region node_modules/zod/v4/locales/kh.js
function El() {
	return Tl();
}
//#endregion
//#region node_modules/zod/v4/locales/kn.js
var Dl = () => {
	let e = {
		string: {
			unit: "ಅಕ್ಷರಗಳು",
			verb: "ಹೊಂದಲು"
		},
		file: {
			unit: "ಬೈಟ್‌ಗಳು",
			verb: "ಹೊಂದಲು"
		},
		array: {
			unit: "ವಸ್ತುಗಳು",
			verb: "ಹೊಂದಲು"
		},
		set: {
			unit: "ವಸ್ತುಗಳು",
			verb: "ಹೊಂದಲು"
		},
		map: {
			unit: "entries",
			verb: "ಹೊಂದಲು"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ಇನ್ಪುಟ್",
		email: "email ವಿಳಾಸ",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO ದಿನಾಂಕದ ಸಮಯ",
		date: "ISO ದಿನಾಂಕ",
		time: "ISO ಸಮಯ",
		duration: "ISO ಅವಧಿ",
		ipv4: "IPv4 ವಿಳಾಸ",
		ipv6: "IPv6 ವಿಳಾಸ",
		mac: "MAC ವಿಳಾಸ",
		cidrv4: "IPv4 ವ್ಯಾಪ್ತಿಯ",
		cidrv6: "IPv6 ವ್ಯಾಪ್ತಿಯ",
		base64: "base64-encodedಸ್ಟ್ರಿಂಗ್",
		base64url: "base64url-encodedಸ್ಟ್ರಿಂಗ್",
		json_string: "JSONಸ್ಟ್ರಿಂಗ್",
		e164: "E.164 ಸಂಖ್ಯೆ",
		credit_card: "ಕ್ರೆಡಿಟ್ ಕಾರ್ಡ್ ಸಂಖ್ಯೆ",
		jwt: "JWT",
		template_literal: "ಇನ್ಪುಟ್"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input);
				return `ಅಮಾನ್ಯ ಇನ್‌ಪುಟ್: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${t}, ಸ್ವೀಕರಿಸಿದನು ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `ಅಮಾನ್ಯ ಇನ್‌ಪುಟ್: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${P(e.values[0])}` : `ಅಮಾನ್ಯ ಆಯ್ಕೆ: ಇವುಗಳಲ್ಲಿ ಒಂದನ್ನು ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ತುಂಬಾ ದೊಡ್ಡದು: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.origin ?? "value"} ಹೊಂದಲು ${n}${e.maximum.toString()} ${r.unit ?? "ಅಂಶಗಳು"}` : `ತುಂಬಾ ದೊಡ್ಡದು: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.origin ?? "value"} ಎಂದು ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `ತುಂಬಾ ಚಿಕ್ಕದು: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.origin} ಹೊಂದಲು ${n}${e.minimum.toString()} ${r.unit}` : `ತುಂಬಾ ಚಿಕ್ಕದು: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.origin} ಎಂದು ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `ಅಮಾನ್ಯವಾದ ಸ್ಟ್ರಿಂಗ್: ಇದರೊಂದಿಗೆ ಪ್ರಾರಂಭಿಸಬೇಕು "${t.prefix}"` : t.format === "ends_with" ? `ಅಮಾನ್ಯವಾದ ಸ್ಟ್ರಿಂಗ್: ಇದರೊಂದಿಗೆ ಕೊನೆಗೊಳ್ಳಬೇಕು "${t.suffix}"` : t.format === "includes" ? `ಅಮಾನ್ಯ ಸ್ಟ್ರಿಂಗ್: ಒಳಗೊಂಡಿರಬೇಕು "${t.includes}"` : t.format === "regex" ? `ಅಮಾನ್ಯವಾದ ಸ್ಟ್ರಿಂಗ್: ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗಬೇಕು ${t.pattern}` : `ಅಮಾನ್ಯ ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `ಅಮಾನ್ಯ ಸಂಖ್ಯೆ: ಬಹುಸಂಖ್ಯೆಯಾಗಿರಬೇಕು ${e.divisor}`;
			case "unrecognized_keys": return `ಗುರುತಿಸಲಾಗದ ಕೀ ${e.keys.length > 1 ? "s" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `ಅಮಾನ್ಯವಾದ ಕೀ ಇನ್ ${e.origin}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `ಅಮಾನ್ಯ ತಾರತಮ್ಯ ಮೌಲ್ಯ. ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.options.map((e) => `'${e}'`).join(" | ")}` : "ಅಮಾನ್ಯ ಇನ್‌ಪುಟ್";
			case "invalid_element": return `ರಲ್ಲಿ ಅಮಾನ್ಯ ಮೌಲ್ಯ ${e.origin}`;
			default: return "ಅಮಾನ್ಯ ಇನ್‌ಪುಟ್";
		}
	};
};
function Ol() {
	return { localeError: Dl() };
}
//#endregion
//#region node_modules/zod/v4/locales/ko.js
var kl = () => {
	let e = {
		string: {
			unit: "문자",
			verb: "to have"
		},
		file: {
			unit: "바이트",
			verb: "to have"
		},
		array: {
			unit: "개",
			verb: "to have"
		},
		set: {
			unit: "개",
			verb: "to have"
		},
		map: {
			unit: "개",
			verb: "to have"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "입력",
		email: "이메일 주소",
		url: "URL",
		emoji: "이모지",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO 날짜시간",
		date: "ISO 날짜",
		time: "ISO 시간",
		duration: "ISO 기간",
		ipv4: "IPv4 주소",
		ipv6: "IPv6 주소",
		mac: "MAC 주소",
		cidrv4: "IPv4 범위",
		cidrv6: "IPv6 범위",
		base64: "base64 인코딩 문자열",
		base64url: "base64url 인코딩 문자열",
		json_string: "JSON 문자열",
		e164: "E.164 번호",
		credit_card: "신용카드 번호",
		jwt: "JWT",
		template_literal: "입력"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `잘못된 입력: 예상 타입은 instanceof ${e.expected}, 받은 타입은 ${i}입니다` : `잘못된 입력: 예상 타입은 ${t}, 받은 타입은 ${i}입니다`;
			}
			case "invalid_value": return e.values.length === 1 ? `잘못된 입력: 값은 ${P(e.values[0])} 이어야 합니다` : `잘못된 옵션: ${x(e.values, "또는 ")} 중 하나여야 합니다`;
			case "too_big": {
				let n = e.inclusive ? "이하" : "미만", r = n === "미만" ? "이어야 합니다" : "여야 합니다", i = t(e.origin), a = i?.unit ?? "요소";
				return i ? `${e.origin ?? "값"}이 너무 큽니다: ${e.maximum.toString()}${a} ${n}${r}` : `${e.origin ?? "값"}이 너무 큽니다: ${e.maximum.toString()} ${n}${r}`;
			}
			case "too_small": {
				let n = e.inclusive ? "이상" : "초과", r = n === "이상" ? "이어야 합니다" : "여야 합니다", i = t(e.origin), a = i?.unit ?? "요소";
				return i ? `${e.origin ?? "값"}이 너무 작습니다: ${e.minimum.toString()}${a} ${n}${r}` : `${e.origin ?? "값"}이 너무 작습니다: ${e.minimum.toString()} ${n}${r}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `잘못된 문자열: "${t.prefix}"(으)로 시작해야 합니다` : t.format === "ends_with" ? `잘못된 문자열: "${t.suffix}"(으)로 끝나야 합니다` : t.format === "includes" ? `잘못된 문자열: "${t.includes}"을(를) 포함해야 합니다` : t.format === "regex" ? `잘못된 문자열: 정규식 ${t.pattern} 패턴과 일치해야 합니다` : `잘못된 ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `잘못된 숫자: ${e.divisor}의 배수여야 합니다`;
			case "unrecognized_keys": return `인식할 수 없는 키: ${x(e.keys, ", ")}`;
			case "invalid_key": return `잘못된 키: ${e.origin}`;
			case "invalid_union": return "잘못된 입력";
			case "invalid_element": return `잘못된 값: ${e.origin}`;
			default: return "잘못된 입력";
		}
	};
};
function Al() {
	return { localeError: kl() };
}
//#endregion
//#region node_modules/zod/v4/locales/lt.js
var jl = (e) => e.charAt(0).toUpperCase() + e.slice(1);
function Ml(e) {
	let t = Math.abs(e), n = t % 10, r = t % 100;
	return r >= 11 && r <= 19 || n === 0 ? "many" : n === 1 ? "one" : "few";
}
var Nl = () => {
	let e = {
		string: {
			unit: {
				one: "simbolis",
				few: "simboliai",
				many: "simbolių"
			},
			verb: {
				smaller: {
					inclusive: "turi būti ne ilgesnė kaip",
					notInclusive: "turi būti trumpesnė kaip"
				},
				bigger: {
					inclusive: "turi būti ne trumpesnė kaip",
					notInclusive: "turi būti ilgesnė kaip"
				}
			}
		},
		file: {
			unit: {
				one: "baitas",
				few: "baitai",
				many: "baitų"
			},
			verb: {
				smaller: {
					inclusive: "turi būti ne didesnis kaip",
					notInclusive: "turi būti mažesnis kaip"
				},
				bigger: {
					inclusive: "turi būti ne mažesnis kaip",
					notInclusive: "turi būti didesnis kaip"
				}
			}
		},
		array: {
			unit: {
				one: "elementą",
				few: "elementus",
				many: "elementų"
			},
			verb: {
				smaller: {
					inclusive: "turi turėti ne daugiau kaip",
					notInclusive: "turi turėti mažiau kaip"
				},
				bigger: {
					inclusive: "turi turėti ne mažiau kaip",
					notInclusive: "turi turėti daugiau kaip"
				}
			}
		},
		set: {
			unit: {
				one: "elementą",
				few: "elementus",
				many: "elementų"
			},
			verb: {
				smaller: {
					inclusive: "turi turėti ne daugiau kaip",
					notInclusive: "turi turėti mažiau kaip"
				},
				bigger: {
					inclusive: "turi turėti ne mažiau kaip",
					notInclusive: "turi turėti daugiau kaip"
				}
			}
		}
	};
	function t(t, n, r, i) {
		let a = e[t] ?? null;
		return a === null ? a : {
			unit: a.unit[n],
			verb: a.verb[i][r ? "inclusive" : "notInclusive"]
		};
	}
	let n = {
		regex: "įvestis",
		email: "el. pašto adresas",
		url: "URL",
		emoji: "jaustukas",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO data ir laikas",
		date: "ISO data",
		time: "ISO laikas",
		duration: "ISO trukmė",
		ipv4: "IPv4 adresas",
		ipv6: "IPv6 adresas",
		mac: "MAC adresas",
		cidrv4: "IPv4 tinklo prefiksas (CIDR)",
		cidrv6: "IPv6 tinklo prefiksas (CIDR)",
		base64: "base64 užkoduota eilutė",
		base64url: "base64url užkoduota eilutė",
		json_string: "JSON eilutė",
		e164: "E.164 numeris",
		credit_card: "kredito kortelės numeris",
		jwt: "JWT",
		template_literal: "įvestis"
	}, r = {
		nan: "NaN",
		number: "skaičius",
		bigint: "sveikasis skaičius",
		string: "eilutė",
		boolean: "loginė reikšmė",
		undefined: "neapibrėžta reikšmė",
		function: "funkcija",
		symbol: "simbolis",
		array: "masyvas",
		object: "objektas",
		null: "nulinė reikšmė"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Gautas tipas ${i}, o tikėtasi - instanceof ${e.expected}` : `Gautas tipas ${i}, o tikėtasi - ${t}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Privalo būti ${P(e.values[0])}` : `Privalo būti vienas iš ${x(e.values, "|")} pasirinkimų`;
			case "too_big": {
				let n = r[e.origin] ?? e.origin, i = t(e.origin, Ml(Number(e.maximum)), e.inclusive ?? !1, "smaller");
				if (i?.verb) return `${jl(n ?? e.origin ?? "reikšmė")} ${i.verb} ${e.maximum.toString()} ${i.unit ?? "elementų"}`;
				let a = e.inclusive ? "ne didesnis kaip" : "mažesnis kaip";
				return `${jl(n ?? e.origin ?? "reikšmė")} turi būti ${a} ${e.maximum.toString()} ${i?.unit}`;
			}
			case "too_small": {
				let n = r[e.origin] ?? e.origin, i = t(e.origin, Ml(Number(e.minimum)), e.inclusive ?? !1, "bigger");
				if (i?.verb) return `${jl(n ?? e.origin ?? "reikšmė")} ${i.verb} ${e.minimum.toString()} ${i.unit ?? "elementų"}`;
				let a = e.inclusive ? "ne mažesnis kaip" : "didesnis kaip";
				return `${jl(n ?? e.origin ?? "reikšmė")} turi būti ${a} ${e.minimum.toString()} ${i?.unit}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Eilutė privalo prasidėti "${t.prefix}"` : t.format === "ends_with" ? `Eilutė privalo pasibaigti "${t.suffix}"` : t.format === "includes" ? `Eilutė privalo įtraukti "${t.includes}"` : t.format === "regex" ? `Eilutė privalo atitikti ${t.pattern}` : `Neteisingas ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Skaičius privalo būti ${e.divisor} kartotinis.`;
			case "unrecognized_keys": return `Neatpažint${e.keys.length > 1 ? "i" : "as"} rakt${e.keys.length > 1 ? "ai" : "as"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return "Rastas klaidingas raktas";
			case "invalid_union": return "Klaidinga įvestis";
			case "invalid_element": return `${jl(r[e.origin] ?? e.origin ?? e.origin ?? "reikšmė")} turi klaidingą įvestį`;
			default: return "Klaidinga įvestis";
		}
	};
};
function Pl() {
	return { localeError: Nl() };
}
//#endregion
//#region node_modules/zod/v4/locales/mk.js
var Fl = () => {
	let e = {
		string: {
			unit: "знаци",
			verb: "да имаат"
		},
		file: {
			unit: "бајти",
			verb: "да имаат"
		},
		array: {
			unit: "ставки",
			verb: "да имаат"
		},
		set: {
			unit: "ставки",
			verb: "да имаат"
		},
		map: {
			unit: "ставки",
			verb: "да имаат"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "внес",
		email: "адреса на е-пошта",
		url: "URL",
		emoji: "емоџи",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO датум и време",
		date: "ISO датум",
		time: "ISO време",
		duration: "ISO времетраење",
		ipv4: "IPv4 адреса",
		ipv6: "IPv6 адреса",
		mac: "MAC адреса",
		cidrv4: "IPv4 опсег",
		cidrv6: "IPv6 опсег",
		base64: "base64-енкодирана низа",
		base64url: "base64url-енкодирана низа",
		json_string: "JSON низа",
		e164: "E.164 број",
		credit_card: "број на кредитна картичка",
		jwt: "JWT",
		template_literal: "внес"
	}, r = {
		nan: "NaN",
		number: "број",
		array: "низа"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Грешен внес: се очекува instanceof ${e.expected}, примено ${i}` : `Грешен внес: се очекува ${t}, примено ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Invalid input: expected ${P(e.values[0])}` : `Грешана опција: се очекува една ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Премногу голем: се очекува ${e.origin ?? "вредноста"} да има ${n}${e.maximum.toString()} ${r.unit ?? "елементи"}` : `Премногу голем: се очекува ${e.origin ?? "вредноста"} да биде ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Премногу мал: се очекува ${e.origin} да има ${n}${e.minimum.toString()} ${r.unit}` : `Премногу мал: се очекува ${e.origin} да биде ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Неважечка низа: мора да започнува со "${t.prefix}"` : t.format === "ends_with" ? `Неважечка низа: мора да завршува со "${t.suffix}"` : t.format === "includes" ? `Неважечка низа: мора да вклучува "${t.includes}"` : t.format === "regex" ? `Неважечка низа: мора да одгоара на патернот ${t.pattern}` : `Invalid ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Грешен број: мора да биде делив со ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Непрепознаени клучеви" : "Непрепознаен клуч"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Грешен клуч во ${e.origin}`;
			case "invalid_union": return "Грешен внес";
			case "invalid_element": return `Грешна вредност во ${e.origin}`;
			default: return "Грешен внес";
		}
	};
};
function Il() {
	return { localeError: Fl() };
}
//#endregion
//#region node_modules/zod/v4/locales/ms.js
var Ll = () => {
	let e = {
		string: {
			unit: "aksara",
			verb: "mempunyai"
		},
		file: {
			unit: "bait",
			verb: "mempunyai"
		},
		array: {
			unit: "elemen",
			verb: "mempunyai"
		},
		set: {
			unit: "elemen",
			verb: "mempunyai"
		},
		map: {
			unit: "elemen",
			verb: "mempunyai"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "alamat e-mel",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "tarikh masa ISO",
		date: "tarikh ISO",
		time: "masa ISO",
		duration: "tempoh ISO",
		ipv4: "alamat IPv4",
		ipv6: "alamat IPv6",
		mac: "alamat MAC",
		cidrv4: "julat IPv4",
		cidrv6: "julat IPv6",
		base64: "string dikodkan base64",
		base64url: "string dikodkan base64url",
		json_string: "string JSON",
		e164: "nombor E.164",
		credit_card: "nombor kad kredit",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "nombor"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Input tidak sah: dijangka instanceof ${e.expected}, diterima ${i}` : `Input tidak sah: dijangka ${t}, diterima ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Input tidak sah: dijangka ${P(e.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Terlalu besar: dijangka ${e.origin ?? "nilai"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit ?? "elemen"}` : `Terlalu besar: dijangka ${e.origin ?? "nilai"} adalah ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Terlalu kecil: dijangka ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `Terlalu kecil: dijangka ${e.origin} adalah ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${t.prefix}"` : t.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${t.suffix}"` : t.format === "includes" ? `String tidak sah: mesti mengandungi "${t.includes}"` : t.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${t.pattern}` : `${n[t.format] ?? e.format} tidak sah`;
			}
			case "not_multiple_of": return `Nombor tidak sah: perlu gandaan ${e.divisor}`;
			case "unrecognized_keys": return `Kunci tidak dikenali: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Kunci tidak sah dalam ${e.origin}`;
			case "invalid_union": return "Input tidak sah";
			case "invalid_element": return `Nilai tidak sah dalam ${e.origin}`;
			default: return "Input tidak sah";
		}
	};
};
function Rl() {
	return { localeError: Ll() };
}
//#endregion
//#region node_modules/zod/v4/locales/ne.js
var zl = () => {
	let e = {
		string: {
			unit: "अक्षर",
			verb: "हुनुपर्छ"
		},
		file: {
			unit: "बाइट",
			verb: "हुनुपर्छ"
		},
		array: {
			unit: "तत्व",
			verb: "हुनुपर्छ"
		},
		set: {
			unit: "तत्व",
			verb: "हुनुपर्छ"
		},
		map: {
			unit: "प्रविष्टि",
			verb: "हुनुपर्छ"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "इनपुट",
		email: "इमेल ठेगाना",
		url: "URL",
		emoji: "इमोजी",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO मिति र समय",
		date: "ISO मिति",
		time: "ISO समय",
		duration: "ISO अवधि",
		ipv4: "IPv4 ठेगाना",
		ipv6: "IPv6 ठेगाना",
		mac: "MAC ठेगाना",
		cidrv4: "IPv4 दायरा",
		cidrv6: "IPv6 दायरा",
		base64: "base64-इन्कोड गरिएको स्ट्रिङ",
		base64url: "base64url-इन्कोड गरिएको स्ट्रिङ",
		json_string: "JSON स्ट्रिङ",
		e164: "E.164 नम्बर",
		credit_card: "क्रेडिट कार्ड नम्बर",
		jwt: "JWT",
		template_literal: "इनपुट"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input);
				return `अमान्य इनपुट: अपेक्षित ${t}, प्राप्त ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `अमान्य इनपुट: अपेक्षित ${P(e.values[0])}` : `अमान्य विकल्प: अपेक्षित मानहरू मध्ये एक ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `धेरै ठूलो: ${e.origin ?? "मान"} मा ${n}${e.maximum.toString()} ${r.unit} ${r.verb}` : `धेरै ठूलो: ${e.origin ?? "मान"} ${n}${e.maximum.toString()} हुनुपर्छ`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `धेरै सानो: ${e.origin} मा ${n}${e.minimum.toString()} ${r.unit} ${r.verb}` : `धेरै सानो: ${e.origin} ${n}${e.minimum.toString()} हुनुपर्छ`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `अमान्य स्ट्रिङ: "${t.prefix}" बाट सुरु हुनुपर्छ` : t.format === "ends_with" ? `अमान्य स्ट्रिङ: "${t.suffix}" मा समाप्त हुनुपर्छ` : t.format === "includes" ? `अमान्य स्ट्रिङ: "${t.includes}" समावेश हुनुपर्छ` : t.format === "regex" ? `अमान्य स्ट्रिङ: ढाँचा ${t.pattern} सँग मेल खानुपर्छ` : `अमान्य ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `अमान्य संख्या: ${e.divisor} को गुणज हुनुपर्छ`;
			case "unrecognized_keys": return `अपरिचित कुञ्जी${e.keys.length > 1 ? "हरू" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `अमान्य कुञ्जी: ${e.origin} मा`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `अमान्य डिस्क्रिमिनेटर मान: अपेक्षित ${e.options.map((e) => `'${e}'`).join(" | ")}` : "अमान्य इनपुट";
			case "invalid_element": return `अमान्य मान: ${e.origin} मा`;
			default: return "अमान्य इनपुट";
		}
	};
};
function Bl() {
	return { localeError: zl() };
}
//#endregion
//#region node_modules/zod/v4/locales/nl.js
var Vl = () => {
	let e = {
		string: {
			unit: "tekens",
			verb: "heeft"
		},
		file: {
			unit: "bytes",
			verb: "heeft"
		},
		array: {
			unit: "elementen",
			verb: "heeft"
		},
		set: {
			unit: "elementen",
			verb: "heeft"
		},
		map: {
			unit: "elementen",
			verb: "heeft"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "invoer",
		email: "emailadres",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datum en tijd",
		date: "ISO datum",
		time: "ISO tijd",
		duration: "ISO duur",
		ipv4: "IPv4-adres",
		ipv6: "IPv6-adres",
		mac: "MAC-adres",
		cidrv4: "IPv4-bereik",
		cidrv6: "IPv6-bereik",
		base64: "base64-gecodeerde tekst",
		base64url: "base64 URL-gecodeerde tekst",
		json_string: "JSON string",
		e164: "E.164-nummer",
		credit_card: "creditcardnummer",
		jwt: "JWT",
		template_literal: "invoer"
	}, r = {
		nan: "NaN",
		number: "getal"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ongeldige invoer: verwacht instanceof ${e.expected}, ontving ${i}` : `Ongeldige invoer: verwacht ${t}, ontving ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ongeldige invoer: verwacht ${P(e.values[0])}` : `Ongeldige optie: verwacht één van ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin), i = e.origin === "date" ? "laat" : e.origin === "string" ? "lang" : "groot";
				return r ? `Te ${i}: verwacht dat ${e.origin ?? "waarde"} ${n}${e.maximum.toString()} ${r.unit ?? "elementen"} ${r.verb}` : `Te ${i}: verwacht dat ${e.origin ?? "waarde"} ${n}${e.maximum.toString()} is`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin), i = e.origin === "date" ? "vroeg" : e.origin === "string" ? "kort" : "klein";
				return r ? `Te ${i}: verwacht dat ${e.origin} ${n}${e.minimum.toString()} ${r.unit} ${r.verb}` : `Te ${i}: verwacht dat ${e.origin} ${n}${e.minimum.toString()} is`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ongeldige tekst: moet met "${t.prefix}" beginnen` : t.format === "ends_with" ? `Ongeldige tekst: moet op "${t.suffix}" eindigen` : t.format === "includes" ? `Ongeldige tekst: moet "${t.includes}" bevatten` : t.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${t.pattern}` : `Ongeldig: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ongeldig getal: moet een veelvoud van ${e.divisor} zijn`;
			case "unrecognized_keys": return `Onbekende key${e.keys.length > 1 ? "s" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Ongeldige key in ${e.origin}`;
			case "invalid_union": return "Ongeldige invoer";
			case "invalid_element": return `Ongeldige waarde in ${e.origin}`;
			default: return "Ongeldige invoer";
		}
	};
};
function Hl() {
	return { localeError: Vl() };
}
//#endregion
//#region node_modules/zod/v4/locales/nn.js
var Ul = () => {
	let e = {
		string: {
			unit: "teikn",
			verb: "å ha"
		},
		file: {
			unit: "bytes",
			verb: "å ha"
		},
		array: {
			unit: "element",
			verb: "å innehalde"
		},
		set: {
			unit: "element",
			verb: "å innehalde"
		},
		map: {
			unit: "element",
			verb: "å innehalde"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "e-postadresse",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO dato- og klokkeslett",
		date: "ISO-dato",
		time: "ISO-klokkeslett",
		duration: "ISO-varigheit",
		ipv4: "IPv4-adresse",
		ipv6: "IPv6-adresse",
		mac: "MAC-adresse",
		cidrv4: "IPv4-spekter",
		cidrv6: "IPv6-spekter",
		base64: "base64-enkoda streng",
		base64url: "base64url-enkoda streng",
		json_string: "JSON-streng",
		e164: "E.164-nummer",
		credit_card: "kredittkortnummer",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "tal",
		array: "liste"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ugyldig input: forventa instanceof ${e.expected}, fekk ${i}` : `Ugyldig input: forventa ${t}, fekk ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ugyldig verdi: forventa ${P(e.values[0])}` : `Ugyldig val: forventa eitt av ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `For stor(t): forventa ${e.origin ?? "value"} til å ha ${n}${e.maximum.toString()} ${r.unit ?? "element"}` : `For stor(t): forventa ${e.origin ?? "value"} til å ha ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `For lite(n): forventa ${e.origin} til å ha ${n}${e.minimum.toString()} ${r.unit}` : `For lite(n): forventa ${e.origin} til å ha ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ugyldig streng: må starte med "${t.prefix}"` : t.format === "ends_with" ? `Ugyldig streng: må slutte med "${t.suffix}"` : t.format === "includes" ? `Ugyldig streng: må innehalde "${t.includes}"` : t.format === "regex" ? `Ugyldig streng: må matche mønsteret ${t.pattern}` : `Ugyldig ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ugyldig tal: må vere eit multiplum av ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Ukjende nøklar" : "Ukjend nøkkel"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Ugyldig nøkkel i ${e.origin}`;
			case "invalid_union": return "Ugyldig input";
			case "invalid_element": return `Ugyldig verdi i ${e.origin}`;
			default: return "Ugyldig input";
		}
	};
};
function Wl() {
	return { localeError: Ul() };
}
//#endregion
//#region node_modules/zod/v4/locales/no.js
var Gl = () => {
	let e = {
		string: {
			unit: "tegn",
			verb: "å ha"
		},
		file: {
			unit: "bytes",
			verb: "å ha"
		},
		array: {
			unit: "elementer",
			verb: "å inneholde"
		},
		set: {
			unit: "elementer",
			verb: "å inneholde"
		},
		map: {
			unit: "elementer",
			verb: "å inneholde"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "e-postadresse",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO dato- og klokkeslett",
		date: "ISO-dato",
		time: "ISO-klokkeslett",
		duration: "ISO-varighet",
		ipv4: "IPv4-adresse",
		ipv6: "IPv6-adresse",
		mac: "MAC-adresse",
		cidrv4: "IPv4-spekter",
		cidrv6: "IPv6-spekter",
		base64: "base64-enkodet streng",
		base64url: "base64url-enkodet streng",
		json_string: "JSON-streng",
		e164: "E.164-nummer",
		credit_card: "kredittkortnummer",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "tall",
		array: "liste"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ugyldig input: forventet instanceof ${e.expected}, fikk ${i}` : `Ugyldig input: forventet ${t}, fikk ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ugyldig verdi: forventet ${P(e.values[0])}` : `Ugyldig valg: forventet en av ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `For stor(t): forventet ${e.origin ?? "value"} til å ha ${n}${e.maximum.toString()} ${r.unit ?? "elementer"}` : `For stor(t): forventet ${e.origin ?? "value"} til å ha ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `For lite(n): forventet ${e.origin} til å ha ${n}${e.minimum.toString()} ${r.unit}` : `For lite(n): forventet ${e.origin} til å ha ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ugyldig streng: må starte med "${t.prefix}"` : t.format === "ends_with" ? `Ugyldig streng: må ende med "${t.suffix}"` : t.format === "includes" ? `Ugyldig streng: må inneholde "${t.includes}"` : t.format === "regex" ? `Ugyldig streng: må matche mønsteret ${t.pattern}` : `Ugyldig ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ugyldig tall: må være et multiplum av ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Ukjente nøkler" : "Ukjent nøkkel"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Ugyldig nøkkel i ${e.origin}`;
			case "invalid_union": return "Ugyldig input";
			case "invalid_element": return `Ugyldig verdi i ${e.origin}`;
			default: return "Ugyldig input";
		}
	};
};
function Kl() {
	return { localeError: Gl() };
}
//#endregion
//#region node_modules/zod/v4/locales/ota.js
var ql = () => {
	let e = {
		string: {
			unit: "harf",
			verb: "olmalıdır"
		},
		file: {
			unit: "bayt",
			verb: "olmalıdır"
		},
		array: {
			unit: "unsur",
			verb: "olmalıdır"
		},
		set: {
			unit: "unsur",
			verb: "olmalıdır"
		},
		map: {
			unit: "unsur",
			verb: "olmalıdır"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "giren",
		email: "epostagâh",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO hengâmı",
		date: "ISO tarihi",
		time: "ISO zamanı",
		duration: "ISO müddeti",
		ipv4: "IPv4 nişânı",
		ipv6: "IPv6 nişânı",
		mac: "MAC nişânı",
		cidrv4: "IPv4 menzili",
		cidrv6: "IPv6 menzili",
		base64: "base64-şifreli metin",
		base64url: "base64url-şifreli metin",
		json_string: "JSON metin",
		e164: "E.164 sayısı",
		credit_card: "i'tibâr kartı numarası",
		jwt: "JWT",
		template_literal: "giren"
	}, r = {
		nan: "NaN",
		number: "numara",
		array: "saf",
		null: "gayb"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Fâsit giren: umulan instanceof ${e.expected}, alınan ${i}` : `Fâsit giren: umulan ${t}, alınan ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Fâsit giren: umulan ${P(e.values[0])}` : `Fâsit tercih: mûteberler ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Fazla büyük: ${e.origin ?? "value"}, ${n}${e.maximum.toString()} ${r.unit ?? "elements"} sahip olmalıydı.` : `Fazla büyük: ${e.origin ?? "value"}, ${n}${e.maximum.toString()} olmalıydı.`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Fazla küçük: ${e.origin}, ${n}${e.minimum.toString()} ${r.unit} sahip olmalıydı.` : `Fazla küçük: ${e.origin}, ${n}${e.minimum.toString()} olmalıydı.`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Fâsit metin: "${t.prefix}" ile başlamalı.` : t.format === "ends_with" ? `Fâsit metin: "${t.suffix}" ile bitmeli.` : t.format === "includes" ? `Fâsit metin: "${t.includes}" ihtivâ etmeli.` : t.format === "regex" ? `Fâsit metin: ${t.pattern} nakşına uymalı.` : `Fâsit ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Fâsit sayı: ${e.divisor} katı olmalıydı.`;
			case "unrecognized_keys": return `Tanınmayan anahtar ${e.keys.length > 1 ? "s" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} için tanınmayan anahtar var.`;
			case "invalid_union": return "Giren tanınamadı.";
			case "invalid_element": return `${e.origin} için tanınmayan kıymet var.`;
			default: return "Kıymet tanınamadı.";
		}
	};
};
function Jl() {
	return { localeError: ql() };
}
//#endregion
//#region node_modules/zod/v4/locales/ps.js
var Yl = () => {
	let e = {
		string: {
			unit: "توکي",
			verb: "ولري"
		},
		file: {
			unit: "بایټس",
			verb: "ولري"
		},
		array: {
			unit: "توکي",
			verb: "ولري"
		},
		set: {
			unit: "توکي",
			verb: "ولري"
		},
		map: {
			unit: "توکي",
			verb: "ولري"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ورودي",
		email: "بریښنالیک",
		url: "یو آر ال",
		emoji: "ایموجي",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "نیټه او وخت",
		date: "نېټه",
		time: "وخت",
		duration: "موده",
		ipv4: "د IPv4 پته",
		ipv6: "د IPv6 پته",
		mac: "د MAC پته",
		cidrv4: "د IPv4 ساحه",
		cidrv6: "د IPv6 ساحه",
		base64: "base64-encoded متن",
		base64url: "base64url-encoded متن",
		json_string: "JSON متن",
		e164: "د E.164 شمېره",
		credit_card: "د کریډیټ کارت شمیره",
		jwt: "JWT",
		template_literal: "ورودي"
	}, r = {
		nan: "NaN",
		number: "عدد",
		array: "ارې"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `ناسم ورودي: باید instanceof ${e.expected} وای, مګر ${i} ترلاسه شو` : `ناسم ورودي: باید ${t} وای, مګر ${i} ترلاسه شو`;
			}
			case "invalid_value": return e.values.length === 1 ? `ناسم ورودي: باید ${P(e.values[0])} وای` : `ناسم انتخاب: باید یو له ${x(e.values, "|")} څخه وای`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ډیر لوی: ${e.origin ?? "ارزښت"} باید ${n}${e.maximum.toString()} ${r.unit ?? "عنصرونه"} ولري` : `ډیر لوی: ${e.origin ?? "ارزښت"} باید ${n}${e.maximum.toString()} وي`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `ډیر کوچنی: ${e.origin} باید ${n}${e.minimum.toString()} ${r.unit} ولري` : `ډیر کوچنی: ${e.origin} باید ${n}${e.minimum.toString()} وي`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `ناسم متن: باید د "${t.prefix}" سره پیل شي` : t.format === "ends_with" ? `ناسم متن: باید د "${t.suffix}" سره پای ته ورسيږي` : t.format === "includes" ? `ناسم متن: باید "${t.includes}" ولري` : t.format === "regex" ? `ناسم متن: باید د ${t.pattern} سره مطابقت ولري` : `${n[t.format] ?? e.format} ناسم دی`;
			}
			case "not_multiple_of": return `ناسم عدد: باید د ${e.divisor} مضرب وي`;
			case "unrecognized_keys": return `ناسم ${e.keys.length > 1 ? "کلیډونه" : "کلیډ"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `ناسم کلیډ په ${e.origin} کې`;
			case "invalid_union": return "ناسمه ورودي";
			case "invalid_element": return `ناسم عنصر په ${e.origin} کې`;
			default: return "ناسمه ورودي";
		}
	};
};
function Xl() {
	return { localeError: Yl() };
}
//#endregion
//#region node_modules/zod/v4/locales/pl.js
var Zl = () => {
	let e = {
		string: {
			unit: "znaków",
			verb: "mieć"
		},
		file: {
			unit: "bajtów",
			verb: "mieć"
		},
		array: {
			unit: "elementów",
			verb: "mieć"
		},
		set: {
			unit: "elementów",
			verb: "mieć"
		},
		map: {
			unit: "elementów",
			verb: "mieć"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "wyrażenie",
		email: "adres email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "data i godzina w formacie ISO",
		date: "data w formacie ISO",
		time: "godzina w formacie ISO",
		duration: "czas trwania ISO",
		ipv4: "adres IPv4",
		ipv6: "adres IPv6",
		mac: "adres MAC",
		cidrv4: "zakres IPv4",
		cidrv6: "zakres IPv6",
		base64: "ciąg znaków zakodowany w formacie base64",
		base64url: "ciąg znaków zakodowany w formacie base64url",
		json_string: "ciąg znaków w formacie JSON",
		e164: "liczba E.164",
		credit_card: "numer karty kredytowej",
		jwt: "JWT",
		template_literal: "wejście"
	}, r = {
		nan: "NaN",
		number: "liczba",
		array: "tablica"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Nieprawidłowe dane wejściowe: oczekiwano instanceof ${e.expected}, otrzymano ${i}` : `Nieprawidłowe dane wejściowe: oczekiwano ${t}, otrzymano ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Nieprawidłowe dane wejściowe: oczekiwano ${P(e.values[0])}` : `Nieprawidłowa opcja: oczekiwano jednej z wartości ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Za duża wartość: oczekiwano, że ${e.origin ?? "wartość"} będzie mieć ${n}${e.maximum.toString()} ${r.unit ?? "elementów"}` : `Zbyt duż(y/a/e): oczekiwano, że ${e.origin ?? "wartość"} będzie wynosić ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Za mała wartość: oczekiwano, że ${e.origin ?? "wartość"} będzie mieć ${n}${e.minimum.toString()} ${r.unit ?? "elementów"}` : `Zbyt mał(y/a/e): oczekiwano, że ${e.origin ?? "wartość"} będzie wynosić ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Nieprawidłowy ciąg znaków: musi zaczynać się od "${t.prefix}"` : t.format === "ends_with" ? `Nieprawidłowy ciąg znaków: musi kończyć się na "${t.suffix}"` : t.format === "includes" ? `Nieprawidłowy ciąg znaków: musi zawierać "${t.includes}"` : t.format === "regex" ? `Nieprawidłowy ciąg znaków: musi odpowiadać wzorcowi ${t.pattern}` : `Nieprawidłow(y/a/e) ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Nieprawidłowa liczba: musi być wielokrotnością ${e.divisor}`;
			case "unrecognized_keys": return `Nierozpoznane klucze${e.keys.length > 1 ? "s" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Nieprawidłowy klucz w ${e.origin}`;
			case "invalid_union": return "Nieprawidłowe dane wejściowe";
			case "invalid_element": return `Nieprawidłowa wartość w ${e.origin}`;
			default: return "Nieprawidłowe dane wejściowe";
		}
	};
};
function Ql() {
	return { localeError: Zl() };
}
//#endregion
//#region node_modules/zod/v4/locales/pt.js
var $l = () => {
	let e = {
		string: { unit: "caracteres" },
		file: { unit: "bytes" },
		array: { unit: "elementos" },
		set: { unit: "elementos" },
		map: { unit: "entradas" }
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "a entrada",
		email: "o endereço de e-mail",
		url: "o URL",
		emoji: "o emoji",
		uuid: "o UUID",
		uuidv4: "o UUIDv4",
		uuidv6: "o UUIDv6",
		nanoid: "o nanoid",
		guid: "o GUID",
		cuid: "o cuid",
		cuid2: "o cuid2",
		ulid: "o ULID",
		xid: "o XID",
		ksuid: "o KSUID",
		datetime: "a data e hora ISO",
		date: "a data ISO",
		time: "a hora ISO",
		duration: "a duração ISO",
		ipv4: "o endereço IPv4",
		ipv6: "o endereço IPv6",
		mac: "o endereço MAC",
		cidrv4: "o intervalo de endereços IPv4",
		cidrv6: "o intervalo de endereços IPv6",
		base64: "o texto codificado em base64",
		base64url: "o texto codificado em base64url",
		json_string: "o texto JSON",
		e164: "o número E.164",
		credit_card: "o número de cartão de crédito",
		jwt: "o JWT",
		template_literal: "a entrada"
	}, r = {
		masculine: {
			definite: "o",
			indefinite: "um"
		},
		feminine: {
			definite: "a",
			indefinite: "uma"
		}
	}, i = {
		string: {
			name: "texto",
			articles: r.masculine
		},
		number: {
			name: "número",
			articles: r.masculine
		},
		int: {
			name: "número inteiro",
			articles: r.masculine
		},
		boolean: {
			name: "valor booleano",
			articles: r.masculine
		},
		bigint: {
			name: "número bigint",
			articles: r.masculine
		},
		symbol: {
			name: "símbolo",
			articles: r.masculine
		},
		undefined: {
			name: "valor \"undefined\"",
			articles: r.masculine
		},
		null: {
			name: "valor \"nulo\"",
			articles: r.masculine
		},
		never: {
			name: "valor \"never\"",
			articles: r.masculine
		},
		void: {
			name: "valor \"void\"",
			articles: r.masculine
		},
		date: {
			name: "data",
			articles: r.feminine
		},
		array: {
			name: "vetor",
			articles: r.masculine
		},
		object: {
			name: "objeto",
			articles: r.masculine
		},
		tuple: {
			name: "tuplo",
			articles: r.masculine
		},
		record: {
			name: "registo",
			articles: r.masculine
		},
		map: {
			name: "mapa",
			articles: r.masculine
		},
		set: {
			name: "conjunto",
			articles: r.masculine
		},
		file: {
			name: "ficheiro",
			articles: r.masculine
		},
		nonoptional: {
			name: "valor não opcional",
			articles: r.masculine
		},
		nan: {
			name: "valor \"NaN\"",
			articles: r.masculine
		},
		function: {
			name: "função",
			articles: r.feminine
		}
	};
	function a(e, t) {
		let n = i[e] ?? {
			name: `valor "${e}"`,
			articles: r.masculine
		};
		return `${n.articles[t]} ${n.name}`;
	}
	return (e) => {
		switch (e.code) {
			case "invalid_type": return `Entrada inválida: esperava ${a(e.expected, "indefinite")}, recebeu ${a(E(e.input), "indefinite")}`;
			case "invalid_value": return e.values.length === 1 ? `Entrada inválida: esperava ${P(e.values[0])}` : `Opção inválida: esperava uma das seguintes opções: ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Demasiado grande: esperava que ${a(e.origin, "definite")} tivesse ${n} ${e.maximum.toString()} ${r.unit ?? "elementos"}` : `Demasiado grande: esperava que ${a(e.origin, "definite")} fosse ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Demasiado pequeno: esperava que ${a(e.origin, "definite")} tivesse ${n} ${e.minimum.toString()} ${r.unit ?? "elementos"}` : `Demasiado pequeno: esperava que ${a(e.origin, "definite")} fosse ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Texto inválido: deve começar por "${t.prefix}"` : t.format === "ends_with" ? `Texto inválido: deve terminar em "${t.suffix}"` : t.format === "includes" ? `Texto inválido: deve incluir "${t.includes}"` : t.format === "regex" ? `Texto inválido: deve corresponder ao padrão ${t.pattern}` : `Formato d${n[t.format] ?? e.format} inválido`;
			}
			case "not_multiple_of": return `Número inválido: deve ser múltiplo de ${e.divisor}`;
			case "unrecognized_keys": {
				let t = e.keys.length > 1 ? "s" : "";
				return `Chave${t} inválida${t}: ${x(e.keys, ", ")}`;
			}
			case "invalid_key": return `Entrada inválida n${a(e.origin, "definite")}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `Valor de discriminação inválido. Esperava ${e.options.map((e) => `'${e}'`).join(" | ")}` : "Entrada inválida";
			case "invalid_element": return `Entrada inválida n${a(e.origin, "definite")}`;
			default: return "Entrada inválida";
		}
	};
};
function eu() {
	return { localeError: $l() };
}
//#endregion
//#region node_modules/zod/v4/locales/pt-BR.js
var tu = () => {
	let e = {
		string: { unit: "caracteres" },
		file: { unit: "bytes" },
		array: { unit: "elementos" },
		set: { unit: "elementos" },
		map: { unit: "entradas" }
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "a entrada",
		email: "o endereço de e-mail",
		url: "o URL",
		emoji: "o emoji",
		uuid: "o UUID",
		uuidv4: "o UUIDv4",
		uuidv6: "o UUIDv6",
		nanoid: "o nanoid",
		guid: "o GUID",
		cuid: "o cuid",
		cuid2: "o cuid2",
		ulid: "o ULID",
		xid: "o XID",
		ksuid: "o KSUID",
		datetime: "a data e hora ISO",
		date: "a data ISO",
		time: "a hora ISO",
		duration: "a duração ISO",
		ipv4: "o endereço IPv4",
		ipv6: "o endereço IPv6",
		mac: "o endereço MAC",
		cidrv4: "a faixa de endereços IPv4",
		cidrv6: "a faixa de endereços IPv6",
		base64: "o texto codificado em base64",
		base64url: "o texto codificado em base64url",
		json_string: "o texto JSON",
		e164: "o número E.164",
		credit_card: "o número de cartão de crédito",
		jwt: "o JWT",
		template_literal: "a entrada"
	}, r = {
		masculine: {
			definite: "o",
			indefinite: "um"
		},
		feminine: {
			definite: "a",
			indefinite: "uma"
		}
	}, i = {
		string: {
			name: "texto",
			articles: r.masculine
		},
		number: {
			name: "número",
			articles: r.masculine
		},
		int: {
			name: "número inteiro",
			articles: r.masculine
		},
		boolean: {
			name: "valor booleano",
			articles: r.masculine
		},
		bigint: {
			name: "número bigint",
			articles: r.masculine
		},
		symbol: {
			name: "símbolo",
			articles: r.masculine
		},
		undefined: {
			name: "valor \"undefined\"",
			articles: r.masculine
		},
		null: {
			name: "valor \"nulo\"",
			articles: r.masculine
		},
		never: {
			name: "valor \"never\"",
			articles: r.masculine
		},
		void: {
			name: "valor \"void\"",
			articles: r.masculine
		},
		date: {
			name: "data",
			articles: r.feminine
		},
		array: {
			name: "vetor",
			articles: r.masculine
		},
		object: {
			name: "objeto",
			articles: r.masculine
		},
		tuple: {
			name: "tupla",
			articles: r.feminine
		},
		record: {
			name: "registro",
			articles: r.masculine
		},
		map: {
			name: "mapa",
			articles: r.masculine
		},
		set: {
			name: "conjunto",
			articles: r.masculine
		},
		file: {
			name: "arquivo",
			articles: r.masculine
		},
		nonoptional: {
			name: "valor não opcional",
			articles: r.masculine
		},
		nan: {
			name: "valor \"NaN\"",
			articles: r.masculine
		},
		function: {
			name: "função",
			articles: r.feminine
		}
	};
	function a(e, t) {
		let n = i[e] ?? {
			name: `valor "${e}"`,
			articles: r.masculine
		};
		return `${n.articles[t]} ${n.name}`;
	}
	return (e) => {
		switch (e.code) {
			case "invalid_type": return `Entrada inválida: esperava ${a(e.expected, "indefinite")}, recebeu ${a(E(e.input), "indefinite")}`;
			case "invalid_value": return e.values.length === 1 ? `Entrada inválida: esperava ${P(e.values[0])}` : `Opção inválida: esperava uma das seguintes opções: ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Grande demais: esperava que ${a(e.origin, "definite")} tivesse ${n} ${e.maximum.toString()} ${r.unit ?? "elementos"}` : `Grande demais: esperava que ${a(e.origin, "definite")} fosse ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Pequeno demais: esperava que ${a(e.origin, "definite")} tivesse ${n} ${e.minimum.toString()} ${r.unit ?? "elementos"}` : `Pequeno demais: esperava que ${a(e.origin, "definite")} fosse ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Texto inválido: deve começar com "${t.prefix}"` : t.format === "ends_with" ? `Texto inválido: deve terminar com "${t.suffix}"` : t.format === "includes" ? `Texto inválido: deve incluir "${t.includes}"` : t.format === "regex" ? `Texto inválido: deve corresponder ao padrão ${t.pattern}` : `Formato d${n[t.format] ?? e.format} inválido`;
			}
			case "not_multiple_of": return `Número inválido: deve ser múltiplo de ${e.divisor}`;
			case "unrecognized_keys": {
				let t = e.keys.length > 1 ? "s" : "";
				return `Chave${t} inválida${t}: ${x(e.keys, ", ")}`;
			}
			case "invalid_key": return `Entrada inválida n${a(e.origin, "definite")}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `Valor de discriminação inválido. Esperava ${e.options.map((e) => `'${e}'`).join(" | ")}` : "Entrada inválida";
			case "invalid_element": return `Entrada inválida n${a(e.origin, "definite")}`;
			default: return "Entrada inválida";
		}
	};
};
function nu() {
	return { localeError: tu() };
}
//#endregion
//#region node_modules/zod/v4/locales/ro.js
var ru = () => {
	let e = {
		string: {
			unit: "caractere",
			verb: "să aibă"
		},
		file: {
			unit: "octeți",
			verb: "să aibă"
		},
		array: {
			unit: "elemente",
			verb: "să aibă"
		},
		set: {
			unit: "elemente",
			verb: "să aibă"
		},
		map: {
			unit: "intrări",
			verb: "să aibă"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "intrare",
		email: "adresă de email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "dată și oră ISO",
		date: "dată ISO",
		time: "oră ISO",
		duration: "durată ISO",
		ipv4: "adresă IPv4",
		ipv6: "adresă IPv6",
		mac: "adresă MAC",
		cidrv4: "interval IPv4",
		cidrv6: "interval IPv6",
		base64: "șir codat base64",
		base64url: "șir codat base64url",
		json_string: "șir JSON",
		e164: "număr E.164",
		credit_card: "număr de card de credit",
		jwt: "JWT",
		template_literal: "intrare"
	}, r = {
		nan: "NaN",
		string: "șir",
		number: "număr",
		boolean: "boolean",
		function: "funcție",
		array: "matrice",
		object: "obiect",
		undefined: "nedefinit",
		symbol: "simbol",
		bigint: "număr mare",
		void: "void",
		never: "never",
		map: "hartă",
		set: "set"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input);
				return `Intrare invalidă: așteptat ${t}, primit ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Intrare invalidă: așteptat ${P(e.values[0])}` : `Opțiune invalidă: așteptat una dintre ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Prea mare: așteptat ca ${e.origin ?? "valoarea"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit ?? "elemente"}` : `Prea mare: așteptat ca ${e.origin ?? "valoarea"} să fie ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Prea mic: așteptat ca ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `Prea mic: așteptat ca ${e.origin} să fie ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Șir invalid: trebuie să înceapă cu "${t.prefix}"` : t.format === "ends_with" ? `Șir invalid: trebuie să se termine cu "${t.suffix}"` : t.format === "includes" ? `Șir invalid: trebuie să includă "${t.includes}"` : t.format === "regex" ? `Șir invalid: trebuie să se potrivească cu modelul ${t.pattern}` : `Format invalid: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Număr invalid: trebuie să fie multiplu de ${e.divisor}`;
			case "unrecognized_keys": return `Chei nerecunoscute: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Cheie invalidă în ${e.origin}`;
			case "invalid_union": return "Intrare invalidă";
			case "invalid_element": return `Valoare invalidă în ${e.origin}`;
			default: return "Intrare invalidă";
		}
	};
};
function iu() {
	return { localeError: ru() };
}
//#endregion
//#region node_modules/zod/v4/locales/ru.js
function au(e, t, n, r) {
	let i = Math.abs(e), a = i % 10, o = i % 100;
	return o >= 11 && o <= 19 ? r : a === 1 ? t : a >= 2 && a <= 4 ? n : r;
}
var ou = () => {
	let e = {
		string: {
			unit: {
				one: "символ",
				few: "символа",
				many: "символов"
			},
			verb: "иметь"
		},
		file: {
			unit: {
				one: "байт",
				few: "байта",
				many: "байт"
			},
			verb: "иметь"
		},
		array: {
			unit: {
				one: "элемент",
				few: "элемента",
				many: "элементов"
			},
			verb: "иметь"
		},
		set: {
			unit: {
				one: "элемент",
				few: "элемента",
				many: "элементов"
			},
			verb: "иметь"
		},
		map: {
			unit: {
				one: "элемент",
				few: "элемента",
				many: "элементов"
			},
			verb: "иметь"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ввод",
		email: "email адрес",
		url: "URL",
		emoji: "эмодзи",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO дата и время",
		date: "ISO дата",
		time: "ISO время",
		duration: "ISO длительность",
		ipv4: "IPv4 адрес",
		ipv6: "IPv6 адрес",
		mac: "MAC адрес",
		cidrv4: "IPv4 диапазон",
		cidrv6: "IPv6 диапазон",
		base64: "строка в формате base64",
		base64url: "строка в формате base64url",
		json_string: "JSON строка",
		e164: "номер E.164",
		credit_card: "номер кредитной карты",
		jwt: "JWT",
		template_literal: "ввод"
	}, r = {
		nan: "NaN",
		number: "число",
		array: "массив"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Неверный ввод: ожидалось instanceof ${e.expected}, получено ${i}` : `Неверный ввод: ожидалось ${t}, получено ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Неверный ввод: ожидалось ${P(e.values[0])}` : `Неверный вариант: ожидалось одно из ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				if (r) {
					let t = au(Number(e.maximum), r.unit.one, r.unit.few, r.unit.many);
					return `Слишком большое значение: ожидалось, что ${e.origin ?? "значение"} будет иметь ${n}${e.maximum.toString()} ${t}`;
				}
				return `Слишком большое значение: ожидалось, что ${e.origin ?? "значение"} будет ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				if (r) {
					let t = au(Number(e.minimum), r.unit.one, r.unit.few, r.unit.many);
					return `Слишком маленькое значение: ожидалось, что ${e.origin} будет иметь ${n}${e.minimum.toString()} ${t}`;
				}
				return `Слишком маленькое значение: ожидалось, что ${e.origin} будет ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Неверная строка: должна начинаться с "${t.prefix}"` : t.format === "ends_with" ? `Неверная строка: должна заканчиваться на "${t.suffix}"` : t.format === "includes" ? `Неверная строка: должна содержать "${t.includes}"` : t.format === "regex" ? `Неверная строка: должна соответствовать шаблону ${t.pattern}` : `Неверный ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Неверное число: должно быть кратным ${e.divisor}`;
			case "unrecognized_keys": return `Нераспознанн${e.keys.length > 1 ? "ые" : "ый"} ключ${e.keys.length > 1 ? "и" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Неверный ключ в ${e.origin}`;
			case "invalid_union": return "Неверные входные данные";
			case "invalid_element": return `Неверное значение в ${e.origin}`;
			default: return "Неверные входные данные";
		}
	};
};
function su() {
	return { localeError: ou() };
}
//#endregion
//#region node_modules/zod/v4/locales/sk.js
var cu = () => {
	let e = {
		string: {
			unit: "znakov",
			verb: "mať"
		},
		file: {
			unit: "bajtov",
			verb: "mať"
		},
		array: {
			unit: "prvkov",
			verb: "mať"
		},
		set: {
			unit: "prvkov",
			verb: "mať"
		},
		map: {
			unit: "položiek",
			verb: "mať"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "regulárny výraz",
		email: "e-mailová adresa",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "dátum a čas vo formáte ISO",
		date: "dátum vo formáte ISO",
		time: "čas vo formáte ISO",
		duration: "doba trvania ISO",
		ipv4: "IPv4 adresa",
		ipv6: "IPv6 adresa",
		mac: "MAC adresa",
		cidrv4: "rozsah IPv4",
		cidrv6: "rozsah IPv6",
		base64: "reťazec zakódovaný vo formáte base64",
		base64url: "reťazec zakódovaný vo formáte base64url",
		json_string: "reťazec vo formáte JSON",
		e164: "číslo E.164",
		credit_card: "číslo kreditnej karty",
		jwt: "JWT",
		template_literal: "vstup"
	}, r = {
		nan: "NaN",
		number: "číslo",
		string: "reťazec",
		function: "funkcia",
		array: "pole"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Neplatný vstup: očakávané instanceof ${e.expected}, obdržané ${i}` : `Neplatný vstup: očakávané ${t}, obdržané ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Neplatný vstup: očakávané ${P(e.values[0])}` : `Neplatný vstup: očakávaná jedna z hodnôt ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Hodnota je príliš veľká: ${e.origin ?? "hodnota"} musí mať ${n}${e.maximum.toString()} ${r.unit ?? "prvkov"}` : `Hodnota je príliš veľká: ${e.origin ?? "hodnota"} musí byť ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Hodnota je príliš malá: ${e.origin ?? "hodnota"} musí mať ${n}${e.minimum.toString()} ${r.unit ?? "prvkov"}` : `Hodnota je príliš malá: ${e.origin ?? "hodnota"} musí byť ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Neplatný reťazec: musí začínať na "${t.prefix}"` : t.format === "ends_with" ? `Neplatný reťazec: musí končiť na "${t.suffix}"` : t.format === "includes" ? `Neplatný reťazec: musí obsahovať "${t.includes}"` : t.format === "regex" ? `Neplatný reťazec: musí zodpovedať vzoru ${t.pattern}` : `Neplatný formát ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Neplatné číslo: musí byť násobkom ${e.divisor}`;
			case "unrecognized_keys": return `Neznáme klúče: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Neplatný klúč v ${e.origin}`;
			case "invalid_union": return "Neplatný vstup";
			case "invalid_element": return `Neplatná hodnota v ${e.origin}`;
			default: return "Neplatný vstup";
		}
	};
};
function lu() {
	return { localeError: cu() };
}
//#endregion
//#region node_modules/zod/v4/locales/sl.js
var uu = () => {
	let e = {
		string: {
			unit: "znakov",
			verb: "imeti"
		},
		file: {
			unit: "bajtov",
			verb: "imeti"
		},
		array: {
			unit: "elementov",
			verb: "imeti"
		},
		set: {
			unit: "elementov",
			verb: "imeti"
		},
		map: {
			unit: "elementov",
			verb: "imeti"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "vnos",
		email: "e-poštni naslov",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datum in čas",
		date: "ISO datum",
		time: "ISO čas",
		duration: "ISO trajanje",
		ipv4: "IPv4 naslov",
		ipv6: "IPv6 naslov",
		mac: "MAC naslov",
		cidrv4: "obseg IPv4",
		cidrv6: "obseg IPv6",
		base64: "base64 kodiran niz",
		base64url: "base64url kodiran niz",
		json_string: "JSON niz",
		e164: "E.164 številka",
		credit_card: "številka kreditne kartice",
		jwt: "JWT",
		template_literal: "vnos"
	}, r = {
		nan: "NaN",
		number: "število",
		array: "tabela"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Neveljaven vnos: pričakovano instanceof ${e.expected}, prejeto ${i}` : `Neveljaven vnos: pričakovano ${t}, prejeto ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Neveljaven vnos: pričakovano ${P(e.values[0])}` : `Neveljavna možnost: pričakovano eno izmed ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Preveliko: pričakovano, da bo ${e.origin ?? "vrednost"} imelo ${n}${e.maximum.toString()} ${r.unit ?? "elementov"}` : `Preveliko: pričakovano, da bo ${e.origin ?? "vrednost"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Premajhno: pričakovano, da bo ${e.origin} imelo ${n}${e.minimum.toString()} ${r.unit}` : `Premajhno: pričakovano, da bo ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Neveljaven niz: mora se začeti z "${t.prefix}"` : t.format === "ends_with" ? `Neveljaven niz: mora se končati z "${t.suffix}"` : t.format === "includes" ? `Neveljaven niz: mora vsebovati "${t.includes}"` : t.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${t.pattern}` : `Neveljaven ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Neveljavno število: mora biti večkratnik ${e.divisor}`;
			case "unrecognized_keys": return `Neprepoznan${e.keys.length > 1 ? "i ključi" : " ključ"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Neveljaven ključ v ${e.origin}`;
			case "invalid_union": return "Neveljaven vnos";
			case "invalid_element": return `Neveljavna vrednost v ${e.origin}`;
			default: return "Neveljaven vnos";
		}
	};
};
function du() {
	return { localeError: uu() };
}
//#endregion
//#region node_modules/zod/v4/locales/sv.js
var fu = () => {
	let e = {
		string: {
			unit: "tecken",
			verb: "att ha"
		},
		file: {
			unit: "bytes",
			verb: "att ha"
		},
		array: {
			unit: "objekt",
			verb: "att innehålla"
		},
		set: {
			unit: "objekt",
			verb: "att innehålla"
		},
		map: {
			unit: "objekt",
			verb: "att innehålla"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "reguljärt uttryck",
		email: "e-postadress",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO-datum och tid",
		date: "ISO-datum",
		time: "ISO-tid",
		duration: "ISO-varaktighet",
		ipv4: "IPv4-adress",
		ipv6: "IPv6-adress",
		mac: "MAC-adress",
		cidrv4: "IPv4-spektrum",
		cidrv6: "IPv6-spektrum",
		base64: "base64-kodad sträng",
		base64url: "base64url-kodad sträng",
		json_string: "JSON-sträng",
		e164: "E.164-nummer",
		credit_card: "kreditkortsnummer",
		jwt: "JWT",
		template_literal: "mall-literal"
	}, r = {
		nan: "NaN",
		number: "antal",
		array: "lista"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ogiltig inmatning: förväntat instanceof ${e.expected}, fick ${i}` : `Ogiltig inmatning: förväntat ${t}, fick ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ogiltig inmatning: förväntat ${P(e.values[0])}` : `Ogiltigt val: förväntade en av ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `För stor(t): förväntade ${e.origin ?? "värdet"} att ha ${n}${e.maximum.toString()} ${r.unit ?? "element"}` : `För stor(t): förväntat ${e.origin ?? "värdet"} att ha ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `För lite(t): förväntade ${e.origin ?? "värdet"} att ha ${n}${e.minimum.toString()} ${r.unit}` : `För lite(t): förväntade ${e.origin ?? "värdet"} att ha ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ogiltig sträng: måste börja med "${t.prefix}"` : t.format === "ends_with" ? `Ogiltig sträng: måste sluta med "${t.suffix}"` : t.format === "includes" ? `Ogiltig sträng: måste innehålla "${t.includes}"` : t.format === "regex" ? `Ogiltig sträng: måste matcha mönstret "${t.pattern}"` : `Ogiltig(t) ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ogiltigt tal: måste vara en multipel av ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Okända nycklar" : "Okänd nyckel"}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Ogiltig nyckel i ${e.origin ?? "värdet"}`;
			case "invalid_union": return "Ogiltig input";
			case "invalid_element": return `Ogiltigt värde i ${e.origin ?? "värdet"}`;
			default: return "Ogiltig input";
		}
	};
};
function pu() {
	return { localeError: fu() };
}
//#endregion
//#region node_modules/zod/v4/locales/ta.js
var mu = () => {
	let e = {
		string: {
			unit: "எழுத்துக்கள்",
			verb: "கொண்டிருக்க வேண்டும்"
		},
		file: {
			unit: "பைட்டுகள்",
			verb: "கொண்டிருக்க வேண்டும்"
		},
		array: {
			unit: "உறுப்புகள்",
			verb: "கொண்டிருக்க வேண்டும்"
		},
		set: {
			unit: "உறுப்புகள்",
			verb: "கொண்டிருக்க வேண்டும்"
		},
		map: {
			unit: "உறுப்புகள்",
			verb: "கொண்டிருக்க வேண்டும்"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "உள்ளீடு",
		email: "மின்னஞ்சல் முகவரி",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO தேதி நேரம்",
		date: "ISO தேதி",
		time: "ISO நேரம்",
		duration: "ISO கால அளவு",
		ipv4: "IPv4 முகவரி",
		ipv6: "IPv6 முகவரி",
		mac: "MAC முகவரி",
		cidrv4: "IPv4 வரம்பு",
		cidrv6: "IPv6 வரம்பு",
		base64: "base64-encoded சரம்",
		base64url: "base64url-encoded சரம்",
		json_string: "JSON சரம்",
		e164: "E.164 எண்",
		credit_card: "கடன் அட்டை எண்",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "எண்",
		array: "அணி",
		null: "வெறுமை"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது instanceof ${e.expected}, பெறப்பட்டது ${i}` : `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது ${t}, பெறப்பட்டது ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது ${P(e.values[0])}` : `தவறான விருப்பம்: எதிர்பார்க்கப்பட்டது ${x(e.values, "|")} இல் ஒன்று`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `மிக பெரியது: எதிர்பார்க்கப்பட்டது ${e.origin ?? "மதிப்பு"} ${n}${e.maximum.toString()} ${r.unit ?? "உறுப்புகள்"} ஆக இருக்க வேண்டும்` : `மிக பெரியது: எதிர்பார்க்கப்பட்டது ${e.origin ?? "மதிப்பு"} ${n}${e.maximum.toString()} ஆக இருக்க வேண்டும்`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `மிகச் சிறியது: எதிர்பார்க்கப்பட்டது ${e.origin} ${n}${e.minimum.toString()} ${r.unit} ஆக இருக்க வேண்டும்` : `மிகச் சிறியது: எதிர்பார்க்கப்பட்டது ${e.origin} ${n}${e.minimum.toString()} ஆக இருக்க வேண்டும்`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `தவறான சரம்: "${t.prefix}" இல் தொடங்க வேண்டும்` : t.format === "ends_with" ? `தவறான சரம்: "${t.suffix}" இல் முடிவடைய வேண்டும்` : t.format === "includes" ? `தவறான சரம்: "${t.includes}" ஐ உள்ளடக்க வேண்டும்` : t.format === "regex" ? `தவறான சரம்: ${t.pattern} முறைபாட்டுடன் பொருந்த வேண்டும்` : `தவறான ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `தவறான எண்: ${e.divisor} இன் பலமாக இருக்க வேண்டும்`;
			case "unrecognized_keys": return `அடையாளம் தெரியாத விசை${e.keys.length > 1 ? "கள்" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} இல் தவறான விசை`;
			case "invalid_union": return "தவறான உள்ளீடு";
			case "invalid_element": return `${e.origin} இல் தவறான மதிப்பு`;
			default: return "தவறான உள்ளீடு";
		}
	};
};
function hu() {
	return { localeError: mu() };
}
//#endregion
//#region node_modules/zod/v4/locales/th.js
var gu = () => {
	let e = {
		string: {
			unit: "ตัวอักษร",
			verb: "ควรมี"
		},
		file: {
			unit: "ไบต์",
			verb: "ควรมี"
		},
		array: {
			unit: "รายการ",
			verb: "ควรมี"
		},
		set: {
			unit: "รายการ",
			verb: "ควรมี"
		},
		map: {
			unit: "รายการ",
			verb: "ควรมี"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ข้อมูลที่ป้อน",
		email: "ที่อยู่อีเมล",
		url: "URL",
		emoji: "อิโมจิ",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "วันที่เวลาแบบ ISO",
		date: "วันที่แบบ ISO",
		time: "เวลาแบบ ISO",
		duration: "ช่วงเวลาแบบ ISO",
		ipv4: "ที่อยู่ IPv4",
		ipv6: "ที่อยู่ IPv6",
		mac: "ที่อยู่ MAC",
		cidrv4: "ช่วง IP แบบ IPv4",
		cidrv6: "ช่วง IP แบบ IPv6",
		base64: "ข้อความแบบ Base64",
		base64url: "ข้อความแบบ Base64 สำหรับ URL",
		json_string: "ข้อความแบบ JSON",
		e164: "เบอร์โทรศัพท์ระหว่างประเทศ (E.164)",
		credit_card: "หมายเลขบัตรเครดิต",
		jwt: "โทเคน JWT",
		template_literal: "ข้อมูลที่ป้อน"
	}, r = {
		nan: "NaN",
		number: "ตัวเลข",
		array: "อาร์เรย์ (Array)",
		null: "ไม่มีค่า (null)"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `ประเภทข้อมูลไม่ถูกต้อง: ควรเป็น instanceof ${e.expected} แต่ได้รับ ${i}` : `ประเภทข้อมูลไม่ถูกต้อง: ควรเป็น ${t} แต่ได้รับ ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `ค่าไม่ถูกต้อง: ควรเป็น ${P(e.values[0])}` : `ตัวเลือกไม่ถูกต้อง: ควรเป็นหนึ่งใน ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "ไม่เกิน" : "น้อยกว่า", r = t(e.origin);
				return r ? `เกินกำหนด: ${e.origin ?? "ค่า"} ควรมี${n} ${e.maximum.toString()} ${r.unit ?? "รายการ"}` : `เกินกำหนด: ${e.origin ?? "ค่า"} ควรมี${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? "อย่างน้อย" : "มากกว่า", r = t(e.origin);
				return r ? `น้อยกว่ากำหนด: ${e.origin} ควรมี${n} ${e.minimum.toString()} ${r.unit}` : `น้อยกว่ากำหนด: ${e.origin} ควรมี${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `รูปแบบไม่ถูกต้อง: ข้อความต้องขึ้นต้นด้วย "${t.prefix}"` : t.format === "ends_with" ? `รูปแบบไม่ถูกต้อง: ข้อความต้องลงท้ายด้วย "${t.suffix}"` : t.format === "includes" ? `รูปแบบไม่ถูกต้อง: ข้อความต้องมี "${t.includes}" อยู่ในข้อความ` : t.format === "regex" ? `รูปแบบไม่ถูกต้อง: ต้องตรงกับรูปแบบที่กำหนด ${t.pattern}` : `รูปแบบไม่ถูกต้อง: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `ตัวเลขไม่ถูกต้อง: ต้องเป็นจำนวนที่หารด้วย ${e.divisor} ได้ลงตัว`;
			case "unrecognized_keys": return `พบคีย์ที่ไม่รู้จัก: ${x(e.keys, ", ")}`;
			case "invalid_key": return `คีย์ไม่ถูกต้องใน ${e.origin}`;
			case "invalid_union": return "ข้อมูลไม่ถูกต้อง: ไม่ตรงกับรูปแบบยูเนียนที่กำหนดไว้";
			case "invalid_element": return `ข้อมูลไม่ถูกต้องใน ${e.origin}`;
			default: return "ข้อมูลไม่ถูกต้อง";
		}
	};
};
function _u() {
	return { localeError: gu() };
}
//#endregion
//#region node_modules/zod/v4/locales/tk.js
var vu = () => {
	let e = {
		string: {
			unit: "simwol",
			verb: "bolmaly"
		},
		file: {
			unit: "baýt",
			verb: "bolmaly"
		},
		array: {
			unit: "elementler",
			verb: "bolmaly"
		},
		set: {
			unit: "elementler",
			verb: "bolmaly"
		},
		map: {
			unit: "elementler",
			verb: "bolmaly"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "giriş",
		email: "e-poçta salgysy",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO sene we wagt",
		date: "ISO sene",
		time: "ISO wagt",
		duration: "ISO wagt aralygy",
		ipv4: "IPv4 salgysy",
		ipv6: "IPv6 salgysy",
		mac: "MAC salgysy",
		cidrv4: "IPv4 aralygy",
		cidrv6: "IPv6 aralygy",
		base64: "base64 bilen şifrlenen setir",
		base64url: "base64url bilen şifrlenen setir",
		json_string: "JSON setiri",
		e164: "E.164 nomeri",
		credit_card: "kredit kartynyň nomeri",
		jwt: "JWT",
		template_literal: "şablon"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input);
				return `Nädogry baha: garaşylan ${t} ýerine ${r[n] ?? n} alyndy`;
			}
			case "invalid_value": return e.values.length === 1 ? `Nädogry baha: ${P(e.values[0])} bolmaly` : `Nädogry saýlaw: aşakdakylardan biri bolmaly: ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Has uly: garaşylýan ${e.origin ?? "baha"} ${n} ${e.maximum.toString()} ${r.unit ?? "element"}` : `Has uly: garaşylýan ${e.origin ?? "baha"} ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Has kiçi: garaşylýan ${e.origin} ${n} ${e.minimum.toString()} ${r.unit}` : `Has kiçi: garaşylýan ${e.origin} ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Nädogry setir: "${t.prefix}" bilen başlamaly` : t.format === "ends_with" ? `Nädogry setir: "${t.suffix}" bilen gutarmaly` : t.format === "includes" ? `Nädogry setir: "${t.includes}" saklamaly` : t.format === "regex" ? `Nädogry setir: ${t.pattern} nusga laýyk bolmaly` : `Nädogry ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Nädogry san: ${e.divisor} bilen galyndysyz bölünmeli`;
			case "unrecognized_keys": return `Tanalmaýan açar${e.keys.length > 1 ? "lar" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} içinde nädogry açar`;
			case "invalid_union": return "Nädogry baha";
			case "invalid_element": return `${e.origin} içinde nädogry baha`;
			default: return "Nädogry baha";
		}
	};
};
function yu() {
	return { localeError: vu() };
}
//#endregion
//#region node_modules/zod/v4/locales/tr.js
var bu = () => {
	let e = {
		string: {
			unit: "karakter",
			verb: "olmalı"
		},
		file: {
			unit: "bayt",
			verb: "olmalı"
		},
		array: {
			unit: "öğe",
			verb: "olmalı"
		},
		set: {
			unit: "öğe",
			verb: "olmalı"
		},
		map: {
			unit: "öğe",
			verb: "olmalı"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "girdi",
		email: "e-posta adresi",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO tarih ve saat",
		date: "ISO tarih",
		time: "ISO saat",
		duration: "ISO süre",
		ipv4: "IPv4 adresi",
		ipv6: "IPv6 adresi",
		mac: "MAC adresi",
		cidrv4: "IPv4 aralığı",
		cidrv6: "IPv6 aralığı",
		base64: "base64 ile şifrelenmiş metin",
		base64url: "base64url ile şifrelenmiş metin",
		json_string: "JSON dizesi",
		e164: "E.164 sayısı",
		credit_card: "kredi kartı numarası",
		jwt: "JWT",
		template_literal: "Şablon dizesi"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Geçersiz değer: beklenen instanceof ${e.expected}, alınan ${i}` : `Geçersiz değer: beklenen ${t}, alınan ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Geçersiz değer: beklenen ${P(e.values[0])}` : `Geçersiz seçenek: aşağıdakilerden biri olmalı: ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Çok büyük: beklenen ${e.origin ?? "değer"} ${n}${e.maximum.toString()} ${r.unit ?? "öğe"}` : `Çok büyük: beklenen ${e.origin ?? "değer"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Çok küçük: beklenen ${e.origin} ${n}${e.minimum.toString()} ${r.unit}` : `Çok küçük: beklenen ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Geçersiz metin: "${t.prefix}" ile başlamalı` : t.format === "ends_with" ? `Geçersiz metin: "${t.suffix}" ile bitmeli` : t.format === "includes" ? `Geçersiz metin: "${t.includes}" içermeli` : t.format === "regex" ? `Geçersiz metin: ${t.pattern} desenine uymalı` : `Geçersiz ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Geçersiz sayı: ${e.divisor} ile tam bölünebilmeli`;
			case "unrecognized_keys": return `Tanınmayan anahtar${e.keys.length > 1 ? "lar" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} içinde geçersiz anahtar`;
			case "invalid_union": return "Geçersiz değer";
			case "invalid_element": return `${e.origin} içinde geçersiz değer`;
			default: return "Geçersiz değer";
		}
	};
};
function xu() {
	return { localeError: bu() };
}
//#endregion
//#region node_modules/zod/v4/locales/uk.js
var Su = () => {
	let e = {
		string: {
			unit: "символів",
			verb: "матиме"
		},
		file: {
			unit: "байтів",
			verb: "матиме"
		},
		array: {
			unit: "елементів",
			verb: "матиме"
		},
		set: {
			unit: "елементів",
			verb: "матиме"
		},
		map: {
			unit: "елементів",
			verb: "матиме"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "вхідні дані",
		email: "адреса електронної пошти",
		url: "URL",
		emoji: "емодзі",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "дата та час ISO",
		date: "дата ISO",
		time: "час ISO",
		duration: "тривалість ISO",
		ipv4: "адреса IPv4",
		ipv6: "адреса IPv6",
		mac: "адреса MAC",
		cidrv4: "діапазон IPv4",
		cidrv6: "діапазон IPv6",
		base64: "рядок у кодуванні base64",
		base64url: "рядок у кодуванні base64url",
		json_string: "рядок JSON",
		e164: "номер E.164",
		credit_card: "номер кредитної картки",
		jwt: "JWT",
		template_literal: "вхідні дані"
	}, r = {
		nan: "NaN",
		number: "число",
		array: "масив"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Неправильні вхідні дані: очікується instanceof ${e.expected}, отримано ${i}` : `Неправильні вхідні дані: очікується ${t}, отримано ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Неправильні вхідні дані: очікується ${P(e.values[0])}` : `Неправильна опція: очікується одне з ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Занадто велике: очікується, що ${e.origin ?? "значення"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit ?? "елементів"}` : `Занадто велике: очікується, що ${e.origin ?? "значення"} буде ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Занадто мале: очікується, що ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `Занадто мале: очікується, що ${e.origin} буде ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Неправильний рядок: повинен починатися з "${t.prefix}"` : t.format === "ends_with" ? `Неправильний рядок: повинен закінчуватися на "${t.suffix}"` : t.format === "includes" ? `Неправильний рядок: повинен містити "${t.includes}"` : t.format === "regex" ? `Неправильний рядок: повинен відповідати шаблону ${t.pattern}` : `Неправильний ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Неправильне число: повинно бути кратним ${e.divisor}`;
			case "unrecognized_keys": return `Нерозпізнаний ключ${e.keys.length > 1 ? "і" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Неправильний ключ у ${e.origin}`;
			case "invalid_union": return "Неправильні вхідні дані";
			case "invalid_element": return `Неправильне значення у ${e.origin}`;
			default: return "Неправильні вхідні дані";
		}
	};
};
function Cu() {
	return { localeError: Su() };
}
//#endregion
//#region node_modules/zod/v4/locales/ua.js
function wu() {
	return Cu();
}
//#endregion
//#region node_modules/zod/v4/locales/ur.js
var Tu = () => {
	let e = {
		string: {
			unit: "حروف",
			verb: "ہونا"
		},
		file: {
			unit: "بائٹس",
			verb: "ہونا"
		},
		array: {
			unit: "آئٹمز",
			verb: "ہونا"
		},
		set: {
			unit: "آئٹمز",
			verb: "ہونا"
		},
		map: {
			unit: "آئٹمز",
			verb: "ہونا"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ان پٹ",
		email: "ای میل ایڈریس",
		url: "یو آر ایل",
		emoji: "ایموجی",
		uuid: "یو یو آئی ڈی",
		uuidv4: "یو یو آئی ڈی وی 4",
		uuidv6: "یو یو آئی ڈی وی 6",
		nanoid: "نینو آئی ڈی",
		guid: "جی یو آئی ڈی",
		cuid: "سی یو آئی ڈی",
		cuid2: "سی یو آئی ڈی 2",
		ulid: "یو ایل آئی ڈی",
		xid: "ایکس آئی ڈی",
		ksuid: "کے ایس یو آئی ڈی",
		datetime: "آئی ایس او ڈیٹ ٹائم",
		date: "آئی ایس او تاریخ",
		time: "آئی ایس او وقت",
		duration: "آئی ایس او مدت",
		ipv4: "آئی پی وی 4 ایڈریس",
		ipv6: "آئی پی وی 6 ایڈریس",
		mac: "ایم اے سی ایڈریس",
		cidrv4: "آئی پی وی 4 رینج",
		cidrv6: "آئی پی وی 6 رینج",
		base64: "بیس 64 ان کوڈڈ سٹرنگ",
		base64url: "بیس 64 یو آر ایل ان کوڈڈ سٹرنگ",
		json_string: "جے ایس او این سٹرنگ",
		e164: "ای 164 نمبر",
		credit_card: "کریڈٹ کارڈ نمبر",
		jwt: "جے ڈبلیو ٹی",
		template_literal: "ان پٹ"
	}, r = {
		nan: "NaN",
		number: "نمبر",
		array: "آرے",
		null: "نل"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `غلط ان پٹ: instanceof ${e.expected} متوقع تھا، ${i} موصول ہوا` : `غلط ان پٹ: ${t} متوقع تھا، ${i} موصول ہوا`;
			}
			case "invalid_value": return e.values.length === 1 ? `غلط ان پٹ: ${P(e.values[0])} متوقع تھا` : `غلط آپشن: ${x(e.values, "|")} میں سے ایک متوقع تھا`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `بہت بڑا: ${e.origin ?? "ویلیو"} کے ${n}${e.maximum.toString()} ${r.unit ?? "عناصر"} ہونے متوقع تھے` : `بہت بڑا: ${e.origin ?? "ویلیو"} کا ${n}${e.maximum.toString()} ہونا متوقع تھا`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `بہت چھوٹا: ${e.origin} کے ${n}${e.minimum.toString()} ${r.unit} ہونے متوقع تھے` : `بہت چھوٹا: ${e.origin} کا ${n}${e.minimum.toString()} ہونا متوقع تھا`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `غلط سٹرنگ: "${t.prefix}" سے شروع ہونا چاہیے` : t.format === "ends_with" ? `غلط سٹرنگ: "${t.suffix}" پر ختم ہونا چاہیے` : t.format === "includes" ? `غلط سٹرنگ: "${t.includes}" شامل ہونا چاہیے` : t.format === "regex" ? `غلط سٹرنگ: پیٹرن ${t.pattern} سے میچ ہونا چاہیے` : `غلط ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `غلط نمبر: ${e.divisor} کا مضاعف ہونا چاہیے`;
			case "unrecognized_keys": return `غیر تسلیم شدہ کی${e.keys.length > 1 ? "ز" : ""}: ${x(e.keys, "، ")}`;
			case "invalid_key": return `${e.origin} میں غلط کی`;
			case "invalid_union": return "غلط ان پٹ";
			case "invalid_element": return `${e.origin} میں غلط ویلیو`;
			default: return "غلط ان پٹ";
		}
	};
};
function Eu() {
	return { localeError: Tu() };
}
//#endregion
//#region node_modules/zod/v4/locales/uz.js
var Du = () => {
	let e = {
		string: {
			unit: "belgi",
			verb: "bo‘lishi kerak"
		},
		file: {
			unit: "bayt",
			verb: "bo‘lishi kerak"
		},
		array: {
			unit: "element",
			verb: "bo‘lishi kerak"
		},
		set: {
			unit: "element",
			verb: "bo‘lishi kerak"
		},
		map: {
			unit: "yozuv",
			verb: "bo‘lishi kerak"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "kirish",
		email: "elektron pochta manzili",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO sana va vaqti",
		date: "ISO sana",
		time: "ISO vaqt",
		duration: "ISO davomiylik",
		ipv4: "IPv4 manzil",
		ipv6: "IPv6 manzil",
		mac: "MAC manzil",
		cidrv4: "IPv4 diapazon",
		cidrv6: "IPv6 diapazon",
		base64: "base64 kodlangan satr",
		base64url: "base64url kodlangan satr",
		json_string: "JSON satr",
		e164: "E.164 raqam",
		credit_card: "kredit karta raqami",
		jwt: "JWT",
		template_literal: "kirish"
	}, r = {
		nan: "NaN",
		number: "raqam",
		array: "massiv"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Noto‘g‘ri kirish: kutilgan instanceof ${e.expected}, qabul qilingan ${i}` : `Noto‘g‘ri kirish: kutilgan ${t}, qabul qilingan ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Noto‘g‘ri kirish: kutilgan ${P(e.values[0])}` : `Noto‘g‘ri variant: quyidagilardan biri kutilgan ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Juda katta: kutilgan ${e.origin ?? "qiymat"} ${n}${e.maximum.toString()} ${r.unit} ${r.verb}` : `Juda katta: kutilgan ${e.origin ?? "qiymat"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Juda kichik: kutilgan ${e.origin} ${n}${e.minimum.toString()} ${r.unit} ${r.verb}` : `Juda kichik: kutilgan ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Noto‘g‘ri satr: "${t.prefix}" bilan boshlanishi kerak` : t.format === "ends_with" ? `Noto‘g‘ri satr: "${t.suffix}" bilan tugashi kerak` : t.format === "includes" ? `Noto‘g‘ri satr: "${t.includes}" ni o‘z ichiga olishi kerak` : t.format === "regex" ? `Noto‘g‘ri satr: ${t.pattern} shabloniga mos kelishi kerak` : `Noto‘g‘ri ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Noto‘g‘ri raqam: ${e.divisor} ning karralisi bo‘lishi kerak`;
			case "unrecognized_keys": return `Noma’lum kalit${e.keys.length > 1 ? "lar" : ""}: ${x(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} dagi kalit noto‘g‘ri`;
			case "invalid_union": return "Noto‘g‘ri kirish";
			case "invalid_element": return `${e.origin} da noto‘g‘ri qiymat`;
			default: return "Noto‘g‘ri kirish";
		}
	};
};
function Ou() {
	return { localeError: Du() };
}
//#endregion
//#region node_modules/zod/v4/locales/vi.js
var ku = () => {
	let e = {
		string: {
			unit: "ký tự",
			verb: "có"
		},
		file: {
			unit: "byte",
			verb: "có"
		},
		array: {
			unit: "phần tử",
			verb: "có"
		},
		set: {
			unit: "phần tử",
			verb: "có"
		},
		map: {
			unit: "phần tử",
			verb: "có"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "đầu vào",
		email: "địa chỉ email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ngày giờ ISO",
		date: "ngày ISO",
		time: "giờ ISO",
		duration: "khoảng thời gian ISO",
		ipv4: "địa chỉ IPv4",
		ipv6: "địa chỉ IPv6",
		mac: "địa chỉ MAC",
		cidrv4: "dải IPv4",
		cidrv6: "dải IPv6",
		base64: "chuỗi mã hóa base64",
		base64url: "chuỗi mã hóa base64url",
		json_string: "chuỗi JSON",
		e164: "số E.164",
		credit_card: "số thẻ tín dụng",
		jwt: "JWT",
		template_literal: "đầu vào"
	}, r = {
		nan: "NaN",
		number: "số",
		array: "mảng"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Đầu vào không hợp lệ: mong đợi instanceof ${e.expected}, nhận được ${i}` : `Đầu vào không hợp lệ: mong đợi ${t}, nhận được ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Đầu vào không hợp lệ: mong đợi ${P(e.values[0])}` : `Tùy chọn không hợp lệ: mong đợi một trong các giá trị ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Quá lớn: mong đợi ${e.origin ?? "giá trị"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit ?? "phần tử"}` : `Quá lớn: mong đợi ${e.origin ?? "giá trị"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Quá nhỏ: mong đợi ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `Quá nhỏ: mong đợi ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Chuỗi không hợp lệ: phải bắt đầu bằng "${t.prefix}"` : t.format === "ends_with" ? `Chuỗi không hợp lệ: phải kết thúc bằng "${t.suffix}"` : t.format === "includes" ? `Chuỗi không hợp lệ: phải bao gồm "${t.includes}"` : t.format === "regex" ? `Chuỗi không hợp lệ: phải khớp với mẫu ${t.pattern}` : `${n[t.format] ?? e.format} không hợp lệ`;
			}
			case "not_multiple_of": return `Số không hợp lệ: phải là bội số của ${e.divisor}`;
			case "unrecognized_keys": return `Khóa không được nhận dạng: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Khóa không hợp lệ trong ${e.origin}`;
			case "invalid_union": return "Đầu vào không hợp lệ";
			case "invalid_element": return `Giá trị không hợp lệ trong ${e.origin}`;
			default: return "Đầu vào không hợp lệ";
		}
	};
};
function Au() {
	return { localeError: ku() };
}
//#endregion
//#region node_modules/zod/v4/locales/zh-CN.js
var ju = () => {
	let e = {
		string: {
			unit: "字符",
			verb: "包含"
		},
		file: {
			unit: "字节",
			verb: "包含"
		},
		array: {
			unit: "项",
			verb: "包含"
		},
		set: {
			unit: "项",
			verb: "包含"
		},
		map: {
			unit: "项",
			verb: "包含"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "输入",
		email: "电子邮件",
		url: "URL",
		emoji: "表情符号",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO日期时间",
		date: "ISO日期",
		time: "ISO时间",
		duration: "ISO时长",
		ipv4: "IPv4地址",
		ipv6: "IPv6地址",
		mac: "MAC地址",
		cidrv4: "IPv4网段",
		cidrv6: "IPv6网段",
		base64: "base64编码字符串",
		base64url: "base64url编码字符串",
		json_string: "JSON字符串",
		e164: "E.164号码",
		credit_card: "信用卡号",
		jwt: "JWT",
		template_literal: "输入"
	}, r = {
		nan: "NaN",
		number: "数字",
		array: "数组",
		null: "空值(null)"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `无效输入：期望 instanceof ${e.expected}，实际接收 ${i}` : `无效输入：期望 ${t}，实际接收 ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `无效输入：期望 ${P(e.values[0])}` : `无效选项：期望以下之一 ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `数值过大：期望 ${e.origin ?? "值"} ${n}${e.maximum.toString()} ${r.unit ?? "个元素"}` : `数值过大：期望 ${e.origin ?? "值"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `数值过小：期望 ${e.origin} ${n}${e.minimum.toString()} ${r.unit}` : `数值过小：期望 ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `无效字符串：必须以 "${t.prefix}" 开头` : t.format === "ends_with" ? `无效字符串：必须以 "${t.suffix}" 结尾` : t.format === "includes" ? `无效字符串：必须包含 "${t.includes}"` : t.format === "regex" ? `无效字符串：必须满足正则表达式 ${t.pattern}` : `无效${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `无效数字：必须是 ${e.divisor} 的倍数`;
			case "unrecognized_keys": return `出现未知的键(key): ${x(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} 中的键(key)无效`;
			case "invalid_union": return "无效输入";
			case "invalid_element": return `${e.origin} 中包含无效值(value)`;
			default: return "无效输入";
		}
	};
};
function Mu() {
	return { localeError: ju() };
}
//#endregion
//#region node_modules/zod/v4/locales/zh-TW.js
var Nu = () => {
	let e = {
		string: {
			unit: "字元",
			verb: "擁有"
		},
		file: {
			unit: "位元組",
			verb: "擁有"
		},
		array: {
			unit: "項目",
			verb: "擁有"
		},
		set: {
			unit: "項目",
			verb: "擁有"
		},
		map: {
			unit: "項目",
			verb: "擁有"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "輸入",
		email: "郵件地址",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO 日期時間",
		date: "ISO 日期",
		time: "ISO 時間",
		duration: "ISO 期間",
		ipv4: "IPv4 位址",
		ipv6: "IPv6 位址",
		mac: "MAC 位址",
		cidrv4: "IPv4 範圍",
		cidrv6: "IPv6 範圍",
		base64: "base64 編碼字串",
		base64url: "base64url 編碼字串",
		json_string: "JSON 字串",
		e164: "E.164 數值",
		credit_card: "信用卡號",
		jwt: "JWT",
		template_literal: "輸入"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `無效的輸入值：預期為 instanceof ${e.expected}，但收到 ${i}` : `無效的輸入值：預期為 ${t}，但收到 ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `無效的輸入值：預期為 ${P(e.values[0])}` : `無效的選項：預期為以下其中之一 ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `數值過大：預期 ${e.origin ?? "值"} 應為 ${n}${e.maximum.toString()} ${r.unit ?? "個元素"}` : `數值過大：預期 ${e.origin ?? "值"} 應為 ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `數值過小：預期 ${e.origin} 應為 ${n}${e.minimum.toString()} ${r.unit}` : `數值過小：預期 ${e.origin} 應為 ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `無效的字串：必須以 "${t.prefix}" 開頭` : t.format === "ends_with" ? `無效的字串：必須以 "${t.suffix}" 結尾` : t.format === "includes" ? `無效的字串：必須包含 "${t.includes}"` : t.format === "regex" ? `無效的字串：必須符合格式 ${t.pattern}` : `無效的 ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `無效的數字：必須為 ${e.divisor} 的倍數`;
			case "unrecognized_keys": return `無法識別的鍵值${e.keys.length > 1 ? "們" : ""}：${x(e.keys, "、")}`;
			case "invalid_key": return `${e.origin} 中有無效的鍵值`;
			case "invalid_union": return "無效的輸入值";
			case "invalid_element": return `${e.origin} 中有無效的值`;
			default: return "無效的輸入值";
		}
	};
};
function Pu() {
	return { localeError: Nu() };
}
//#endregion
//#region node_modules/zod/v4/locales/yo.js
var Fu = () => {
	let e = {
		string: {
			unit: "àmi",
			verb: "ní"
		},
		file: {
			unit: "bytes",
			verb: "ní"
		},
		array: {
			unit: "nkan",
			verb: "ní"
		},
		set: {
			unit: "nkan",
			verb: "ní"
		},
		map: {
			unit: "nkan",
			verb: "ní"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ẹ̀rọ ìbáwọlé",
		email: "àdírẹ́sì ìmẹ́lì",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "àkókò ISO",
		date: "ọjọ́ ISO",
		time: "àkókò ISO",
		duration: "àkókò tó pé ISO",
		ipv4: "àdírẹ́sì IPv4",
		ipv6: "àdírẹ́sì IPv6",
		mac: "àdírẹ́sì MAC",
		cidrv4: "àgbègbè IPv4",
		cidrv6: "àgbègbè IPv6",
		base64: "ọ̀rọ̀ tí a kọ́ ní base64",
		base64url: "ọ̀rọ̀ base64url",
		json_string: "ọ̀rọ̀ JSON",
		e164: "nọ́mbà E.164",
		credit_card: "nọmba kaadi gbese",
		jwt: "JWT",
		template_literal: "ẹ̀rọ ìbáwọlé"
	}, r = {
		nan: "NaN",
		number: "nọ́mbà",
		array: "akopọ"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = E(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ìbáwọlé aṣìṣe: a ní láti fi instanceof ${e.expected}, àmọ̀ a rí ${i}` : `Ìbáwọlé aṣìṣe: a ní láti fi ${t}, àmọ̀ a rí ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ìbáwọlé aṣìṣe: a ní láti fi ${P(e.values[0])}` : `Àṣàyàn aṣìṣe: yan ọ̀kan lára ${x(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Tó pọ̀ jù: a ní láti jẹ́ pé ${e.origin ?? "iye"} ${r.verb} ${n}${e.maximum} ${r.unit}` : `Tó pọ̀ jù: a ní láti jẹ́ ${n}${e.maximum}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Kéré ju: a ní láti jẹ́ pé ${e.origin} ${r.verb} ${n}${e.minimum} ${r.unit}` : `Kéré ju: a ní láti jẹ́ ${n}${e.minimum}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ bẹ̀rẹ̀ pẹ̀lú "${t.prefix}"` : t.format === "ends_with" ? `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ parí pẹ̀lú "${t.suffix}"` : t.format === "includes" ? `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ ní "${t.includes}"` : t.format === "regex" ? `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ bá àpẹẹrẹ mu ${t.pattern}` : `Aṣìṣe: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Nọ́mbà aṣìṣe: gbọ́dọ̀ jẹ́ èyà pípín ti ${e.divisor}`;
			case "unrecognized_keys": return `Bọtìnì àìmọ̀: ${x(e.keys, ", ")}`;
			case "invalid_key": return `Bọtìnì aṣìṣe nínú ${e.origin}`;
			case "invalid_union": return "Ìbáwọlé aṣìṣe";
			case "invalid_element": return `Iye aṣìṣe nínú ${e.origin}`;
			default: return "Ìbáwọlé aṣìṣe";
		}
	};
};
function Iu() {
	return { localeError: Fu() };
}
//#endregion
//#region node_modules/zod/v4/locales/index.js
var Lu = /* @__PURE__ */ e({
	ar: () => xc,
	az: () => Cc,
	be: () => Ec,
	bg: () => Oc,
	bn: () => Ac,
	ca: () => Mc,
	ckb: () => Pc,
	cs: () => Ic,
	da: () => Rc,
	de: () => Bc,
	el: () => Hc,
	en: () => xt,
	eo: () => Wc,
	es: () => Kc,
	fa: () => Jc,
	fi: () => Xc,
	fr: () => Qc,
	frCA: () => el,
	gu: () => nl,
	he: () => il,
	hi: () => ol,
	hr: () => cl,
	hu: () => ul,
	hy: () => pl,
	id: () => hl,
	is: () => _l,
	it: () => yl,
	ja: () => xl,
	ka: () => Cl,
	kh: () => El,
	km: () => Tl,
	kn: () => Ol,
	ko: () => Al,
	lt: () => Pl,
	mk: () => Il,
	ms: () => Rl,
	ne: () => Bl,
	nl: () => Hl,
	nn: () => Wl,
	no: () => Kl,
	ota: () => Jl,
	pl: () => Ql,
	ps: () => Xl,
	pt: () => eu,
	ptBR: () => nu,
	ro: () => iu,
	ru: () => su,
	sk: () => lu,
	sl: () => du,
	sv: () => pu,
	ta: () => hu,
	th: () => _u,
	tk: () => yu,
	tr: () => xu,
	ua: () => wu,
	uk: () => Cu,
	ur: () => Eu,
	uz: () => Ou,
	vi: () => Au,
	yo: () => Iu,
	zhCN: () => Mu,
	zhTW: () => Pu
}), V = Symbol.for("zod.compile.invalid"), Ru = Symbol.for("zod.compile.fallback"), H = class extends Error {
	constructor(e = "z.compile does not support async refinements, transforms, or checks") {
		super(e), this.name = "ZodCompileAsyncError";
	}
}, U = class extends Error {
	constructor(e, t = !0) {
		super(`z.compile does not support ${e}; this schema must use the runtime parser`), this.name = "ZodCompileUnsupportedError", this.islandable = t;
	}
};
function zu(e, t) {
	try {
		return Hu(e, { assertOnly: !0 });
	} catch {
		return t;
	}
}
function Bu(e, t) {
	try {
		let t = Hu(e), n = L(e), r = e._zod.run, i = r.__originalRun ?? r, a = (e, n) => {
			if (n?.async || n?.direction === "backward" || n?.skipChecks || n?.[Ru] || n && jr(n, e.value)) return i(e, n);
			let r = t(e.value);
			return r === V ? (n && (n[Ru] = !0), i(e, n)) : (e.value = r, e);
		};
		return a.__originalRun = i, n._zod.bag.fallbackRun = i, n._zod.bag.validator = zu(e, t), n._zod.run = a, r.__originalRun || Vu(n, e, t), n;
	} catch (n) {
		if (t?.strict) throw n;
		return e;
	}
}
function Vu(e, t, n) {
	let r = e, i = t;
	if (typeof i.safeParse == "function") {
		let e = i.safeParse;
		r.safeParse = (t, r) => {
			let i = n(t);
			return i === V ? e(t, r) : {
				success: !0,
				data: i
			};
		};
	}
	if (typeof i.parse == "function") {
		let e = i.parse;
		r.parse = (t, r) => {
			let i = n(t);
			return i === V ? e(t, r) : i;
		};
	}
}
function Hu(e, t) {
	let n = !0;
	try {
		n = Jr(e);
	} catch {}
	if (n) throw new U("a schema whose subtree contains a reference cycle");
	let r = {
		constants: /* @__PURE__ */ new Map(),
		constantCounter: 0,
		varCounter: 0
	}, i = new Cn(["input"]), a = J(i, r, e, "input", !t?.assertOnly);
	i.write(a === null ? "return true;" : `return ${a};`);
	let o = ["INVALID", ...r.constants.keys()], s = [V, ...r.constants.values()], c = i.content.join("\n"), l = t?.debug ? o.length > 0 ? `// Constants: ${o.join(", ")}\n${c}` : c : "", u = Function, d = `return (input) => {\n${c}\n}`, f;
	try {
		f = new u(...o, d)(...s);
	} catch (e) {
		throw new U(`this schema (generated code failed to evaluate: ${e.message})`);
	}
	return t?.debug && (f.code = l), f;
}
function W(e, t) {
	for (let [n, r] of e.constants) if (r === t) return n;
	let n = `c${e.constantCounter++}`;
	return e.constants.set(n, t), n;
}
function G(e) {
	return `v${e.varCounter++}`;
}
function Uu(e, t) {
	let n = e._zod.run({
		value: t,
		issues: []
	}, {});
	if (n && typeof n.then == "function") return V;
	let r = n;
	return r.issues.length === 0 ? r.value : V;
}
function K(e, t, n, r, i = !0) {
	let a = e.content.length, o = t.constants.size, s = t.constantCounter, c = t.varCounter;
	try {
		return J(e, t, n, r, i);
	} catch (i) {
		if (!(i instanceof U) || !i.islandable) throw i;
		if (e.content.length = a, t.constants.size > o) {
			let e = Array.from(t.constants.keys()).slice(o);
			for (let n of e) t.constants.delete(n);
		}
		return t.constantCounter = s, t.varCounter = c, Wu(e, t, n, r);
	}
}
function Wu(e, t, n, r) {
	let i = W(t, n), a = W(t, Uu), o = G(t);
	return e.write(`const ${o} = ${a}(${i}, ${r});`), e.write(`if (${o} === INVALID) return INVALID;`), o;
}
var Gu = /* @__PURE__ */ new Set([
	"max_size",
	"min_size",
	"size_equals",
	"max_length",
	"min_length",
	"length_equals"
]);
function Ku(e, t, n, r) {
	let i = n._zod.def.checks;
	if (!i || i.length === 0) return r;
	let a = r;
	for (let n of i) {
		let r = n._zod.def;
		if (r.when && !Gu.has(r.check)) throw new U("check with a custom \"when\" condition");
		switch (r.check) {
			case "greater_than":
				Yu(e, t, r, a);
				break;
			case "less_than":
				Xu(e, t, r, a);
				break;
			case "multiple_of":
				Zu(e, t, r, a);
				break;
			case "number_format":
				Qu(e, r, a);
				break;
			case "min_length": {
				let n = q(r.minimum, "min_length"), i = qu(e, t, a, `${a}.length >= ${n} && ${a}.length < ${r.minimum * 2}`);
				e.write(`if (${i} < ${n}) return INVALID;`);
				break;
			}
			case "max_length": {
				let n = q(r.maximum, "max_length"), i = qu(e, t, a, `${a}.length > ${n}`);
				e.write(`if (${i} > ${n}) return INVALID;`);
				break;
			}
			case "length_equals": {
				let n = q(r.length, "length_equals"), i = qu(e, t, a, `${a}.length >= ${n} && ${a}.length <= ${r.length * 2}`);
				e.write(`if (${i} !== ${n}) return INVALID;`);
				break;
			}
			case "min_size":
				e.write(`if (${a}.size < ${q(r.minimum, "min_size")}) return INVALID;`);
				break;
			case "max_size":
				e.write(`if (${a}.size > ${q(r.maximum, "max_size")}) return INVALID;`);
				break;
			case "size_equals":
				e.write(`if (${a}.size !== ${q(r.size, "size_equals")}) return INVALID;`);
				break;
			case "string_format":
				a = sd(e, t, r, a);
				break;
			case "custom":
				a = ad(e, t, n, a);
				break;
			case "bigint_format":
				$u(e, r, a);
				break;
			case "mime_type":
				ed(e, t, r, a);
				break;
			case "property":
				td(e, t, r, a);
				break;
			case "overwrite": {
				let r = G(t);
				nd(e, t, n, a, r), a = r;
				break;
			}
			default: throw new U(`check type ${r.check}`);
		}
	}
	return a;
}
function qu(e, t, n, r) {
	let i = W(t, St), a = G(t);
	return e.write(`const ${a} = typeof ${n} === "string" && ${r} ? ${i}(${n}) : ${n}.length;`), a;
}
function q(e, t) {
	if (typeof e != "number" || !Number.isFinite(e)) throw new U(`${t} bound of type ${typeof e}`);
	return `${e}`;
}
function Ju(e, t) {
	if (typeof t == "bigint") return `${t}n`;
	if (typeof t == "number") {
		if (Number.isNaN(t)) throw new U("comparison check with NaN bound");
		return `${t}`;
	}
	if (t instanceof Date) {
		if (Number.isNaN(t.getTime())) throw new U("comparison check with Invalid Date bound");
		return W(e, t);
	}
	throw new U(`comparison check bound of type ${typeof t}`);
}
function Yu(e, t, n, r) {
	let i = n.inclusive ? "<" : "<=";
	e.write(`if (${r} ${i} ${Ju(t, n.value)}) return INVALID;`);
}
function Xu(e, t, n, r) {
	let i = n.inclusive ? ">" : ">=";
	e.write(`if (${r} ${i} ${Ju(t, n.value)}) return INVALID;`);
}
function Zu(e, t, n, r) {
	if (typeof n.value == "bigint") {
		if (n.value === BigInt(0)) throw new U("multiple_of check with a zero divisor");
		e.write(`if (${r} % ${n.value}n !== 0n) return INVALID;`);
	} else {
		let i = W(t, Mr);
		e.write(`if (${i}(${r}, ${q(n.value, "multiple_of")}) !== 0) return INVALID;`);
	}
}
function Qu(e, t, n) {
	let r = t.format;
	switch (r) {
		case "safeint":
			e.write(`if (!Number.isSafeInteger(${n})) return INVALID;`);
			break;
		case "int32":
			e.write(`if (!Number.isInteger(${n}) || ${n} < -2147483648 || ${n} > 2147483647) return INVALID;`);
			break;
		case "uint32":
			e.write(`if (!Number.isInteger(${n}) || ${n} < 0 || ${n} > 4294967295) return INVALID;`);
			break;
		case "float32":
			e.write(`if (!Number.isFinite(${n}) || ${n} < -3.4028234663852886e38 || ${n} > 3.4028234663852886e38) return INVALID;`);
			break;
		case "float64":
			e.write(`if (!Number.isFinite(${n})) return INVALID;`);
			break;
		default: throw new U(`number format ${r}`);
	}
}
function $u(e, t, n) {
	let r = t.format;
	if (r) switch (r) {
		case "int64":
			e.write(`if (${n} < -9223372036854775808n || ${n} > 9223372036854775807n) return INVALID;`);
			break;
		case "uint64":
			e.write(`if (${n} < 0n || ${n} > 18446744073709551615n) return INVALID;`);
			break;
		default: throw new U(`bigint format ${r}`);
	}
}
function ed(e, t, n, r) {
	let i = n.mime;
	if (i && i.length > 0) {
		let n = W(t, new Set(i));
		e.write(`if (!${n}.has(${r}.type)) return INVALID;`);
	}
}
function td(e, t, n, r) {
	let i = `${r}[${JSON.stringify(n.property)}]`;
	J(e, t, n.schema, i);
}
function nd(e, t, n, r, i) {
	let a = n._zod.def.tx;
	if (!a) throw new U("overwrite check without a transform function");
	if (Z(a)) throw new H("z.compile: async overwrite transforms are not supported");
	let o = W(t, a);
	e.write(`const ${i} = ${o}(${r});`);
}
function rd() {
	throw new Fn();
}
function id(e) {
	this.issues.push(e);
}
function ad(e, t, n, r) {
	let i = n._zod.def;
	if (i.fn) {
		if (Z(i.fn)) throw new H("z.compile: async .refine() predicates are not supported");
		let n = W(t, i.fn), a = W(t, rd), o = G(t);
		return e.write(`const ${o} = ${n}(${r});`), e.write(`if (${o} instanceof Promise) ${a}();`), e.write(`if (!${o}) return INVALID;`), r;
	}
	if (n._zod.check) {
		if (Z(n._zod.check)) throw new H("z.compile: async .superRefine() / check functions are not supported");
		let i = n._zod.check, a = W(t, (e) => {
			let t = {
				value: e,
				issues: [],
				addIssue: id
			};
			return i(t) instanceof Promise && rd(), t.issues.length === 0 ? t.value : V;
		}), o = G(t);
		return e.write(`const ${o} = ${a}(${r});`), e.write(`if (${o} === INVALID) return INVALID;`), o;
	}
	throw new U("custom check without a predicate or check function");
}
var od = /* @__PURE__ */ new Set([
	"cidrv4",
	"cuid",
	"cuid2",
	"date",
	"datetime",
	"duration",
	"e164",
	"email",
	"emoji",
	"ends_with",
	"guid",
	"includes",
	"ipv4",
	"ksuid",
	"lowercase",
	"mac",
	"nanoid",
	"regex",
	"starts_with",
	"time",
	"ulid",
	"uppercase",
	"uuid",
	"xid"
]);
function sd(e, t, n, r) {
	let i = n.format;
	if (i === "base64") {
		let n = W(t, ec);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (i === "base64url") {
		let n = W(t, Yn);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (i === "jwt") {
		let i = W(t, Le), a = W(t, n.alg ?? null);
		return e.write(`if (!${i}(${r}, ${a})) return INVALID;`), r;
	}
	if (i === "ipv6") {
		let n = W(t, ir);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (i === "cidrv6") {
		let n = W(t, ye);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (i === "credit_card") {
		let n = W(t, Ks);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	let a = n;
	if (i === "url" || i === "httpurl" || a.normalize || a.hostname !== void 0 || a.protocol !== void 0) {
		let i = W(t, mn), o = W(t, n), s = G(t), c = G(t);
		if (e.write(`const ${s} = ${r}.trim();`), e.write(`const ${c} = ${i}(${s}, ${o});`), e.write(`if (typeof ${c} === "number") return INVALID;`), a.hostname !== void 0) {
			let n = W(t, Va);
			e.write(`if (!${n}(${c}, ${o}.hostname)) return INVALID;`);
		}
		if (a.protocol !== void 0) {
			let n = W(t, Zt);
			e.write(`if (!${n}(${c}, ${o}.protocol)) return INVALID;`);
		}
		let l = G(t), u = a.normalize ? `${c}.href` : `${W(t, te)}(${s})`;
		return e.write(`const ${l} = ${u};`), l;
	}
	let o = n.fn;
	if (o) {
		if (Z(o)) throw new U(`async string format ${i}`);
		let n = W(t, o);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (od.has(i) && n.pattern) {
		let i = W(t, n.pattern);
		return e.write(`${i}.lastIndex = 0;`), e.write(`if (!${i}.test(${r})) return INVALID;`), r;
	}
	let s = n.format;
	switch (s) {
		case "regex": throw new U("regex format without a pattern");
		case "lowercase":
			e.write(`if (${r} !== ${r}.toLowerCase()) return INVALID;`);
			break;
		case "uppercase":
			e.write(`if (${r} !== ${r}.toUpperCase()) return INVALID;`);
			break;
		case "includes":
			e.write(`if (!${r}.includes(${T(n.includes)})) return INVALID;`);
			break;
		case "starts_with": {
			let t = n.prefix;
			e.write(`if (${r}.slice(0, ${t.length}) !== ${T(t)}) return INVALID;`);
			break;
		}
		case "ends_with": {
			let t = n.suffix;
			e.write(`if (${r}.slice(-${t.length}) !== ${T(t)}) return INVALID;`);
			break;
		}
		default: throw new U(`string format ${s}`);
	}
	return r;
}
function J(e, t, n, r, i = !0) {
	let a = n._zod.def, o = a.type;
	if (a.coerce) throw new U(`coercion (z.coerce.${o}())`);
	let s = i || !!a.checks?.length, c;
	switch (o) {
		case "string":
			c = cd(e, t, n, r);
			break;
		case "number":
			c = ld(e, n, r);
			break;
		case "boolean":
			c = ud(e, r);
			break;
		case "bigint":
			c = dd(e, n, r);
			break;
		case "symbol":
			c = fd(e, r);
			break;
		case "undefined":
			c = pd(e, r);
			break;
		case "null":
			c = md(e, r);
			break;
		case "any":
		case "unknown":
			c = r;
			break;
		case "never":
			e.write("return INVALID;"), c = r;
			break;
		case "void":
			c = hd(e, r);
			break;
		case "nan":
			c = gd(e, r);
			break;
		case "date":
			c = _d(e, r);
			break;
		case "object":
			c = vd(e, t, n, r, s);
			break;
		case "optional":
			c = yd(e, t, n, r, s);
			break;
		case "nullable":
			c = Cd(e, t, n, r, s);
			break;
		case "array":
			c = wd(e, t, n, r, s);
			break;
		case "literal":
			c = Td(e, t, n, r);
			break;
		case "enum":
			c = Ed(e, t, n, r);
			break;
		case "readonly": {
			let i = Dd(e, t, n, r), a = G(t);
			e.write(`const ${a} = Object.freeze(${i});`), c = a;
			break;
		}
		case "success":
			Dd(e, t, n, r), c = "true";
			break;
		case "default":
		case "prefault":
			c = Od(e, t, n, r);
			break;
		case "nonoptional":
			c = kd(e, t, n, r);
			break;
		case "tuple":
			c = Ad(e, t, n, r);
			break;
		case "union":
			c = Md(e, t, n, r);
			break;
		case "intersection":
			c = Fd(e, t, n, r);
			break;
		case "record":
			c = Id(e, t, n, r);
			break;
		case "map":
			c = Rd(e, t, n, r);
			break;
		case "set":
			c = zd(e, t, n, r);
			break;
		case "file":
			c = Bd(e, r);
			break;
		case "template_literal":
			c = Vd(e, t, n, r);
			break;
		case "lazy":
			c = Hd(e, t, n, r);
			break;
		case "pipe":
			c = Ud(e, t, n, r);
			break;
		case "custom":
			c = Wd(e, t, n, r);
			break;
		case "transform":
			c = qd(e, t, n, r);
			break;
		case "catch":
			c = Kd(e, t, n, r);
			break;
		default: throw new U(`schema type ${o}`);
	}
	return c === null ? null : Ku(e, t, n, c);
}
function cd(e, t, n, r) {
	e.write(`if (typeof ${r} !== "string") return INVALID;`);
	let i = n._zod.def;
	return i.format === void 0 ? r : sd(e, t, i, r);
}
function ld(e, t, n) {
	e.write(`if (typeof ${n} !== "number" || !Number.isFinite(${n})) return INVALID;`);
	let r = t._zod.def;
	return r.check === "number_format" && r.format && Qu(e, { format: r.format }, n), n;
}
function ud(e, t) {
	return e.write(`if (typeof ${t} !== "boolean") return INVALID;`), t;
}
function dd(e, t, n) {
	e.write(`if (typeof ${n} !== "bigint") return INVALID;`);
	let r = t._zod.def;
	if (r.format) switch (r.format) {
		case "int64":
			e.write(`if (${n} < -9223372036854775808n || ${n} > 9223372036854775807n) return INVALID;`);
			break;
		case "uint64": e.write(`if (${n} < 0n || ${n} > 18446744073709551615n) return INVALID;`);
	}
	return n;
}
function fd(e, t) {
	return e.write(`if (typeof ${t} !== "symbol") return INVALID;`), t;
}
function pd(e, t) {
	return e.write(`if (${t} !== undefined) return INVALID;`), t;
}
function md(e, t) {
	return e.write(`if (${t} !== null) return INVALID;`), t;
}
function hd(e, t) {
	return e.write(`if (${t} !== undefined) return INVALID;`), t;
}
function gd(e, t) {
	return e.write(`if (typeof ${t} !== "number" || !Number.isNaN(${t})) return INVALID;`), t;
}
function _d(e, t) {
	return e.write(`if (!(${t} instanceof Date) || Number.isNaN(${t}.getTime())) return INVALID;`), t;
}
function vd(e, t, n, r, i = !0) {
	let a = n._zod.def;
	e.write(`if (typeof ${r} !== "object" || ${r} === null || Array.isArray(${r})) return INVALID;`);
	let o = a.shape, s = Object.keys(o), c = Object.getOwnPropertySymbols(o), l = c.length ? [...s, ...c] : s, u = (e) => typeof e == "symbol" ? W(t, e) : T(e), d = (e) => typeof e == "symbol" ? `[${u(e)}]` : T(e), f = o;
	if (s.includes("__proto__")) throw new U("object shape key \"__proto__\"");
	let p = /* @__PURE__ */ new Map();
	for (let n of l) {
		let a = f[n], o = u(n), s = G(t);
		if (e.write(`const ${s} = ${r}[${o}];`), a._zod.optin !== void 0) {
			let i = G(t);
			e.write(`let ${i} = (() => {`), e.indented((e) => {
				let n = K(e, t, a, s);
				e.write(`return ${n};`);
			}), e.write("})();"), a._zod.optout === "optional" ? (e.write(`if (${i} === INVALID) {`), e.indented((e) => {
				e.write(`if (${o} in ${r}) return INVALID;`), e.write(`${i} = undefined;`);
			}), e.write("}")) : e.write(`if (${i} === INVALID) return INVALID;`), p.set(n, i);
		} else {
			xd(a) && e.write(`if (!(${o} in ${r})) return INVALID;`);
			let c = K(e, t, a, s, i);
			c !== null && p.set(n, c);
		}
	}
	let m = a.catchall, ee = "none";
	if (m) {
		let t = m._zod.def.type;
		if (t === "never") {
			let t = s.map((e) => `k !== ${T(e)}`).join(" && ") || "true";
			e.write(`for (const k in ${r}) {`), e.indented((e) => {
				e.write(`if (${t}) return INVALID;`);
			}), e.write("}");
		} else ee = (t === "unknown" || t === "any") && !m._zod.def.checks?.length ? "passthrough" : "schema";
	}
	let h = G(t), te = l.some((e) => X(f[e]) || Sd(f[e]));
	if (!i) {
		if (ee === "schema") {
			let n = s.length > 0 ? W(t, new Set(s)) : null;
			e.write(`for (const k in ${r}) {`), e.indented((e) => {
				e.write("if (k === \"__proto__\") continue;"), n && e.write(`if (${n}.has(k)) continue;`);
				let i = G(t);
				e.write(`const ${i} = ${r}[k];`), K(e, t, m, i, !1);
			}), e.write("}");
		}
		return null;
	}
	if (te) {
		e.write(`const ${h} = {};`);
		for (let t of l) {
			let n = u(t), i = p.get(t);
			Sd(f[t]) ? e.write(`if (${n} in ${r}) ${h}[${n}] = ${i};`) : X(f[t]) ? e.write(`if (${i} !== undefined || ${n} in ${r}) ${h}[${n}] = ${i};`) : e.write(`${h}[${n}] = ${i};`);
		}
	} else {
		let t = l.map((e) => `${d(e)}: ${p.get(e)}`).join(", ");
		e.write(`const ${h} = { ${t} };`);
	}
	if (ee !== "none") {
		let n = s.length > 0 ? W(t, new Set(s)) : null;
		e.write(`for (const k in ${r}) {`), e.indented((e) => {
			if (e.write("if (k === \"__proto__\") continue;"), n && e.write(`if (${n}.has(k)) continue;`), ee === "passthrough") e.write(`${h}[k] = ${r}[k];`);
			else {
				let n = G(t);
				e.write(`const ${n} = ${r}[k];`);
				let i = K(e, t, m, n);
				e.write(`${h}[k] = ${i};`);
			}
		}), e.write("}");
	}
	return h;
}
function yd(e, t, n, r, i = !0) {
	let a = n._zod.def;
	if (bd(n)) return J(e, t, a.innerType, r, i);
	if (a.innerType._zod.optin === "defaulted") {
		let n = G(t), i = G(t);
		return e.write(`let ${n};`), e.write(`if (${r} === undefined) {`), e.indented((e) => {
			e.write(`const ${i} = (() => {`), e.indented((e) => {
				let n = J(e, t, a.innerType, r);
				e.write(`return ${n};`);
			}), e.write("})();"), e.write(`if (${i} !== INVALID) ${n} = ${i};`);
		}), e.write("} else {"), e.indented((e) => {
			let i = J(e, t, a.innerType, r);
			e.write(`${n} = ${i};`);
		}), e.write("}"), n;
	}
	let o = i ? G(t) : null;
	return o && e.write(`let ${o};`), e.write(`if (${r} !== undefined) {`), e.indented((e) => {
		let n = J(e, t, a.innerType, r, i);
		o && n !== null && e.write(`${o} = ${n};`);
	}), e.write("}"), o;
}
function bd(e) {
	return e._zod.traits?.has("$ZodExactOptional") === !0;
}
function xd(e) {
	return e._zod.optin === void 0 && Y(e);
}
function Y(e) {
	if (e._zod.def.coerce) return !0;
	let t = e._zod.def;
	switch (t.type) {
		case "any":
		case "unknown":
		case "undefined":
		case "void":
		case "default":
		case "prefault":
		case "transform":
		case "custom":
		case "lazy": return !0;
		case "string":
		case "number":
		case "boolean":
		case "bigint":
		case "symbol":
		case "null":
		case "never":
		case "nan":
		case "date":
		case "object":
		case "array":
		case "tuple":
		case "record":
		case "map":
		case "set":
		case "file":
		case "template_literal": return !1;
		case "nonoptional": return t.innerType ? Y(t.innerType) : !1;
		case "literal": return !!t.values?.includes(void 0);
		case "enum": return !!e._zod.values?.has(void 0);
		case "optional":
		case "nullable":
		case "readonly":
		case "success": return !t.innerType || Y(t.innerType);
		case "catch": return !0;
		case "union": return !t.options || t.options.some(Y);
		case "intersection": return !t.left || !t.right || Y(t.left) && Y(t.right);
		case "pipe": return !t.in || Y(t.in);
		default: return !0;
	}
}
function Sd(e) {
	return e._zod.optin === "optional" && e._zod.optout === "optional";
}
function X(e) {
	let t = e._zod.def;
	switch (t.type) {
		case "string":
		case "number":
		case "boolean":
		case "bigint":
		case "symbol":
		case "null":
		case "nan":
		case "date":
		case "object":
		case "array":
		case "tuple":
		case "record":
		case "map":
		case "set":
		case "file":
		case "template_literal":
		case "never":
		case "success": return !1;
		case "literal": return !!t.values?.includes(void 0);
		case "enum": return !!e._zod.values?.has(void 0);
		case "optional": return !0;
		case "nullable":
		case "readonly":
		case "nonoptional": return !t.innerType || X(t.innerType);
		case "union": return !t.options || t.options.some(X);
		case "intersection": return !t.left || !t.right || X(t.left) || X(t.right);
		case "pipe": return !t.out || X(t.out);
		default: return !0;
	}
}
function Cd(e, t, n, r, i = !0) {
	let a = n._zod.def, o = i ? G(t) : null;
	return o && e.write(`let ${o} = null;`), e.write(`if (${r} !== null) {`), e.indented((e) => {
		let n = J(e, t, a.innerType, r, i);
		o && n !== null && e.write(`${o} = ${n};`);
	}), e.write("}"), o;
}
function wd(e, t, n, r, i = !0) {
	let a = n._zod.def;
	e.write(`if (!Array.isArray(${r})) return INVALID;`);
	let o = i ? G(t) : null, s = G(t), c = G(t);
	return o && e.write(`const ${o} = new Array(${r}.length);`), e.write(`for (let ${s} = 0; ${s} < ${r}.length; ${s}++) {`), e.indented((e) => {
		e.write(`const ${c} = ${r}[${s}];`);
		let n = K(e, t, a.element, c, i);
		o && n !== null && e.write(`${o}[${s}] = ${n};`);
	}), e.write("}"), o;
}
function Td(e, t, n, r) {
	let i = n._zod.def.values;
	if (i.length !== 1) {
		let n = W(t, new Set(i));
		return e.write(`if (!${n}.has(${r})) return INVALID;`), r;
	}
	let a = i[0];
	if (typeof a == "number" && Number.isNaN(a)) {
		let n = W(t, new Set(i));
		return e.write(`if (!${n}.has(${r})) return INVALID;`), r;
	}
	if (typeof a == "string") e.write(`if (${r} !== ${T(a)}) return INVALID;`);
	else if (typeof a == "number" || typeof a == "boolean") e.write(`if (${r} !== ${a}) return INVALID;`);
	else if (a === null) e.write(`if (${r} !== null) return INVALID;`);
	else if (a === void 0) e.write(`if (${r} !== undefined) return INVALID;`);
	else if (typeof a == "bigint") e.write(`if (${r} !== ${a}n) return INVALID;`);
	else throw new U(`literal type ${typeof a}`);
	return r;
}
function Ed(e, t, n, r) {
	let i = n._zod.values;
	if (!i) throw new U("enum schema without enumerated values");
	let a = W(t, i);
	return e.write(`if (!${a}.has(${r})) return INVALID;`), r;
}
function Dd(e, t, n, r) {
	let i = n._zod.def;
	return J(e, t, i.innerType, r);
}
function Od(e, t, n, r) {
	let i = n._zod.def, a = Object.getOwnPropertyDescriptor(n._zod.def, "defaultValue") ? () => n._zod.def.defaultValue : void 0;
	if (n._zod.def.type === "prefault") {
		if (!a) return J(e, t, i.innerType, r);
		let n = W(t, a), o = G(t);
		return e.write(`let ${o} = ${r};`), e.write(`if (${r} === undefined) ${o} = ${n}();`), J(e, t, i.innerType, o);
	}
	let o = G(t);
	if (a) {
		let n = W(t, a), s = W(t, gs);
		e.write(`let ${o};`), e.write(`if (${r} === undefined) {`), e.indented((e) => {
			e.write(`${o} = ${s}(${n}());`);
		}), e.write("} else {"), e.indented((e) => {
			let a = J(e, t, i.innerType, r);
			e.write(`${o} = ${a} === undefined ? ${s}(${n}()) : ${a};`);
		}), e.write("}");
	} else e.write(`let ${o};`), e.write(`if (${r} !== undefined) {`), e.indented((e) => {
		let n = J(e, t, i.innerType, r);
		e.write(`${o} = ${n};`);
	}), e.write("}");
	return o;
}
function kd(e, t, n, r) {
	let i = n._zod.def, a = J(e, t, i.innerType, r), o = G(t);
	return e.write(`const ${o} = ${a};`), e.write(`if (${o} === undefined) return INVALID;`), o;
}
function Ad(e, t, n, r) {
	let i = n._zod.def, a = i.items, o = i.rest;
	e.write(`if (!Array.isArray(${r})) return INVALID;`);
	let s = jd(a, "optin"), c = jd(a, "optout");
	o ? e.write(`if (${r}.length < ${s}) return INVALID;`) : e.write(`if (${r}.length < ${s} || ${r}.length > ${a.length}) return INVALID;`);
	let l = G(t);
	e.write(`const ${l} = [];`);
	for (let n = 0; n < a.length; n++) {
		let i = a[n];
		if (n >= c) e.write(`if (${l}.length === ${n}) {`), e.indented((e) => {
			e.write(`if (${n} < ${r}.length) {`), e.indented((e) => {
				let a = G(t);
				e.write(`const ${a} = ${r}[${n}];`);
				let o = K(e, t, i, a);
				e.write(`${l}[${n}] = ${o};`);
			}), e.write("} else {"), e.indented((e) => {
				if (Sd(i)) {
					e.write(`${l}.length = ${n};`);
					return;
				}
				let r = G(t), a = G(t);
				e.write(`const ${r} = undefined;`), e.write(`const ${a} = (() => {`), e.indented((e) => {
					let n = K(e, t, i, r);
					e.write(`return ${n};`);
				}), e.write("})();"), e.write(`if (${a} === INVALID || ${a} === undefined) ${l}.length = ${n};`), e.write(`else ${l}[${n}] = ${a};`);
			}), e.write("}");
		}), e.write("}");
		else {
			let a = G(t);
			e.write(`const ${a} = ${r}[${n}];`);
			let o = K(e, t, i, a);
			e.write(`${l}[${n}] = ${o};`);
		}
	}
	if (o) {
		let n = G(t), i = G(t);
		e.write(`for (let ${n} = ${a.length}; ${n} < ${r}.length; ${n}++) {`), e.indented((e) => {
			e.write(`const ${i} = ${r}[${n}];`);
			let a = K(e, t, o, i);
			e.write(`${l}[${n}] = ${a};`);
		}), e.write("}");
	}
	return l;
}
function jd(e, t) {
	for (let n = e.length - 1; n >= 0; n--) if (!(t === "optin" ? e[n]._zod.optin !== void 0 : e[n]._zod.optout === "optional")) return n + 1;
	return 0;
}
function Md(e, t, n, r) {
	let i = n._zod.def, a = i.options;
	if (i.discriminator) return Nd(e, t, i, r);
	if (i.inclusive === !1) throw new U("exclusive unions (z.xor)");
	if (a.length === 0) return e.write("return INVALID;"), r;
	if (a.length === 1) return J(e, t, a[0], r);
	if (a.every((e) => e._zod.def.type === "literal" && !e._zod.def.checks?.length)) {
		let n = W(t, new Set(a.flatMap((e) => e._zod.def.values)));
		return e.write(`if (!${n}.has(${r})) return INVALID;`), r;
	}
	let o = G(t);
	e.write(`let ${o};`);
	for (let n = 0; n < a.length; n++) {
		let i = a[n];
		n === 0 ? e.write(`${o} = (() => {`) : e.write(`if (${o} === INVALID) ${o} = (() => {`), e.indented((e) => {
			let n = J(e, t, i, r);
			e.write(`return ${n};`);
		}), e.write("})();");
	}
	return e.write(`if (${o} === INVALID) return INVALID;`), o;
}
function Nd(e, t, n, r) {
	if (n.unionFallback) throw new U("discriminated union with unionFallback");
	if (n.options.length === 0) return e.write("return INVALID;"), r;
	let i = G(t), a = G(t);
	e.write(`const ${i} = ${r}?.[${T(n.discriminator)}];`), e.write(`let ${a};`);
	let o = !0, s = /* @__PURE__ */ new Set();
	for (let c of n.options) {
		let l = c._zod.propValues?.[n.discriminator];
		if (!l || l.size === 0) throw new U("discriminated union option without static discriminator values");
		for (let e of l) {
			if (s.has(e)) throw new U(`duplicate discriminator value ${String(e)}`);
			s.add(e);
		}
		let u = Array.from(l, (e) => Pd(t, i, e)), d = o ? "if" : "else if";
		e.write(`${d} (${u.join(" || ")}) {`), e.indented((e) => {
			let n = J(e, t, c, r);
			e.write(`${a} = ${n};`);
		}), e.write("}"), o = !1;
	}
	return e.write("else { return INVALID; }"), a;
}
function Pd(e, t, n) {
	if (typeof n == "string") return `${t} === ${T(n)}`;
	if (typeof n == "number") return Number.isNaN(n) ? `Number.isNaN(${t})` : `${t} === ${n}`;
	if (typeof n == "boolean") return `${t} === ${n}`;
	if (n === null) return `${t} === null`;
	if (n === void 0) return `${t} === undefined`;
	if (typeof n == "bigint") return `${t} === ${n}n`;
	if (typeof n == "symbol") return `${t} === ${W(e, n)}`;
	throw new U(`literal discriminator value ${String(n)}`);
}
function Fd(e, t, n, r) {
	let i = n._zod.def, a = K(e, t, i.left, r), o = K(e, t, i.right, r), s = W(t, Oe), c = G(t);
	return e.write(`const ${c} = ${s}(${a}, ${o});`), e.write(`if (!${c}.valid) return INVALID;`), `${c}.data`;
}
function Id(e, t, n, r) {
	let i = n._zod.def, a = W(t, Yr);
	e.write(`if (!${a}(${r})) return INVALID;`);
	let o = G(t), s = G(t), c = G(t);
	e.write(`const ${o} = {};`);
	let l = i, u = l.partial ? void 0 : i.keyType._zod.values;
	if (u) {
		let n = [];
		for (let a of u) {
			if (typeof a != "string" && typeof a != "number" && typeof a != "symbol") throw new U(`record key value ${String(a)}`);
			let s = typeof a == "number" ? a.toString() : a;
			if (s === "__proto__") throw new U("record key \"__proto__\"");
			n.push(s);
			let c = W(t, a), l = J(e, t, i.keyType, c), u = G(t);
			e.write(`const ${u} = ${r}[${Ld(t, s)}];`);
			let d = K(e, t, i.valueType, u);
			e.write(`${o}[${l}] = ${d};`);
		}
		let a = W(t, new Set(n));
		return e.write(`for (const ${s} in ${r}) {`), e.indented((e) => {
			e.write(`if (${a}.has(${s})) continue;`), l.mode === "loose" ? e.write(`if (${s} !== "__proto__") ${o}[${s}] = ${r}[${s}];`) : e.write("return INVALID;");
		}), e.write("}"), o;
	}
	let d = i.keyType._zod.def;
	if (d.type !== "string" || d.format !== void 0 || d.coerce || (d.checks?.length ?? 0) !== 0) {
		let n = i.mode === "loose", a = W(t, Hu(i.keyType)), c = W(t, Yo), l = W(t, Object.prototype.propertyIsEnumerable), u = G(t);
		return e.write(`for (const ${s} of Reflect.ownKeys(${r})) {`), e.indented((e) => {
			e.write(`if (${s} === "__proto__") continue;`), e.write(`if (!${l}.call(${r}, ${s})) continue;`), e.write(`let ${u} = ${a}(${s});`), e.write(`if (${u} === INVALID && typeof ${s} === "string" && ${c}.test(${s})) ${u} = ${a}(Number(${s}));`), n ? e.write(`if (${u} === INVALID) { ${o}[${s}] = ${r}[${s}]; continue; }`) : e.write(`if (${u} === INVALID) return INVALID;`), e.write(`if (${u} === "__proto__") continue;`);
			let d = G(t);
			e.write(`const ${d} = ${r}[${s}];`);
			let f = K(e, t, i.valueType, d);
			e.write(`${o}[${u}] = ${f};`);
		}), e.write("}"), o;
	}
	let f = W(t, Object.prototype.propertyIsEnumerable);
	return e.write(`for (const ${s} of Reflect.ownKeys(${r})) {`), e.indented((e) => {
		e.write(`if (${s} === "__proto__") continue;`), e.write(`if (!${f}.call(${r}, ${s})) continue;`), e.write(`if (typeof ${s} !== "string") return INVALID;`), e.write(`const ${c} = ${r}[${s}];`);
		let n = K(e, t, i.valueType, c);
		e.write(`${o}[${s}] = ${n};`);
	}), e.write("}"), o;
}
function Ld(e, t) {
	return typeof t == "string" ? T(t) : W(e, t);
}
function Rd(e, t, n, r) {
	let i = n._zod.def;
	e.write(`if (!(${r} instanceof Map)) return INVALID;`);
	let a = G(t), o = G(t), s = G(t);
	return e.write(`const ${a} = new Map();`), e.write(`for (const [${o}, ${s}] of ${r}) {`), e.indented((e) => {
		let n = J(e, t, i.keyType, o), r = J(e, t, i.valueType, s);
		e.write(`${a}.set(${n}, ${r});`);
	}), e.write("}"), a;
}
function zd(e, t, n, r) {
	let i = n._zod.def;
	e.write(`if (!(${r} instanceof Set)) return INVALID;`);
	let a = G(t), o = G(t);
	return e.write(`const ${a} = new Set();`), e.write(`for (const ${o} of ${r}) {`), e.indented((e) => {
		let n = J(e, t, i.valueType, o);
		e.write(`${a}.add(${n});`);
	}), e.write("}"), a;
}
function Bd(e, t) {
	return e.write(`if (!(${t} instanceof File)) return INVALID;`), t;
}
function Vd(e, t, n, r) {
	e.write(`if (typeof ${r} !== "string") return INVALID;`);
	let i = n._zod.pattern;
	if (i) {
		let n = W(t, i);
		e.write(`${n}.lastIndex = 0;`), e.write(`if (!${n}.test(${r})) return INVALID;`);
	}
	return r;
}
function Hd(e, t, n, r) {
	let i = n._zod.def, a = W(t, i.getter), o = W(t, { parser: null });
	e.write(`if (!${o}.parser) {`), e.indented((e) => {
		e.write(`const inner = ${a}();`), e.write(`${o}.parser = function(input) {`), e.indented((e) => {
			e.write("const result = inner._zod.run({ value: input, issues: [] }, {});"), e.write("return result.issues.length === 0 ? result.value : INVALID;");
		}), e.write("};");
	}), e.write("}");
	let s = G(t);
	return e.write(`const ${s} = ${o}.parser(${r});`), e.write(`if (${s} === INVALID) return INVALID;`), s;
}
function Ud(e, t, n, r) {
	let i = n._zod.def, a = J(e, t, i.in, r);
	if (i.transform) {
		if (Z(i.transform)) throw new H("z.compile: async transforms in pipes are not supported");
		let n = i.transform, r = W(t, (e) => {
			let t = {
				value: e,
				issues: [],
				addIssue: id
			}, r = n(e, t);
			return r instanceof Promise ? V : t.issues.length === 0 ? r : V;
		}), o = G(t);
		return e.write(`const ${o} = ${r}(${a});`), e.write(`if (${o} === INVALID) return INVALID;`), J(e, t, i.out, o);
	}
	return J(e, t, i.out, a);
}
function Z(e) {
	return typeof e == "function" && (e.constructor.name === "AsyncFunction" || e[Symbol.toStringTag] === "AsyncFunction");
}
function Wd(e, t, n, r) {
	let i = n._zod.def;
	if (i.fn) {
		if (Z(i.fn)) throw new H("z.compile: async custom predicates are not supported");
		let n = W(t, i.fn), a = W(t, rd), o = G(t);
		e.write(`const ${o} = ${n}(${r});`), e.write(`if (${o} instanceof Promise) ${a}();`), e.write(`if (!${o}) return INVALID;`);
	} else throw new U("custom schema without a predicate function");
	return r;
}
function Gd(e, t, n) {
	let r = e._zod.run({
		value: n,
		issues: []
	}, {});
	if (r && typeof r.then == "function") return V;
	let i = r;
	return i.issues.length === 0 ? i.value : t();
}
function Kd(e, t, n, r) {
	let i = n._zod.def;
	if (!i.catchValue["~constantCatch"]) throw new U("catch with a callback (only a constant catch value compiles)", !1);
	let a = G(t);
	e.write(`let ${a} = (() => {`), e.indented((e) => {
		let n = K(e, t, i.innerType, r);
		e.write(`return ${n};`);
	}), e.write("})();");
	let o = W(t, i.innerType), s = W(t, i.catchValue), c = W(t, Gd);
	return e.write(`if (${a} === INVALID) {`), e.indented((e) => {
		e.write(`${a} = ${c}(${o}, ${s}, ${r});`), e.write(`if (${a} === INVALID) return INVALID;`);
	}), e.write("}"), a;
}
function qd(e, t, n, r) {
	let i = n._zod.def;
	if (i.transform) {
		if (Z(i.transform)) throw new H("z.compile: async transforms are not supported");
		let n = i.transform, a = W(t, (e) => {
			let t = {
				value: e,
				issues: [],
				addIssue: id
			}, r = n(e, t);
			return r instanceof Promise ? V : t.issues.length === 0 ? r : V;
		}), o = G(t);
		return e.write(`const ${o} = ${a}(${r});`), e.write(`if (${o} === INVALID) return INVALID;`), o;
	}
	return r;
}
//#endregion
//#region node_modules/zod/v4/core/json-schema-generator.js
var Jd = class {
	get metadataRegistry() {
		return this.ctx.metadataRegistry;
	}
	get target() {
		return this.ctx.target;
	}
	get unrepresentable() {
		return this.ctx.unrepresentable;
	}
	get override() {
		return this.ctx.override;
	}
	get io() {
		return this.ctx.io;
	}
	get counter() {
		return this.ctx.counter;
	}
	set counter(e) {
		this.ctx.counter = e;
	}
	get seen() {
		return this.ctx.seen;
	}
	constructor(e) {
		let t = e?.target ?? "draft-2020-12";
		t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), this.ctx = Xt({
			processors: rr,
			target: t,
			...e?.metadata && { metadata: e.metadata },
			...e?.unrepresentable && { unrepresentable: e.unrepresentable },
			...e?.override && { override: e.override },
			...e?.io && { io: e.io }
		});
	}
	process(e, t = {
		path: [],
		schemaPath: []
	}) {
		return an(e, this.ctx, t);
	}
	emit(e, t) {
		t && (t.cycles && (this.ctx.cycles = t.cycles), t.reused && (this.ctx.reused = t.reused), t.external && (this.ctx.external = t.external)), this.ctx.sharedDefsExtractedFor = void 0, this.ctx.sharedEmitDoneFor = void 0, Ya(this.ctx, e);
		let { "~standard": n, ...r } = h(this.ctx, e);
		return r;
	}
}, Yd = /* @__PURE__ */ e({}), Xd = /* @__PURE__ */ e({
	$ZodAny: () => n,
	$ZodArray: () => Zi,
	$ZodAsyncError: () => Fn,
	$ZodBase64: () => vs,
	$ZodBase64URL: () => yo,
	$ZodBigInt: () => $o,
	$ZodBigIntFormat: () => Ma,
	$ZodBoolean: () => gi,
	$ZodCIDRv4: () => Do,
	$ZodCIDRv6: () => cs,
	$ZodCUID: () => Pi,
	$ZodCUID2: () => no,
	$ZodCatch: () => Ds,
	$ZodCheck: () => Ke,
	$ZodCheckBigIntFormat: () => vt,
	$ZodCheckEndsWith: () => Gt,
	$ZodCheckGreaterThan: () => Bn,
	$ZodCheckIncludes: () => vc,
	$ZodCheckLengthEquals: () => ue,
	$ZodCheckLessThan: () => br,
	$ZodCheckLowerCase: () => lt,
	$ZodCheckMaxLength: () => dr,
	$ZodCheckMaxSize: () => Or,
	$ZodCheckMimeType: () => et,
	$ZodCheckMinLength: () => It,
	$ZodCheckMinSize: () => Go,
	$ZodCheckMultipleOf: () => Dt,
	$ZodCheckNumberFormat: () => Gr,
	$ZodCheckOverwrite: () => Lr,
	$ZodCheckProperty: () => ei,
	$ZodCheckRegex: () => jn,
	$ZodCheckSizeEquals: () => c,
	$ZodCheckStartsWith: () => Ji,
	$ZodCheckStringFormat: () => ms,
	$ZodCheckUpperCase: () => go,
	$ZodCodec: () => Ui,
	$ZodCreditCard: () => aa,
	$ZodCustom: () => Fo,
	$ZodCustomStringFormat: () => uo,
	$ZodCyclicError: () => Br,
	$ZodDate: () => Ca,
	$ZodDefault: () => ma,
	$ZodDiscriminatedUnion: () => si,
	$ZodE164: () => Is,
	$ZodEmail: () => sc,
	$ZodEmoji: () => Ti,
	$ZodEncodeError: () => pc,
	$ZodEnum: () => Qs,
	$ZodError: () => La,
	$ZodExactOptional: () => qn,
	$ZodFile: () => _e,
	$ZodFunction: () => Ws,
	$ZodGUID: () => nr,
	$ZodIPv4: () => Fe,
	$ZodIPv6: () => Ee,
	$ZodISODate: () => fn,
	$ZodISODateTime: () => Ja,
	$ZodISODuration: () => ee,
	$ZodISOTime: () => za,
	$ZodIntersection: () => Yt,
	$ZodJWT: () => rn,
	$ZodKSUID: () => xn,
	$ZodLazy: () => We,
	$ZodLiteral: () => gt,
	$ZodMAC: () => Ut,
	$ZodMap: () => Rn,
	$ZodNaN: () => gc,
	$ZodNanoID: () => ce,
	$ZodNever: () => vr,
	$ZodNonOptional: () => st,
	$ZodNull: () => lr,
	$ZodNullable: () => Er,
	$ZodNumber: () => Qe,
	$ZodNumberFormat: () => Pt,
	$ZodObject: () => Uo,
	$ZodObjectJIT: () => Tt,
	$ZodOptional: () => Ur,
	$ZodPipe: () => Fr,
	$ZodPrefault: () => Qr,
	$ZodPreprocess: () => kn,
	$ZodPromise: () => o,
	$ZodReadonly: () => $i,
	$ZodRealError: () => qt,
	$ZodRecord: () => bs,
	$ZodRegistry: () => or,
	$ZodSet: () => xo,
	$ZodString: () => ts,
	$ZodStringFormat: () => Pa,
	$ZodSuccess: () => vi,
	$ZodSymbol: () => ko,
	$ZodTemplateLiteral: () => us,
	$ZodTransform: () => Ii,
	$ZodTuple: () => io,
	$ZodType: () => ks,
	$ZodULID: () => Gi,
	$ZodURL: () => sa,
	$ZodUUID: () => Lo,
	$ZodUndefined: () => po,
	$ZodUnion: () => Ta,
	$ZodUnknown: () => ga,
	$ZodVoid: () => li,
	$ZodXID: () => Rs,
	$ZodXor: () => lc,
	$brand: () => ae,
	$constructor: () => hr,
	$input: () => Cr,
	$output: () => Ye,
	Doc: () => Cn,
	INVALID: () => V,
	JSONSchema: () => Yd,
	JSONSchemaGenerator: () => Jd,
	NEVER: () => it,
	TimePrecision: () => Sn,
	URL_BAD_FORMAT: () => 1,
	URL_UNPARSEABLE: () => 2,
	ZodCompileAsyncError: () => H,
	ZodCompileUnsupportedError: () => U,
	_any: () => Ge,
	_array: () => _t,
	_base64: () => Wt,
	_base64url: () => zn,
	_bigint: () => _c,
	_boolean: () => le,
	_catch: () => yr,
	_check: () => ct,
	_cidrv4: () => ur,
	_cidrv6: () => Dr,
	_coercedBigint: () => $e,
	_coercedBoolean: () => Ft,
	_coercedDate: () => Wo,
	_coercedNumber: () => Et,
	_coercedString: () => Wr,
	_creditCard: () => Ir,
	_cuid: () => $r,
	_cuid2: () => An,
	_custom: () => s,
	_date: () => Yi,
	_decode: () => pi,
	_decodeAsync: () => To,
	_default: () => hs,
	_discriminatedUnion: () => _o,
	_e164: () => Xo,
	_email: () => ka,
	_emoji: () => mi,
	_encode: () => as,
	_encodeAsync: () => ji,
	_endsWith: () => F,
	_enum: () => os,
	_file: () => Mi,
	_float32: () => eo,
	_float64: () => Ts,
	_gt: () => Vi,
	_gte: () => D,
	_guid: () => No,
	_includes: () => M,
	_int: () => xa,
	_int32: () => fa,
	_int64: () => ai,
	_intersection: () => Ps,
	_ipv4: () => ac,
	_ipv6: () => Ci,
	_isoDate: () => Xs,
	_isoDateTime: () => Gn,
	_isoDuration: () => he,
	_isoTime: () => Hs,
	_jwt: () => er,
	_ksuid: () => Ne,
	_lazy: () => we,
	_length: () => b,
	_literal: () => Ka,
	_lowercase: () => p,
	_lt: () => A,
	_lte: () => v,
	_mac: () => tn,
	_map: () => yn,
	_max: () => v,
	_maxLength: () => He,
	_maxSize: () => mt,
	_mime: () => Vt,
	_min: () => D,
	_minLength: () => In,
	_minSize: () => mc,
	_multipleOf: () => oe,
	_nan: () => gr,
	_nanoid: () => at,
	_nativeEnum: () => sr,
	_negative: () => w,
	_never: () => Xe,
	_nonnegative: () => Mt,
	_nonoptional: () => Vo,
	_nonpositive: () => Ct,
	_normalize: () => Vr,
	_null: () => Nr,
	_nullable: () => Xr,
	_number: () => Dn,
	_optional: () => i,
	_overwrite: () => qi,
	_parse: () => $a,
	_parseAsync: () => ws,
	_pipe: () => ps,
	_positive: () => N,
	_promise: () => Jo,
	_properties: () => O,
	_property: () => fi,
	_readonly: () => wo,
	_record: () => is,
	_refine: () => Ai,
	_regex: () => j,
	_safeDecode: () => Bi,
	_safeDecodeAsync: () => ra,
	_safeEncode: () => Mo,
	_safeEncodeAsync: () => co,
	_safeParse: () => ba,
	_safeParseAsync: () => da,
	_set: () => Cs,
	_size: () => zi,
	_slugify: () => na,
	_startsWith: () => I,
	_string: () => so,
	_stringFormat: () => ya,
	_stringbool: () => ua,
	_success: () => ri,
	_superRefine: () => Ms,
	_symbol: () => rc,
	_templateLiteral: () => xi,
	_toLowerCase: () => z,
	_toUpperCase: () => Un,
	_transform: () => pe,
	_trim: () => R,
	_tuple: () => Qn,
	_uint32: () => je,
	_uint64: () => Se,
	_ulid: () => ln,
	_undefined: () => Wa,
	_union: () => d,
	_unknown: () => Ia,
	_uppercase: () => _,
	_url: () => $t,
	_uuid: () => _n,
	_uuidv4: () => Be,
	_uuidv6: () => ft,
	_uuidv7: () => zt,
	_void: () => Pn,
	_xid: () => fc,
	_xor: () => ie,
	clone: () => L,
	compile: () => Bu,
	compileFn: () => Hu,
	config: () => C,
	createStandardJSONSchemaMethod: () => De,
	createToJSONSchemaMethod: () => pn,
	decode: () => ii,
	decodeAsync: () => Ns,
	describe: () => mr,
	encode: () => ic,
	encodeAsync: () => Si,
	extractDefs: () => Ya,
	finalize: () => h,
	flattenError: () => en,
	formatError: () => vn,
	getDiscriminatedOption: () => Di,
	globalConfig: () => wr,
	globalRegistry: () => At,
	handleUnrepresentable: () => Ba,
	initializeContext: () => Xt,
	isBackEdge: () => jr,
	isRecursiveSchema: () => Jr,
	isValidBase64: () => ec,
	isValidBase64URL: () => Yn,
	isValidCIDRv6: () => ye,
	isValidCreditCard: () => Ks,
	isValidIPv6: () => ir,
	isValidJWT: () => Le,
	locales: () => Lu,
	memoizer: () => En,
	mergeValues: () => Oe,
	meta: () => rt,
	parse: () => Ys,
	parseAsync: () => Wn,
	parseURLObject: () => mn,
	prettifyError: () => Ve,
	process: () => an,
	regexes: () => Oa,
	registry: () => Bo,
	safeDecode: () => me,
	safeDecodeAsync: () => Vs,
	safeEncode: () => $n,
	safeEncodeAsync: () => Me,
	safeParse: () => Ce,
	safeParseAsync: () => un,
	standardProps: () => Xa,
	stripTabAndNewline: () => te,
	toDotPath: () => pt,
	toJSONSchema: () => Ie,
	toZod: () => Zo,
	treeifyError: () => Bt,
	urlHostnameOk: () => Va,
	urlProtocolOk: () => Zt,
	util: () => Aa,
	validate: () => Ga,
	validateAsync: () => f,
	version: () => on
}), Zd = /* @__PURE__ */ e({
	endsWith: () => F,
	gt: () => Vi,
	gte: () => D,
	includes: () => M,
	length: () => b,
	lowercase: () => p,
	lt: () => A,
	lte: () => v,
	maxLength: () => He,
	maxSize: () => mt,
	mime: () => Vt,
	minLength: () => In,
	minSize: () => mc,
	multipleOf: () => oe,
	negative: () => w,
	nonnegative: () => Mt,
	nonpositive: () => Ct,
	normalize: () => Vr,
	overwrite: () => qi,
	positive: () => N,
	properties: () => O,
	property: () => fi,
	regex: () => j,
	size: () => zi,
	slugify: () => na,
	startsWith: () => I,
	toLowerCase: () => z,
	toUpperCase: () => Un,
	trim: () => R,
	uppercase: () => _
}), Qd = {
	invalid_type: "invalid_type",
	too_big: "too_big",
	too_small: "too_small",
	invalid_format: "invalid_format",
	not_multiple_of: "not_multiple_of",
	unrecognized_keys: "unrecognized_keys",
	invalid_union: "invalid_union",
	invalid_key: "invalid_key",
	invalid_element: "invalid_element",
	invalid_value: "invalid_value",
	custom: "custom"
};
function $d(e) {
	C({ customError: e });
}
function ef() {
	return C().customError;
}
var tf;
tf ||= {};
//#endregion
//#region node_modules/zod/v4/classic/iso.js
var nf = /* @__PURE__ */ e({
	ZodISODate: () => u,
	ZodISODateTime: () => k,
	ZodISODuration: () => g,
	ZodISOTime: () => y,
	date: () => af,
	datetime: () => rf,
	duration: () => sf,
	time: () => of
});
function rf(e) {
	return Gn(k, e);
}
function af(e) {
	return Xs(u, e);
}
function of(e) {
	return Hs(y, e);
}
function sf(e) {
	return he(g, e);
}
//#endregion
//#region node_modules/zod/v4/classic/from-json-schema.js
var Q = {
	..._r,
	...Zd,
	iso: nf
}, cf = /*@__PURE__*/ new Set(/* @__PURE__ */ "$schema.$ref.$defs.definitions.$id.id.$comment.$anchor.$vocabulary.$dynamicRef.$dynamicAnchor.type.enum.const.anyOf.oneOf.allOf.not.properties.required.additionalProperties.patternProperties.propertyNames.minProperties.maxProperties.items.prefixItems.additionalItems.minItems.maxItems.uniqueItems.contains.minContains.maxContains.minLength.maxLength.pattern.format.minimum.maximum.exclusiveMinimum.exclusiveMaximum.multipleOf.description.default.contentEncoding.contentMediaType.contentSchema.unevaluatedItems.unevaluatedProperties.if.then.else.dependentSchemas.dependentRequired.nullable.readOnly".split("."));
function lf(e, t) {
	let n = e.$schema;
	return n === "https://json-schema.org/draft/2020-12/schema" ? "draft-2020-12" : n === "http://json-schema.org/draft-07/schema#" ? "draft-7" : n === "http://json-schema.org/draft-04/schema#" ? "draft-4" : t ?? "draft-2020-12";
}
function uf(e, t) {
	return e.map((e, n) => n < t ? e : e.optional());
}
function df(e) {
	return e.replace(/~1/g, "/").replace(/~0/g, "~");
}
function ff(e, t) {
	if (!e.startsWith("#")) throw Error("External $ref is not supported, only local refs (#/...) are allowed");
	let n = e.slice(1).split("/").filter(Boolean);
	if (n.length === 0) return t.rootSchema;
	let r = t.version === "draft-2020-12" ? "$defs" : "definitions";
	if (n[0] === r) {
		let r = n[1] === void 0 ? void 0 : df(n[1]);
		if (!r || !t.defs[r]) throw Error(`Reference not found: ${e}`);
		return t.defs[r];
	}
	throw Error(`Reference not found: ${e}`);
}
function pf(e, t) {
	return Q.transform((e) => e).check((e) => {
		let n = e.value;
		if (typeof n == "object" && n && !Array.isArray(n)) for (let r of Object.getOwnPropertyNames(n)) {
			let n = t.safeParse(r);
			n.success || e.issues.push({
				code: "invalid_key",
				origin: "record",
				issues: n.error.issues,
				input: r,
				path: [r],
				continue: !0
			});
		}
	}).pipe(e);
}
function mf(e, t) {
	if (e !== !1) return e === void 0 || e === !0 ? Q.any() : $(e, t);
}
var hf = /^(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/;
function gf(e, t) {
	if (e.not !== void 0) {
		if (typeof e.not == "object" && Object.keys(e.not).length === 0) return Q.never();
		throw Error("not is not supported in Zod (except { not: {} } for never)");
	}
	if (e.unevaluatedItems !== void 0) throw Error("unevaluatedItems is not supported");
	if (e.unevaluatedProperties !== void 0) throw Error("unevaluatedProperties is not supported");
	if (e.if !== void 0 || e.then !== void 0 || e.else !== void 0) throw Error("Conditional schemas (if/then/else) are not supported");
	if (e.dependentSchemas !== void 0 || e.dependentRequired !== void 0) throw Error("dependentSchemas and dependentRequired are not supported");
	if (e.$ref) {
		let n = e.$ref;
		if (t.refs.has(n)) return t.refs.get(n);
		if (t.processing.has(n)) return Q.lazy(() => {
			if (!t.refs.has(n)) throw Error(`Circular reference not resolved: ${n}`);
			return t.refs.get(n);
		});
		t.processing.add(n);
		let r = $(ff(n, t), t);
		return t.refs.set(n, r), t.processing.delete(n), r;
	}
	if (e.enum !== void 0) {
		let n = e.enum;
		if (t.version === "openapi-3.0" && e.nullable === !0 && n.length === 1 && n[0] === null) return Q.null();
		if (n.length === 0) return Q.never();
		if (n.length === 1) return Q.literal(n[0]);
		if (n.every((e) => typeof e == "string")) return Q.enum(n);
		let r = n.map((e) => Q.literal(e));
		return r.length < 2 ? r[0] : Q.union([
			r[0],
			r[1],
			...r.slice(2)
		]);
	}
	if (e.const !== void 0) return Q.literal(e.const);
	let n = e.type;
	if (Array.isArray(n)) {
		let r = n.map((n) => gf({
			...e,
			type: n
		}, t));
		return r.length === 0 ? Q.never() : r.length === 1 ? r[0] : Q.union(r);
	}
	if (!n) return Q.any();
	let r;
	switch (n) {
		case "string": {
			let t = Q.string();
			if (e.format) {
				let n = e.format;
				n === "email" ? t = t.check(Q.email()) : n === "uri" || n === "uri-reference" ? t = t.check(Q.url()) : n === "uuid" || n === "guid" ? t = t.check(Q.uuid()) : n === "date-time" ? t = t.check(Q.iso.datetime({ offset: !0 })) : n === "date" ? t = t.check(Q.iso.date()) : n === "time" ? t = t.check(Q.regex(hf)) : n === "duration" ? t = t.check(Q.iso.duration()) : n === "hostname" ? t = t.check(Q.hostname()) : n === "ipv4" ? t = t.check(Q.ipv4()) : n === "ipv6" ? t = t.check(Q.ipv6()) : n === "mac" ? t = t.check(Q.mac()) : n === "cidr" ? t = t.check(Q.cidrv4()) : n === "cidr-v6" ? t = t.check(Q.cidrv6()) : n === "base64" ? t = t.check(Q.base64()) : n === "base64url" ? t = t.check(Q.base64url()) : n === "e164" ? t = t.check(Q.e164()) : n === "credit_card" ? t = t.check(Q.creditCard()) : n === "jwt" ? t = t.check(Q.jwt()) : n === "emoji" ? t = t.check(Q.emoji()) : n === "nanoid" ? t = t.check(Q.nanoid()) : n === "cuid" ? t = t.check(Q.cuid()) : n === "cuid2" ? t = t.check(Q.cuid2()) : n === "ulid" ? t = t.check(Q.ulid()) : n === "xid" ? t = t.check(Q.xid()) : n === "ksuid" && (t = t.check(Q.ksuid()));
			}
			typeof e.minLength == "number" && (t = t.min(e.minLength)), typeof e.maxLength == "number" && (t = t.max(e.maxLength)), e.pattern && (t = t.regex(new RegExp(e.pattern))), r = t;
			break;
		}
		case "number":
		case "integer": {
			let t = n === "integer" ? Q.number().int() : Q.number();
			typeof e.minimum == "number" && e.exclusiveMinimum !== !0 && (t = t.min(e.minimum)), typeof e.maximum == "number" && e.exclusiveMaximum !== !0 && (t = t.max(e.maximum)), typeof e.exclusiveMinimum == "number" ? t = t.gt(e.exclusiveMinimum) : e.exclusiveMinimum === !0 && typeof e.minimum == "number" && (t = t.gt(e.minimum)), typeof e.exclusiveMaximum == "number" ? t = t.lt(e.exclusiveMaximum) : e.exclusiveMaximum === !0 && typeof e.maximum == "number" && (t = t.lt(e.maximum)), typeof e.multipleOf == "number" && (t = t.multipleOf(e.multipleOf)), r = t;
			break;
		}
		case "boolean":
			r = Q.boolean();
			break;
		case "null":
			r = Q.null();
			break;
		case "object": {
			let n = {}, i = e.properties || {}, a = new Set(e.required || []), o = typeof e.additionalProperties == "object" ? $(e.additionalProperties, t) : void 0;
			for (let [e, r] of Object.entries(i)) {
				let i = $(r, t);
				jt(n, e, a.has(e) ? i : i.optional());
			}
			if (e.patternProperties) {
				let i = e.patternProperties, a = Object.keys(i), o = [];
				for (let e of a) {
					let n = $(i[e], t), r = Q.string().regex(new RegExp(e));
					o.push(Q.looseRecord(r, n));
				}
				let s = [];
				if (Object.keys(n).length > 0 && s.push(Q.object(n).passthrough()), s.push(...o), s.length === 0) r = Q.object({}).passthrough();
				else if (s.length === 1) r = s[0];
				else {
					let e = Q.intersection(s[0], s[1]);
					for (let t = 2; t < s.length; t++) e = Q.intersection(e, s[t]);
					r = e;
				}
				if (e.additionalProperties === !1) {
					let e = Object.keys(n), t = a.map((e) => new RegExp(e)), i = r;
					r = r.check((n) => {
						if (!Yr(n.value)) return;
						let r = [];
						for (let i of Object.keys(n.value)) e.includes(i) || t.some((e) => e.test(i)) || r.push(i);
						r.length && n.issues.push({
							code: "unrecognized_keys",
							keys: r,
							input: n.value,
							inst: i
						});
					});
				}
			} else {
				let t = Q.object(n);
				r = e.additionalProperties === !1 ? t.strict() : o ? t.catchall(o) : t.passthrough();
			}
			if (e.propertyNames !== void 0 && e.propertyNames !== !0) {
				let n = typeof e.propertyNames == "object" && e.propertyNames.type === void 0 ? {
					type: "string",
					...e.propertyNames
				} : e.propertyNames;
				r = pf(r, $(n, t));
			}
			break;
		}
		case "array": {
			let n = e.prefixItems, i = e.items;
			if (n && Array.isArray(n)) {
				let a = typeof e.minItems == "number" ? e.minItems : 0, o = uf(n.map((e) => $(e, t)), a), s = Array.isArray(i) ? void 0 : mf(i, t), c = Q.tuple(o);
				r = s ? c.rest(s) : c, typeof e.minItems == "number" && (r = r.check(Q.minLength(e.minItems))), typeof e.maxItems == "number" && (r = r.check(Q.maxLength(e.maxItems)));
			} else if (Array.isArray(i)) {
				let n = typeof e.minItems == "number" ? e.minItems : 0, a = uf(i.map((e) => $(e, t)), n), o = mf(e.additionalItems, t), s = Q.tuple(a);
				r = o ? s.rest(o) : s, typeof e.minItems == "number" && (r = r.check(Q.minLength(e.minItems))), typeof e.maxItems == "number" && (r = r.check(Q.maxLength(e.maxItems)));
			} else if (i !== void 0) {
				let n = $(i, t), a = Q.array(n);
				typeof e.minItems == "number" && (a = a.min(e.minItems)), typeof e.maxItems == "number" && (a = a.max(e.maxItems)), r = a;
			} else r = Q.array(Q.any());
			break;
		}
		default: throw Error(`Unsupported type: ${n}`);
	}
	return r;
}
function $(e, t) {
	if (typeof e == "boolean") return e ? Q.any() : Q.never();
	let n = gf(e, t), r = e.type || e.enum !== void 0 || e.const !== void 0;
	if (e.anyOf && Array.isArray(e.anyOf)) {
		let i = e.anyOf.map((e) => $(e, t)), a = Q.union(i);
		n = r ? Q.intersection(n, a) : a;
	}
	if (e.oneOf && Array.isArray(e.oneOf)) {
		let i = e.oneOf.map((e) => $(e, t)), a = Q.xor(i);
		n = r ? Q.intersection(n, a) : a;
	}
	if (e.allOf && Array.isArray(e.allOf)) {
		if (e.allOf.length === 0) n = r ? n : Q.any();
		else {
			let i = r ? n : $(e.allOf[0], t), a = +!r;
			for (let n = a; n < e.allOf.length; n++) i = Q.intersection(i, $(e.allOf[n], t));
			n = i;
		}
	}
	e.nullable === !0 && t.version === "openapi-3.0" && (n = Q.nullable(n)), e.readOnly === !0 && (n = Q.readonly(n)), e.default !== void 0 && (n = n.default(e.default));
	let i = {};
	for (let t of [
		"$id",
		"id",
		"$comment",
		"$anchor",
		"$vocabulary",
		"$dynamicRef",
		"$dynamicAnchor"
	]) t in e && (i[t] = e[t]);
	for (let t of [
		"contentEncoding",
		"contentMediaType",
		"contentSchema"
	]) t in e && (i[t] = e[t]);
	e.propertyNames !== void 0 && e.type === "object" && e.$ref === void 0 && (i.propertyNames = e.propertyNames);
	for (let t of Object.keys(e)) cf.has(t) || jt(i, t, e[t]);
	return Object.keys(i).length > 0 && t.registry.add(n, i), e.description && (n = n.describe(e.description)), n;
}
function _f(e, t) {
	if (typeof e == "boolean") return e ? Q.any() : Q.never();
	let n;
	try {
		n = JSON.parse(JSON.stringify(e));
	} catch {
		throw Error("fromJSONSchema input is not valid JSON (possibly cyclic); use $defs/$ref for recursive schemas");
	}
	let r = {
		version: lf(n, t?.defaultTarget),
		defs: n.$defs || n.definitions || {},
		refs: /* @__PURE__ */ new Map(),
		processing: /* @__PURE__ */ new Set(),
		rootSchema: n,
		registry: t?.registry ?? At
	};
	return $(n, r);
}
//#endregion
//#region node_modules/zod/v4/core/visit.js
var vf = Symbol("z.visit/resolving");
function yf(e, t) {
	let n = typeof t == "function" ? t : (e, n) => {
		let r = t[e._zod.def.type];
		return r ? r(e, n) : e;
	}, r = /* @__PURE__ */ new Map();
	function i(e) {
		let t = r.get(e);
		if (t === vf) return new We({
			type: "lazy",
			getter: () => r.get(e)
		});
		if (t !== void 0) return t;
		r.set(e, vf);
		let i = a(e), o = n(i, i !== e);
		return r.set(e, o), o;
	}
	function a(e) {
		let t = e._zod.def;
		switch (t.type) {
			case "object": {
				let n = t.shape, r = Object.keys(n), a = !1, o = {};
				for (let e of r) {
					let t = i(n[e]);
					t !== n[e] && (a = !0), o[e] = t;
				}
				let s = t.catchall;
				return t.catchall && (s = i(t.catchall), s !== t.catchall && (a = !0)), a ? L(e, {
					...t,
					shape: o,
					catchall: s
				}) : e;
			}
			case "array": {
				let n = i(t.element);
				return n === t.element ? e : L(e, {
					...t,
					element: n
				});
			}
			case "tuple": {
				let n = t.items, r = !1, a = [];
				for (let e of n) {
					let t = i(e);
					t !== e && (r = !0), a.push(t);
				}
				let o = t.rest;
				return t.rest && (o = i(t.rest), o !== t.rest && (r = !0)), r ? L(e, {
					...t,
					items: a,
					rest: o
				}) : e;
			}
			case "record":
			case "map": {
				let n = i(t.keyType), r = i(t.valueType);
				return n === t.keyType && r === t.valueType ? e : L(e, {
					...t,
					keyType: n,
					valueType: r
				});
			}
			case "set": {
				let n = i(t.valueType);
				return n === t.valueType ? e : L(e, {
					...t,
					valueType: n
				});
			}
			case "union": {
				let n = t.options, r = !1, a = [];
				for (let e of n) {
					let t = i(e);
					t !== e && (r = !0), a.push(t);
				}
				return r ? L(e, {
					...t,
					options: a
				}) : e;
			}
			case "intersection": {
				let n = i(t.left), r = i(t.right);
				return n === t.left && r === t.right ? e : L(e, {
					...t,
					left: n,
					right: r
				});
			}
			case "optional":
			case "nullable":
			case "default":
			case "prefault":
			case "catch":
			case "readonly":
			case "nonoptional":
			case "promise":
			case "success": {
				let n = i(t.innerType);
				return n === t.innerType ? e : L(e, {
					...t,
					innerType: n
				});
			}
			case "pipe": {
				let n = i(t.in), r = i(t.out);
				return n === t.in && r === t.out ? e : L(e, {
					...t,
					in: n,
					out: r
				});
			}
			case "function": {
				let n = i(t.input), r = i(t.output);
				return n === t.input && r === t.output ? e : L(e, {
					...t,
					input: n,
					output: r
				});
			}
			case "lazy": {
				let n = t.getter, { _cachedInner: r, ...a } = t;
				return L(e, {
					...a,
					getter: () => i(n())
				});
			}
			case "template_literal":
			case "string":
			case "number":
			case "int":
			case "boolean":
			case "bigint":
			case "symbol":
			case "undefined":
			case "null":
			case "void":
			case "never":
			case "any":
			case "unknown":
			case "date":
			case "nan":
			case "enum":
			case "literal":
			case "file":
			case "transform":
			case "custom": return e;
			default: return e;
		}
	}
	return i(e);
}
//#endregion
//#region node_modules/zod/v4/classic/deep-partial.js
function bf(e) {
	return yf(e, {
		object: (e) => e.partial(),
		union: (e) => {
			let t = e._zod.def;
			return t.discriminator === void 0 ? e : bo(t.options);
		}
	});
}
//#endregion
//#region node_modules/zod/v4/classic/in-out.js
function xf(e, t) {
	if (!t?.length) return e;
	let n = e._zod.def;
	return L(e, r(n, { checks: [...n.checks ?? [], ...t] }), { parent: !0 });
}
function Sf(e) {
	return xf(e.out, e.checks);
}
function Cf(e) {
	return e.in._zod.traits.has("$ZodTransform") ? Sf(e) : e.in;
}
function wf(e) {
	return yf(e, {
		pipe: (e) => Cf(e._zod.def),
		default: (e, t) => t ? Jt(e._zod.def.innerType) : e,
		catch: (e, t) => t ? e._zod.def.innerType : e
	});
}
function Tf(e) {
	return yf(e, {
		pipe: (e) => Sf(e._zod.def),
		prefault: (e, t) => t ? e._zod.def.innerType : e
	});
}
//#endregion
//#region node_modules/zod/v4/classic/coerce.js
var Ef = /* @__PURE__ */ e({
	bigint: () => Af,
	boolean: () => kf,
	date: () => jf,
	number: () => Of,
	string: () => Df
});
function Df(e) {
	return Wr(Fa, e);
}
function Of(e) {
	return Et(zo, e);
}
function kf(e) {
	return Ft(rs, e);
}
function Af(e) {
	return $e(di, e);
}
function jf(e) {
	return Wo(ni, e);
}
//#endregion
//#region node_modules/zod/v4/classic/external.js
var Mf = /* @__PURE__ */ e({
	$brand: () => ae,
	$input: () => Cr,
	$output: () => Ye,
	NEVER: () => it,
	TimePrecision: () => Sn,
	ZodAny: () => fs,
	ZodArray: () => ho,
	ZodBase64: () => qo,
	ZodBase64URL: () => Da,
	ZodBigInt: () => di,
	ZodBigIntFormat: () => Co,
	ZodBoolean: () => rs,
	ZodCIDRv4: () => ki,
	ZodCIDRv6: () => Qa,
	ZodCUID: () => Ss,
	ZodCUID2: () => Ri,
	ZodCatch: () => ta,
	ZodCodec: () => jo,
	ZodCompileAsyncError: () => H,
	ZodCompileUnsupportedError: () => U,
	ZodCreditCard: () => oo,
	ZodCustom: () => va,
	ZodCustomStringFormat: () => la,
	ZodDate: () => ni,
	ZodDefault: () => js,
	ZodDiscriminatedUnion: () => nc,
	ZodE164: () => bi,
	ZodEmail: () => Js,
	ZodEmoji: () => Hn,
	ZodEnum: () => fe,
	ZodError: () => ve,
	ZodExactOptional: () => Bs,
	ZodFile: () => Zn,
	ZodFirstPartyTypeKind: () => tf,
	ZodFunction: () => Ae,
	ZodGUID: () => xe,
	ZodIPv4: () => cn,
	ZodIPv6: () => Ua,
	ZodISODate: () => u,
	ZodISODateTime: () => k,
	ZodISODuration: () => g,
	ZodISOTime: () => y,
	ZodIntersection: () => gn,
	ZodIssueCode: () => Qd,
	ZodJWT: () => ze,
	ZodKSUID: () => dt,
	ZodLazy: () => Rt,
	ZodLiteral: () => Nn,
	ZodMAC: () => dc,
	ZodMap: () => re,
	ZodNaN: () => pr,
	ZodNanoID: () => nt,
	ZodNever: () => ar,
	ZodNonOptional: () => Sr,
	ZodNull: () => Je,
	ZodNullable: () => kt,
	ZodNumber: () => zo,
	ZodNumberFormat: () => bt,
	ZodObject: () => zr,
	ZodOptional: () => Ar,
	ZodPipe: () => qr,
	ZodPrefault: () => Tn,
	ZodPreprocess: () => t,
	ZodPromise: () => ea,
	ZodReadonly: () => xs,
	ZodRealError: () => Gs,
	ZodRecord: () => So,
	ZodSet: () => ns,
	ZodString: () => Fa,
	ZodStringFormat: () => yi,
	ZodSuccess: () => Ao,
	ZodSymbol: () => ds,
	ZodTemplateLiteral: () => Li,
	ZodTransform: () => ao,
	ZodTuple: () => As,
	ZodType: () => Ki,
	ZodULID: () => ca,
	ZodURL: () => Ro,
	ZodUUID: () => mo,
	ZodUndefined: () => Ea,
	ZodUnion: () => _a,
	ZodUnknown: () => ui,
	ZodVoid: () => zs,
	ZodXID: () => uc,
	ZodXor: () => Oi,
	_ZodString: () => tc,
	_default: () => be,
	_function: () => S,
	any: () => ne,
	array: () => Ha,
	base64: () => Qt,
	base64url: () => sn,
	bigint: () => wn,
	boolean: () => qe,
	catch: () => Xn,
	check: () => yt,
	cidrv4: () => Kt,
	cidrv6: () => Vn,
	clone: () => L,
	codec: () => yc,
	coerce: () => Ef,
	compile: () => Bu,
	config: () => C,
	core: () => Xd,
	creditCard: () => de,
	cuid: () => xr,
	cuid2: () => ut,
	custom: () => fr,
	date: () => kr,
	decode: () => Wi,
	decodeAsync: () => oa,
	deepPartial: () => bf,
	describe: () => tt,
	discriminatedUnion: () => Lt,
	e164: () => Ko,
	email: () => Ot,
	emoji: () => Kr,
	encode: () => Io,
	encodeAsync: () => fo,
	endsWith: () => F,
	enum: () => qs,
	exactOptional: () => Rr,
	file: () => ti,
	flattenError: () => en,
	float32: () => Mn,
	float64: () => l,
	formatError: () => vn,
	fromJSONSchema: () => _f,
	function: () => S,
	getDiscriminatedOption: () => Di,
	getErrorMap: () => ef,
	globalRegistry: () => At,
	gt: () => Vi,
	gte: () => D,
	guid: () => Xi,
	hash: () => _s,
	hex: () => vo,
	hostname: () => Qo,
	httpUrl: () => ja,
	includes: () => M,
	input: () => wf,
	instanceof: () => Re,
	int: () => hi,
	int32: () => Eo,
	int64: () => ss,
	intersection: () => Ni,
	invertCodec: () => to,
	ipv4: () => Es,
	ipv6: () => Hi,
	iso: () => nf,
	json: () => ia,
	jwt: () => Po,
	keyof: () => lo,
	ksuid: () => Sa,
	lazy: () => pa,
	length: () => b,
	literal: () => oi,
	locales: () => Lu,
	looseObject: () => Fs,
	looseRecord: () => oc,
	lowercase: () => p,
	lt: () => A,
	lte: () => v,
	mac: () => wi,
	map: () => Zs,
	maxLength: () => He,
	maxSize: () => mt,
	memoizer: () => En,
	meta: () => Kn,
	mime: () => Vt,
	minLength: () => In,
	minSize: () => mc,
	multipleOf: () => oe,
	nan: () => ge,
	nanoid: () => Us,
	nativeEnum: () => tr,
	negative: () => w,
	never: () => Pe,
	nonnegative: () => Mt,
	nonoptional: () => Te,
	nonpositive: () => Ct,
	normalize: () => Vr,
	null: () => ke,
	nullable: () => dn,
	nullish: () => qa,
	number: () => m,
	object: () => Ra,
	optional: () => Jt,
	output: () => Tf,
	overwrite: () => qi,
	parse: () => wa,
	parseAsync: () => ha,
	partialRecord: () => nn,
	pipe: () => bn,
	positive: () => N,
	prefault: () => Ue,
	preprocess: () => ht,
	prettifyError: () => Ve,
	promise: () => Ht,
	properties: () => O,
	property: () => fi,
	readonly: () => Ln,
	record: () => hc,
	refine: () => se,
	regex: () => j,
	regexes: () => Oa,
	registry: () => Bo,
	safeDecode: () => ci,
	safeDecodeAsync: () => Ls,
	safeEncode: () => cc,
	safeEncodeAsync: () => Ei,
	safeParse: () => $s,
	safeParseAsync: () => Jn,
	set: () => ot,
	setErrorMap: () => $d,
	size: () => zi,
	slugify: () => na,
	startsWith: () => I,
	strictObject: () => cr,
	string: () => Tr,
	stringFormat: () => Ze,
	stringbool: () => Nt,
	success: () => Ho,
	superRefine: () => wt,
	symbol: () => Hr,
	templateLiteral: () => Pr,
	toJSONSchema: () => Ie,
	toLowerCase: () => z,
	toUpperCase: () => Un,
	toZod: () => Zo,
	transform: () => Zr,
	treeifyError: () => Bt,
	trim: () => R,
	tuple: () => On,
	uint32: () => a,
	uint64: () => Qi,
	ulid: () => ys,
	undefined: () => hn,
	union: () => bo,
	unknown: () => es,
	uppercase: () => _,
	url: () => Na,
	util: () => Aa,
	uuid: () => _i,
	uuidv4: () => Oo,
	uuidv6: () => ls,
	uuidv7: () => Fi,
	validate: () => Ga,
	validateAsync: () => f,
	void: () => Za,
	xid: () => ro,
	xor: () => Os
}), Nf = /* @__PURE__ */ e({
	$brand: () => ae,
	$input: () => Cr,
	$output: () => Ye,
	NEVER: () => it,
	TimePrecision: () => Sn,
	ZodAny: () => fs,
	ZodArray: () => ho,
	ZodBase64: () => qo,
	ZodBase64URL: () => Da,
	ZodBigInt: () => di,
	ZodBigIntFormat: () => Co,
	ZodBoolean: () => rs,
	ZodCIDRv4: () => ki,
	ZodCIDRv6: () => Qa,
	ZodCUID: () => Ss,
	ZodCUID2: () => Ri,
	ZodCatch: () => ta,
	ZodCodec: () => jo,
	ZodCompileAsyncError: () => H,
	ZodCompileUnsupportedError: () => U,
	ZodCreditCard: () => oo,
	ZodCustom: () => va,
	ZodCustomStringFormat: () => la,
	ZodDate: () => ni,
	ZodDefault: () => js,
	ZodDiscriminatedUnion: () => nc,
	ZodE164: () => bi,
	ZodEmail: () => Js,
	ZodEmoji: () => Hn,
	ZodEnum: () => fe,
	ZodError: () => ve,
	ZodExactOptional: () => Bs,
	ZodFile: () => Zn,
	ZodFirstPartyTypeKind: () => tf,
	ZodFunction: () => Ae,
	ZodGUID: () => xe,
	ZodIPv4: () => cn,
	ZodIPv6: () => Ua,
	ZodISODate: () => u,
	ZodISODateTime: () => k,
	ZodISODuration: () => g,
	ZodISOTime: () => y,
	ZodIntersection: () => gn,
	ZodIssueCode: () => Qd,
	ZodJWT: () => ze,
	ZodKSUID: () => dt,
	ZodLazy: () => Rt,
	ZodLiteral: () => Nn,
	ZodMAC: () => dc,
	ZodMap: () => re,
	ZodNaN: () => pr,
	ZodNanoID: () => nt,
	ZodNever: () => ar,
	ZodNonOptional: () => Sr,
	ZodNull: () => Je,
	ZodNullable: () => kt,
	ZodNumber: () => zo,
	ZodNumberFormat: () => bt,
	ZodObject: () => zr,
	ZodOptional: () => Ar,
	ZodPipe: () => qr,
	ZodPrefault: () => Tn,
	ZodPreprocess: () => t,
	ZodPromise: () => ea,
	ZodReadonly: () => xs,
	ZodRealError: () => Gs,
	ZodRecord: () => So,
	ZodSet: () => ns,
	ZodString: () => Fa,
	ZodStringFormat: () => yi,
	ZodSuccess: () => Ao,
	ZodSymbol: () => ds,
	ZodTemplateLiteral: () => Li,
	ZodTransform: () => ao,
	ZodTuple: () => As,
	ZodType: () => Ki,
	ZodULID: () => ca,
	ZodURL: () => Ro,
	ZodUUID: () => mo,
	ZodUndefined: () => Ea,
	ZodUnion: () => _a,
	ZodUnknown: () => ui,
	ZodVoid: () => zs,
	ZodXID: () => uc,
	ZodXor: () => Oi,
	_ZodString: () => tc,
	_default: () => be,
	_function: () => S,
	any: () => ne,
	array: () => Ha,
	base64: () => Qt,
	base64url: () => sn,
	bigint: () => wn,
	boolean: () => qe,
	catch: () => Xn,
	check: () => yt,
	cidrv4: () => Kt,
	cidrv6: () => Vn,
	clone: () => L,
	codec: () => yc,
	coerce: () => Ef,
	compile: () => Bu,
	config: () => C,
	core: () => Xd,
	creditCard: () => de,
	cuid: () => xr,
	cuid2: () => ut,
	custom: () => fr,
	date: () => kr,
	decode: () => Wi,
	decodeAsync: () => oa,
	deepPartial: () => bf,
	default: () => Mf,
	describe: () => tt,
	discriminatedUnion: () => Lt,
	e164: () => Ko,
	email: () => Ot,
	emoji: () => Kr,
	encode: () => Io,
	encodeAsync: () => fo,
	endsWith: () => F,
	enum: () => qs,
	exactOptional: () => Rr,
	file: () => ti,
	flattenError: () => en,
	float32: () => Mn,
	float64: () => l,
	formatError: () => vn,
	fromJSONSchema: () => _f,
	function: () => S,
	getDiscriminatedOption: () => Di,
	getErrorMap: () => ef,
	globalRegistry: () => At,
	gt: () => Vi,
	gte: () => D,
	guid: () => Xi,
	hash: () => _s,
	hex: () => vo,
	hostname: () => Qo,
	httpUrl: () => ja,
	includes: () => M,
	input: () => wf,
	instanceof: () => Re,
	int: () => hi,
	int32: () => Eo,
	int64: () => ss,
	intersection: () => Ni,
	invertCodec: () => to,
	ipv4: () => Es,
	ipv6: () => Hi,
	iso: () => nf,
	json: () => ia,
	jwt: () => Po,
	keyof: () => lo,
	ksuid: () => Sa,
	lazy: () => pa,
	length: () => b,
	literal: () => oi,
	locales: () => Lu,
	looseObject: () => Fs,
	looseRecord: () => oc,
	lowercase: () => p,
	lt: () => A,
	lte: () => v,
	mac: () => wi,
	map: () => Zs,
	maxLength: () => He,
	maxSize: () => mt,
	memoizer: () => En,
	meta: () => Kn,
	mime: () => Vt,
	minLength: () => In,
	minSize: () => mc,
	multipleOf: () => oe,
	nan: () => ge,
	nanoid: () => Us,
	nativeEnum: () => tr,
	negative: () => w,
	never: () => Pe,
	nonnegative: () => Mt,
	nonoptional: () => Te,
	nonpositive: () => Ct,
	normalize: () => Vr,
	null: () => ke,
	nullable: () => dn,
	nullish: () => qa,
	number: () => m,
	object: () => Ra,
	optional: () => Jt,
	output: () => Tf,
	overwrite: () => qi,
	parse: () => wa,
	parseAsync: () => ha,
	partialRecord: () => nn,
	pipe: () => bn,
	positive: () => N,
	prefault: () => Ue,
	preprocess: () => ht,
	prettifyError: () => Ve,
	promise: () => Ht,
	properties: () => O,
	property: () => fi,
	readonly: () => Ln,
	record: () => hc,
	refine: () => se,
	regex: () => j,
	regexes: () => Oa,
	registry: () => Bo,
	safeDecode: () => ci,
	safeDecodeAsync: () => Ls,
	safeEncode: () => cc,
	safeEncodeAsync: () => Ei,
	safeParse: () => $s,
	safeParseAsync: () => Jn,
	set: () => ot,
	setErrorMap: () => $d,
	size: () => zi,
	slugify: () => na,
	startsWith: () => I,
	strictObject: () => cr,
	string: () => Tr,
	stringFormat: () => Ze,
	stringbool: () => Nt,
	success: () => Ho,
	superRefine: () => wt,
	symbol: () => Hr,
	templateLiteral: () => Pr,
	toJSONSchema: () => Ie,
	toLowerCase: () => z,
	toUpperCase: () => Un,
	toZod: () => Zo,
	transform: () => Zr,
	treeifyError: () => Bt,
	trim: () => R,
	tuple: () => On,
	uint32: () => a,
	uint64: () => Qi,
	ulid: () => ys,
	undefined: () => hn,
	union: () => bo,
	unknown: () => es,
	uppercase: () => _,
	url: () => Na,
	util: () => Aa,
	uuid: () => _i,
	uuidv4: () => Oo,
	uuidv6: () => ls,
	uuidv7: () => Fi,
	validate: () => Ga,
	validateAsync: () => f,
	void: () => Za,
	xid: () => ro,
	xor: () => Os,
	z: () => Mf
}), Pf = ae, Ff = Cr, If = Ye, Lf = it, Rf = Sn, zf = fs, Bf = ho, Vf = qo, Hf = Da, Uf = di, Wf = Co, Gf = rs, Kf = ki, qf = Qa, Jf = Ss, Yf = Ri, Xf = ta, Zf = jo, Qf = H, $f = U, ep = oo, tp = va, np = la, rp = ni, ip = js, ap = nc, op = bi, sp = Js, cp = Hn, lp = fe, up = ve, dp = Bs, fp = Zn, pp = tf, mp = Ae, hp = xe, gp = cn, _p = Ua, vp = u, yp = k, bp = g, xp = y, Sp = gn, Cp = Qd, wp = ze, Tp = dt, Ep = Rt, Dp = Nn, Op = dc, kp = re, Ap = pr, jp = nt, Mp = ar, Np = Sr, Pp = Je, Fp = kt, Ip = zo, Lp = bt, Rp = zr, zp = Ar, Bp = qr, Vp = Tn, Hp = t, Up = ea, Wp = xs, Gp = Gs, Kp = So, qp = ns, Jp = Fa, Yp = yi, Xp = Ao, Zp = ds, Qp = Li, $p = ao, em = As, tm = Ki, nm = ca, rm = Ro, im = mo, am = Ea, om = _a, sm = ui, cm = zs, lm = uc, um = Oi, dm = tc, fm = be, pm = S, mm = ne, hm = Ha, gm = Qt, _m = sn, vm = wn, ym = qe, bm = Xn, xm = yt, Sm = Kt, Cm = Vn, wm = L, Tm = yc, Em = Ef, Dm = Bu, Om = C, km = Xd, Am = de, jm = xr, Mm = ut, Nm = fr, Pm = kr, Fm = Wi, Im = oa, Lm = bf, Rm = tt, zm = Lt, Bm = Ko, Vm = Ot, Hm = Kr, Um = Io, Wm = fo, Gm = F, Km = qs, qm = Rr, Jm = ti, Ym = en, Xm = Mn, Zm = l, Qm = vn, $m = _f, eh = S, th = Di, nh = ef, rh = At, ih = Vi, ah = D, oh = Xi, sh = _s, ch = vo, lh = Qo, uh = ja, dh = M, fh = wf, ph = Re, mh = hi, hh = Eo, gh = ss, _h = Ni, vh = to, yh = Es, bh = Hi, xh = nf, Sh = ia, Ch = Po, wh = lo, Th = Sa, Eh = pa, Dh = b, Oh = oi, kh = Lu, Ah = Fs, jh = oc, Mh = p, Nh = A, Ph = v, Fh = wi, Ih = Zs, Lh = He, Rh = mt, zh = En, Bh = Kn, Vh = Vt, Hh = In, Uh = mc, Wh = oe, Gh = ge, Kh = Us, qh = tr, Jh = w, Yh = Pe, Xh = Mt, Zh = Te, Qh = Ct, $h = Vr, eg = ke, tg = dn, ng = qa, rg = m, ig = Ra, ag = Jt, og = Tf, sg = qi, cg = wa, lg = ha, ug = nn, dg = bn, fg = N, pg = Ue, mg = ht, hg = Ve, gg = Ht, _g = O, vg = fi, yg = Ln, bg = hc, xg = se, Sg = j, Cg = Oa, wg = Bo, Tg = ci, Eg = Ls, Dg = cc, Og = Ei, kg = $s, Ag = Jn, jg = ot, Mg = $d, Ng = zi, Pg = na, Fg = I, Ig = cr, Lg = Tr, Rg = Ze, zg = Nt, Bg = Ho, Vg = wt, Hg = Hr, Ug = Pr, Wg = Ie, Gg = z, Kg = Un, qg = Zo, Jg = Zr, Yg = Bt, Xg = R, Zg = On, Qg = a, $g = Qi, e_ = ys, t_ = hn, n_ = bo, r_ = es, i_ = _, a_ = Na, o_ = Aa, s_ = _i, c_ = Oo, l_ = ls, u_ = Fi, d_ = Ga, f_ = f, p_ = Za, m_ = ro, h_ = Os, g_ = Mf;
//#endregion
export { Pf as $brand, Ff as $input, If as $output, Lf as NEVER, Rf as TimePrecision, zf as ZodAny, Bf as ZodArray, Vf as ZodBase64, Hf as ZodBase64URL, Uf as ZodBigInt, Wf as ZodBigIntFormat, Gf as ZodBoolean, Kf as ZodCIDRv4, qf as ZodCIDRv6, Jf as ZodCUID, Yf as ZodCUID2, Xf as ZodCatch, Zf as ZodCodec, Qf as ZodCompileAsyncError, $f as ZodCompileUnsupportedError, ep as ZodCreditCard, tp as ZodCustom, np as ZodCustomStringFormat, rp as ZodDate, ip as ZodDefault, ap as ZodDiscriminatedUnion, op as ZodE164, sp as ZodEmail, cp as ZodEmoji, lp as ZodEnum, up as ZodError, dp as ZodExactOptional, fp as ZodFile, pp as ZodFirstPartyTypeKind, mp as ZodFunction, hp as ZodGUID, gp as ZodIPv4, _p as ZodIPv6, vp as ZodISODate, yp as ZodISODateTime, bp as ZodISODuration, xp as ZodISOTime, Sp as ZodIntersection, Cp as ZodIssueCode, wp as ZodJWT, Tp as ZodKSUID, Ep as ZodLazy, Dp as ZodLiteral, Op as ZodMAC, kp as ZodMap, Ap as ZodNaN, jp as ZodNanoID, Mp as ZodNever, Np as ZodNonOptional, Pp as ZodNull, Fp as ZodNullable, Ip as ZodNumber, Lp as ZodNumberFormat, Rp as ZodObject, zp as ZodOptional, Bp as ZodPipe, Vp as ZodPrefault, Hp as ZodPreprocess, Up as ZodPromise, Wp as ZodReadonly, Gp as ZodRealError, Kp as ZodRecord, qp as ZodSet, Jp as ZodString, Yp as ZodStringFormat, Xp as ZodSuccess, Zp as ZodSymbol, Qp as ZodTemplateLiteral, $p as ZodTransform, em as ZodTuple, tm as ZodType, nm as ZodULID, rm as ZodURL, im as ZodUUID, am as ZodUndefined, om as ZodUnion, sm as ZodUnknown, cm as ZodVoid, lm as ZodXID, um as ZodXor, dm as _ZodString, fm as _default, pm as _function, mm as any, hm as array, gm as base64, _m as base64url, vm as bigint, ym as boolean, bm as catch, xm as check, Sm as cidrv4, Cm as cidrv6, wm as clone, Tm as codec, Em as coerce, Dm as compile, Om as config, km as core, Am as creditCard, jm as cuid, Mm as cuid2, Nm as custom, Pm as date, Fm as decode, Im as decodeAsync, Lm as deepPartial, Nf as default, Rm as describe, zm as discriminatedUnion, Bm as e164, Vm as email, Hm as emoji, Um as encode, Wm as encodeAsync, Gm as endsWith, Km as enum, qm as exactOptional, Jm as file, Ym as flattenError, Xm as float32, Zm as float64, Qm as formatError, $m as fromJSONSchema, eh as function, th as getDiscriminatedOption, nh as getErrorMap, rh as globalRegistry, ih as gt, ah as gte, oh as guid, sh as hash, ch as hex, lh as hostname, uh as httpUrl, dh as includes, fh as input, ph as instanceof, mh as int, hh as int32, gh as int64, _h as intersection, vh as invertCodec, yh as ipv4, bh as ipv6, xh as iso, Sh as json, Ch as jwt, wh as keyof, Th as ksuid, Eh as lazy, Dh as length, Oh as literal, kh as locales, Ah as looseObject, jh as looseRecord, Mh as lowercase, Nh as lt, Ph as lte, Fh as mac, Ih as map, Lh as maxLength, Rh as maxSize, zh as memoizer, Bh as meta, Vh as mime, Hh as minLength, Uh as minSize, Wh as multipleOf, Gh as nan, Kh as nanoid, qh as nativeEnum, Jh as negative, Yh as never, Xh as nonnegative, Zh as nonoptional, Qh as nonpositive, $h as normalize, eg as null, tg as nullable, ng as nullish, rg as number, ig as object, ag as optional, og as output, sg as overwrite, cg as parse, lg as parseAsync, ug as partialRecord, dg as pipe, fg as positive, pg as prefault, mg as preprocess, hg as prettifyError, gg as promise, _g as properties, vg as property, yg as readonly, bg as record, xg as refine, Sg as regex, Cg as regexes, wg as registry, Tg as safeDecode, Eg as safeDecodeAsync, Dg as safeEncode, Og as safeEncodeAsync, kg as safeParse, Ag as safeParseAsync, jg as set, Mg as setErrorMap, Ng as size, Pg as slugify, Fg as startsWith, Ig as strictObject, Lg as string, Rg as stringFormat, zg as stringbool, Bg as success, Vg as superRefine, Hg as symbol, Ug as templateLiteral, Wg as toJSONSchema, Gg as toLowerCase, Kg as toUpperCase, qg as toZod, Jg as transform, Yg as treeifyError, Xg as trim, Zg as tuple, Qg as uint32, $g as uint64, e_ as ulid, t_ as undefined, n_ as union, r_ as unknown, i_ as uppercase, a_ as url, o_ as util, s_ as uuid, c_ as uuidv4, l_ as uuidv6, u_ as uuidv7, d_ as validate, f_ as validateAsync, p_ as void, m_ as xid, h_ as xor, g_ as z };
