//#region src/shared/player-colors.ts
var e = [
	{
		id: "blueberry",
		hex: "#2563eb",
		nameKey: "lobby.colors.blueberry"
	},
	{
		id: "tangerine",
		hex: "#ea580c",
		nameKey: "lobby.colors.tangerine"
	},
	{
		id: "grape",
		hex: "#7c3aed",
		nameKey: "lobby.colors.grape"
	},
	{
		id: "honey",
		hex: "#ca8a04",
		nameKey: "lobby.colors.honey"
	},
	{
		id: "seasalt",
		hex: "#0891b2",
		nameKey: "lobby.colors.seasalt"
	},
	{
		id: "peach",
		hex: "#db2777",
		nameKey: "lobby.colors.peach"
	},
	{
		id: "avocado",
		hex: "#4d7c0f",
		nameKey: "lobby.colors.avocado"
	},
	{
		id: "cocoa",
		hex: "#8b5a2b",
		nameKey: "lobby.colors.cocoa"
	},
	{
		id: "mint",
		hex: "#0d9488",
		nameKey: "lobby.colors.mint"
	},
	{
		id: "sesame",
		hex: "#57534e",
		nameKey: "lobby.colors.sesame"
	}
];
//#endregion
export { e as PLAYER_COLORS };
