//#region src/shared/avatars.ts
var e = Array.from({ length: 32 }, (e, t) => `avatars/${t}.webp`);
//#endregion
export { e as AVATARS };
