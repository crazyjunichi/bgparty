//#region packages/sdk/src/assets.ts
function e(e) {
	if (!globalThis.__bgpartyAssetUrl) throw Error("Game runtime is not ready");
	return globalThis.__bgpartyAssetUrl(e);
}
var t = e;
//#endregion
export { e as gameAssetUrl, t as sharedAssetUrl };
