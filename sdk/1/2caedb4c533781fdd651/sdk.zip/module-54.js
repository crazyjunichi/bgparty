import { n as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/vanilla-C5IeD8Y7.js";
import { n, t as r } from "@bgparty/sdk/_/chunks/react-B1TUhMyJ.js";
//#endregion
//#region .bgparty/cache/sdk-entry/zustand.js
var i = /* @__PURE__ */ e({
	create: () => r,
	createStore: () => t,
	useStore: () => n
}), a = r, o = t, s = n;
//#endregion
export { a as create, o as createStore, i as default, s as useStore };
