import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/shared/fx/dice-cube.tsx
var r = /* @__PURE__ */ e(t(), 1), i = /* @__PURE__ */ e(n(), 1), a = [
	"translateZ(var(--dice-half))",
	"rotateY(180deg) translateZ(var(--dice-half))",
	"rotateY(90deg) translateZ(var(--dice-half))",
	"rotateY(-90deg) translateZ(var(--dice-half))",
	"rotateX(90deg) translateZ(var(--dice-half))",
	"rotateX(-90deg) translateZ(var(--dice-half))"
], o = [
	{
		x: 0,
		y: 0
	},
	{
		x: 0,
		y: 180
	},
	{
		x: 0,
		y: -90
	},
	{
		x: 0,
		y: 90
	},
	{
		x: -90,
		y: 0
	},
	{
		x: 90,
		y: 0
	}
], s = {
	1: [4],
	2: [0, 8],
	3: [
		0,
		4,
		8
	],
	4: [
		0,
		2,
		6,
		8
	],
	5: [
		0,
		2,
		4,
		6,
		8
	],
	6: [
		0,
		2,
		3,
		5,
		6,
		8
	]
};
function c({ value: e, pipClass: t = "bg-ink" }) {
	let n = s[e] ?? [];
	return /* @__PURE__ */ (0, i.jsx)("div", {
		className: "grid size-full grid-cols-3 grid-rows-3 p-[14%]",
		children: Array.from({ length: 9 }, (e, r) => /* @__PURE__ */ (0, i.jsx)("span", {
			className: "grid place-items-center",
			children: n.includes(r) && /* @__PURE__ */ (0, i.jsx)("span", { className: `size-[70%] rounded-full ${t}` })
		}, r))
	});
}
var l = {
	1: 0,
	6: 1,
	3: 2,
	4: 3,
	2: 4,
	5: 5
}, u = [
	1,
	6,
	3,
	4,
	2,
	5
].map((e) => /* @__PURE__ */ (0, i.jsx)(c, { value: e }, e)), d = [
	1,
	6,
	3,
	4,
	2,
	5
].map((e) => /* @__PURE__ */ (0, i.jsx)(c, {
	value: e,
	pipClass: "bg-surface"
}, e)), f = "overflow-hidden rounded-[16%] border-3 border-ink bg-surface";
function p(e, t, n) {
	return (t ?? (n ? d : u))[e] ?? null;
}
function m({ face: e, faces: t, faceBg: n, size: s = 64, ms: c = 900, delay: l = 0 }) {
	let p = (0, r.useRef)(null), m = (0, r.useRef)(null);
	return (0, r.useLayoutEffect)(() => {
		let t = p.current, n = m.current;
		if (!t || !n) return;
		let r = o[e] ?? o[0], i = Math.random() * 360 - 180, a = Math.random() * 360 - 180, u = r.x + 720, d = r.y + 720, f = Math.round(s * .45), h = [n.animate([
			{ transform: `rotateX(${i}deg) rotateY(${a}deg)` },
			{
				transform: `rotateX(${(i + u) / 2 + 40}deg) rotateY(${(a + d) / 2 - 70}deg)`,
				offset: .55
			},
			{ transform: `rotateX(${u}deg) rotateY(${d}deg)` }
		], {
			duration: c,
			delay: l,
			easing: "cubic-bezier(.2,.7,.3,1)",
			fill: "both"
		}), t.animate([
			{ transform: "translateY(0px)" },
			{
				transform: `translateY(-${f}px)`,
				offset: .35,
				easing: "ease-out"
			},
			{
				transform: "translateY(0px)",
				offset: .7,
				easing: "ease-in"
			},
			{
				transform: `translateY(-${Math.round(f / 4)}px)`,
				offset: .85,
				easing: "ease-out"
			},
			{ transform: "translateY(0px)" }
		], {
			duration: c,
			delay: l,
			fill: "both"
		})];
		return () => h.forEach((e) => e.cancel());
	}, [
		e,
		s,
		c,
		l
	]), /* @__PURE__ */ (0, i.jsx)("div", {
		className: "relative",
		style: {
			width: s,
			height: s
		},
		children: /* @__PURE__ */ (0, i.jsx)("div", {
			ref: p,
			className: "size-full",
			style: { perspective: s * 8 },
			children: /* @__PURE__ */ (0, i.jsx)("div", {
				ref: m,
				className: "relative size-full transform-3d",
				style: { "--dice-half": `${s / 2}px` },
				children: (t ?? (n ? d : u)).map((e, t) => /* @__PURE__ */ (0, i.jsx)("div", {
					className: `absolute inset-0 backface-hidden ${f}`,
					style: {
						transform: a[t],
						background: n
					},
					children: e
				}, t))
			})
		})
	});
}
//#endregion
export { l as D6_SLOT, f as DICE_FACE_CLASS, m as DiceCube, p as diceFaceContent };
