import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/shared/sheet-mark.tsx
var n = /* @__PURE__ */ e(t(), 1);
function r({ mark: e, rect: t, color: r = "var(--color-ink)", strokeWidth: i, inset: a = .2 }) {
	let { x: o, y: s, w: c, h: l } = t, u = i ?? Math.min(c, l) * .14, d = c * a, f = l * a;
	return /* @__PURE__ */ (0, n.jsxs)("g", {
		stroke: r,
		strokeWidth: u,
		strokeLinecap: "round",
		fill: "none",
		pointerEvents: "none",
		children: [
			e === "x" && /* @__PURE__ */ (0, n.jsxs)(n.Fragment, { children: [/* @__PURE__ */ (0, n.jsx)("line", {
				x1: o + d,
				y1: s + f,
				x2: o + c - d,
				y2: s + l - f
			}), /* @__PURE__ */ (0, n.jsx)("line", {
				x1: o + c - d,
				y1: s + f,
				x2: o + d,
				y2: s + l - f
			})] }),
			e === "slash" && /* @__PURE__ */ (0, n.jsx)("line", {
				x1: o + d,
				y1: s + l - f,
				x2: o + c - d,
				y2: s + f
			}),
			e === "circle" && /* @__PURE__ */ (0, n.jsx)("ellipse", {
				cx: o + c / 2,
				cy: s + l / 2,
				rx: c / 2 - d,
				ry: l / 2 - f
			})
		]
	});
}
//#endregion
export { r as SheetMark };
