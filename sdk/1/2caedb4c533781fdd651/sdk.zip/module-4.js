import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/shared/confirm-button.tsx
var r = /* @__PURE__ */ e(t(), 1), i = /* @__PURE__ */ e(n(), 1), a = 3e3;
function o({ label: e, confirmLabel: t, onConfirm: n, className: o, compact: s, ariaLabel: c }) {
	let [l, u] = (0, r.useState)(!1), d = (0, r.useRef)(null);
	(0, r.useEffect)(() => () => {
		d.current && clearTimeout(d.current);
	}, []);
	let f = () => {
		u(!0), d.current && clearTimeout(d.current), d.current = setTimeout(() => u(!1), a);
	}, p = () => {
		if (!l) {
			f();
			return;
		}
		d.current && clearTimeout(d.current), u(!1), n();
	}, m = s ? "flex min-h-9 cursor-pointer items-center justify-center gap-1 rounded-xl border-2 border-ink px-2 text-xs font-bold whitespace-nowrap" : "btn-base";
	return /* @__PURE__ */ (0, i.jsx)("button", {
		type: "button",
		"aria-label": c,
		onClick: p,
		className: l ? `${m} danger-stripes text-white ${o ?? ""}` : `${m} bg-surface text-ink ${o ?? ""}`,
		children: l ? t : e
	});
}
//#endregion
export { o as ConfirmButton };
