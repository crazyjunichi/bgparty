import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { useFxAnchorsMaybe as r } from "@bgparty/sdk/_/module-10.js";
//#region src/shared/sheet-view.tsx
var i = /* @__PURE__ */ e(t(), 1), a = /* @__PURE__ */ e(n(), 1);
function o({ r: e, inset: t }) {
	let n = Math.min(1, Math.min(e.w, e.h) / 102), r = t ? Math.max(2, 7 * n) : -6 * n, i = e.x - r, o = e.y - r, s = e.w + 2 * r, c = e.h + 2 * r;
	return /* @__PURE__ */ (0, a.jsxs)("g", {
		pointerEvents: "none",
		className: "hint-flash",
		children: [
			/* @__PURE__ */ (0, a.jsx)("rect", {
				x: i,
				y: o,
				width: s,
				height: c,
				rx: 16 * n,
				fill: "#ffffff",
				fillOpacity: .3
			}),
			/* @__PURE__ */ (0, a.jsx)("rect", {
				x: i,
				y: o,
				width: s,
				height: c,
				rx: 16 * n,
				fill: "none",
				stroke: "#ffffff",
				strokeWidth: 13 * n
			}),
			/* @__PURE__ */ (0, a.jsx)("rect", {
				x: i,
				y: o,
				width: s,
				height: c,
				rx: 16 * n,
				fill: "none",
				className: "stroke-ink",
				strokeWidth: 6 * n,
				strokeDasharray: `${20 * n} ${14 * n}`,
				strokeLinecap: "round",
				children: /* @__PURE__ */ (0, a.jsx)("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: `${-34 * n}`,
					dur: "0.7s",
					repeatCount: "indefinite"
				})
			})
		]
	});
}
function s({ r: e, text: t }) {
	return /* @__PURE__ */ (0, a.jsx)("text", {
		x: e.x + e.w / 2,
		y: e.y + e.h / 2,
		textAnchor: "middle",
		dominantBaseline: "central",
		fontSize: e.h * .55,
		fontWeight: 800,
		fill: "var(--color-ink)",
		stroke: "#ffffff",
		strokeWidth: e.h * .09,
		paintOrder: "stroke",
		pointerEvents: "none",
		children: t
	});
}
function c({ name: e, r: t }) {
	let n = r(), o = (0, i.useRef)(null);
	return (0, i.useEffect)(() => {
		if (n) return n.registerProbe(e, () => {
			let e = o.current?.getBoundingClientRect();
			return e ? {
				x: e.left,
				y: e.top,
				w: e.width,
				h: e.height
			} : null;
		}), () => n.registerProbe(e, null);
	}, [n, e]), /* @__PURE__ */ (0, a.jsx)("rect", {
		ref: o,
		x: t.x,
		y: t.y,
		width: t.w,
		height: t.h,
		fill: "none",
		pointerEvents: "none"
	});
}
function l(e, t, n, r, i) {
	if (r <= 0 || i <= 0 || e.s <= 0) return e;
	let a = r / (2 * e.s), o = i / (2 * e.s);
	return {
		...e,
		cx: a >= t / 2 ? t / 2 : Math.min(Math.max(e.cx, a), t - a),
		cy: o >= n / 2 ? n / 2 : Math.min(Math.max(e.cy, o), n - o)
	};
}
function u({ image: e, sheetW: t, sheetH: n, eligible: r, onTapEligible: s, readOnly: c, fitKey: u, clampToSheet: d = !1, focus: f, highlight: p, children: m }) {
	let h = (0, i.useRef)(null), [g, _] = (0, i.useState)({
		w: 0,
		h: 0
	}), [v, y] = (0, i.useState)(null), b = (0, i.useRef)({
		cx: t / 2,
		cy: n / 2,
		s: 1
	});
	(0, i.useEffect)(() => {
		let e = h.current, t = new ResizeObserver(() => _({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let x = g.w > 0 ? Math.min(g.w / t, g.h / n) : 1, S = (0, i.useMemo)(() => ({
		cx: t / 2,
		cy: n / 2,
		s: x
	}), [
		t,
		n,
		x
	]), C = `${u}:${+(g.w > 0)}${d ? `:${g.w}x${g.h}` : ""}`, [w, T] = (0, i.useState)("");
	w !== C && g.w > 0 && (T(C), y(S));
	let E = v ?? S;
	(0, i.useEffect)(() => {
		b.current = E;
	});
	let D = (e) => Math.min(Math.max(e, x), x * 4), O = (0, i.useCallback)((e) => d ? l(e, t, n, g.w, g.h) : e, [
		d,
		t,
		n,
		g.w,
		g.h
	]), k = (0, i.useRef)(0), A = (0, i.useRef)(0), j = (0, i.useRef)(null), M = f?.key ?? 0;
	(0, i.useEffect)(() => {
		if (!f || g.w === 0) f || (j.current = null);
		else {
			let e = b.current, r = g.w / e.s, i = g.h / e.s, a = f.rect, o = a.x >= e.cx - r / 2 && a.x + a.w <= e.cx + r / 2 && a.y >= e.cy - i / 2 && a.y + a.h <= e.cy + i / 2, s = f.returnAfterMs, c = (e) => {
				let t = { ...b.current }, n = performance.now(), r = (i) => {
					let a = Math.min(1, (i - n) / 280), o = 1 - (1 - a) ** 3, s = O({
						s: t.s,
						cx: t.cx + (e.cx - t.cx) * o,
						cy: t.cy + (e.cy - t.cy) * o
					});
					b.current = s, y(s), a < 1 && (k.current = requestAnimationFrame(r));
				};
				cancelAnimationFrame(k.current), k.current = requestAnimationFrame(r);
			};
			s === void 0 ? j.current = null : (!o && !j.current && (j.current = { ...e }), (!o || j.current) && (A.current = window.setTimeout(() => {
				let e = j.current;
				j.current = null, e && c(e);
			}, s))), o || c({
				cx: Math.min(Math.max(a.x + a.w / 2, 0), t),
				cy: Math.min(Math.max(a.y + a.h / 2, 0), n)
			});
		}
		return () => {
			cancelAnimationFrame(k.current), window.clearTimeout(A.current);
		};
	}, [M, g.w > 0]), (0, i.useEffect)(() => {
		j.current = null, window.clearTimeout(A.current);
	}, [C]), (0, i.useEffect)(() => {
		let e = h.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = b.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = D(r.s * i), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = O({
				s: a,
				cx: c - o / a,
				cy: l - s / a
			});
			b.current = u, y(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [x, O]);
	let N = (0, i.useRef)(/* @__PURE__ */ new Map()), P = (0, i.useRef)(0), F = (0, i.useRef)(0), I = (e) => {
		if (cancelAnimationFrame(k.current), window.clearTimeout(A.current), j.current = null, e.currentTarget.setPointerCapture(e.pointerId), N.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), N.current.size === 1 && (P.current = 0), N.current.size === 2) {
			let [e, t] = [...N.current.values()];
			F.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, L = (e) => {
		let t = N.current.get(e.pointerId);
		if (!t) return;
		let n = h.current.getBoundingClientRect();
		if (N.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			P.current += Math.abs(n) + Math.abs(r);
			let i = b.current, a = O({
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			});
			b.current = a, y(a);
		} else if (N.current.size === 2) {
			N.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...N.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (F.current > 0 && i > 0) {
				let e = b.current, a = D(e.s * i / F.current), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = O({
					s: a,
					cx: c - o / a,
					cy: l - s / a
				});
				b.current = u, y(u);
			}
			F.current = i, P.current = 99;
			return;
		}
		N.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, R = (e) => {
		let t = N.current.size === 1 && P.current < 10;
		if (N.current.delete(e.pointerId), F.current = 0, !t || c || !r || r.length === 0 || !s) return;
		let n = h.current.getBoundingClientRect(), i = b.current, a = i.cx + (e.clientX - n.left - n.width / 2) / i.s, o = i.cy + (e.clientY - n.top - n.height / 2) / i.s;
		for (let e of r) {
			let t = e.rect;
			if (a >= t.x - 14 && a <= t.x + t.w + 14 && o >= t.y - 14 && o <= t.y + t.h + 14) {
				s(e.key);
				return;
			}
		}
	};
	return /* @__PURE__ */ (0, a.jsx)("div", {
		ref: h,
		className: "relative h-full w-full overflow-hidden",
		children: /* @__PURE__ */ (0, a.jsx)("svg", {
			className: "h-full w-full touch-none select-none",
			onPointerDown: I,
			onPointerMove: L,
			onPointerUp: R,
			onPointerCancel: R,
			children: /* @__PURE__ */ (0, a.jsxs)("g", {
				transform: `translate(${g.w / 2 - E.cx * E.s}, ${g.h / 2 - E.cy * E.s}) scale(${E.s})`,
				children: [
					e && /* @__PURE__ */ (0, a.jsx)("image", {
						href: e,
						width: t,
						height: n
					}),
					m,
					p !== "off" && r?.map((e) => /* @__PURE__ */ (0, a.jsx)(o, {
						r: e.rect,
						inset: p === "inset"
					}, e.key))
				]
			})
		})
	});
}
//#endregion
export { c as SheetFxProbe, s as SheetText, u as SheetView };
