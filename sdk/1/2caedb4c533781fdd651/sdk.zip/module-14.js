//#region src/shared/fx/dice-roll-ms.ts
var e = {
	stagger: 90,
	tumble: 900,
	hold: 400,
	fly: 450,
	banner: (e) => (e - 1) * 90 + 900 + 400 + 450 + 150,
	inplace: (e) => (e - 1) * 90 + 900 + 350
};
//#endregion
export { e as DICE_ROLL_MS };
