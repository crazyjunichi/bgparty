import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { a as n, o as r } from "@bgparty/sdk/_/chunks/i18n-BrDyMwni.js";
import { O as i } from "@bgparty/sdk/_/chunks/icons-DzpZGOit.js";
import { t as a } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { BottomSheet as o } from "@bgparty/sdk/_/module-3.js";
//#region src/shared/use-build-time.ts
var s = /* @__PURE__ */ e(t(), 1);
function c() {
	let e = n((e) => e.locale), [t, r] = (0, s.useState)(() => {
		let e = document.querySelector("meta[name=\"bgparty-build-time\"]")?.content;
		return e && Number.isFinite(Date.parse(e)) ? e : null;
	});
	return (0, s.useEffect)(() => {
		fetch("./version.json", { cache: "no-store" }).then((e) => e.ok ? e.json() : null).then((e) => {
			e && typeof e.t == "string" && Number.isFinite(Date.parse(e.t)) && r(e.t);
		}).catch(() => {});
	}, []), t ? new Intl.DateTimeFormat(e, {
		dateStyle: "medium",
		timeStyle: "short"
	}).format(new Date(t)) : "—";
}
//#endregion
//#region src/shared/game-menu.tsx
var l = /* @__PURE__ */ e(a(), 1);
function u({ children: e, notice: t, quickAction: n, attention: a, headerAction: u }) {
	let d = r(), [f, p] = (0, s.useState)(!1), m = () => p(!1), h = c();
	return /* @__PURE__ */ (0, l.jsxs)(l.Fragment, { children: [
		t && /* @__PURE__ */ (0, l.jsx)("div", {
			className: "pointer-events-none fixed top-[calc(env(safe-area-inset-top)+6px)] left-[calc(env(safe-area-inset-left)+6px)] z-[19] max-w-[calc(100vw-72px)]",
			children: t
		}),
		n && /* @__PURE__ */ (0, l.jsx)("div", {
			className: "fixed top-[calc(env(safe-area-inset-top)+54px)] right-[calc(env(safe-area-inset-right)+6px)] z-[19]",
			children: n
		}),
		/* @__PURE__ */ (0, l.jsxs)("button", {
			type: "button",
			"aria-label": `${d(f ? "session.menu.close" : "session.menu.open")}${a ? ` · ${a}` : ""}`,
			"aria-expanded": f,
			className: "fixed top-[calc(env(safe-area-inset-top)+4px)] right-[calc(env(safe-area-inset-right)+4px)] z-[19] grid size-11 cursor-pointer place-items-center rounded-xl bg-transparent text-ink",
			onClick: () => p((e) => !e),
			children: [/* @__PURE__ */ (0, l.jsx)(i, {
				size: 22,
				className: "drop-shadow-[0_1px_1px_white]"
			}), a && /* @__PURE__ */ (0, l.jsx)("span", {
				"aria-hidden": !0,
				className: "absolute -top-1 -left-1 size-3 rounded-full border border-ink bg-warn"
			})]
		}),
		/* @__PURE__ */ (0, l.jsx)(o, {
			open: f,
			onClose: m,
			label: d("session.menu.open"),
			title: d("session.menu.open"),
			headerAction: u,
			keepMounted: !0,
			compact: !0,
			footer: /* @__PURE__ */ (0, l.jsxs)("p", {
				className: "flex-none px-3 pt-1 pb-[calc(0.75rem+env(safe-area-inset-bottom))] text-center text-xs font-medium text-ink/60",
				children: [
					d("home.buildTime"),
					" ",
					h
				]
			}),
			children: e(m)
		})
	] });
}
function d({ icon: e, label: t, onClick: n, danger: r, pressed: i }) {
	return /* @__PURE__ */ (0, l.jsxs)("button", {
		type: "button",
		"aria-pressed": i,
		className: `flex min-h-11 w-full cursor-pointer items-center gap-3 rounded-xl border-2 px-3 text-left text-sm font-bold ${r ? "border-danger bg-danger-soft text-danger-ink" : i ? "border-ink bg-pop text-white" : "border-ink bg-paper text-ink"}`,
		onClick: n,
		children: [e, /* @__PURE__ */ (0, l.jsx)("span", {
			className: "min-w-0 flex-1",
			children: t
		})]
	});
}
//#endregion
export { u as GameMenu, d as GameMenuAction };
