import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/games/ui/hint-ring.tsx
var n = /* @__PURE__ */ e(t(), 1);
function r({ radius: e = 10, dur: t = 1.6, flash: r = !0 }) {
	let i = e + 4;
	return /* @__PURE__ */ (0, n.jsxs)("svg", {
		className: `${r ? "hint-flash " : ""}pointer-events-none absolute -inset-1`,
		style: {
			width: "calc(100% + 8px)",
			height: "calc(100% + 8px)"
		},
		"aria-hidden": !0,
		children: [/* @__PURE__ */ (0, n.jsx)("rect", {
			x: 2,
			y: 2,
			rx: i,
			style: {
				width: "calc(100% - 4px)",
				height: "calc(100% - 4px)"
			},
			fill: "none",
			stroke: "#ffffff",
			strokeWidth: 4,
			opacity: .9
		}), /* @__PURE__ */ (0, n.jsx)("rect", {
			x: 2,
			y: 2,
			rx: i,
			style: {
				width: "calc(100% - 4px)",
				height: "calc(100% - 4px)"
			},
			fill: "none",
			className: "stroke-ink",
			strokeWidth: 2.5,
			strokeDasharray: "8 6",
			strokeLinecap: "round",
			children: /* @__PURE__ */ (0, n.jsx)("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-28",
				dur: `${t}s`,
				repeatCount: "indefinite"
			})
		})]
	});
}
//#endregion
export { r as HintRing };
