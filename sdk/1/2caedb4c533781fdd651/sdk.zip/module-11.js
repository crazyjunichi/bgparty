import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { usePrefersReducedMotion as r } from "@bgparty/sdk/_/module-16.js";
//#region src/shared/fx/delta-number.tsx
var i = /* @__PURE__ */ e(t(), 1), a = /* @__PURE__ */ e(n(), 1);
function o({ value: e, className: t }) {
	let [n, o] = (0, i.useState)(e), s = (0, i.useRef)(e), c = r();
	return (0, i.useEffect)(() => {
		let t = s.current;
		if (s.current = e, t === e || c) {
			o(e);
			return;
		}
		let n = performance.now(), r = 0, i = (a) => {
			let s = Math.min(1, (a - n) / 400);
			o(Math.round(t + (e - t) * (1 - (1 - s) * (1 - s)))), s < 1 && (r = requestAnimationFrame(i));
		};
		return r = requestAnimationFrame(i), () => cancelAnimationFrame(r);
	}, [e, c]), /* @__PURE__ */ (0, a.jsx)("span", {
		className: t,
		children: n
	});
}
//#endregion
export { o as DeltaNumber };
