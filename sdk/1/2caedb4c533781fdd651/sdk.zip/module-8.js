import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { CANVAS_SIZE as n, PALETTE as r, STROKE_WIDTHS as i } from "@bgparty/sdk/_/module-7.js";
//#region src/shared/drawing/view.tsx
var a = /* @__PURE__ */ e(t(), 1);
function o({ strokes: e, className: t }) {
	return /* @__PURE__ */ (0, a.jsx)("svg", {
		viewBox: `0 0 ${n} ${n}`,
		className: t,
		"aria-hidden": !0,
		children: e.map((e, t) => /* @__PURE__ */ (0, a.jsx)(s, { stroke: e }, t))
	});
}
function s({ stroke: e }) {
	let t = r[e.c] ?? r[0], n = i[e.w] ?? i[1], o = [];
	for (let t = 0; t + 1 < e.pts.length; t += 2) o.push(`${e.pts[t]},${e.pts[t + 1]}`);
	if (o.length === 1) {
		let [e, r] = o[0].split(",").map(Number);
		return /* @__PURE__ */ (0, a.jsx)("circle", {
			cx: e,
			cy: r,
			r: n / 2,
			fill: t
		});
	}
	return /* @__PURE__ */ (0, a.jsx)("polyline", {
		points: o.join(" "),
		fill: "none",
		stroke: t,
		strokeWidth: n,
		strokeLinecap: "round",
		strokeLinejoin: "round"
	});
}
//#endregion
export { o as DrawingView, s as StrokePath };
