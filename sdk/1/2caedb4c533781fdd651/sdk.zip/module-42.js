//#region src/shared/use-wake-lock.ts
function e() {}
//#endregion
export { e as useWakeLock };
