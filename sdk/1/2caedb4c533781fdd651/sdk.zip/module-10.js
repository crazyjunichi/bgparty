import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/shared/fx/anchors.tsx
var r = /* @__PURE__ */ e(t(), 1), i = /* @__PURE__ */ e(n(), 1), a = (0, r.createContext)(null), o = (0, r.createContext)(0);
function s({ children: e }) {
	let t = (0, r.useRef)(null), n = (0, r.useRef)(/* @__PURE__ */ new Map()), [s, c] = (0, r.useReducer)((e) => e + 1, 0), l = (0, r.useMemo)(() => ({
		register(e, t) {
			let r = n.current.get(e) ?? {
				el: null,
				probe: null,
				busy: 0
			};
			r.el = t, n.current.set(e, r);
		},
		registerProbe(e, t) {
			let r = n.current.get(e) ?? {
				el: null,
				probe: null,
				busy: 0
			};
			r.probe = t, n.current.set(e, r);
		},
		measure(e) {
			let r = n.current.get(e), i = t.current;
			if (!r || !i) return null;
			let a = i.getBoundingClientRect();
			if (r.el) {
				let e = r.el.getBoundingClientRect();
				return {
					x: e.left - a.left,
					y: e.top - a.top,
					w: e.width,
					h: e.height
				};
			}
			let o = r.probe?.();
			return o ? {
				x: o.x - a.left,
				y: o.y - a.top,
				w: o.w,
				h: o.h
			} : null;
		},
		setBusy(e, t) {
			let r = n.current.get(e);
			r && (r.busy = Math.max(0, r.busy + (t ? 1 : -1)), c());
		},
		isBusy(e) {
			return (n.current.get(e)?.busy ?? 0) > 0;
		}
	}), []);
	return /* @__PURE__ */ (0, i.jsx)(a.Provider, {
		value: l,
		children: /* @__PURE__ */ (0, i.jsx)(o.Provider, {
			value: s,
			children: /* @__PURE__ */ (0, i.jsx)("div", {
				ref: t,
				className: "relative h-full min-h-0",
				children: e
			})
		})
	});
}
function c() {
	let e = (0, r.useContext)(a);
	if (!e) throw Error("useFxAnchors 必须在 FxAnchorsProvider 下");
	return e;
}
function l() {
	return (0, r.useContext)(a);
}
function u(e) {
	let t = (0, r.useContext)(a);
	return (0, r.useContext)(o), {
		ref: (0, r.useCallback)((n) => e ? t?.register(e, n) : void 0, [t, e]),
		hidden: e ? t?.isBusy(e) ?? !1 : !1
	};
}
//#endregion
export { s as FxAnchorsProvider, u as useFxAnchor, c as useFxAnchors, l as useFxAnchorsMaybe };
