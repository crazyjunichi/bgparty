import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/shared/fx/primitives.tsx
var r = /* @__PURE__ */ e(t(), 1), i = /* @__PURE__ */ e(n(), 1);
function a({ from: e, to: t, ms: n, delay: a = 0, children: o }) {
	let s = (0, r.useRef)(null);
	return (0, r.useLayoutEffect)(() => {
		let r = s.current;
		if (!r) return;
		let i = r.firstElementChild instanceof HTMLElement ? r.firstElementChild : null, o = i?.offsetWidth || e.w, c = i?.offsetHeight || e.h;
		r.style.left = `${e.x + (e.w - o) / 2}px`, r.style.top = `${e.y + (e.h - c) / 2}px`, r.style.width = `${o}px`, r.style.height = `${c}px`;
		let l = t.x + t.w / 2 - (e.x + e.w / 2), u = t.y + t.h / 2 - (e.y + e.h / 2), d = o > 0 ? t.w / o : 1, f = Math.abs(d - 1) < .02, p = f ? 1 : (1 + d) / 2, m = f ? 1 : d, h = r.animate([
			{ transform: "translate(0px, 0px) scale(1)" },
			{
				transform: `translate(${l * .55}px, ${u * .55 - 14}px) scale(${p})`,
				offset: .55
			},
			{ transform: `translate(${l}px, ${u}px) scale(${m})` }
		], {
			duration: n,
			delay: a,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => h.cancel();
	}, [
		e,
		t,
		n,
		a
	]), /* @__PURE__ */ (0, i.jsx)("div", {
		ref: s,
		className: "absolute",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: o
	});
}
function o({ at: e, ms: t, delay: n = 0, children: a }) {
	let o = (0, r.useRef)(null);
	return (0, r.useEffect)(() => {
		let e = o.current;
		if (!e) return;
		let r = e.animate([
			{
				transform: "translate(-50%, 0)",
				opacity: 0
			},
			{
				transform: "translate(-50%, -6px)",
				opacity: 1,
				offset: .2
			},
			{
				transform: "translate(-50%, -28px)",
				opacity: 0
			}
		], {
			duration: t,
			delay: n,
			easing: "ease-out",
			fill: "both"
		});
		return () => r.cancel();
	}, [
		e,
		t,
		n
	]), /* @__PURE__ */ (0, i.jsx)("div", {
		ref: o,
		className: "absolute text-sm font-extrabold whitespace-nowrap",
		style: {
			left: e.x + e.w / 2,
			top: e.y - 6
		},
		children: a
	});
}
function s({ ms: e, className: t = "bg-danger" }) {
	let n = (0, r.useRef)(null);
	return (0, r.useEffect)(() => {
		let t = n.current;
		if (!t) return;
		let r = t.animate([
			{ opacity: 0 },
			{
				opacity: .35,
				offset: .25
			},
			{ opacity: 0 }
		], {
			duration: e,
			easing: "ease-out",
			fill: "both"
		});
		return () => r.cancel();
	}, [e]), /* @__PURE__ */ (0, i.jsx)("div", {
		ref: n,
		className: `absolute inset-0 ${t}`
	});
}
function c({ at: e, ms: t, delay: n = 0 }) {
	let a = (0, r.useRef)(null);
	return (0, r.useEffect)(() => {
		let r = a.current;
		if (!r) return;
		let i = 1 + 4 / Math.max(e.w, e.h), o = r.animate([
			{
				transform: "scale(1)",
				opacity: 0
			},
			{
				transform: `scale(${i})`,
				opacity: .9,
				offset: .25
			},
			{
				transform: "scale(1)",
				opacity: .35,
				offset: .5
			},
			{
				transform: `scale(${i})`,
				opacity: .9,
				offset: .75
			},
			{
				transform: "scale(1)",
				opacity: 0
			}
		], {
			duration: t,
			delay: n,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => o.cancel();
	}, [
		e,
		t,
		n
	]), /* @__PURE__ */ (0, i.jsx)("div", {
		ref: a,
		className: "absolute rounded-xl border-3 border-ink",
		style: {
			left: e.x - 3,
			top: e.y - 3,
			width: e.w + 6,
			height: e.h + 6
		}
	});
}
//#endregion
export { s as Flash, o as Floater, a as FlySprite, c as PulseBox };
