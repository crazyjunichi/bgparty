import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/games/ui/game-options.tsx
var n = /* @__PURE__ */ e(t(), 1);
function r({ title: e, count: t, children: r, columns: i = 2 }) {
	return /* @__PURE__ */ (0, n.jsxs)("fieldset", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, n.jsxs)("legend", {
			className: "section-label mb-2 w-full",
			children: [e, t != null && /* @__PURE__ */ (0, n.jsx)("span", {
				className: "ml-2 font-mono text-xs tabular-nums opacity-65",
				children: t
			})]
		}), /* @__PURE__ */ (0, n.jsx)("div", {
			className: `grid gap-2 ${i === 3 ? "grid-cols-3" : "grid-cols-2"}`,
			children: r
		})]
	});
}
function i({ label: e, hint: t }) {
	return /* @__PURE__ */ (0, n.jsxs)("span", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, n.jsx)("span", {
			className: "block text-sm font-bold leading-tight",
			children: e
		}), t && /* @__PURE__ */ (0, n.jsx)("span", {
			className: "mt-0.5 block text-xs leading-tight text-ink/65",
			children: t
		})]
	});
}
function a({ name: e, value: t, checked: r, label: a, hint: o, disabled: s, title: c, accent: l, onChange: u }) {
	return /* @__PURE__ */ (0, n.jsxs)("label", {
		title: c,
		className: "flex min-h-11 min-w-0 cursor-pointer items-center gap-2 rounded-lg border-2 border-ink/35 bg-surface px-2 py-1.5 focus-within:outline-3 focus-within:outline-offset-2 focus-within:outline-info disabled:opacity-40 has-[:disabled]:cursor-not-allowed has-[:disabled]:opacity-40",
		style: r ? { borderColor: l ?? "var(--color-info)" } : void 0,
		children: [
			/* @__PURE__ */ (0, n.jsx)("input", {
				className: "sr-only",
				type: "radio",
				name: e,
				value: t,
				checked: r,
				disabled: s,
				onChange: u
			}),
			/* @__PURE__ */ (0, n.jsx)("span", {
				"aria-hidden": !0,
				className: "grid size-5 flex-none place-items-center rounded-full border-2 border-ink bg-surface",
				children: r && /* @__PURE__ */ (0, n.jsx)("span", { className: "size-2.5 rounded-full bg-ink" })
			}),
			/* @__PURE__ */ (0, n.jsx)(i, {
				label: a,
				hint: o
			})
		]
	});
}
function o({ name: e, value: t, checked: r, label: a, hint: o, disabled: s, title: c, accent: l, onChange: u }) {
	return /* @__PURE__ */ (0, n.jsxs)("label", {
		title: c,
		className: "flex min-h-11 min-w-0 cursor-pointer items-center gap-2 rounded-lg border-2 border-ink/35 bg-surface px-2 py-1.5 focus-within:outline-3 focus-within:outline-offset-2 focus-within:outline-info has-[:disabled]:cursor-not-allowed has-[:disabled]:opacity-40",
		style: r ? { borderColor: l ?? "var(--color-info)" } : void 0,
		children: [
			/* @__PURE__ */ (0, n.jsx)("input", {
				className: "sr-only",
				type: "checkbox",
				name: e,
				value: t,
				checked: r,
				disabled: s,
				onChange: u
			}),
			/* @__PURE__ */ (0, n.jsx)("span", {
				"aria-hidden": !0,
				className: "grid size-5 flex-none place-items-center rounded border-2 border-ink bg-surface text-sm font-black leading-none",
				children: r ? "✓" : null
			}),
			/* @__PURE__ */ (0, n.jsx)(i, {
				label: a,
				hint: o
			})
		]
	});
}
function s({ checked: e, label: t, hint: r, disabled: a, accent: o, onChange: s }) {
	return /* @__PURE__ */ (0, n.jsxs)("label", {
		className: "flex min-h-12 cursor-pointer items-center gap-3 border-b border-ink/15 py-2 focus-within:outline-3 focus-within:outline-offset-2 focus-within:outline-info has-[:disabled]:cursor-not-allowed has-[:disabled]:opacity-40",
		children: [
			/* @__PURE__ */ (0, n.jsx)("input", {
				className: "sr-only",
				type: "checkbox",
				role: "switch",
				checked: e,
				disabled: a,
				onChange: s
			}),
			/* @__PURE__ */ (0, n.jsx)("span", {
				className: "min-w-0 flex-1",
				children: /* @__PURE__ */ (0, n.jsx)(i, {
					label: t,
					hint: r
				})
			}),
			/* @__PURE__ */ (0, n.jsx)("span", {
				"aria-hidden": !0,
				className: "flex h-7 w-12 flex-none items-center rounded-full border-2 border-ink bg-ink/20 px-0.5",
				style: e ? { backgroundColor: o ?? "var(--color-info)" } : void 0,
				children: /* @__PURE__ */ (0, n.jsx)("span", { className: `size-5 rounded-full border border-ink bg-surface transition-transform duration-100 ${e ? "translate-x-5" : ""}` })
			})
		]
	});
}
//#endregion
export { o as OptionCheckbox, a as OptionRadio, r as OptionSection, s as OptionSwitch };
