import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
//#region src/shared/texture.tsx
var r = /* @__PURE__ */ e(t(), 1), i = /* @__PURE__ */ e(n(), 1), a = {
	sheen: null,
	dots: {
		size: 16,
		body: (e) => /* @__PURE__ */ (0, i.jsxs)("g", {
			fill: e,
			children: [/* @__PURE__ */ (0, i.jsx)("circle", {
				cx: 4,
				cy: 4,
				r: 1.5
			}), /* @__PURE__ */ (0, i.jsx)("circle", {
				cx: 12,
				cy: 12,
				r: 1.5
			})]
		})
	},
	hatch: {
		size: 16,
		body: (e) => /* @__PURE__ */ (0, i.jsx)("path", {
			d: "M-4 4 L4 -4 M0 16 L16 0 M12 20 L20 12",
			fill: "none",
			stroke: e,
			strokeWidth: 1.5
		})
	},
	diamond: {
		size: 16,
		body: (e) => /* @__PURE__ */ (0, i.jsx)("path", {
			d: "M8 1.5 L14.5 8 L8 14.5 L1.5 8 Z",
			fill: "none",
			stroke: e,
			strokeWidth: 1.1
		})
	}
};
function o({ kind: e, base: t, line: n = t, className: o }) {
	let s = (0, r.useId)().replace(/:/g, ""), c = a[e];
	return /* @__PURE__ */ (0, i.jsxs)("span", {
		className: o,
		"aria-hidden": !0,
		children: [/* @__PURE__ */ (0, i.jsxs)("svg", {
			className: "absolute inset-0 size-full",
			children: [
				c && /* @__PURE__ */ (0, i.jsx)("defs", { children: /* @__PURE__ */ (0, i.jsx)("pattern", {
					id: `t${s}`,
					width: c.size,
					height: c.size,
					patternUnits: "userSpaceOnUse",
					children: c.body(n)
				}) }),
				/* @__PURE__ */ (0, i.jsx)("rect", {
					width: "100%",
					height: "100%",
					fill: t
				}),
				c && /* @__PURE__ */ (0, i.jsx)("rect", {
					width: "100%",
					height: "100%",
					fill: `url(#t${s})`
				})
			]
		}), /* @__PURE__ */ (0, i.jsx)("span", {
			className: "absolute inset-0 rounded-[inherit]",
			style: { boxShadow: "inset 0 20px 28px -22px rgb(255 255 255 / 0.7), inset 0 0 40px rgb(43 33 24 / 0.07), inset 0 -14px 24px -16px rgb(43 33 24 / 0.1)" }
		})]
	});
}
//#endregion
export { o as Texture };
