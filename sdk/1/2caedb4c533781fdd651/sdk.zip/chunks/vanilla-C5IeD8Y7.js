import { n as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
//#region node_modules/zustand/esm/vanilla.mjs
var t = /* @__PURE__ */ e({ createStore: () => r }), n = (e) => {
	let t, n = /* @__PURE__ */ new Set(), r = (e, r) => {
		let i = typeof e == "function" ? e(t) : e;
		if (!Object.is(i, t)) {
			let e = t;
			t = r ?? (typeof i != "object" || !i) ? i : Object.assign({}, t, i), n.forEach((n) => n(t, e));
		}
	}, i = () => t, a = {
		setState: r,
		getState: i,
		getInitialState: () => o,
		subscribe: (e) => (n.add(e), () => n.delete(e))
	}, o = t = e(r, i, a);
	return a;
}, r = ((e) => e ? n(e) : n);
//#endregion
export { t as n, r as t };
