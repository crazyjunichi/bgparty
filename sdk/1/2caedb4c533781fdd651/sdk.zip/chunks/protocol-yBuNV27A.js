import { An as e, Dt as t, Ft as n, Kt as r, Nn as i, Wn as a, _n as o, an as s, gn as c, ir as l, jn as u, jt as d, nr as f, wt as p, zn as m } from "@bgparty/sdk/_/chunks/schemas-BpsPIIob.js";
//#region src/shared/protocol/envelope.ts
var h = c(() => f([
	a(),
	e(),
	n(),
	t(),
	d(h),
	m(a(), h)
])), g = p(["lobby", "game"]), _ = u({
	kind: a().min(1),
	rid: a().optional(),
	data: h.optional(),
	for: d(a()).optional(),
	secret: h.optional(),
	with: n().optional(),
	ephemeral: n().optional()
});
u({
	v: s(),
	kind: g,
	rid: a().min(1),
	seq: s().nonnegative(),
	hello: n(),
	data: h,
	relay: n().optional(),
	hb: n().optional()
}), r("ok", [u({
	v: s(),
	ok: o(!0),
	view: h,
	fx: d(_).optional()
}), u({
	v: s(),
	ok: o(!1),
	reason: a().optional(),
	params: m(a(), f([a(), e()])).optional()
})]);
//#endregion
//#region src/game-packs/format.ts
var v = "bgparty.pack@1", y = "bgparty.source@1", b = {
	compressedBytes: 100663296,
	unpackedBytes: 268435456,
	fileBytes: 67108864,
	files: 4096
}, x = a().regex(/^[a-f0-9]{64}$/), S = a().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100), C = a().regex(/^[a-zA-Z0-9][a-zA-Z0-9.+_-]{0,99}$/);
function w(e) {
	return e.length > 0 && e.length <= 300 && !/[\\%?#:]/.test(e) && !Array.from(e).some((e) => e.charCodeAt(0) < 32) && e.split("/").every((e) => e.length > 0 && e !== "." && e !== "..");
}
var T = a().refine(w), E = u({
	sha256: x,
	bytes: e().int().min(0).max(b.fileBytes),
	mime: a().max(100).regex(/^[a-z0-9.+-]+\/[a-z0-9.+-]+(?:;charset=utf-8)?$/)
}).strict(), D = u({
	name: a().min(1).max(150),
	desc: a().max(1e3),
	rules: a().max(1e5)
}).strict(), O = u({
	id: S,
	labels: u({
		zh: D,
		en: D
	}).strict(),
	icon: a().max(30),
	iconPath: T.optional(),
	minPlayers: e().int().min(1).max(128),
	maxPlayers: e().int().min(1).max(128),
	bestPlayers: d(e().int().min(1).max(128)).max(128).optional(),
	rulesUrl: i(p([
		"zh",
		"en",
		"de",
		"fr",
		"es",
		"it",
		"ru",
		"ja"
	]), l().refine((e) => e.startsWith("https://"))).optional(),
	botDelayMs: e().int().min(0).max(6e4).optional(),
	accent: a().regex(/^#[a-fA-F0-9]{6}$/),
	hotseat: p([
		"open",
		"cover",
		"off"
	]),
	tier: p([
		"dev",
		"alpha",
		"beta",
		"released"
	]),
	releasedAt: a().max(40),
	mechanics: d(S).max(32),
	interactionTags: d(S).max(16),
	search: u({
		py: a().max(1e3),
		init: a().max(100)
	}).strict(),
	capabilities: u({
		bot: n(),
		ai: n(),
		options: n(),
		guide: n()
	}).strict()
}).strict().refine((e) => e.maxPlayers >= e.minPlayers), k = u({
	url: a().min(1).max(2048),
	sha256: x,
	bytes: e().int().positive().max(b.compressedBytes),
	id: S,
	version: C,
	sdkMajor: e().int().positive(),
	sdkApi: e().int().min(1).max(1e5).optional()
}).strict();
u({
	format: o(v),
	kind: p([
		"game",
		"sdk",
		"resource"
	]),
	id: S,
	version: C,
	bridge: o(1),
	sdkMajor: e().int().min(1).max(1e3),
	sdkApi: e().int().min(1).max(1e5).optional(),
	platformApi: e().int().min(1).max(1e5).optional(),
	entry: T,
	exports: m(a().max(200), T),
	assets: m(a().max(500), T),
	css: d(T).max(128),
	files: m(T, E),
	dependencies: d(k).max(32).default([]),
	game: O.optional()
}).strict().superRefine((e, t) => {
	let n = Object.keys(e.files);
	(n.length === 0 || n.length > b.files || !e.files[e.entry]) && t.addIssue({
		code: "custom",
		message: "Invalid package entry or file count"
	}), Object.values(e.files).reduce((e, t) => e + t.bytes, 0) > b.unpackedBytes && t.addIssue({
		code: "custom",
		message: "Package is too large"
	});
	for (let n of [
		...Object.values(e.exports),
		...Object.values(e.assets),
		...e.css,
		...e.game?.iconPath ? [e.game.iconPath] : []
	]) e.files[n] || t.addIssue({
		code: "custom",
		message: "Missing package file"
	});
	e.kind === "game" && (!e.game || e.game.id !== e.id) && t.addIssue({
		code: "custom",
		message: "Missing game metadata"
	});
	for (let n of Object.keys(e.exports)) e.kind === "game" && !n.startsWith("@bgparty/game/") && t.addIssue({
		code: "custom",
		message: "Reserved module namespace"
	});
	e.kind === "resource" && (Object.keys(e.exports).length || e.dependencies.length || e.css.length) && t.addIssue({
		code: "custom",
		message: "Resource packages cannot contain executable modules or dependencies"
	});
}), u({
	format: o("bgparty.sdk@1"),
	releases: d(k).max(1e4)
}).strict();
var A = u({
	source: a().max(2048),
	game: k,
	sdk: k
}).strict();
u({
	format: o(y),
	name: a().min(1).max(150),
	games: d(u({
		metadata: O,
		release: k
	}).strict()).max(1e4)
}).strict().superRefine((e, t) => {
	let n = /* @__PURE__ */ new Set();
	for (let r of e.games) (n.has(r.metadata.id) || r.metadata.id !== r.release.id) && t.addIssue({
		code: "custom",
		message: "Duplicate or inconsistent game identity"
	}), n.add(r.metadata.id);
});
//#endregion
//#region src/lobby/protocol.ts
var j = r("type", [
	u({
		type: o("join"),
		name: a().max(64),
		avatar: s().nonnegative()
	}),
	u({ type: o("leave") }),
	u({
		type: o("autopilot"),
		on: n()
	})
]), M = u({
	rid: a(),
	name: a(),
	colorIndex: s().nonnegative(),
	avatar: s().nonnegative(),
	online: n(),
	autopilot: n().optional()
}), N = "bot:", P = "aibot:", F = (e, t = "rule") => `${t === "ai" ? P : N}${e}`, I = (e) => {
	let t = e.startsWith(P) ? P : e.startsWith(N) ? N : null;
	if (t === null) return null;
	let n = Number(e.slice(t.length));
	return Number.isInteger(n) && n >= 0 ? n : null;
}, L = (e) => I(e) !== null, R = (e) => e.startsWith(P) && I(e) !== null, z = "local:", B = (e) => `${z}${e}`, V = (e) => {
	if (!e.startsWith(z)) return null;
	let t = Number(e.slice(6));
	return Number.isInteger(t) && t >= 0 ? t : null;
}, H = (e) => V(e) !== null, U = u({
	winner: d(a()),
	ranking: d(a()),
	scores: m(a(), e()).optional(),
	autopilot: m(a(), e()).optional()
}), W = u({
	lobby: u({
		phase: p(["lobby", "playing"]),
		gameId: a().nullable(),
		runtime: A.optional(),
		members: d(M)
	}),
	game: h.optional(),
	analyticsMatchId: a().regex(/^[a-z0-9]{32}$/).optional()
});
//#endregion
export { L as a, j as c, W as d, R as i, V as l, F as n, H as o, U as r, M as s, I as t, B as u };
