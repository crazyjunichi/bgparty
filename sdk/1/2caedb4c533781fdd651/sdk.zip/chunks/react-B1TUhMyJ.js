import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/vanilla-C5IeD8Y7.js";
//#region node_modules/zustand/esm/react.mjs
var r = /* @__PURE__ */ e(t(), 1), i = (e) => e;
function a(e, t = i) {
	let n = r.useSyncExternalStore(e.subscribe, r.useCallback(() => t(e.getState()), [e, t]), r.useCallback(() => t(e.getInitialState()), [e, t]));
	return r.useDebugValue(n), n;
}
var o = (e) => {
	let t = n(e), r = (e) => a(t, e);
	return Object.assign(r, t), r;
}, s = ((e) => e ? o(e) : o);
//#endregion
export { a as n, s as t };
