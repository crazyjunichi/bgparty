import { t as e } from "@bgparty/sdk/_/chunks/react-B1TUhMyJ.js";
import { a as t } from "@bgparty/sdk/_/chunks/middleware-BVjMCqJq.js";
//#region src/shared/i18n/index.ts
var n = null;
function r(e) {
	n = e;
}
function i(e, t) {
	if (n) for (let r of ["zh", "en"]) {
		let i = n[r].games;
		i[e] = t[r];
	}
}
function a(e, t) {
	return t ? e.replace(/\{\{(\w+)\}\}/g, (e, n) => String(t[n] ?? `{{${n}}}`)) : e;
}
function o(e, t, r) {
	let i = n?.[e];
	for (let e of t.split(".")) {
		if (typeof i != "object" || !i) return t;
		i = i[e];
	}
	return typeof i == "string" ? a(i, r) : t;
}
var s = e()(t((e) => ({
	locale: navigator.language.toLowerCase().startsWith("zh") ? "zh" : "en",
	setLocale: (t) => e({ locale: t })
}), {
	name: "bgparty:settings",
	partialize: (e) => ({ locale: e.locale })
}));
function c() {
	let e = s((e) => e.locale);
	return (t, n) => o(e, t, n);
}
function l(e, t) {
	return n?.[e].avatarNames[t] ?? `Avatar ${t + 1}`;
}
//#endregion
export { s as a, o as i, i as n, c as o, r, l as t };
