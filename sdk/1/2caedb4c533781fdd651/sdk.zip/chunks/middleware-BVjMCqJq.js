import { n as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
//#region node_modules/zustand/esm/middleware.mjs
var t = /* @__PURE__ */ e({
	combine: () => m,
	createJSONStorage: () => h,
	devtools: () => d,
	persist: () => _,
	redux: () => n,
	subscribeWithSelector: () => p,
	unstable_ssrSafe: () => v
}), n = (e, t) => (n, r, i) => (i.dispatch = (t) => (n((n) => e(n, t), !1, t), t), i.dispatchFromDevtools = !0, {
	dispatch: (...e) => i.dispatch(...e),
	...t
}), r = (e) => !!e.dispatchFromDevtools && typeof e.dispatch == "function", i = /* @__PURE__ */ new Map(), a = (e) => {
	let t = i.get(e);
	return t ? Object.fromEntries(Object.entries(t.stores).map(([e, t]) => [e, t.getState()])) : {};
}, o = (e, t, n) => {
	if (e === void 0) return {
		type: "untracked",
		connection: t.connect(n)
	};
	let r = i.get(n.name);
	if (r) return {
		type: "tracked",
		store: e,
		...r
	};
	let a = {
		connection: t.connect(n),
		stores: {}
	};
	return i.set(n.name, a), {
		type: "tracked",
		store: e,
		...a
	};
}, s = (e, t) => {
	if (t === void 0) return;
	let n = i.get(e);
	n && (delete n.stores[t], Object.keys(n.stores).length === 0 && i.delete(e));
}, c = /^at (?:new |async )?(.+?) \(/, l = /^([^@]+)@/;
function u(e) {
	if (!e) return;
	let t = e.split("\n"), n = t.findIndex((e) => e.includes("api.setState"));
	if (n < 0) return;
	let r = t[n + 1]?.trim() || "";
	return c.exec(r)?.[1] || l.exec(r)?.[1];
}
var d = (e, t = {}) => (n, i, c) => {
	let { enabled: l, anonymousActionType: d, store: p, ...m } = t, h;
	try {
		h = (l ?? !1) && window.__REDUX_DEVTOOLS_EXTENSION__;
	} catch {}
	if (!h) return e(n, i, c);
	let { connection: g, ..._ } = o(p, h, m), v = !0;
	c.setState = ((e, t, r) => {
		let o = n(e, t);
		if (!v) return o;
		let s = r === void 0 ? { type: d || u((/* @__PURE__ */ Error()).stack) || "anonymous" } : typeof r == "string" ? { type: r } : r;
		return p === void 0 ? (g?.send(s, i()), o) : (g?.send({
			...s,
			type: `${p}/${s.type}`
		}, {
			...a(m.name),
			[p]: c.getState()
		}), o);
	}), c.devtools = { cleanup: () => {
		g && typeof g.unsubscribe == "function" && g.unsubscribe(), s(m.name, p);
	} };
	let y = (...e) => {
		let t = v;
		v = !1, n(...e), v = t;
	}, b = e(c.setState, i, c);
	if (_.type === "untracked" ? g?.init(b) : (_.stores[_.store] = c, g?.init(Object.fromEntries(Object.entries(_.stores).map(([e, t]) => [e, e === _.store ? b : t.getState()])))), r(c)) {
		let e = c.dispatch;
		c.dispatch = (...t) => {
			e(...t);
		};
	}
	return g.subscribe((e) => {
		switch (e.type) {
			case "ACTION":
				if (typeof e.payload != "string") {
					console.error("[zustand devtools middleware] Unsupported action format");
					return;
				}
				return f(e.payload, (e) => {
					if (e.type === "__setState") {
						if (p === void 0) {
							y(e.state);
							return;
						}
						Object.keys(e.state).length !== 1 && console.error("\n                    [zustand devtools middleware] Unsupported __setState action format.\n                    When using 'store' option in devtools(), the 'state' should have only one key, which is a value of 'store' that was passed in devtools(),\n                    and value of this only key should be a state object. Example: { \"type\": \"__setState\", \"state\": { \"abc123Store\": { \"foo\": \"bar\" } } }\n                    ");
						let t = e.state[p];
						if (t == null) return;
						JSON.stringify(c.getState()) !== JSON.stringify(t) && y(t);
						return;
					}
					r(c) && c.dispatch(e);
				});
			case "DISPATCH":
				switch (e.payload.type) {
					case "RESET": return y(b), p === void 0 ? g?.init(c.getState()) : g?.init(a(m.name));
					case "COMMIT":
						if (p === void 0) {
							g?.init(c.getState());
							return;
						}
						return g?.init(a(m.name));
					case "ROLLBACK": return f(e.state, (e) => {
						if (p === void 0) {
							y(e), g?.init(c.getState());
							return;
						}
						y(e[p]), g?.init(a(m.name));
					});
					case "JUMP_TO_STATE":
					case "JUMP_TO_ACTION": return f(e.state, (e) => {
						if (p === void 0) {
							y(e);
							return;
						}
						JSON.stringify(c.getState()) !== JSON.stringify(e[p]) && y(e[p]);
					});
					case "IMPORT_STATE": {
						let { nextLiftedState: t } = e.payload, n = t.computedStates.slice(-1)[0]?.state;
						if (!n) return;
						y(p === void 0 ? n : n[p]), g?.send(null, t);
						return;
					}
					case "PAUSE_RECORDING": return v = !v;
				}
				return;
		}
	}), b;
}, f = (e, t) => {
	let n;
	try {
		n = JSON.parse(e);
	} catch (e) {
		console.error("[zustand devtools middleware] Could not parse the received json", e);
	}
	n !== void 0 && t(n);
}, p = (e) => (t, n, r) => {
	let i = r.subscribe;
	return r.subscribe = ((e, t, n) => {
		let a = e;
		if (t) {
			let i = n?.equalityFn || Object.is, o = e(r.getState());
			a = (n) => {
				let r = e(n);
				if (!i(o, r)) {
					let e = o;
					t(o = r, e);
				}
			}, n?.fireImmediately && t(o, o);
		}
		return i(a);
	}), e(t, n, r);
};
function m(e, t) {
	return (...n) => Object.assign({}, e, t(...n));
}
function h(e, t) {
	let n;
	try {
		n = e();
	} catch {
		return;
	}
	return {
		getItem: (e) => {
			let r = (e) => e === null ? null : JSON.parse(e, t?.reviver), i = n.getItem(e) ?? null;
			return i instanceof Promise ? i.then(r) : r(i);
		},
		setItem: (e, r) => n.setItem(e, JSON.stringify(r, t?.replacer)),
		removeItem: (e) => n.removeItem(e)
	};
}
var g = (e) => (t) => {
	try {
		let n = e(t);
		return n instanceof Promise ? n : {
			then(e) {
				return g(e)(n);
			},
			catch(e) {
				return this;
			}
		};
	} catch (e) {
		return {
			then(e) {
				return this;
			},
			catch(t) {
				return g(t)(e);
			}
		};
	}
}, _ = (e, t) => (n, r, i) => {
	let a = {
		storage: h(() => window.localStorage),
		partialize: (e) => e,
		version: 0,
		merge: (e, t) => ({
			...t,
			...e
		}),
		...t
	}, o = !1, s = 0, c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), u = a.storage;
	if (!u) return e((...e) => {
		console.warn(`[zustand persist middleware] Unable to update item '${a.name}', the given storage is currently unavailable.`), n(...e);
	}, r, i);
	let d = () => {
		let e = a.partialize({ ...r() });
		return u.setItem(a.name, {
			state: e,
			version: a.version
		});
	}, f = i.setState;
	i.setState = (e, t) => (f(e, t), d());
	let p = e((...e) => (n(...e), d()), r, i);
	i.getInitialState = () => p;
	let m, _ = () => {
		if (!u) return;
		let e = ++s;
		o = !1, c.forEach((e) => e(r() ?? p));
		let t = a.onRehydrateStorage?.call(a, r() ?? p) || void 0;
		return g(u.getItem.bind(u))(a.name).then((e) => {
			if (e) {
				if (typeof e.version == "number" && e.version !== a.version) {
					if (a.migrate) {
						let t = a.migrate(e.state, e.version);
						return t instanceof Promise ? t.then((e) => [!0, e]) : [!0, t];
					}
					console.error("State loaded from storage couldn't be migrated since no migrate function was provided");
				} else return [!1, e.state];
			}
			return [!1, void 0];
		}).then((t) => {
			if (e !== s) return;
			let [i, o] = t;
			if (m = a.merge(o, r() ?? p), n(m, !0), i) return d();
		}).then(() => {
			e === s && (t?.(r(), void 0), m = r(), o = !0, l.forEach((e) => e(m)));
		}).catch((n) => {
			e === s && t?.(void 0, n);
		});
	};
	return i.persist = {
		setOptions: (e) => {
			a = {
				...a,
				...e
			}, e.storage && (u = e.storage);
		},
		clearStorage: () => {
			++s, u?.removeItem(a.name);
		},
		getOptions: () => a,
		rehydrate: () => _(),
		hasHydrated: () => o,
		onHydrate: (e) => (c.add(e), () => {
			c.delete(e);
		}),
		onFinishHydration: (e) => (l.add(e), () => {
			l.delete(e);
		})
	}, a.skipHydration || _(), m || p;
};
function v(e, t = typeof window > "u") {
	return (n, r, i) => {
		if (!t) return e(n, r, i);
		let a = () => {
			throw Error("Cannot set state of Zustand store in SSR");
		};
		return i.setState = a, e(a, r, i);
	};
}
//#endregion
export { _ as a, p as c, t as i, h as n, n as o, d as r, v as s, m as t };
