import { n as e, r as t, t as n } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t as r } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as i } from "@bgparty/sdk/_/chunks/vanilla-C5IeD8Y7.js";
import { t as a } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { $ as o, Fr as s, Lr as c, Pn as l, Qn as u, Wi as d, X as f, Z as p, c as m, co as h, ia as g, lo as _, o as v, oa as ee, sa as te } from "@bgparty/sdk/_/chunks/three.module-CXYNdk4Y.js";
//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.js
var ne = /* @__PURE__ */ n(((e) => {
	var t = r();
	function n(e, t) {
		return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t;
	}
	var i = typeof Object.is == "function" ? Object.is : n, a = t.useState, o = t.useEffect, s = t.useLayoutEffect, c = t.useDebugValue;
	function l(e, t) {
		var n = t(), r = a({ inst: {
			value: n,
			getSnapshot: t
		} }), i = r[0].inst, l = r[1];
		return s(function() {
			i.value = n, i.getSnapshot = t, u(i) && l({ inst: i });
		}, [
			e,
			n,
			t
		]), o(function() {
			return u(i) && l({ inst: i }), e(function() {
				u(i) && l({ inst: i });
			});
		}, [e]), c(n), n;
	}
	function u(e) {
		var t = e.getSnapshot;
		e = e.value;
		try {
			var n = t();
			return !i(e, n);
		} catch {
			return !0;
		}
	}
	function d(e, t) {
		return t();
	}
	var f = typeof window > "u" || window.document === void 0 || window.document.createElement === void 0 ? d : l;
	e.useSyncExternalStore = t.useSyncExternalStore === void 0 ? f : t.useSyncExternalStore;
})), y = /* @__PURE__ */ n(((e, t) => {
	t.exports = ne();
})), re = /* @__PURE__ */ n(((e) => {
	var t = r(), n = y();
	function i(e, t) {
		return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t;
	}
	var a = typeof Object.is == "function" ? Object.is : i, o = n.useSyncExternalStore, s = t.useRef, c = t.useEffect, l = t.useMemo, u = t.useDebugValue;
	e.useSyncExternalStoreWithSelector = function(e, t, n, r, i) {
		var d = s(null);
		if (d.current === null) {
			var f = {
				hasValue: !1,
				value: null
			};
			d.current = f;
		} else f = d.current;
		d = l(function() {
			function e(e) {
				if (!o) {
					if (o = !0, s = e, e = r(e), i !== void 0 && f.hasValue) {
						var t = f.value;
						if (i(t, e)) return c = t;
					}
					return c = e;
				}
				if (t = c, a(s, e)) return t;
				var n = r(e);
				return i !== void 0 && i(t, n) ? (s = e, t) : (s = e, c = n);
			}
			var o = !1, s, c, l = n === void 0 ? null : n;
			return [function() {
				return e(t());
			}, l === null ? void 0 : function() {
				return e(l());
			}];
		}, [
			t,
			n,
			r,
			i
		]);
		var p = o(e, d[0], d[1]);
		return c(function() {
			f.hasValue = !0, f.value = p;
		}, [p]), u(p), p;
	};
})), b = /* @__PURE__ */ n(((e, t) => {
	t.exports = re();
})), x = /* @__PURE__ */ t(a()), S = /* @__PURE__ */ t(r(), 1), { useSyncExternalStoreWithSelector: ie } = (/* @__PURE__ */ t(b(), 1)).default, ae = (e) => e;
function oe(e, t = ae, n) {
	let r = ie(e.subscribe, e.getState, e.getInitialState, t, n);
	return S.useDebugValue(r), r;
}
var se = (e, t) => {
	let n = i(e), r = (e, r = t) => oe(n, e, r);
	return Object.assign(r, n), r;
}, ce = ((e, t) => e ? se(e, t) : se), le = (e) => typeof e == "object" && typeof e.then == "function", C = [];
function ue(e, t, n = (e, t) => e === t) {
	if (e === t) return !0;
	if (!e || !t) return !1;
	let r = e.length;
	if (t.length !== r) return !1;
	for (let i = 0; i < r; i++) if (!n(e[i], t[i])) return !1;
	return !0;
}
function de(e, t = null, n = !1, r = {}) {
	t === null && (t = [e]);
	for (let e of C) if (ue(t, e.keys, e.equal)) {
		if (n) return;
		if (Object.prototype.hasOwnProperty.call(e, "error")) throw e.error;
		if (Object.prototype.hasOwnProperty.call(e, "response")) return r.lifespan && r.lifespan > 0 && (e.timeout && clearTimeout(e.timeout), e.timeout = setTimeout(e.remove, r.lifespan)), e.response;
		if (!n) throw e.promise;
	}
	let i = {
		keys: t,
		equal: r.equal,
		remove: () => {
			let e = C.indexOf(i);
			e !== -1 && C.splice(e, 1);
		},
		promise: (le(e) ? e : e(...t)).then((e) => {
			i.response = e, r.lifespan && r.lifespan > 0 && (i.timeout = setTimeout(i.remove, r.lifespan));
		}).catch((e) => i.error = e)
	};
	if (C.push(i), !n) throw i.promise;
}
var fe = (e, t, n) => de(e, t, !1, n), pe = (e, t, n) => void de(e, t, !0, n), me = (e) => {
	if (e === void 0 || e.length === 0) C.splice(0, C.length);
	else {
		let t = C.find((t) => ue(e, t.keys, t.equal));
		t && t.remove();
	}
}, he = /* @__PURE__ */ n(((e) => {
	function t(e, t) {
		var n = e.length;
		e.push(t);
		a: for (; 0 < n;) {
			var r = n - 1 >>> 1, a = e[r];
			if (0 < i(a, t)) e[r] = t, e[n] = a, n = r;
			else break a;
		}
	}
	function n(e) {
		return e.length === 0 ? null : e[0];
	}
	function r(e) {
		if (e.length === 0) return null;
		var t = e[0], n = e.pop();
		if (n !== t) {
			e[0] = n;
			a: for (var r = 0, a = e.length, o = a >>> 1; r < o;) {
				var s = 2 * (r + 1) - 1, c = e[s], l = s + 1, u = e[l];
				if (0 > i(c, n)) l < a && 0 > i(u, c) ? (e[r] = u, e[l] = n, r = l) : (e[r] = c, e[s] = n, r = s);
				else if (l < a && 0 > i(u, n)) e[r] = u, e[l] = n, r = l;
				else break a;
			}
		}
		return t;
	}
	function i(e, t) {
		var n = e.sortIndex - t.sortIndex;
		return n === 0 ? e.id - t.id : n;
	}
	if (e.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
		var a = performance;
		e.unstable_now = function() {
			return a.now();
		};
	} else {
		var o = Date, s = o.now();
		e.unstable_now = function() {
			return o.now() - s;
		};
	}
	var c = [], l = [], u = 1, d = null, f = 3, p = !1, m = !1, h = !1, g = !1, _ = typeof setTimeout == "function" ? setTimeout : null, v = typeof clearTimeout == "function" ? clearTimeout : null, ee = typeof setImmediate < "u" ? setImmediate : null;
	function te(e) {
		for (var i = n(l); i !== null;) {
			if (i.callback === null) r(l);
			else if (i.startTime <= e) r(l), i.sortIndex = i.expirationTime, t(c, i);
			else break;
			i = n(l);
		}
	}
	function ne(e) {
		if (h = !1, te(e), !m) {
			if (n(c) !== null) m = !0, y || (y = !0, ae());
			else {
				var t = n(l);
				t !== null && ce(ne, t.startTime - e);
			}
		}
	}
	var y = !1, re = -1, b = 5, x = -1;
	function S() {
		return g ? !0 : !(e.unstable_now() - x < b);
	}
	function ie() {
		if (g = !1, y) {
			var t = e.unstable_now();
			x = t;
			var i = !0;
			try {
				a: {
					m = !1, h && (h = !1, v(re), re = -1), p = !0;
					var a = f;
					try {
						b: {
							for (te(t), d = n(c); d !== null && !(d.expirationTime > t && S());) {
								var o = d.callback;
								if (typeof o == "function") {
									d.callback = null, f = d.priorityLevel;
									var s = o(d.expirationTime <= t);
									if (t = e.unstable_now(), typeof s == "function") {
										d.callback = s, te(t), i = !0;
										break b;
									}
									d === n(c) && r(c), te(t);
								} else r(c);
								d = n(c);
							}
							if (d !== null) i = !0;
							else {
								var u = n(l);
								u !== null && ce(ne, u.startTime - t), i = !1;
							}
						}
						break a;
					} finally {
						d = null, f = a, p = !1;
					}
					i = void 0;
				}
			} finally {
				i ? ae() : y = !1;
			}
		}
	}
	var ae;
	if (typeof ee == "function") ae = function() {
		ee(ie);
	};
	else if (typeof MessageChannel < "u") {
		var oe = new MessageChannel(), se = oe.port2;
		oe.port1.onmessage = ie, ae = function() {
			se.postMessage(null);
		};
	} else ae = function() {
		_(ie, 0);
	};
	function ce(t, n) {
		re = _(function() {
			t(e.unstable_now());
		}, n);
	}
	e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(e) {
		e.callback = null;
	}, e.unstable_forceFrameRate = function(e) {
		0 > e || 125 < e ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : b = 0 < e ? Math.floor(1e3 / e) : 5;
	}, e.unstable_getCurrentPriorityLevel = function() {
		return f;
	}, e.unstable_next = function(e) {
		switch (f) {
			case 1:
			case 2:
			case 3:
				var t = 3;
				break;
			default: t = f;
		}
		var n = f;
		f = t;
		try {
			return e();
		} finally {
			f = n;
		}
	}, e.unstable_requestPaint = function() {
		g = !0;
	}, e.unstable_runWithPriority = function(e, t) {
		switch (e) {
			case 1:
			case 2:
			case 3:
			case 4:
			case 5: break;
			default: e = 3;
		}
		var n = f;
		f = e;
		try {
			return t();
		} finally {
			f = n;
		}
	}, e.unstable_scheduleCallback = function(r, i, a) {
		var o = e.unstable_now();
		switch (typeof a == "object" && a ? (a = a.delay, a = typeof a == "number" && 0 < a ? o + a : o) : a = o, r) {
			case 1:
				var s = -1;
				break;
			case 2:
				s = 250;
				break;
			case 5:
				s = 1073741823;
				break;
			case 4:
				s = 1e4;
				break;
			default: s = 5e3;
		}
		return s = a + s, r = {
			id: u++,
			callback: i,
			priorityLevel: r,
			startTime: a,
			expirationTime: s,
			sortIndex: -1
		}, a > o ? (r.sortIndex = a, t(l, r), n(c) === null && r === n(l) && (h ? (v(re), re = -1) : h = !0, ce(ne, a - o))) : (r.sortIndex = s, t(c, r), m || p || (m = !0, y || (y = !0, ae()))), r;
	}, e.unstable_shouldYield = S, e.unstable_wrapCallback = function(e) {
		var t = f;
		return function() {
			var n = f;
			f = t;
			try {
				return e.apply(this, arguments);
			} finally {
				f = n;
			}
		};
	};
})), ge = /* @__PURE__ */ t((/* @__PURE__ */ n(((e, t) => {
	t.exports = he();
})))());
typeof window < "u" && (window.document?.createElement || window.navigator?.product === "ReactNative") ? S.useLayoutEffect : S.useEffect;
function _e(e, t, n) {
	if (!e) return;
	if (n(e) === !0) return e;
	let r = t ? e.return : e.child;
	for (; r;) {
		let e = _e(r, t, n);
		if (e) return e;
		r = t ? null : r.sibling;
	}
}
function ve(e) {
	try {
		return Object.defineProperties(e, {
			_currentRenderer: {
				get() {
					return null;
				},
				set() {}
			},
			_currentRenderer2: {
				get() {
					return null;
				},
				set() {}
			}
		});
	} catch {
		return e;
	}
}
var ye = /* @__PURE__ */ ve(/* @__PURE__ */ S.createContext(null)), be = class extends S.Component {
	render() {
		return /* @__PURE__ */ S.createElement(ye.Provider, { value: this._reactInternals }, this.props.children);
	}
};
function xe() {
	let e = S.useContext(ye);
	if (e === null) throw Error("its-fine: useFiber must be called within a <FiberProvider />!");
	let t = S.useId();
	return S.useMemo(() => {
		for (let n of [e, e?.alternate]) {
			if (!n) continue;
			let e = _e(n, !1, (e) => {
				let n = e.memoizedState;
				for (; n;) {
					if (n.memoizedState === t) return !0;
					n = n.next;
				}
			});
			if (e) return e;
		}
	}, [e, t]);
}
var Se = Symbol.for("react.context"), Ce = (e) => typeof e == "object" && !!e && "$$typeof" in e && e.$$typeof === Se;
function we() {
	let e = xe(), [t] = S.useState(() => /* @__PURE__ */ new Map());
	t.clear();
	let n = e;
	for (; n;) {
		let e = n.type;
		Ce(e) && e !== ye && !t.has(e) && t.set(e, S.use(ve(e))), n = n.return;
	}
	return t;
}
function Te() {
	let e = we();
	return S.useMemo(() => Array.from(e.keys()).reduce((t, n) => (r) => /* @__PURE__ */ S.createElement(t, null, /* @__PURE__ */ S.createElement(n.Provider, {
		...r,
		value: e.get(n)
	})), (e) => /* @__PURE__ */ S.createElement(be, { ...e })), [e]);
}
function Ee(e) {
	if (typeof requestAnimationFrame == "function") {
		let t = requestAnimationFrame(e);
		return () => cancelAnimationFrame(t);
	}
	let t = setTimeout(e, 16);
	return () => clearTimeout(t);
}
function De() {
	if (!S.Activity) throw Error("its-fine: useActivityBridge requires React 19.2 or later!");
	let e = xe(), [t] = S.useState(() => {
		let t = [], n = !1;
		_e(e, !0, (e) => {
			if (e.elementType === S.Activity) {
				let n = e.child?.tag === 22 ? e.child.stateNode : null;
				if (typeof n?._visibility != "number") throw Error("its-fine: unsupported React Activity internals!");
				t.push(n);
			} else e.tag === 22 && e.return?.elementType !== S.Activity && (n = !0);
		});
		let r = "hidden", i = /* @__PURE__ */ new Set(), a, o = {
			mounted: !1,
			connected: !1,
			subscribe(e) {
				return i.add(e), () => {
					i.delete(e);
				};
			},
			sync(e) {
				o.mounted && !o.connected && n && t.length > 0 ? a ||= Ee(() => {
					a = void 0, o.sync(!0);
				}) : (a?.(), a = void 0);
				let s = r;
				if (o.mounted ? o.connected ? s = "visible" : e && (s = t.every((e) => !!(e._visibility & 1)) ? "visible" : "hidden") : s = "hidden", r !== s) {
					r = s;
					for (let e of i) e();
				}
			},
			Bridge({ children: e }) {
				return /* @__PURE__ */ S.createElement(S.Activity, { mode: S.useSyncExternalStore(o.subscribe, () => r, () => "hidden") }, e);
			}
		};
		return o;
	});
	return S.useInsertionEffect(() => (t.mounted = !0, queueMicrotask(() => t.sync(!1)), () => {
		t.mounted = !1, queueMicrotask(() => t.sync(!1));
	}), [t]), S.useLayoutEffect(() => (t.connected = !0, t.sync(!1), () => {
		t.connected = !1, t.sync(!0);
	}), [t]), t.Bridge;
}
//#endregion
//#region node_modules/@react-three/fiber/dist/events-9ce18a08.esm.js
var Oe = /*#__PURE__*/ Object.freeze({ __proto__: null });
function ke(e) {
	let t = e.root;
	for (; t.getState().previousRoot;) t = t.getState().previousRoot;
	return t;
}
var Ae = S.act, je = (e) => e && e.isOrthographicCamera, Me = (e) => e && e.hasOwnProperty("current"), Ne = (e) => e != null && (typeof e == "string" || typeof e == "number" || e.isColor), Pe = /* @__PURE__ */ ((e, t) => typeof window < "u" && ((e = window.document)?.createElement || (t = window.navigator)?.product === "ReactNative"))() ? S.useLayoutEffect : S.useEffect;
function Fe(e) {
	let t = S.useRef(e);
	return Pe(() => void (t.current = e), [e]), t;
}
var Ie = () => {};
function Le({ promise: e, onSettled: t }) {
	return S.use(e), Pe(t, [t]), null;
}
function Re() {
	let [e, t] = S.useState(null), n = S.useCallback(() => t(null), []), r = S.useCallback((e) => t((t) => t ?? Promise.resolve(e).then(Ie, Ie)), []);
	return [e ? /*#__PURE__*/ (0, x.jsx)(S.Suspense, {
		fallback: null,
		children: /*#__PURE__*/ (0, x.jsx)(Le, {
			promise: e,
			onSettled: n
		})
	}) : null, r];
}
var ze = S.Activity ? De : () => S.Fragment;
function w() {
	let e = xe(), t = Te(), n = ze();
	return S.useMemo(() => ({ children: r }) => {
		let i = _e(e, !0, (e) => e.type === S.StrictMode) ? S.StrictMode : S.Fragment;
		return /*#__PURE__*/ (0, x.jsx)(i, { children: /*#__PURE__*/ (0, x.jsx)(n, { children: /*#__PURE__*/ (0, x.jsx)(t, { children: r }) }) });
	}, [
		e,
		t,
		n
	]);
}
function Be({ set: e }) {
	return Pe(() => (e(new Promise(() => null)), () => e(!1)), [e]), null;
}
var Ve = /* @__PURE__ */ ((e) => (e = class extends S.Component {
	constructor(...e) {
		super(...e), this.state = { error: !1 };
	}
	componentDidCatch(e) {
		this.props.set(e);
	}
	render() {
		return this.state.error ? null : this.props.children;
	}
}, e.getDerivedStateFromError = () => ({ error: !0 }), e))();
function He(e) {
	let t = typeof window < "u" ? window.devicePixelRatio ?? 2 : 1;
	return Array.isArray(e) ? Math.min(Math.max(e[0], t), e[1]) : e;
}
function Ue(e) {
	return e.__r3f?.root.getState();
}
var T = {
	obj: (e) => e === Object(e) && !T.arr(e) && typeof e != "function",
	fun: (e) => typeof e == "function",
	str: (e) => typeof e == "string",
	num: (e) => typeof e == "number",
	boo: (e) => typeof e == "boolean",
	und: (e) => e === void 0,
	nul: (e) => e === null,
	arr: (e) => Array.isArray(e),
	equ(e, t, { arrays: n = "shallow", objects: r = "reference", strict: i = !0 } = {}) {
		if (typeof e != typeof t || !!e != !!t) return !1;
		if (T.str(e) || T.num(e) || T.boo(e)) return e === t;
		let a = T.obj(e);
		if (a && r === "reference") return e === t;
		let o = T.arr(e);
		if (o && n === "reference") return e === t;
		if ((o || a) && e === t) return !0;
		let s;
		for (s in e) if (!(s in t)) return !1;
		if (a && n === "shallow" && r === "shallow") {
			for (s in i ? t : e) if (!T.equ(e[s], t[s], {
				strict: i,
				objects: "reference"
			})) return !1;
		} else for (s in i ? t : e) if (e[s] !== t[s]) return !1;
		if (T.und(s)) {
			if (o && e.length === 0 && t.length === 0 || a && Object.keys(e).length === 0 && Object.keys(t).length === 0) return !0;
			if (e !== t) return !1;
		}
		return !0;
	}
};
function We(e) {
	let t = {
		nodes: {},
		materials: {},
		meshes: {}
	};
	return e && e.traverse((e) => {
		e.name && (t.nodes[e.name] = e), e.material && !t.materials[e.material.name] && (t.materials[e.material.name] = e.material), e.isMesh && !t.meshes[e.name] && (t.meshes[e.name] = e);
	}), t;
}
function Ge(e) {
	e.type !== "Scene" && (e.dispose == null || e.dispose());
	for (let t in e) {
		let n = e[t];
		n?.type !== "Scene" && (n == null || n.dispose == null || n.dispose());
	}
}
var Ke = [
	"children",
	"key",
	"ref"
];
function qe(e) {
	let t = {};
	for (let n in e) Ke.includes(n) || (t[n] = e[n]);
	return t;
}
function Je(e, t, n, r) {
	let i = e, a = i?.__r3f;
	return a || (a = {
		root: t,
		type: n,
		parent: null,
		children: [],
		props: qe(r),
		object: i,
		eventCount: 0,
		handlers: {},
		previousVisible: void 0,
		isHidden: !1
	}, i && (i.__r3f = a)), a;
}
function Ye(e, t) {
	if (!t.includes("-") || t in e) return {
		root: e,
		key: t,
		target: e[t]
	};
	let n = e, r = t.split("-");
	for (let i of r) {
		if (typeof n != "object" || !n) {
			if (n !== void 0) {
				let e = r.slice(r.indexOf(i)).join("-");
				return {
					root: n,
					key: e,
					target: void 0
				};
			}
			return {
				root: e,
				key: t,
				target: void 0
			};
		}
		t = i, e = n, n = n[t];
	}
	return {
		root: e,
		key: t,
		target: n
	};
}
var Xe = /-\d+$/;
function Ze(e, t) {
	if (T.str(t.props.attach)) {
		if (Xe.test(t.props.attach)) {
			let n = t.props.attach.replace(Xe, ""), { root: r, key: i } = Ye(e.object, n);
			Array.isArray(r[i]) || (r[i] = []);
		}
		let { root: n, key: r } = Ye(e.object, t.props.attach);
		t.previousAttach = n[r], n[r] = t.object;
	} else T.fun(t.props.attach) && (t.previousAttach = t.props.attach(e.object, t.object));
}
function Qe(e, t) {
	if (T.str(t.props.attach)) {
		let { root: n, key: r } = Ye(e.object, t.props.attach), i = t.previousAttach;
		i === void 0 ? delete n[r] : n[r] = i;
	} else t.previousAttach == null || t.previousAttach(e.object, t.object);
	delete t.previousAttach;
}
var $e = [
	...Ke,
	"args",
	"dispose",
	"attach",
	"object",
	"onUpdate",
	"dispose"
], et = /* @__PURE__ */ new Map();
function tt(e) {
	let t = et.get(e.constructor);
	try {
		t || (t = new e.constructor(), et.set(e.constructor, t));
	} catch {}
	return t;
}
function nt(e, t) {
	let n = {};
	for (let r in t) if (!$e.includes(r) && !T.equ(t[r], e.props[r])) {
		n[r] = t[r];
		for (let e in t) e.startsWith(`${r}-`) && (n[e] = t[e]);
	}
	for (let r in e.props) {
		if ($e.includes(r) || t.hasOwnProperty(r)) continue;
		let { root: i, key: a } = Ye(e.object, r);
		if (i.constructor && i.constructor.length === 0) {
			let e = tt(i);
			T.und(e) || (n[r] = e[a]);
		} else n[r] = 0;
	}
	return n;
}
var rt = [
	"map",
	"emissiveMap",
	"sheenColorMap",
	"specularColorMap",
	"envMap"
], it = /^on(Pointer|Click|DoubleClick|ContextMenu|Wheel)/;
function at(e, t) {
	var n;
	let r = e.__r3f, i = r && ke(r).getState(), a = r?.eventCount;
	for (let n in t) {
		let a = t[n];
		if ($e.includes(n)) continue;
		if (r && it.test(n)) {
			typeof a == "function" ? r.handlers[n] = a : delete r.handlers[n], r.eventCount = Object.keys(r.handlers).length;
			continue;
		}
		if (a === void 0) continue;
		if (n === "visible" && r != null && r.isHidden && r.previousVisible !== void 0) {
			r.previousVisible = a;
			continue;
		}
		let { root: s, key: c, target: u } = Ye(e, n);
		if (u === void 0 && (typeof s != "object" || !s)) throw Error(`R3F: Cannot set "${n}". Ensure it is an object before setting "${c}".`);
		if (u instanceof l && a instanceof l) u.mask = a.mask;
		else if (u instanceof p && Ne(a)) u.set(a);
		else if (typeof u == "object" && u && typeof u.set == "function" && typeof u.copy == "function" && a != null && a.constructor && u.constructor === a.constructor) u.copy(a);
		else if (typeof u == "object" && u && typeof u.set == "function" && Array.isArray(a)) typeof u.fromArray == "function" ? u.fromArray(a) : u.set(...a);
		else if (typeof u == "object" && u && typeof u.set == "function" && typeof a == "number") typeof u.setScalar == "function" ? u.setScalar(a) : u.set(a);
		else if (s instanceof te && c === "uniforms" && T.obj(a)) {
			T.obj(s.uniforms) || (s.uniforms = {});
			let e = s.uniforms, t = a;
			for (let n in t) {
				let r = t[n], i = e[n];
				i ? Object.assign(i, r) : e[n] = { ...r };
			}
		} else {
			var o;
			s[c] = a, i && !i.linear && rt.includes(c) && (o = s[c]) != null && o.isTexture && s[c].format === 1023 && s[c].type === 1009 && (s[c].colorSpace = g);
		}
	}
	if (r != null && r.parent && i != null && i.internal && (n = r.object) != null && n.isObject3D && a !== r.eventCount) {
		let e = r.object, t = i.internal.interaction.indexOf(e);
		t > -1 && i.internal.interaction.splice(t, 1), r.eventCount && e.raycast !== null && i.internal.interaction.push(e);
	}
	return r && r.props.attach === void 0 && (r.object.isBufferGeometry ? r.props.attach = "geometry" : r.object.isMaterial && (r.props.attach = "material")), r && ot(r), e;
}
function ot(e) {
	var t;
	if (!e.parent) return;
	e.props.onUpdate == null || e.props.onUpdate(e.object);
	let n = (t = e.root) == null || t.getState == null ? void 0 : t.getState();
	n && n.internal.frames === 0 && n.invalidate();
}
function st(e, t) {
	e.manual || (je(e) ? (e.left = t.width / -2, e.right = t.width / 2, e.top = t.height / 2, e.bottom = t.height / -2) : e.aspect = t.width / t.height, e.updateProjectionMatrix());
}
var ct = (e) => e?.isObject3D;
function lt(e) {
	return (e.eventObject || e.object).uuid + "/" + e.index + e.instanceId;
}
function ut(e, t, n, r) {
	let i = n.get(t);
	i && (n.delete(t), n.size === 0 && (e.delete(r), i.target.releasePointerCapture(r)));
}
function dt(e, t, n) {
	let { internal: r } = e.getState();
	for (let e = 0; e < r.interaction.length; e++) r.interaction[e] === t && (r.interaction[e] = n);
	for (let e = 0; e < r.initialHits.length; e++) r.initialHits[e] === t && (r.initialHits[e] = n);
	r.hovered.forEach((e, i) => {
		if (e.eventObject === t || e.object === t) {
			r.hovered.delete(i);
			let a = {
				...e,
				eventObject: e.eventObject === t ? n : e.eventObject,
				object: e.object === t ? n : e.object
			};
			r.hovered.set(lt(a), a);
		}
	}), r.capturedMap.forEach((e) => {
		let r = e.get(t);
		r && (e.delete(t), e.set(n, r));
	});
}
function ft(e, t) {
	let { internal: n } = e.getState();
	n.interaction = n.interaction.filter((e) => e !== t), n.initialHits = n.initialHits.filter((e) => e !== t), n.hovered.forEach((e, r) => {
		(e.eventObject === t || e.object === t) && n.hovered.delete(r);
	}), n.capturedMap.forEach((e, r) => {
		ut(n.capturedMap, t, e, r);
	});
}
function pt(e) {
	function t(t) {
		let { internal: n } = e.getState(), r = t.offsetX - n.initialClick[0], i = t.offsetY - n.initialClick[1];
		return Math.round(Math.sqrt(r * r + i * i));
	}
	function n(e) {
		return e.filter((e) => [
			"Move",
			"Over",
			"Enter",
			"Out",
			"Leave"
		].some((t) => e.__r3f?.handlers["onPointer" + t]));
	}
	function r(t, n) {
		let r = e.getState(), i = /* @__PURE__ */ new Set(), a = [], o = n ? n(r.internal.interaction) : r.internal.interaction;
		for (let e = 0; e < o.length; e++) {
			let t = Ue(o[e]);
			t && (t.raycaster.camera = void 0);
		}
		r.previousRoot || r.events.compute == null || r.events.compute(t, r);
		function s(e) {
			let n = Ue(e);
			return !n || !n.events.enabled || n.raycaster.camera === null ? [] : (n.raycaster.camera === void 0 && (n.events.compute == null || n.events.compute(t, n, n.previousRoot?.getState()), n.raycaster.camera === void 0 && (n.raycaster.camera = null)), n.raycaster.camera ? n.raycaster.intersectObject(e, !0) : []);
		}
		let c = o.flatMap(s).sort((e, t) => {
			let n = Ue(e.object), r = Ue(t.object);
			return !n || !r ? e.distance - t.distance : r.events.priority - n.events.priority || e.distance - t.distance;
		}).filter((e) => {
			let t = lt(e);
			return !i.has(t) && (i.add(t), !0);
		});
		r.events.filter && (c = r.events.filter(c, r));
		for (let e of c) {
			let t = e.object;
			for (; t;) {
				var l;
				(l = t.__r3f) != null && l.eventCount && a.push({
					...e,
					eventObject: t
				}), t = t.parent;
			}
		}
		if ("pointerId" in t && r.internal.capturedMap.has(t.pointerId)) for (let e of r.internal.capturedMap.get(t.pointerId).values()) i.has(lt(e.intersection)) || a.push(e.intersection);
		return a;
	}
	function i(e, t, n, r) {
		if (e.length) {
			let i = { stopped: !1 };
			for (let o of e) {
				let s = Ue(o.object);
				if (s || o.object.traverseAncestors((e) => {
					let t = Ue(e);
					if (t) return s = t, !1;
				}), s) {
					let { raycaster: c, pointer: l, camera: u, internal: d } = s, f = new _(l.x, l.y, 0).unproject(u), p = (e) => d.capturedMap.get(e)?.has(o.eventObject) ?? !1, m = (e) => {
						let n = {
							intersection: o,
							target: t.target
						};
						d.capturedMap.has(e) ? d.capturedMap.get(e).set(o.eventObject, n) : d.capturedMap.set(e, /* @__PURE__ */ new Map([[o.eventObject, n]])), t.target.setPointerCapture(e);
					}, h = (e) => {
						let t = d.capturedMap.get(e);
						t && ut(d.capturedMap, o.eventObject, t, e);
					}, g = {};
					for (let e in t) {
						let n = t[e];
						typeof n != "function" && (g[e] = n);
					}
					let v = {
						...o,
						...g,
						pointer: l,
						intersections: e,
						stopped: i.stopped,
						delta: n,
						unprojectedPoint: f,
						ray: c.ray,
						camera: u,
						stopPropagation() {
							let n = "pointerId" in t && d.capturedMap.get(t.pointerId);
							(!n || n.has(o.eventObject)) && (v.stopped = i.stopped = !0, d.hovered.size && Array.from(d.hovered.values()).find((e) => e.eventObject === o.eventObject) && a([...e.slice(0, e.indexOf(o)), o]));
						},
						target: {
							hasPointerCapture: p,
							setPointerCapture: m,
							releasePointerCapture: h
						},
						currentTarget: {
							hasPointerCapture: p,
							setPointerCapture: m,
							releasePointerCapture: h
						},
						nativeEvent: t
					};
					if (r(v), i.stopped === !0) break;
				}
			}
		}
		return e;
	}
	function a(t) {
		let { internal: n } = e.getState();
		for (let e of n.hovered.values()) if (!t.length || !t.find((t) => t.object === e.object && t.index === e.index && t.instanceId === e.instanceId)) {
			let r = e.eventObject.__r3f;
			if (n.hovered.delete(lt(e)), r != null && r.eventCount) {
				let n = r.handlers, i = {
					...e,
					intersections: t
				};
				n.onPointerOut == null || n.onPointerOut(i), n.onPointerLeave == null || n.onPointerLeave(i);
			}
		}
	}
	function o(e, t) {
		for (let n = 0; n < t.length; n++) {
			let r = t[n].__r3f;
			r == null || r.handlers.onPointerMissed == null || r.handlers.onPointerMissed(e);
		}
	}
	function s(s) {
		switch (s) {
			case "onPointerLeave":
			case "onPointerCancel": return () => a([]);
			case "onLostPointerCapture": return (t) => {
				let { internal: n } = e.getState();
				"pointerId" in t && n.capturedMap.has(t.pointerId) && requestAnimationFrame(() => {
					n.capturedMap.has(t.pointerId) && (n.capturedMap.delete(t.pointerId), a([]));
				});
			};
		}
		return function(c) {
			let { onPointerMissed: l, internal: u } = e.getState();
			u.lastEvent.current = c;
			let d = s === "onPointerMove", f = s === "onClick" || s === "onContextMenu" || s === "onDoubleClick", p = r(c, d ? n : void 0), m = f ? t(c) : 0;
			s === "onPointerDown" && (u.initialClick = [c.offsetX, c.offsetY], u.initialHits = p.map((e) => e.eventObject)), f && !p.length && m <= 2 && (o(c, u.interaction), l && l(c)), d && a(p);
			function h(e) {
				let t = e.eventObject, n = t.__r3f;
				if (!(n != null && n.eventCount)) return;
				let r = n.handlers;
				if (d) {
					if (r.onPointerOver || r.onPointerEnter || r.onPointerOut || r.onPointerLeave) {
						let t = lt(e), n = u.hovered.get(t);
						n ? n.stopped && e.stopPropagation() : (u.hovered.set(t, e), r.onPointerOver == null || r.onPointerOver(e), r.onPointerEnter == null || r.onPointerEnter(e));
					}
					r.onPointerMove == null || r.onPointerMove(e);
				} else {
					let n = r[s];
					n ? (!f || u.initialHits.includes(t)) && (o(c, u.interaction.filter((e) => !u.initialHits.includes(e))), n(e)) : f && u.initialHits.includes(t) && o(c, u.interaction.filter((e) => !u.initialHits.includes(e)));
				}
			}
			i(p, c, m, h);
		};
	}
	return { handlePointer: s };
}
var mt = (e) => !!(e != null && e.render), ht = /* @__PURE__ */ S.createContext(null), gt = (e, t) => {
	let n = ce((n, r) => {
		let i = new _(), a = new _(), o = new _();
		function s(e = r().camera, t = a, n = r().size) {
			let { width: s, height: c, top: l, left: u } = n, d = s / c;
			t.isVector3 ? o.copy(t) : o.set(...t);
			let f = e.getWorldPosition(i).distanceTo(o);
			if (je(e)) return {
				width: s / e.zoom,
				height: c / e.zoom,
				top: l,
				left: u,
				factor: 1,
				distance: f,
				aspect: d
			};
			{
				let t = e.fov * Math.PI / 180, n = 2 * Math.tan(t / 2) * f, r = s / c * n;
				return {
					width: r,
					height: n,
					top: l,
					left: u,
					factor: s / r,
					distance: f,
					aspect: d
				};
			}
		}
		let c, l = (e) => n((t) => ({ performance: {
			...t.performance,
			current: e
		} })), u = new h();
		return {
			set: n,
			get: r,
			gl: null,
			camera: null,
			raycaster: null,
			events: {
				priority: 1,
				enabled: !0,
				connected: !1
			},
			scene: null,
			xr: null,
			invalidate: (t = 1) => e(r(), t),
			advance: (e, n) => t(e, n, r()),
			legacy: !1,
			linear: !1,
			flat: !1,
			controls: null,
			clock: new f(),
			pointer: u,
			mouse: u,
			frameloop: "always",
			onPointerMissed: void 0,
			performance: {
				current: 1,
				min: .5,
				max: 1,
				debounce: 200,
				regress: () => {
					let e = r();
					c && clearTimeout(c), e.performance.current !== e.performance.min && l(e.performance.min), c = setTimeout(() => l(r().performance.max), e.performance.debounce);
				}
			},
			size: {
				width: 0,
				height: 0,
				top: 0,
				left: 0
			},
			viewport: {
				initialDpr: 0,
				dpr: 0,
				width: 0,
				height: 0,
				top: 0,
				left: 0,
				aspect: 0,
				distance: 0,
				factor: 0,
				getCurrentViewport: s
			},
			setEvents: (e) => n((t) => ({
				...t,
				events: {
					...t.events,
					...e
				}
			})),
			setSize: (e, t, i = 0, o = 0) => {
				let c = r().camera, l = {
					width: e,
					height: t,
					top: i,
					left: o
				};
				n((e) => ({
					size: l,
					viewport: {
						...e.viewport,
						...s(c, a, l)
					}
				}));
			},
			setDpr: (e) => n((t) => {
				let n = He(e);
				return { viewport: {
					...t.viewport,
					dpr: n,
					initialDpr: t.viewport.initialDpr || n
				} };
			}),
			setFrameloop: (e = "always") => {
				let t = r().clock;
				t.stop(), t.elapsedTime = 0, e !== "never" && (t.start(), t.elapsedTime = 0), n(() => ({ frameloop: e }));
			},
			previousRoot: void 0,
			internal: {
				interaction: [],
				hovered: /* @__PURE__ */ new Map(),
				subscribers: [],
				initialClick: [0, 0],
				initialHits: [],
				capturedMap: /* @__PURE__ */ new Map(),
				lastEvent: /*#__PURE__*/ S.createRef(),
				active: !1,
				frames: 0,
				priority: 0,
				subscribe: (e, t, n) => {
					let i = r().internal;
					return i.priority += +(t > 0), i.subscribers.push({
						ref: e,
						priority: t,
						store: n
					}), i.subscribers = i.subscribers.sort((e, t) => e.priority - t.priority), () => {
						let n = r().internal;
						n != null && n.subscribers && (n.priority -= +(t > 0), n.subscribers = n.subscribers.filter((t) => t.ref !== e));
					};
				}
			}
		};
	}), r = n.getState(), i = r.size, a = r.viewport.dpr, o = r.camera;
	return n.subscribe(() => {
		let { camera: e, size: t, viewport: r, gl: s, set: c } = n.getState();
		if (t.width !== i.width || t.height !== i.height || r.dpr !== a) {
			i = t, a = r.dpr, st(e, t), r.dpr > 0 && s.setPixelRatio(r.dpr);
			let n = typeof HTMLCanvasElement < "u" && s.domElement instanceof HTMLCanvasElement;
			s.setSize(t.width, t.height, n);
		}
		e !== o && (o = e, c((t) => ({ viewport: {
			...t.viewport,
			...t.viewport.getCurrentViewport(e)
		} })));
	}), n.subscribe((t) => e(t)), n;
};
function _t(e) {
	let t = S.useRef(null);
	return S.useImperativeHandle(t, () => e.current.__r3f, [e]), t;
}
function vt() {
	let e = S.useContext(ht);
	if (!e) throw Error("R3F: Hooks can only be used within the Canvas component!");
	return e;
}
function yt(e = (e) => e, t) {
	return vt()(e, t);
}
function bt(e, t = 0) {
	let n = vt(), r = n.getState().internal.subscribe, i = Fe(e);
	return Pe(() => r(i, t, n), [
		t,
		r,
		n
	]), null;
}
function xt(e) {
	return S.useMemo(() => We(e), [e]);
}
var St = /* @__PURE__ */ new WeakMap(), Ct = (e) => typeof e == "function" && e?.prototype?.constructor === e;
function wt(e, t) {
	return function(n, ...r) {
		let i;
		return Ct(n) ? (i = St.get(n), i || (i = new n(), St.set(n, i))) : i = n, e && e(i), Promise.all(r.map((e) => new Promise((n, r) => i.load(e, (e) => {
			ct(e?.scene) && Object.assign(e, We(e.scene)), n(e);
		}, t, (t) => r(/* @__PURE__ */ Error(`Could not load ${e}: ${t?.message}`))))));
	};
}
function Tt(e, t, n, r) {
	let i = Array.isArray(t) ? t : [t], a = fe(wt(n, r), [e, ...i], { equal: T.equ });
	return Array.isArray(t) ? a : a[0];
}
Tt.preload = function(e, t, n) {
	let r = Array.isArray(t) ? t : [t];
	return pe(wt(n), [e, ...r]);
}, Tt.clear = function(e, t) {
	return me([e, ...Array.isArray(t) ? t : [t]]);
};
var Et = 1, Dt = 8, Ot = 32, kt = 2, At = 268435456, jt = { objects: "shallow" };
function Mt(e, t) {
	let n = {
		canvas: e,
		powerPreference: "high-performance",
		antialias: !0,
		alpha: !0
	};
	return typeof t == "function" ? t(n) : mt(t) ? t : new v({
		...n,
		...t
	});
}
function Nt(e, t) {
	if (!t && typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement && e.parentElement) {
		let { width: t, height: n, top: r, left: i } = e.parentElement.getBoundingClientRect();
		return {
			width: t,
			height: n,
			top: r,
			left: i
		};
	}
	return !t && typeof OffscreenCanvas < "u" && e instanceof OffscreenCanvas ? {
		width: e.width,
		height: e.height,
		top: 0,
		left: 0
	} : {
		width: 0,
		height: 0,
		top: 0,
		left: 0,
		...t
	};
}
function Pt({ store: e, configuration: t }, n, r) {
	let { gl: i, scene: a, camera: l, shadows: f = !1, linear: p = !1, flat: m = !1, legacy: h = !1, frameloop: _ = "always", dpr: v = [1, 2], performance: te, onPointerMissed: ne } = r, y = Nt(n, r.size), re = {
		...r,
		shadows: f,
		linear: p,
		flat: m,
		legacy: h,
		frameloop: _,
		size: y
	}, b = e.getState(), x = b.gl, S = t.previous, ie = (e) => !S || !T.equ(re[e], S[e], jt);
	t.previous = void 0;
	let ae = b.raycaster;
	if (ae || b.set({ raycaster: ae = new d() }), ie("raycaster")) {
		let { params: e, ...t } = r.raycaster ?? {};
		at(ae, {
			...t,
			params: {
				...ae.params,
				...e
			}
		});
	}
	if (!b.camera || b.camera === t.camera && ie("camera")) {
		t.camera = l;
		let e = l?.isCamera, n = e ? l : r.orthographic ? new s(0, 0, 0, 0, .1, 1e3) : new c(75, 0, .1, 1e3);
		e || (n.position.z = 5, l && (at(n, l), n.manual || ("aspect" in l || "left" in l || "right" in l || "bottom" in l || "top" in l) && (n.manual = !0, n.updateProjectionMatrix())), !b.camera && !(l != null && l.rotation) && n.lookAt(0, 0, 0)), b.set({ camera: n }), ae.camera = n;
	}
	if (!b.scene) {
		let t;
		a != null && a.isScene ? (t = a, Je(t, e, "", {})) : (t = new ee(), Je(t, e, "", {}), a && at(t, a)), b.set({ scene: t });
	}
	if (r.events && !b.events.handlers && b.set({ events: r.events(e) }), ie("size") && b.setSize(y.width, y.height, y.top, y.left), b.viewport.dpr !== He(v) && b.setDpr(v), ie("frameloop") && b.setFrameloop(_), ie("onPointerMissed") && b.set({ onPointerMissed: ne }), te && ie("performance") && b.set((e) => ({ performance: {
		...e.performance,
		...te
	} })), !b.xr) {
		let t = (t, n) => {
			let r = e.getState();
			r.frameloop !== "never" && qn(t, !0, r, n);
		}, n = () => {
			let n = e.getState();
			n.gl.xr.enabled = n.gl.xr.isPresenting, n.gl.xr.setAnimationLoop(n.gl.xr.isPresenting ? t : null), n.gl.xr.isPresenting || Kn(n);
		}, r = {
			connect() {
				let t = e.getState().gl;
				t.xr.addEventListener("sessionstart", n), t.xr.addEventListener("sessionend", n);
			},
			disconnect() {
				let t = e.getState().gl;
				t.xr.removeEventListener("sessionstart", n), t.xr.removeEventListener("sessionend", n);
			}
		};
		typeof x.xr?.addEventListener == "function" && r.connect(), b.set({ xr: r });
	}
	if (x.shadowMap && ie("shadows")) {
		let e = x.shadowMap.enabled, t = x.shadowMap.type;
		if (x.shadowMap.enabled = !!f, T.boo(f)) x.shadowMap.type = 2;
		else if (T.str(f)) {
			let e = {
				basic: 0,
				percentage: 1,
				soft: 2,
				variance: 3
			};
			x.shadowMap.type = e[f] ?? 2;
		} else T.obj(f) && Object.assign(x.shadowMap, f);
		(e !== x.shadowMap.enabled || t !== x.shadowMap.type) && (x.shadowMap.needsUpdate = !0);
	}
	let oe = i && !T.fun(i) && !mt(i) ? i : void 0;
	ie("legacy") && (o.enabled = !h, b.set({ legacy: h })), ie("linear") && (oe?.outputColorSpace === void 0 && (x.outputColorSpace = p ? u : g), b.set({ linear: p })), ie("flat") && (oe?.toneMapping === void 0 && (x.toneMapping = m ? 0 : 4), b.set({ flat: m })), oe && ie("gl") && at(x, oe), t.previous = re;
}
var Ft = (e) => typeof e?.then == "function", It = (e) => Object.assign(Promise.resolve(e), {
	status: "fulfilled",
	value: e
}), Lt = (e) => {
	let t = Promise.reject(e);
	return t.catch(() => {}), Object.assign(t, {
		status: "rejected",
		reason: e
	});
}, Rt = () => {
	let e, t, n = new Promise((r, i) => {
		e = (e) => {
			Object.assign(n, {
				status: "fulfilled",
				value: e
			}), r(e);
		}, t = (e) => {
			Object.assign(n, {
				status: "rejected",
				reason: e
			}), i(e);
		};
	});
	return n.status = "pending", n.catch(() => {}), {
		promise: n,
		resolve: e,
		reject: t
	};
}, zt = {
	name: "@react-three/fiber",
	version: "9.8.1",
	description: "A React renderer for Threejs",
	keywords: [
		"react",
		"renderer",
		"fiber",
		"three",
		"threejs"
	],
	author: "Paul Henschel (https://github.com/drcmda)",
	license: "MIT",
	maintainers: [
		"Josh Ellis (https://github.com/joshuaellis)",
		"Cody Bennett (https://github.com/codyjasonbennett)",
		"Kris Baumgarter (https://github.com/krispya)"
	],
	bugs: { url: "https://github.com/pmndrs/react-three-fiber/issues" },
	homepage: "https://github.com/pmndrs/react-three-fiber#readme",
	repository: {
		type: "git",
		url: "git+https://github.com/pmndrs/react-three-fiber.git"
	},
	collective: {
		type: "opencollective",
		url: "https://opencollective.com/react-three-fiber"
	},
	main: "dist/react-three-fiber.cjs.js",
	module: "dist/react-three-fiber.esm.js",
	types: "dist/react-three-fiber.cjs.d.ts",
	"react-native": "native/dist/react-three-fiber-native.cjs.js",
	sideEffects: !1,
	preconstruct: { entrypoints: ["index.tsx", "native.tsx"] },
	scripts: { prebuild: "cp ../../readme.md readme.md" },
	devDependencies: {
		"@types/react-reconciler": "^0.33.0",
		"react-reconciler": "^0.34.0"
	},
	dependencies: {
		"@babel/runtime": "^7.17.8",
		"@types/webxr": "*",
		"base64-js": "^1.5.1",
		buffer: "^6.0.3",
		"its-fine": "^2.1.1",
		"react-use-measure": "^2.1.7",
		scheduler: "^0.28.0",
		"suspend-react": "^0.1.3",
		"use-sync-external-store": "^1.4.0",
		zustand: "^5.0.3"
	},
	peerDependencies: {
		expo: ">=43.0",
		"expo-asset": ">=8.4",
		"expo-file-system": ">=11.0",
		"expo-gl": ">=11.0",
		react: ">=19 <19.4",
		"react-dom": ">=19 <19.4",
		"react-native": ">=0.78",
		three: ">=0.156"
	},
	peerDependenciesMeta: {
		"react-dom": { optional: !0 },
		"react-native": { optional: !0 },
		expo: { optional: !0 },
		"expo-asset": { optional: !0 },
		"expo-file-system": { optional: !0 },
		"expo-gl": { optional: !0 }
	}
};
function Bt(e) {
	return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Vt = { exports: {} }, Ht = { exports: {} };
Ht.exports;
var Ut;
function E() {
	return Ut || (Ut = 1, function(e) {
		e.exports = function(e) {
			function t(e, t, n, r) {
				return new go(e, t, n, r);
			}
			function n() {}
			function r(e) {
				var t = "https://react.dev/errors/" + e;
				if (1 < arguments.length) {
					t += "?args[]=" + encodeURIComponent(arguments[1]);
					for (var n = 2; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
				}
				return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
			}
			function i(e) {
				for (var t = e, n = t; n && !n.alternate;) t = n, t.flags & 4098 && (e = t.return), n = t.return;
				for (; t.return;) t = t.return;
				return t.tag === 3 ? e : null;
			}
			function a(e) {
				if (i(e) !== e) throw Error(r(188));
			}
			function o(e) {
				var t = e.alternate;
				if (!t) {
					if (t = i(e), t === null) throw Error(r(188));
					return t === e ? e : null;
				}
				for (var n = e, o = t;;) {
					var s = n.return;
					if (s === null) break;
					var c = s.alternate;
					if (c === null) {
						if (o = s.return, o !== null) {
							n = o;
							continue;
						}
						break;
					}
					if (s.child === c.child) {
						for (c = s.child; c;) {
							if (c === n) return a(s), e;
							if (c === o) return a(s), t;
							c = c.sibling;
						}
						throw Error(r(188));
					}
					if (n.return !== o.return) n = s, o = c;
					else {
						for (var l = !1, u = s.child; u;) {
							if (u === n) {
								l = !0, n = s, o = c;
								break;
							}
							if (u === o) {
								l = !0, o = s, n = c;
								break;
							}
							u = u.sibling;
						}
						if (!l) {
							for (u = c.child; u;) {
								if (u === n) {
									l = !0, n = c, o = s;
									break;
								}
								if (u === o) {
									l = !0, o = c, n = s;
									break;
								}
								u = u.sibling;
							}
							if (!l) throw Error(r(189));
						}
					}
					if (n.alternate !== o) throw Error(r(190));
				}
				if (n.tag !== 3) throw Error(r(188));
				return n.stateNode.current === n ? e : t;
			}
			function s(e) {
				var t = e.tag;
				if (t === 5 || t === 26 || t === 27 || t === 6) return e;
				for (e = e.child; e !== null;) {
					if (t = s(e), t !== null) return t;
					e = e.sibling;
				}
				return null;
			}
			function c(e) {
				var t = e.tag;
				if (t === 5 || t === 26 || t === 27 || t === 6) return e;
				for (e = e.child; e !== null;) {
					if (e.tag !== 4 && (t = c(e), t !== null)) return t;
					e = e.sibling;
				}
				return null;
			}
			function l(e) {
				return typeof e != "object" || !e ? null : (e = $o && e[$o] || e["@@iterator"], typeof e == "function" ? e : null);
			}
			function u(e) {
				if (e == null) return null;
				if (typeof e == "function") return e.$$typeof === ts ? null : e.displayName || e.name || null;
				if (typeof e == "string") return e;
				switch (e) {
					case Ro: return "Fragment";
					case Bo: return "Profiler";
					case zo: return "StrictMode";
					case Wo: return "Suspense";
					case Go: return "SuspenseList";
					case Jo: return "Activity";
					case Zo: return "ViewTransition";
				}
				if (typeof e == "object") switch (e.$$typeof) {
					case Lo: return "Portal";
					case Ho: return e.displayName || "Context";
					case Vo: return (e._context.displayName || "Context") + ".Consumer";
					case Uo:
						var t = e.render;
						return e = e.displayName, e ||= (e = t.displayName || t.name || "", e === "" ? "ForwardRef" : "ForwardRef(" + e + ")"), e;
					case Ko: return t = e.displayName || null, t === null ? u(e.type) || "Memo" : t;
					case qo:
						t = e._payload, e = e._init;
						try {
							return u(e(t));
						} catch {}
				}
				return null;
			}
			function d(e) {
				return { current: e };
			}
			function f(e) {
				0 > Rl || (e.current = Ll[Rl], Ll[Rl] = null, Rl--);
			}
			function p(e, t) {
				Rl++, Ll[Rl] = e.current, e.current = t;
			}
			function m(e) {
				return e >>>= 0, e === 0 ? 32 : 31 - (Vl(e) / Hl | 0) | 0;
			}
			function h(e) {
				var t = e & 42;
				if (t !== 0) return t;
				switch (e & -e) {
					case 1: return 1;
					case 2: return 2;
					case 4: return 4;
					case 8: return 8;
					case 16: return 16;
					case 32: return 32;
					case 64: return 64;
					case 128: return 128;
					case 256:
					case 512:
					case 1024:
					case 2048:
					case 4096:
					case 8192:
					case 16384:
					case 32768:
					case 65536:
					case 131072: return e & -e;
					case 262144:
					case 524288:
					case 1048576:
					case 2097152: return e & 3932160;
					case 4194304:
					case 8388608:
					case 16777216:
					case 33554432: return e & 62914560;
					case 67108864: return 67108864;
					case 134217728: return 134217728;
					case 268435456: return 268435456;
					case 536870912: return 536870912;
					case 1073741824: return 0;
					default: return e;
				}
			}
			function g(e, t, n) {
				var r = e.pendingLanes;
				if (r === 0) return 0;
				var i = 0, a = e.suspendedLanes, o = e.pingedLanes;
				e = e.warmLanes;
				var s = r & 134217727;
				return s === 0 ? (s = r & ~a, s === 0 ? o === 0 ? n || (n = r & ~e, n !== 0 && (i = h(n))) : i = h(o) : i = h(s)) : (r = s & ~a, r === 0 ? (o &= s, o === 0 ? n || (n = s & ~e, n !== 0 && (i = h(n))) : i = h(o)) : i = h(r)), i === 0 ? 0 : t !== 0 && t !== i && (t & a) === 0 && (a = i & -i, n = t & -t, a >= n || a === 32 && n & 4194048) ? t : i;
			}
			function _(e, t) {
				return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0;
			}
			function v(e, t) {
				t & 8 && (t |= t & 32);
				var n = e.entangledLanes;
				if (n !== 0) for (e = e.entanglements, n &= t; 0 < n;) {
					var r = 31 - Bl(n), i = 1 << r;
					t |= e[r], n &= ~i;
				}
				return t;
			}
			function ee(e, t) {
				switch (e) {
					case 1:
					case 2:
					case 4:
					case 8:
					case 64: return t + 250;
					case 16:
					case 32:
					case 128:
					case 256:
					case 512:
					case 1024:
					case 2048:
					case 4096:
					case 8192:
					case 16384:
					case 32768:
					case 65536:
					case 131072:
					case 262144:
					case 524288:
					case 1048576:
					case 2097152: return t + 5e3;
					case 4194304:
					case 8388608:
					case 16777216:
					case 33554432: return -1;
					case 67108864:
					case 134217728:
					case 268435456:
					case 536870912:
					case 1073741824: return -1;
					default: return -1;
				}
			}
			function te() {
				var e = Gl;
				return Gl <<= 1, !(Gl & 62914560) && (Gl = 4194304), e;
			}
			function ne(e) {
				for (var t = [], n = 0; 31 > n; n++) t.push(e);
				return t;
			}
			function y(e, t) {
				e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0);
			}
			function re(e, t, n, r, i, a) {
				var o = e.pendingLanes;
				e.pendingLanes = n, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= n, e.entangledLanes &= n, e.errorRecoveryDisabledLanes &= n, e.shellSuspendCounter = 0;
				var s = e.entanglements, c = e.expirationTimes, l = e.hiddenUpdates;
				for (n = o & ~n; 0 < n;) {
					var u = 31 - Bl(n), d = 1 << u;
					s[u] = 0, c[u] = -1;
					var f = l[u];
					if (f !== null) for (l[u] = null, u = 0; u < f.length; u++) {
						var p = f[u];
						p !== null && (p.lane &= -536870913);
					}
					n &= ~d;
				}
				r !== 0 && b(e, r, 0), a !== 0 && i === 0 && e.tag !== 0 && (e.suspendedLanes |= a & ~(o & ~t));
			}
			function b(e, t, n) {
				e.pendingLanes |= t, e.suspendedLanes &= ~t;
				var r = 31 - Bl(t);
				e.entangledLanes |= t, e.entanglements[r] = e.entanglements[r] | 1073741824 | n & 261930;
			}
			function x(e, t) {
				var n = e.entangledLanes |= t;
				for (e = e.entanglements; n;) {
					var r = 31 - Bl(n), i = 1 << r;
					i & t | e[r] & t && (e[r] |= t), n &= ~i;
				}
			}
			function ie(e, t) {
				var n = t & -t;
				return n = n & 42 ? 1 : ae(n), (n & (e.suspendedLanes | t)) === 0 ? n : 0;
			}
			function ae(e) {
				switch (e) {
					case 2:
						e = 1;
						break;
					case 8:
						e = 4;
						break;
					case 32:
						e = 16;
						break;
					case 256:
					case 512:
					case 1024:
					case 2048:
					case 4096:
					case 8192:
					case 16384:
					case 32768:
					case 65536:
					case 131072:
					case 262144:
					case 524288:
					case 1048576:
					case 2097152:
					case 4194304:
					case 8388608:
					case 16777216:
					case 33554432:
						e = 128;
						break;
					case 268435456:
						e = 134217728;
						break;
					default: e = 0;
				}
				return e;
			}
			function oe(e) {
				return e &= -e, 2 < e ? 8 < e ? e & 134217727 ? 32 : 268435456 : 8 : 2;
			}
			function se(e) {
				if (typeof tu == "function" && nu(e), iu && typeof iu.setStrictMode == "function") try {
					iu.setStrictMode(ru, e);
				} catch {}
			}
			function ce(e, t) {
				if (e.name != null && e.name !== "auto") return e.name;
				if (t.autoName !== null) return t.autoName;
				e = gf.identifierPrefix;
				var n = au++;
				return e = "_" + e + "t_" + n.toString(32) + "_", t.autoName = e;
			}
			function le(e) {
				if (e == null || typeof e == "string") return e;
				var t = null, n = wf;
				if (n !== null) for (var r = 0; r < n.length; r++) {
					var i = e[n[r]];
					if (i != null) {
						if (i === "none") return "none";
						t = t == null ? i : t + (" " + i);
					}
				}
				return t ?? e.default;
			}
			function C(e, t) {
				return e = le(e), t = le(t), t == null ? e === "auto" ? null : e : t === "auto" ? null : t;
			}
			function ue(e, t) {
				return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t;
			}
			function de(e) {
				if (lu === void 0) try {
					throw Error();
				} catch (e) {
					var t = e.stack.trim().match(/\n( *(at )?)/);
					lu = t && t[1] || "", uu = -1 < e.stack.indexOf("\n    at") ? " (<anonymous>)" : -1 < e.stack.indexOf("@") ? "@unknown:0:0" : "";
				}
				return "\n" + lu + e + uu;
			}
			function fe(e, t) {
				if (!e || du) return "";
				du = !0;
				var n = Error.prepareStackTrace;
				Error.prepareStackTrace = void 0;
				try {
					var r = { DetermineComponentFrameRoot: function() {
						try {
							if (t) {
								var n = function() {
									throw Error();
								};
								if (Object.defineProperty(n.prototype, "props", { set: function() {
									throw Error();
								} }), typeof Reflect == "object" && Reflect.construct) {
									try {
										Reflect.construct(n, []);
									} catch (e) {
										var r = e;
									}
									Reflect.construct(e, [], n);
								} else {
									try {
										n.call();
									} catch (e) {
										r = e;
									}
									n = !1;
									try {
										var i = Object.getOwnPropertyDescriptor(e.prototype, "props");
										Object.defineProperty(e.prototype, "props", {
											configurable: !0,
											set: function() {
												throw Error();
											}
										}), n = !0, new e();
									} finally {
										n && (i === void 0 ? delete e.prototype.props : Object.defineProperty(e.prototype, "props", i));
									}
								}
							} else {
								try {
									throw Error();
								} catch (e) {
									r = e;
								}
								(n = e()) && typeof n.catch == "function" && n.catch(function() {});
							}
						} catch (e) {
							if (e && r && typeof e.stack == "string") return [e.stack, r.stack];
						}
						return [null, null];
					} };
					r.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
					var i = Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot, "name");
					i && i.configurable && Object.defineProperty(r.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
					var a = r.DetermineComponentFrameRoot(), o = a[0], s = a[1];
					if (o && s) {
						var c = o.split("\n"), l = s.split("\n");
						for (i = r = 0; r < c.length && !c[r].includes("DetermineComponentFrameRoot");) r++;
						for (; i < l.length && !l[i].includes("DetermineComponentFrameRoot");) i++;
						if (r === c.length || i === l.length) for (r = c.length - 1, i = l.length - 1; 1 <= r && 0 <= i && c[r] !== l[i];) i--;
						for (; 1 <= r && 0 <= i; r--, i--) if (c[r] !== l[i]) {
							if (r !== 1 || i !== 1) do
								if (r--, i--, 0 > i || c[r] !== l[i]) {
									var u = "\n" + c[r].replace(" at new ", " at ");
									return e.displayName && u.includes("<anonymous>") && (u = u.replace("<anonymous>", e.displayName)), u;
								}
							while (1 <= r && 0 <= i);
							break;
						}
					}
				} finally {
					du = !1, Error.prepareStackTrace = n;
				}
				return (n = e ? e.displayName || e.name : "") ? de(n) : "";
			}
			function pe(e, t) {
				switch (e.tag) {
					case 26:
					case 27:
					case 5: return de(e.type);
					case 16: return de("Lazy");
					case 13: return e.child !== t && t !== null ? de("Suspense Fallback") : de("Suspense");
					case 19: return de("SuspenseList");
					case 0:
					case 15: return fe(e.type, !1);
					case 11: return fe(e.type.render, !1);
					case 1: return fe(e.type, !0);
					case 31: return de("Activity");
					case 30: return de("ViewTransition");
					default: return "";
				}
			}
			function me(e) {
				try {
					var t = "", n = null;
					do
						t += pe(e, n), n = e, e = e.return;
					while (e);
					return t;
				} catch (e) {
					return "\nError generating stack: " + e.message + "\n" + e.stack;
				}
			}
			function he(e, t) {
				if (typeof e == "object" && e) {
					var n = fu.get(e);
					return n === void 0 ? (t = {
						value: e,
						source: t,
						stack: me(t)
					}, fu.set(e, t), t) : n;
				}
				return {
					value: e,
					source: t,
					stack: me(t)
				};
			}
			function _e(e, t) {
				pu[mu++] = gu, pu[mu++] = hu, hu = e, gu = t;
			}
			function ve(e, t, n) {
				_u[vu++] = bu, _u[vu++] = xu, _u[vu++] = yu, yu = e;
				var r = bu;
				e = xu;
				var i = 32 - Bl(r) - 1;
				r &= ~(1 << i), n += 1;
				var a = 32 - Bl(t) + i;
				if (30 < a) {
					var o = i - i % 5;
					a = (r & (1 << o) - 1).toString(32), r >>= o, i -= o, bu = 1 << 32 - Bl(t) + i | n << i | r, xu = a + e;
				} else bu = 1 << a | n << i | r, xu = e;
			}
			function ye(e) {
				e.return !== null && (_e(e, 1), ve(e, 1, 0));
			}
			function be(e) {
				for (; e === hu;) hu = pu[--mu], pu[mu] = null, gu = pu[--mu], pu[mu] = null;
				for (; e === yu;) yu = _u[--vu], _u[vu] = null, xu = _u[--vu], _u[vu] = null, bu = _u[--vu], _u[vu] = null;
			}
			function xe(e, t) {
				_u[vu++] = bu, _u[vu++] = xu, _u[vu++] = yu, bu = t.id, xu = t.overflow, yu = e;
			}
			function Se(e, t) {
				p(wu, t), p(Cu, e), p(Su, null), e = ss(t), f(Su), p(Su, e);
			}
			function Ce() {
				f(Su), f(Cu), f(wu);
			}
			function we(e) {
				var t = e.memoizedState;
				t !== null && (t = t.memoizedState, ys ? Rs._currentValue = t : Rs._currentValue2 = t, p(Tu, e)), t = Su.current;
				var n = cs(t, e.type);
				t !== n && (p(Cu, e), p(Su, n));
			}
			function Te(e) {
				Cu.current === e && (f(Su), f(Cu)), Tu.current === e && (f(Tu), ys ? Rs._currentValue = Ls : Rs._currentValue2 = Ls);
			}
			function Ee(e) {
				throw Me(he(Error(r(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML", "")), e)), Ou;
			}
			function De(e, t) {
				if (!xs) throw Error(r(175));
				$c(e.stateNode, e.type, e.memoizedProps, t, e) || Ee(e, !0);
			}
			function Oe(e) {
				for (F = e.return; F;) switch (F.tag) {
					case 5:
					case 31:
					case 13:
						Du = !1;
						return;
					case 27:
					case 3:
						Du = !0;
						return;
					default: F = F.return;
				}
			}
			function ke(e) {
				if (!xs || e !== F) return !1;
				if (!L) return Oe(e), L = !0, !1;
				var t = e.tag;
				if (P ? t !== 3 && t !== 27 && (t !== 5 || hl(e.type) && !ms(e.type, e.memoizedProps)) && I && Ee(e) : t !== 3 && (t !== 5 || hl(e.type) && !ms(e.type, e.memoizedProps)) && I && Ee(e), Oe(e), t === 13) {
					if (!xs) throw Error(r(316));
					if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(r(317));
					I = il(e);
				} else if (t === 31) {
					if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(r(317));
					I = rl(e);
				} else I = P && t === 27 ? Uc(e.type, I) : F ? Hc(e.stateNode) : null;
				return !0;
			}
			function Ae() {
				xs && (I = F = null, L = !1);
			}
			function je() {
				var e = Eu;
				return e !== null && (lf === null ? lf = e : lf.push.apply(lf, e), Eu = null), e;
			}
			function Me(e) {
				Eu === null ? Eu = [e] : Eu.push(e);
			}
			function Ne(e, t, n) {
				ys ? (p(ku, t._currentValue), t._currentValue = n) : (p(ku, t._currentValue2), t._currentValue2 = n);
			}
			function Pe(e) {
				var t = ku.current;
				ys ? e._currentValue = t : e._currentValue2 = t, f(ku);
			}
			function Fe(e, t, n) {
				for (; e !== null;) {
					var r = e.alternate;
					if ((e.childLanes & t) === t ? r !== null && (r.childLanes & t) !== t && (r.childLanes |= t) : (e.childLanes |= t, r !== null && (r.childLanes |= t)), e === n) break;
					e = e.return;
				}
			}
			function Ie(e, t, n, i) {
				var a = e.child;
				for (a !== null && (a.return = e); a !== null;) {
					var o = a.dependencies;
					if (o !== null) {
						var s = a.child;
						o = o.firstContext;
						e: for (; o !== null;) {
							var c = o;
							o = a;
							for (var l = 0; l < t.length; l++) if (c.context === t[l]) {
								o.lanes |= n, c = o.alternate, c !== null && (c.lanes |= n), Fe(o.return, n, e), i || (s = null);
								break e;
							}
							o = c.next;
						}
					} else if (a.tag === 18) {
						if (s = a.return, s === null) throw Error(r(341));
						s.lanes |= n, o = s.alternate, o !== null && (o.lanes |= n), Fe(s, n, e), s = null;
					} else a.tag === 13 && a.memoizedState !== null && a.memoizedState.dehydrated === null ? (a.lanes |= n, s = a.alternate, s !== null && (s.lanes |= n), Fe(a.return, n, e), s = a.child, s = s === null ? null : s.sibling) : s = a.child;
					if (s !== null) s.return = a;
					else for (s = a; s !== null;) {
						if (s === e) {
							s = null;
							break;
						}
						if (a = s.sibling, a !== null) {
							a.return = s.return, s = a;
							break;
						}
						s = s.return;
					}
					a = s;
				}
			}
			function Le(e, t, n, i) {
				e = null;
				for (var a = t, o = !1; a !== null;) {
					if (!o) {
						if (a.flags & 524288) o = !0;
						else if (a.flags & 262144) break;
					}
					if (a.tag === 10) {
						var s = a.alternate;
						if (s === null) throw Error(r(387));
						if (s = s.memoizedProps, s !== null) {
							var c = a.type;
							ou(a.pendingProps.value, s.value) || (e === null ? e = [c] : e.push(c));
						}
					} else if (a === Tu.current) {
						if (s = a.alternate, s === null) throw Error(r(387));
						s.memoizedState.memoizedState !== a.memoizedState.memoizedState && (e === null ? e = [Rs] : e.push(Rs));
					}
					a = a.return;
				}
				return e !== null && Ie(t, e, n, i), t.flags |= 262144, e !== null;
			}
			function Re(e) {
				for (e = e.firstContext; e !== null;) {
					var t = e.context;
					if (!ou(ys ? t._currentValue : t._currentValue2, e.memoizedValue)) return !0;
					e = e.next;
				}
				return !1;
			}
			function ze(e) {
				Au = e, ju = null, e = e.dependencies, e !== null && (e.firstContext = null);
			}
			function w(e) {
				return Ve(Au, e);
			}
			function Be(e, t) {
				return Au === null && ze(e), Ve(e, t);
			}
			function Ve(e, t) {
				var n = ys ? t._currentValue : t._currentValue2;
				if (t = {
					context: t,
					memoizedValue: n,
					next: null
				}, ju === null) {
					if (e === null) throw Error(r(308));
					ju = t, e.dependencies = {
						lanes: 0,
						firstContext: t
					}, e.flags |= 524288;
				} else ju = ju.next = t;
				return n;
			}
			function He() {
				return {
					controller: new Mu(),
					data: /* @__PURE__ */ new Map(),
					refCount: 0
				};
			}
			function Ue(e) {
				e.refCount--, e.refCount === 0 && Nu(Pu, function() {
					e.controller.abort();
				});
			}
			function T(e, t) {
				if (e.pendingLanes & 4194048) {
					var n = e.transitionTypes;
					for (n === null && (n = e.transitionTypes = []), e = 0; e < t.length; e++) {
						var r = t[e];
						n.indexOf(r) === -1 && n.push(r);
					}
				}
			}
			function We(e) {
				var t = e.transitionTypes;
				return e.transitionTypes = null, t;
			}
			function Ge() {}
			function Ke(e) {
				e !== Lu && e.next === null && (Lu === null ? Iu = Lu = e : Lu = Lu.next = e), zu = !0, Ru || (Ru = !0, $e());
			}
			function qe(e, t) {
				if (!Bu && zu) {
					Bu = !0;
					do
						for (var n = !1, r = Iu; r !== null;) {
							if (!t) {
								if (e !== 0) {
									var i = r.pendingLanes;
									if (i === 0) var a = 0;
									else {
										var o = r.suspendedLanes, s = r.pingedLanes;
										a = (1 << 31 - Bl(42 | e) + 1) - 1, a &= i & ~(o & ~s), a = a & 201326741 ? a & 201326741 | 1 : a ? a | 2 : 0;
									}
									a !== 0 && (n = !0, Qe(r, a));
								} else a = X, a = g(r, r === J ? a : 0, r.cancelPendingCommit !== null || r.timeoutHandle !== vs), !(a & 3) || _(r, a) || (n = !0, Qe(r, a));
							}
							r = r.next;
						}
					while (n);
					Bu = !1;
				}
			}
			function Je() {
				Ye();
			}
			function Ye() {
				zu = Ru = !1;
				var e = 0;
				Vu !== 0 && Ds() && (e = Vu);
				for (var t = Xl(), n = null, r = Iu; r !== null;) {
					var i = r.next, a = Xe(r, t);
					a === 0 ? (r.next = null, n === null ? Iu = i : n.next = i, i === null && (Lu = n)) : (n = r, (e !== 0 || a & 3) && (zu = !0)), r = i;
				}
				$ !== 0 && $ !== 5 || qe(e, !1), Vu !== 0 && (Vu = 0);
			}
			function Xe(e, t) {
				for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, a = e.pendingLanes & -62914561; 0 < a;) {
					var o = 31 - Bl(a), s = 1 << o, c = i[o];
					c === -1 ? ((s & n) === 0 || (s & r) !== 0) && (i[o] = ee(s, t)) : c <= t && (e.expiredLanes |= s), a &= ~s;
				}
				if (t = J, n = X, n = g(e, e === t ? n : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== vs), r = e.callbackNode, n === 0 || e === t && (Z === 2 || Z === 9) || e.cancelPendingCommit !== null) return r !== null && r !== null && ql(r), e.callbackNode = null, e.callbackPriority = 0;
				if (!(n & 3) || _(e, n)) {
					if (t = n & -n, t === e.callbackPriority) return t;
					switch (r !== null && ql(r), oe(n)) {
						case 2:
						case 8:
							n = Ql;
							break;
						case 32:
							n = $l;
							break;
						case 268435456:
							n = eu;
							break;
						default: n = $l;
					}
					return r = Ze.bind(null, e), n = Kl(n, r), e.callbackPriority = t, e.callbackNode = n, t;
				}
				return r !== null && r !== null && ql(r), e.callbackPriority = 2, e.callbackNode = null, 2;
			}
			function Ze(e, t) {
				if ($ !== 0 && $ !== 5) return e.callbackNode = null, e.callbackPriority = 0, null;
				var n = e.callbackNode;
				if (oo() && e.callbackNode !== n) return null;
				var r = X;
				return r = g(e, e === J ? r : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== vs), r === 0 ? null : (ja(e, r, t), Xe(e, Xl()), e.callbackNode != null && e.callbackNode === n ? Ze.bind(null, e) : null);
			}
			function Qe(e, t) {
				if (oo()) return null;
				ja(e, t, !0);
			}
			function $e() {
				Bs ? Vs(function() {
					q & 6 ? Kl(Zl, Je) : Ye();
				}) : Kl(Zl, Je);
			}
			function et() {
				if (Vu === 0) {
					var e = Wu;
					e === 0 && (e = Ul, Ul <<= 1, !(Ul & 261888) && (Ul = 256)), Vu = e;
				}
				return Vu;
			}
			function tt(e, t) {
				if (Hu === null) {
					var n = Hu = [];
					Uu = 0, Wu = et(), Gu = {
						status: "pending",
						value: void 0,
						then: function(e) {
							n.push(e);
						}
					};
				}
				return Uu++, t.then(nt, nt), t;
			}
			function nt() {
				if (--Uu === 0 && (Fu = null, Hu !== null)) {
					Gu !== null && (Gu.status = "fulfilled");
					var e = Hu;
					Hu = null, Wu = 0, Gu = null;
					for (var t = 0; t < e.length; t++) (0, e[t])();
				}
			}
			function rt(e, t) {
				var n = [], r = {
					status: "pending",
					value: null,
					reason: null,
					then: function(e) {
						n.push(e);
					}
				};
				return e.then(function() {
					r.status = "fulfilled", r.value = t;
					for (var e = 0; e < n.length; e++) (0, n[e])(t);
				}, function(e) {
					for (r.status = "rejected", r.reason = e, e = 0; e < n.length; e++) (0, n[e])(void 0);
				}), r;
			}
			function it() {
				var e = qu.current;
				return e === null ? J.pooledCache : e;
			}
			function at(e, t) {
				t === null ? p(qu, qu.current) : p(qu, t.pool);
			}
			function ot() {
				var e = it();
				return e === null ? null : {
					parent: ys ? R._currentValue : R._currentValue2,
					pool: e
				};
			}
			function st(e, t) {
				if (ou(e, t)) return !0;
				if (typeof e != "object" || !e || typeof t != "object" || !t) return !1;
				var n = Object.keys(e), r = Object.keys(t);
				if (n.length !== r.length) return !1;
				for (r = 0; r < n.length; r++) {
					var i = n[r];
					if (!cu.call(t, i) || !ou(e[i], t[i])) return !1;
				}
				return !0;
			}
			function ct(e) {
				return e = e.status, e === "fulfilled" || e === "rejected";
			}
			function lt(e, t, n) {
				switch (n = e[n], n === void 0 ? e.push(t) : n !== t && (t.then(Ge, Ge), t = n), t.status) {
					case "fulfilled": return t.value;
					case "rejected": throw e = t.reason, ft(e), e === void 0 && !("reason" in t) ? Error(r(600)) : e;
					default:
						if (typeof t.status == "string") t.then(Ge, Ge);
						else {
							if (e = J, e !== null && 100 < e.shellSuspendCounter) throw Error(r(482));
							e = t, e.status = "pending", e.then(function(e) {
								if (t.status === "pending") {
									var n = t;
									n.status = "fulfilled", n.value = e;
								}
							}, function(e) {
								if (t.status === "pending") {
									var n = t;
									n.status = "rejected", n.reason = e;
								}
							});
						}
						switch (t.status) {
							case "fulfilled": return t.value;
							case "rejected": throw e = t.reason, ft(e), e;
						}
						throw Qu = t, Ju;
				}
			}
			function ut(e) {
				try {
					var t = e._init;
					return t(e._payload);
				} catch (e) {
					throw typeof e == "object" && e && typeof e.then == "function" ? (Qu = e, Ju) : e;
				}
			}
			function dt() {
				if (Qu === null) throw Error(r(459));
				var e = Qu;
				return Qu = null, e;
			}
			function ft(e) {
				if (e === Ju || e === Xu) throw Error(r(483));
			}
			function pt(e) {
				var t = ed;
				return ed += 1, $u === null && ($u = []), lt($u, e, t);
			}
			function mt(e, t) {
				t = t.props.ref, e.ref = t === void 0 ? null : t;
			}
			function ht(e, t) {
				throw t.$$typeof === Fo ? Error(r(525)) : (e = Object.prototype.toString.call(t), Error(r(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e)));
			}
			function gt(e) {
				function n(t, n) {
					if (e) {
						var r = t.deletions;
						r === null ? (t.deletions = [n], t.flags |= 16) : r.push(n);
					}
				}
				function i(t, r) {
					if (!e) return null;
					for (; r !== null;) n(t, r), r = r.sibling;
					return null;
				}
				function a(e) {
					for (var t = /* @__PURE__ */ new Map(); e !== null;) e.key === null ? t.set(e.index, e) : t.set(e.key, e), e = e.sibling;
					return t;
				}
				function o(e, t) {
					return e = vo(e, t), e.index = 0, e.sibling = null, e;
				}
				function s(t, n, r) {
					return t.index = r, e ? (r = t.alternate, r === null ? (t.flags |= 134217730, n) : (r = r.index, r < n ? (t.flags |= 2, n) : r)) : (t.flags |= 1048576, n);
				}
				function c(t) {
					return e && t.alternate === null && (t.flags |= 134217730), t;
				}
				function u(e, t, n, r) {
					return t === null || t.tag !== 6 ? (t = So(n, e.mode, r), t.return = e, t) : (t = o(t, n), t.return = e, t);
				}
				function d(e, t, n, r) {
					var i = n.type;
					return i === Ro ? (e = p(e, t, n.props.children, r, n.key), mt(e, n), e) : t !== null && (t.elementType === i || typeof i == "object" && i && i.$$typeof === qo && ut(i) === t.type) ? (t = o(t, n.props), mt(t, n), t.return = e, t) : (t = bo(n.type, n.key, n.props, null, e.mode, r), mt(t, n), t.return = e, t);
				}
				function f(e, t, n, r) {
					return t === null || t.tag !== 4 || t.stateNode.containerInfo !== n.containerInfo || t.stateNode.implementation !== n.implementation ? (t = wo(n, e.mode, r), t.return = e, t) : (t = o(t, n.children || []), t.return = e, t);
				}
				function p(e, t, n, r, i) {
					return t === null || t.tag !== 7 ? (t = xo(n, e.mode, r, i), t.return = e, t) : (t = o(t, n), t.return = e, t);
				}
				function m(e, t, n) {
					if (typeof t == "string" && t !== "" || typeof t == "number" || typeof t == "bigint") return t = So("" + t, e.mode, n), t.return = e, t;
					if (typeof t == "object" && t) {
						switch (t.$$typeof) {
							case Io: return n = bo(t.type, t.key, t.props, null, e.mode, n), mt(n, t), n.return = e, n;
							case Lo: return t = wo(t, e.mode, n), t.return = e, t;
							case qo: return t = ut(t), m(e, t, n);
						}
						if (ns(t) || l(t)) return t = xo(t, e.mode, n, null), t.return = e, t;
						if (typeof t.then == "function") return m(e, pt(t), n);
						if (t.$$typeof === Ho) return m(e, Be(e, t), n);
						ht(e, t);
					}
					return null;
				}
				function h(e, t, n, r) {
					var i = t === null ? null : t.key;
					if (typeof n == "string" && n !== "" || typeof n == "number" || typeof n == "bigint") return i === null ? u(e, t, "" + n, r) : null;
					if (typeof n == "object" && n) {
						switch (n.$$typeof) {
							case Io: return n.key === i ? d(e, t, n, r) : null;
							case Lo: return n.key === i ? f(e, t, n, r) : null;
							case qo: return n = ut(n), h(e, t, n, r);
						}
						if (ns(n) || l(n)) return i === null ? p(e, t, n, r, null) : null;
						if (typeof n.then == "function") return h(e, t, pt(n), r);
						if (n.$$typeof === Ho) return h(e, t, Be(e, n), r);
						ht(e, n);
					}
					return null;
				}
				function g(e, t, n, r, i) {
					if (typeof r == "string" && r !== "" || typeof r == "number" || typeof r == "bigint") return e = e.get(n) || null, u(t, e, "" + r, i);
					if (typeof r == "object" && r) {
						switch (r.$$typeof) {
							case Io: return e = e.get(r.key === null ? n : r.key) || null, d(t, e, r, i);
							case Lo: return e = e.get(r.key === null ? n : r.key) || null, f(t, e, r, i);
							case qo: return r = ut(r), g(e, t, n, r, i);
						}
						if (ns(r) || l(r)) return e = e.get(n) || null, p(t, e, r, i, null);
						if (typeof r.then == "function") return g(e, t, n, pt(r), i);
						if (r.$$typeof === Ho) return g(e, t, n, Be(t, r), i);
						ht(t, r);
					}
					return null;
				}
				function _(t, r, o, c) {
					for (var l = null, u = null, d = r, f = r = 0, p = null; d !== null && f < o.length; f++) {
						d.index > f ? (p = d, d = null) : p = d.sibling;
						var _ = h(t, d, o[f], c);
						if (_ === null) {
							d === null && (d = p);
							break;
						}
						e && d && _.alternate === null && n(t, d), r = s(_, r, f), u === null ? l = _ : u.sibling = _, u = _, d = p;
					}
					if (f === o.length) return i(t, d), L && _e(t, f), l;
					if (d === null) {
						for (; f < o.length; f++) d = m(t, o[f], c), d !== null && (r = s(d, r, f), u === null ? l = d : u.sibling = d, u = d);
						return L && _e(t, f), l;
					}
					for (d = a(d); f < o.length; f++) p = g(d, t, f, o[f], c), p !== null && (e && (_ = p.alternate, _ !== null && d.delete(_.key === null ? f : _.key)), r = s(p, r, f), u === null ? l = p : u.sibling = p, u = p);
					return e && d.forEach(function(e) {
						return n(t, e);
					}), L && _e(t, f), l;
				}
				function v(t, o, c, l) {
					if (c == null) throw Error(r(151));
					for (var u = null, d = null, f = o, p = o = 0, _ = null, v = c.next(); f !== null && !v.done; p++, v = c.next()) {
						f.index > p ? (_ = f, f = null) : _ = f.sibling;
						var ee = h(t, f, v.value, l);
						if (ee === null) {
							f === null && (f = _);
							break;
						}
						e && f && ee.alternate === null && n(t, f), o = s(ee, o, p), d === null ? u = ee : d.sibling = ee, d = ee, f = _;
					}
					if (v.done) return i(t, f), L && _e(t, p), u;
					if (f === null) {
						for (; !v.done; p++, v = c.next()) v = m(t, v.value, l), v !== null && (o = s(v, o, p), d === null ? u = v : d.sibling = v, d = v);
						return L && _e(t, p), u;
					}
					for (f = a(f); !v.done; p++, v = c.next()) v = g(f, t, p, v.value, l), v !== null && (e && (_ = v.alternate, _ !== null && f.delete(_.key === null ? p : _.key)), o = s(v, o, p), d === null ? u = v : d.sibling = v, d = v);
					return e && f.forEach(function(e) {
						return n(t, e);
					}), L && _e(t, p), u;
				}
				function ee(e, t, a, s) {
					if (typeof a == "object" && a && a.type === Ro && a.key === null && a.props.ref === void 0 && (a = a.props.children), typeof a == "object" && a) {
						switch (a.$$typeof) {
							case Io:
								e: {
									for (var u = a.key; t !== null;) {
										if (t.key === u) {
											if (u = a.type, u === Ro) {
												if (t.tag === 7) {
													i(e, t.sibling), s = o(t, a.props.children), mt(s, a), s.return = e, e = s;
													break e;
												}
											} else if (t.elementType === u || typeof u == "object" && u && u.$$typeof === qo && ut(u) === t.type) {
												i(e, t.sibling), s = o(t, a.props), mt(s, a), s.return = e, e = s;
												break e;
											}
											i(e, t);
											break;
										}
										n(e, t), t = t.sibling;
									}
									a.type === Ro ? (s = xo(a.props.children, e.mode, s, a.key), mt(s, a), s.return = e, e = s) : (s = bo(a.type, a.key, a.props, null, e.mode, s), mt(s, a), s.return = e, e = s);
								}
								return c(e);
							case Lo:
								e: {
									for (u = a.key; t !== null;) {
										if (t.key === u) {
											if (t.tag === 4 && t.stateNode.containerInfo === a.containerInfo && t.stateNode.implementation === a.implementation) {
												i(e, t.sibling), s = o(t, a.children || []), s.return = e, e = s;
												break e;
											}
											i(e, t);
											break;
										}
										n(e, t), t = t.sibling;
									}
									s = wo(a, e.mode, s), s.return = e, e = s;
								}
								return c(e);
							case qo: return a = ut(a), ee(e, t, a, s);
						}
						if (ns(a)) return _(e, t, a, s);
						if (l(a)) {
							if (u = l(a), typeof u != "function") throw Error(r(150));
							return a = u.call(a), v(e, t, a, s);
						}
						if (typeof a.then == "function") return ee(e, t, pt(a), s);
						if (a.$$typeof === Ho) return ee(e, t, Be(e, a), s);
						ht(e, a);
					}
					return typeof a == "string" && a !== "" || typeof a == "number" || typeof a == "bigint" ? (a = "" + a, t !== null && t.tag === 6 ? (i(e, t.sibling), s = o(t, a), s.return = e, e = s) : (i(e, t), s = So(a, e.mode, s), s.return = e, e = s), c(e)) : i(e, t);
				}
				return function(e, n, r, i) {
					try {
						ed = 0;
						var a = ee(e, n, r, i);
						return $u = null, a;
					} catch (n) {
						if (n === Ju || n === Xu) throw n;
						var o = t(29, n, null, e.mode);
						return o.lanes = i, o.return = e, o;
					}
				};
			}
			function _t() {
				for (var e = id, t = ad = id = 0; t < e;) {
					var n = rd[t];
					rd[t++] = null;
					var r = rd[t];
					rd[t++] = null;
					var i = rd[t];
					rd[t++] = null;
					var a = rd[t];
					if (rd[t++] = null, r !== null && i !== null) {
						var o = r.pending;
						o === null ? i.next = i : (i.next = o.next, o.next = i), r.pending = i;
					}
					a !== 0 && xt(n, i, a);
				}
			}
			function vt(e, t, n, r) {
				rd[id++] = e, rd[id++] = t, rd[id++] = n, rd[id++] = r, ad |= r, e.lanes |= r, e = e.alternate, e !== null && (e.lanes |= r);
			}
			function yt(e, t, n, r) {
				return vt(e, t, n, r), St(e);
			}
			function bt(e, t) {
				return vt(e, null, null, t), St(e);
			}
			function xt(e, t, n) {
				e.lanes |= n;
				var r = e.alternate;
				r !== null && (r.lanes |= n);
				for (var i = !1, a = e.return; a !== null;) a.childLanes |= n, r = a.alternate, r !== null && (r.childLanes |= n), a.tag === 22 && (e = a.stateNode, e === null || e._visibility & 1 || (i = !0)), e = a, a = a.return;
				return e.tag === 3 ? (a = e.stateNode, i && t !== null && (i = 31 - Bl(n), e = a.hiddenUpdates, r = e[i], r === null ? e[i] = [t] : r.push(t), t.lane = n | 536870912), a) : null;
			}
			function St(e) {
				if (50 < Tf) throw Tf = 0, Ef = null, Error(r(185));
				for (var t = e.return; t !== null;) e = t, t = e.return;
				return e.tag === 3 ? e.stateNode : null;
			}
			function Ct(e) {
				e.updateQueue = {
					baseState: e.memoizedState,
					firstBaseUpdate: null,
					lastBaseUpdate: null,
					shared: {
						pending: null,
						lanes: 0,
						hiddenCallbacks: null
					},
					callbacks: null
				};
			}
			function wt(e, t) {
				e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
					baseState: e.baseState,
					firstBaseUpdate: e.firstBaseUpdate,
					lastBaseUpdate: e.lastBaseUpdate,
					shared: e.shared,
					callbacks: null
				});
			}
			function Tt(e) {
				return {
					lane: e,
					tag: 0,
					payload: null,
					callback: null,
					next: null
				};
			}
			function Et(e, t, n) {
				var r = e.updateQueue;
				if (r === null) return null;
				if (r = r.shared, q & 2) {
					var i = r.pending;
					return i === null ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, t = St(e), xt(e, null, n), t;
				}
				return vt(e, r, t, n), St(e);
			}
			function Dt(e, t, n) {
				if (t = t.updateQueue, t !== null && (t = t.shared, n & 4194048)) {
					var r = t.lanes;
					r &= e.pendingLanes, n |= r, t.lanes = n, x(e, n);
				}
			}
			function Ot(e, t) {
				var n = e.updateQueue, r = e.alternate;
				if (r !== null && (r = r.updateQueue, n === r)) {
					var i = null, a = null;
					if (n = n.firstBaseUpdate, n !== null) {
						do {
							var o = {
								lane: n.lane,
								tag: n.tag,
								payload: n.payload,
								callback: null,
								next: null
							};
							a === null ? i = a = o : a = a.next = o, n = n.next;
						} while (n !== null);
						a === null ? i = a = t : a = a.next = t;
					} else i = a = t;
					n = {
						baseState: r.baseState,
						firstBaseUpdate: i,
						lastBaseUpdate: a,
						shared: r.shared,
						callbacks: r.callbacks
					}, e.updateQueue = n;
					return;
				}
				e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t;
			}
			function kt() {
				if (sd) {
					var e = Gu;
					if (e !== null) throw e;
				}
			}
			function At(e, t, n, r) {
				sd = !1;
				var i = e.updateQueue;
				od = !1;
				var a = i.firstBaseUpdate, o = i.lastBaseUpdate, s = i.shared.pending;
				if (s !== null) {
					i.shared.pending = null;
					var c = s, l = c.next;
					c.next = null, o === null ? a = l : o.next = l, o = c;
					var u = e.alternate;
					u !== null && (u = u.updateQueue, s = u.lastBaseUpdate, s !== o && (s === null ? u.firstBaseUpdate = l : s.next = l, u.lastBaseUpdate = c));
				}
				if (a !== null) {
					var d = i.baseState;
					o = 0, u = l = c = null, s = a;
					do {
						var f = s.lane & -536870913, p = f !== s.lane;
						if (p ? (X & f) === f : (r & f) === f) {
							f !== 0 && f === Wu && (sd = !0), u !== null && (u = u.next = {
								lane: 0,
								tag: s.tag,
								payload: s.payload,
								callback: null,
								next: null
							});
							e: {
								var m = e, h = s;
								f = t;
								var g = n;
								switch (h.tag) {
									case 1:
										if (m = h.payload, typeof m == "function") {
											d = m.call(g, d, f);
											break e;
										}
										d = m;
										break e;
									case 3: m.flags = m.flags & -65537 | 128;
									case 0:
										if (m = h.payload, f = typeof m == "function" ? m.call(g, d, f) : m, f == null) break e;
										d = Po({}, d, f);
										break e;
									case 2: od = !0;
								}
							}
							f = s.callback, f !== null && (e.flags |= 64, p && (e.flags |= 8192), p = i.callbacks, p === null ? i.callbacks = [f] : p.push(f));
						} else p = {
							lane: f,
							tag: s.tag,
							payload: s.payload,
							callback: s.callback,
							next: null
						}, u === null ? (l = u = p, c = d) : u = u.next = p, o |= f;
						if (s = s.next, s === null) {
							if (s = i.shared.pending, s === null) break;
							p = s, s = p.next, p.next = null, i.lastBaseUpdate = p, i.shared.pending = null;
						}
					} while (1);
					u === null && (c = d), i.baseState = c, i.firstBaseUpdate = l, i.lastBaseUpdate = u, a === null && (i.shared.lanes = 0), nf |= o, e.lanes = o, e.memoizedState = d;
				}
			}
			function jt(e, t) {
				if (typeof e != "function") throw Error(r(191, e));
				e.call(t);
			}
			function Mt(e, t) {
				var n = e.callbacks;
				if (n !== null) for (e.callbacks = null, e = 0; e < n.length; e++) jt(n[e], t);
			}
			function Nt(e, t) {
				e = tf, p(ld, e), p(cd, t), tf = e | t.baseLanes;
			}
			function Pt() {
				p(ld, tf), p(cd, cd.current);
			}
			function Ft() {
				tf = ld.current, f(cd), f(ld);
			}
			function It(e) {
				var t = e.alternate;
				p(fd, fd.current & 1), p(ud, e), dd === null && (t === null || cd.current !== null || t.memoizedState !== null) && (dd = e);
			}
			function Lt(e) {
				p(fd, fd.current), p(ud, e), dd === null && (dd = e);
			}
			function Rt(e) {
				e.tag === 22 ? (p(fd, fd.current), p(ud, e), dd === null && (dd = e)) : zt();
			}
			function zt() {
				p(fd, fd.current), p(ud, ud.current);
			}
			function Bt(e) {
				f(ud), dd === e && (dd = null), f(fd);
			}
			function Vt(e, t) {
				p(ud, ud.current), p(fd, t);
			}
			function Ht(e) {
				f(fd), f(ud), dd === e && (dd = null);
			}
			function Ut(e) {
				for (var t = e; t !== null;) {
					if (t.tag === 13) {
						var n = t.memoizedState;
						if (n !== null && (n = n.dehydrated, n === null || Ic(n) || Lc(n))) return t;
					} else if (t.tag === 19 && t.memoizedProps.revealOrder !== "independent") {
						if (t.flags & 128) return t;
					} else if (t.child !== null) {
						t.child.return = t, t = t.child;
						continue;
					}
					if (t === e) break;
					for (; t.sibling === null;) {
						if (t.return === null || t.return === e) return null;
						t = t.return;
					}
					t.sibling.return = t.return, t = t.sibling;
				}
				return null;
			}
			function E() {
				throw Error(r(321));
			}
			function Wt(e, t) {
				if (t === null) return !1;
				for (var n = 0; n < t.length && n < e.length; n++) if (!ou(e[n], t[n])) return !1;
				return !0;
			}
			function Gt(e, t, n, r, i, a) {
				return pd = a, z = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, M.H = e === null || e.memoizedState === null ? Sd : Cd, gd = !1, a = n(r, i), gd = !1, hd && (a = qt(t, n, r, i)), Kt(e), a;
			}
			function Kt(e) {
				M.H = xd;
				var t = B !== null && B.next !== null;
				if (pd = 0, V = B = z = null, md = !1, vd = 0, yd = null, t) throw Error(r(300));
				e === null || H || (e = e.dependencies, e !== null && Re(e) && (H = !0));
			}
			function qt(e, t, n, i) {
				z = e;
				var a = 0;
				do {
					if (hd && (yd = null), vd = 0, hd = !1, 25 <= a) throw Error(r(301));
					if (a += 1, V = B = null, e.updateQueue != null) {
						var o = e.updateQueue;
						o.lastEffect = null, o.events = null, o.stores = null, o.memoCache != null && (o.memoCache.index = 0);
					}
					M.H = wd, o = t(n, i);
				} while (hd);
				return o;
			}
			function Jt() {
				var e = M.H, t = e.useState()[0];
				return t = typeof t.then == "function" ? en(t) : t, e = e.useState()[0], (B === null ? null : B.memoizedState) !== e && (z.flags |= 1024), t;
			}
			function Yt() {
				var e = _d !== 0;
				return _d = 0, e;
			}
			function Xt(e, t, n) {
				t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~n;
			}
			function Zt(e) {
				if (md) {
					for (e = e.memoizedState; e !== null;) {
						var t = e.queue;
						t !== null && (t.pending = null), e = e.next;
					}
					md = !1;
				}
				pd = 0, V = B = z = null, hd = !1, vd = _d = 0, yd = null;
			}
			function Qt() {
				var e = {
					memoizedState: null,
					baseState: null,
					baseQueue: null,
					queue: null,
					next: null
				};
				return V === null ? z.memoizedState = V = e : V = V.next = e, V;
			}
			function D() {
				if (B === null) {
					var e = z.alternate;
					e = e === null ? null : e.memoizedState;
				} else e = B.next;
				var t = V === null ? z.memoizedState : V.next;
				if (t !== null) V = t, B = e;
				else {
					if (e === null) throw z.alternate === null ? Error(r(467)) : Error(r(310));
					B = e, e = {
						memoizedState: B.memoizedState,
						baseState: B.baseState,
						baseQueue: B.baseQueue,
						queue: B.queue,
						next: null
					}, V === null ? z.memoizedState = V = e : V = V.next = e;
				}
				return V;
			}
			function $t() {
				return {
					lastEffect: null,
					events: null,
					stores: null,
					memoCache: null
				};
			}
			function en(e) {
				var t = vd;
				return vd += 1, yd === null && (yd = []), e = lt(yd, e, t), t = z, (V === null ? t.memoizedState : V.next) === null && (t = t.alternate, M.H = t === null || t.memoizedState === null ? Sd : Cd), e;
			}
			function tn(e) {
				if (typeof e == "object" && e) {
					if (typeof e.then == "function") return en(e);
					if (e.$$typeof === Qo) return;
					if (e.$$typeof === Ho) return w(e);
				}
				throw Error(r(438, String(e)));
			}
			function nn(e) {
				var t = null, n = z.updateQueue;
				if (n !== null && (t = n.memoCache), t == null) {
					var r = z.alternate;
					r !== null && (r = r.updateQueue, r !== null && (r = r.memoCache, r != null && (t = {
						data: r.data.map(function(e) {
							return e.slice();
						}),
						index: 0
					})));
				}
				if (t ??= {
					data: [],
					index: 0
				}, n === null && (n = $t(), z.updateQueue = n), n.memoCache = t, n = t.data[t.index], n === void 0) for (n = t.data[t.index] = Array(e), r = 0; r < e; r++) n[r] = Xo;
				return t.index++, n;
			}
			function rn(e, t) {
				return typeof t == "function" ? t(e) : t;
			}
			function an(e) {
				return on(D(), B, e);
			}
			function on(e, t, n) {
				var i = e.queue;
				if (i === null) throw Error(r(311));
				i.lastRenderedReducer = n;
				var a = e.baseQueue, o = i.pending;
				if (o !== null) {
					if (a !== null) {
						var s = a.next;
						a.next = o.next, o.next = s;
					}
					t.baseQueue = a = o, i.pending = null;
				}
				if (o = e.baseState, a === null) e.memoizedState = o;
				else {
					t = a.next;
					var c = s = null, l = null, u = t, d = !1;
					do {
						var f = u.lane & -536870913;
						if (f === u.lane ? (pd & f) === f : (X & f) === f) {
							var p = u.revertLane;
							if (p === 0) l !== null && (l = l.next = {
								lane: 0,
								revertLane: 0,
								gesture: null,
								action: u.action,
								hasEagerState: u.hasEagerState,
								eagerState: u.eagerState,
								next: null
							}), f === Wu && (d = !0);
							else if ((pd & p) === p) {
								u = u.next, p === Wu && (d = !0);
								continue;
							} else f = {
								lane: 0,
								revertLane: u.revertLane,
								gesture: null,
								action: u.action,
								hasEagerState: u.hasEagerState,
								eagerState: u.eagerState,
								next: null
							}, l === null ? (c = l = f, s = o) : l = l.next = f, z.lanes |= p, nf |= p;
							f = u.action, gd && n(o, f), o = u.hasEagerState ? u.eagerState : n(o, f);
						} else p = {
							lane: f,
							revertLane: u.revertLane,
							gesture: u.gesture,
							action: u.action,
							hasEagerState: u.hasEagerState,
							eagerState: u.eagerState,
							next: null
						}, l === null ? (c = l = p, s = o) : l = l.next = p, z.lanes |= f, nf |= f;
						u = u.next;
					} while (u !== null && u !== t);
					if (l === null ? s = o : l.next = c, !ou(o, e.memoizedState) && (H = !0, d && (n = Gu, n !== null))) throw n;
					e.memoizedState = o, e.baseState = s, e.baseQueue = l, i.lastRenderedState = o;
				}
				return a === null && (i.lanes = 0), [e.memoizedState, i.dispatch];
			}
			function sn(e) {
				var t = D(), n = t.queue;
				if (n === null) throw Error(r(311));
				n.lastRenderedReducer = e;
				var i = n.dispatch, a = n.pending, o = t.memoizedState;
				if (a !== null) {
					n.pending = null;
					var s = a = a.next;
					do
						o = e(o, s.action), s = s.next;
					while (s !== a);
					ou(o, t.memoizedState) || (H = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o;
				}
				return [o, i];
			}
			function cn(e, t, n) {
				var i = z, a = D(), o = L;
				if (o) {
					if (n === void 0) throw Error(r(407));
					n = n();
				} else n = t();
				var s = !ou((B || a).memoizedState, n);
				if (s && (a.memoizedState = n, H = !0), a = a.queue, Nn(dn.bind(null, i, a, e), [e]), e = a.getSnapshot !== t || s || V !== null && !!(V.memoizedState.tag & 1), On(e ? 9 : 8, { destroy: void 0 }, un.bind(null, i, a, n, t), null), e) {
					if (i.flags |= 2048, J === null) throw Error(r(349));
					o || pd & 127 || ln(i, t, n);
				}
				return n;
			}
			function ln(e, t, n) {
				e.flags |= 16384, e = {
					getSnapshot: t,
					value: n
				}, t = z.updateQueue, t === null ? (t = $t(), z.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e));
			}
			function un(e, t, n, r) {
				t.value = n, t.getSnapshot = r, fn(t) && pn(e);
			}
			function dn(e, t, n) {
				return n(function() {
					fn(t) && pn(e);
				});
			}
			function fn(e) {
				var t = e.getSnapshot;
				e = e.value;
				try {
					var n = t();
					return !ou(e, n);
				} catch {
					return !0;
				}
			}
			function pn(e) {
				var t = bt(e, 2);
				t !== null && Aa(t, e, 2);
			}
			function mn(e) {
				var t = Qt();
				if (typeof e == "function") {
					var n = e;
					if (e = n(), gd) {
						se(!0);
						try {
							n();
						} finally {
							se(!1);
						}
					}
				}
				return t.memoizedState = t.baseState = e, t.queue = {
					pending: null,
					lanes: 0,
					dispatch: null,
					lastRenderedReducer: rn,
					lastRenderedState: e
				}, t;
			}
			function hn(e, t, n, r) {
				return e.baseState = n, on(e, B, typeof r == "function" ? r : rn);
			}
			function gn(e, t, n, i, a) {
				if (tr(e)) throw Error(r(485));
				if (e = t.action, e !== null) {
					var o = {
						payload: a,
						action: e,
						next: null,
						isTransition: !0,
						status: "pending",
						value: null,
						reason: null,
						listeners: [],
						then: function(e) {
							o.listeners.push(e);
						}
					};
					M.T === null ? o.isTransition = !1 : n(!0), i(o), n = t.pending, n === null ? (o.next = t.pending = o, _n(t, o)) : (o.next = n.next, t.pending = n.next = o);
				}
			}
			function _n(e, t) {
				var n = t.action, r = t.payload, i = e.state;
				if (t.isTransition) {
					var a = M.T, o = {};
					o.types = a === null ? null : a.types, M.T = o;
					try {
						var s = n(i, r), c = M.S;
						c !== null && c(o, s), vn(e, t, s);
					} catch (n) {
						bn(e, t, n);
					} finally {
						a !== null && o.types !== null && (a.types = o.types), M.T = a;
					}
				} else try {
					a = n(i, r), vn(e, t, a);
				} catch (n) {
					bn(e, t, n);
				}
			}
			function vn(e, t, n) {
				typeof n == "object" && n && typeof n.then == "function" ? n.then(function(n) {
					yn(e, t, n);
				}, function(n) {
					return bn(e, t, n);
				}) : yn(e, t, n);
			}
			function yn(e, t, n) {
				t.status = "fulfilled", t.value = n, xn(t), e.state = n, t = e.pending, t !== null && (n = t.next, n === t ? e.pending = null : (n = n.next, t.next = n, _n(e, n)));
			}
			function bn(e, t, n) {
				var r = e.pending;
				if (e.pending = null, r !== null) {
					r = r.next;
					do
						t.status = "rejected", t.reason = n, xn(t), t = t.next;
					while (t !== r);
				}
				e.action = null;
			}
			function xn(e) {
				e = e.listeners;
				for (var t = 0; t < e.length; t++) (0, e[t])();
			}
			function Sn(e, t) {
				return t;
			}
			function Cn(e, t) {
				if (L) {
					var n = J.formState;
					if (n !== null) {
						e: {
							var r = z;
							if (L) {
								if (I) {
									var i = Bc(I, Du);
									if (i) {
										I = Hc(i), r = Vc(i);
										break e;
									}
								}
								Ee(r);
							}
							r = !1;
						}
						r && (t = n[0]);
					}
				}
				n = Qt(), n.memoizedState = n.baseState = t, r = {
					pending: null,
					lanes: 0,
					dispatch: null,
					lastRenderedReducer: Sn,
					lastRenderedState: t
				}, n.queue = r, n = Qn.bind(null, z, r), r.dispatch = n, r = mn(!1);
				var a = er.bind(null, z, !1, r.queue);
				return r = Qt(), i = {
					state: t,
					dispatch: null,
					action: e,
					pending: null
				}, r.queue = i, n = gn.bind(null, z, i, a, n), i.dispatch = n, r.memoizedState = e, [
					t,
					n,
					!1
				];
			}
			function wn(e) {
				return Tn(D(), B, e);
			}
			function Tn(e, t, n) {
				if (t = on(e, t, Sn)[0], e = an(rn)[0], typeof t == "object" && t && typeof t.then == "function") try {
					var r = en(t);
				} catch (e) {
					throw e === Ju ? Xu : e;
				}
				else r = t;
				t = D();
				var i = t.queue, a = i.dispatch;
				return n !== t.memoizedState && (z.flags |= 2048, On(9, { destroy: void 0 }, En.bind(null, i, n), null)), [
					r,
					a,
					e
				];
			}
			function En(e, t) {
				e.action = t;
			}
			function Dn(e) {
				var t = D(), n = B;
				if (n !== null) return Tn(t, n, e);
				D(), t = t.memoizedState, n = D();
				var r = n.queue.dispatch;
				return n.memoizedState = e, [
					t,
					r,
					!1
				];
			}
			function On(e, t, n, r) {
				return e = {
					tag: e,
					create: n,
					deps: r,
					inst: t,
					next: null
				}, t = z.updateQueue, t === null && (t = $t(), z.updateQueue = t), n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e), e;
			}
			function kn() {
				return D().memoizedState;
			}
			function An(e, t, n, r) {
				var i = Qt();
				z.flags |= e, i.memoizedState = On(1 | t, { destroy: void 0 }, n, r === void 0 ? null : r);
			}
			function jn(e, t, n, r) {
				var i = D();
				r = r === void 0 ? null : r;
				var a = i.memoizedState.inst;
				B !== null && r !== null && Wt(r, B.memoizedState.deps) ? i.memoizedState = On(t, a, n, r) : (z.flags |= e, i.memoizedState = On(1 | t, a, n, r));
			}
			function Mn(e, t) {
				An(8390656, 8, e, t);
			}
			function Nn(e, t) {
				jn(2048, 8, e, t);
			}
			function Pn(e) {
				z.flags |= 4;
				var t = z.updateQueue;
				if (t === null) t = $t(), z.updateQueue = t, t.events = [e];
				else {
					var n = t.events;
					n === null ? t.events = [e] : n.push(e);
				}
			}
			function Fn(e) {
				var t = D().memoizedState;
				return Pn({
					ref: t,
					nextImpl: e
				}), function() {
					if (q & 2) throw Error(r(440));
					return t.impl.apply(void 0, arguments);
				};
			}
			function In(e, t) {
				return jn(4, 2, e, t);
			}
			function Ln(e, t) {
				return jn(4, 4, e, t);
			}
			function Rn(e, t) {
				if (typeof t == "function") {
					e = e();
					var n = t(e);
					return function() {
						typeof n == "function" ? n() : t(null);
					};
				}
				if (t != null) return e = e(), t.current = e, function() {
					t.current = null;
				};
			}
			function zn(e, t, n) {
				n = n == null ? null : n.concat([e]), jn(4, 4, Rn.bind(null, t, e), n);
			}
			function Bn() {}
			function Vn(e, t) {
				var n = D();
				t = t === void 0 ? null : t;
				var r = n.memoizedState;
				return t !== null && Wt(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e);
			}
			function Hn(e, t) {
				var n = D();
				t = t === void 0 ? null : t;
				var r = n.memoizedState;
				if (t !== null && Wt(t, r[1])) return r[0];
				if (r = e(), gd) {
					se(!0);
					try {
						e();
					} finally {
						se(!1);
					}
				}
				return n.memoizedState = [r, t], r;
			}
			function Un(e, t, n) {
				return n === void 0 || pd & 1073741824 && !(X & 261930) ? e.memoizedState = t : (e.memoizedState = n, e = Oa(), z.lanes |= e, nf |= e, n);
			}
			function Wn(e, t, n, r) {
				return ou(n, t) ? n : cd.current === null ? !(pd & 106) || pd & 1073741824 && !(X & 261930) ? (H = !0, e.memoizedState = n) : (e = Oa(), z.lanes |= e, nf |= e, t) : (e = Un(e, n, r), ou(e, t) || (H = !0), e);
			}
			function Gn(e, t, n, r, i) {
				var a = Ts();
				ws(a !== 0 && 8 > a ? a : 8);
				var o = M.T, s = {};
				s.types = o === null ? null : o.types, M.T = s, er(e, !1, t, n);
				try {
					var c = i(), l = M.S;
					l !== null && l(s, c), typeof c == "object" && c && typeof c.then == "function" ? $n(e, t, rt(c, r), Da(e)) : $n(e, t, r, Da(e));
				} catch (n) {
					$n(e, t, {
						then: function() {},
						status: "rejected",
						reason: n
					}, Da());
				} finally {
					ws(a), o !== null && s.types !== null && (o.types = s.types), M.T = o;
				}
			}
			function Kn(e) {
				var t = e.memoizedState;
				if (t !== null) return t;
				t = {
					memoizedState: Ls,
					baseState: Ls,
					baseQueue: null,
					queue: {
						pending: null,
						lanes: 0,
						dispatch: null,
						lastRenderedReducer: rn,
						lastRenderedState: Ls
					},
					next: null
				};
				var n = {};
				return t.next = {
					memoizedState: n,
					baseState: n,
					baseQueue: null,
					queue: {
						pending: null,
						lanes: 0,
						dispatch: null,
						lastRenderedReducer: rn,
						lastRenderedState: n
					},
					next: null
				}, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t;
			}
			function qn() {
				return w(Rs);
			}
			function Jn() {
				return D().memoizedState;
			}
			function Yn() {
				return D().memoizedState;
			}
			function Xn(e) {
				for (var t = e.return; t !== null;) {
					switch (t.tag) {
						case 24:
						case 3:
							var n = Da();
							e = Tt(n);
							var r = Et(t, e, n);
							r !== null && (Aa(r, t, n), Dt(r, t, n)), t = { cache: He() }, e.payload = t;
							return;
					}
					t = t.return;
				}
			}
			function Zn(e, t, n) {
				var r = Da();
				n = {
					lane: r,
					revertLane: 0,
					gesture: null,
					action: n,
					hasEagerState: !1,
					eagerState: null,
					next: null
				}, tr(e) ? nr(t, n) : (n = yt(e, t, n, r), n !== null && (Aa(n, e, r), rr(n, t, r)));
			}
			function Qn(e, t, n) {
				$n(e, t, n, Da());
			}
			function $n(e, t, n, r) {
				var i = {
					lane: r,
					revertLane: 0,
					gesture: null,
					action: n,
					hasEagerState: !1,
					eagerState: null,
					next: null
				};
				if (tr(e)) nr(t, i);
				else {
					var a = e.alternate;
					if (e.lanes === 0 && (a === null || a.lanes === 0) && (a = t.lastRenderedReducer, a !== null)) try {
						var o = t.lastRenderedState, s = a(o, n);
						if (i.hasEagerState = !0, i.eagerState = s, ou(s, o)) return vt(e, t, i, 0), J === null && _t(), !1;
					} catch {}
					if (n = yt(e, t, i, r), n !== null) return Aa(n, e, r), rr(n, t, r), !0;
				}
				return !1;
			}
			function er(e, t, n, i) {
				if (i = {
					lane: 2,
					revertLane: et(),
					gesture: null,
					action: i,
					hasEagerState: !1,
					eagerState: null,
					next: null
				}, tr(e)) {
					if (t) throw Error(r(479));
				} else t = yt(e, n, i, 2), t !== null && Aa(t, e, 2);
			}
			function tr(e) {
				var t = e.alternate;
				return e === z || t !== null && t === z;
			}
			function nr(e, t) {
				hd = md = !0;
				var n = e.pending;
				n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t;
			}
			function rr(e, t, n) {
				if (n & 4194048) {
					var r = t.lanes;
					r &= e.pendingLanes, n |= r, t.lanes = n, x(e, n);
				}
			}
			function ir(e, t, n, r) {
				t = e.memoizedState, n = n(r, t), n = n == null ? t : Po({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n);
			}
			function ar(e, t, n, r, i, a, o) {
				return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, a, o) : t.prototype && t.prototype.isPureReactComponent ? !st(n, r) || !st(i, a) : !0;
			}
			function or(e, t, n, r) {
				e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Td.enqueueReplaceState(t, t.state, null);
			}
			function sr(e, t) {
				var n = t;
				if ("ref" in t) for (var r in n = {}, t) r !== "ref" && (n[r] = t[r]);
				if (e = e.defaultProps) for (var i in n === t && (n = Po({}, n)), e) n[i] === void 0 && (n[i] = e[i]);
				return n;
			}
			function cr(e, t) {
				try {
					var n = e.onUncaughtError;
					n(t.value, { componentStack: t.stack });
				} catch (e) {
					setTimeout(function() {
						throw e;
					});
				}
			}
			function lr(e, t, n) {
				try {
					var r = e.onCaughtError;
					r(n.value, {
						componentStack: n.stack,
						errorBoundary: t.tag === 1 ? t.stateNode : null
					});
				} catch (e) {
					setTimeout(function() {
						throw e;
					});
				}
			}
			function ur(e, t, n) {
				return n = Tt(n), n.tag = 3, n.payload = { element: null }, n.callback = function() {
					cr(e, t);
				}, n;
			}
			function dr(e) {
				return e = Tt(e), e.tag = 3, e;
			}
			function fr(e, t, n, r) {
				var i = n.type.getDerivedStateFromError;
				if (typeof i == "function") {
					var a = r.value;
					e.payload = function() {
						return i(a);
					}, e.callback = function() {
						lr(t, n, r);
					};
				}
				var o = n.stateNode;
				o !== null && typeof o.componentDidCatch == "function" && (e.callback = function() {
					lr(t, n, r), typeof i != "function" && (hf === null ? hf = /* @__PURE__ */ new Set([this]) : hf.add(this));
					var e = r.stack;
					this.componentDidCatch(r.value, { componentStack: e === null ? "" : e });
				});
			}
			function pr(e, t, n, i, a) {
				if (n.flags |= 32768, typeof i == "object" && i && typeof i.then == "function") {
					if (t = n.alternate, t !== null && Le(t, n, a, !0), n = ud.current, n !== null) {
						switch (n.tag) {
							case 31:
							case 13:
							case 19: return dd === null ? Ha() : n.alternate === null && Q === 0 && (Q = 3), n.flags &= -257, n.flags |= 65536, n.lanes = a, i === Zu ? n.flags |= 16384 : (t = n.updateQueue, t === null ? n.updateQueue = /* @__PURE__ */ new Set([i]) : t.add(i), lo(e, i, a)), !1;
							case 22: return n.flags |= 65536, i === Zu ? n.flags |= 16384 : (t = n.updateQueue, t === null ? (t = {
								transitions: null,
								markerInstances: null,
								retryQueue: /* @__PURE__ */ new Set([i])
							}, n.updateQueue = t) : (n = t.retryQueue, n === null ? t.retryQueue = /* @__PURE__ */ new Set([i]) : n.add(i)), lo(e, i, a)), !1;
						}
						throw Error(r(435, n.tag));
					}
					return lo(e, i, a), Ha(), !1;
				}
				if (L) return t = ud.current, t === null ? (i !== Ou && (t = Error(r(423), { cause: i }), Me(he(t, n))), e = e.current.alternate, e.flags |= 65536, a &= -a, e.lanes |= a, i = he(i, n), a = ur(e.stateNode, i, a), Ot(e, a), Q !== 4 && (Q = 2)) : (!(t.flags & 65536) && (t.flags |= 256), t.flags |= 65536, t.lanes = a, i !== Ou && (e = Error(r(422), { cause: i }), Me(he(e, n)))), !1;
				var o = Error(r(520), { cause: i });
				if (o = he(o, n), cf === null ? cf = [o] : cf.push(o), Q !== 4 && (Q = 2), t === null) return !0;
				i = he(i, n), n = t;
				do {
					switch (n.tag) {
						case 3: return n.flags |= 65536, e = a & -a, n.lanes |= e, e = ur(n.stateNode, i, e), Ot(n, e), !1;
						case 1:
							if (t = n.type, o = n.stateNode, !(n.flags & 128) && (typeof t.getDerivedStateFromError == "function" || o !== null && typeof o.componentDidCatch == "function" && (hf === null || !hf.has(o)))) return n.flags |= 65536, a &= -a, n.lanes |= a, a = dr(a), fr(a, e, n, i), Ot(n, a), !1;
							break;
						case 22: if (n.memoizedState !== null) return n.flags |= 65536, !1;
					}
					n = n.return;
				} while (n !== null);
				return !1;
			}
			function O(e, t, n, r) {
				t.child = e === null ? nd(t, null, n, r) : td(t, e.child, n, r);
			}
			function mr(e, t, n, r, i) {
				n = n.render;
				var a = t.ref;
				if ("ref" in r) {
					var o = {};
					for (var s in r) s !== "ref" && (o[s] = r[s]);
				} else o = r;
				return ze(t), r = Gt(e, t, n, o, a, i), s = Yt(), e !== null && !H ? (Xt(e, t, i), Vr(e, t, i)) : (L && s && ye(t), t.flags |= 1, O(e, t, r, i), t.child);
			}
			function hr(e, t, n, r, i) {
				if (e === null) {
					var a = n.type;
					return typeof a == "function" && !_o(a) && a.defaultProps === void 0 && n.compare === null ? (t.tag = 15, t.type = a, gr(e, t, a, r, i)) : (e = bo(n.type, null, r, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e);
				}
				if (a = e.child, !Hr(e, i)) {
					var o = a.memoizedProps;
					if (n = n.compare, n = n === null ? st : n, n(o, r) && e.ref === t.ref) return Vr(e, t, i);
				}
				return t.flags |= 1, e = vo(a, r), e.ref = t.ref, e.return = t, t.child = e;
			}
			function gr(e, t, n, r, i) {
				if (e !== null) {
					var a = e.memoizedProps;
					if (st(a, r) && e.ref === t.ref) {
						if (H = !1, t.pendingProps = r = a, Hr(e, i)) e.flags & 131072 && (H = !0);
						else return t.lanes = e.lanes, Vr(e, t, i);
					}
				}
				return wr(e, t, n, r, i);
			}
			function _r(e, t, n, r) {
				var i = r.children, a = e === null ? null : e.memoizedState;
				if (e === null && t.stateNode === null && (t.stateNode = {
					_visibility: 1,
					_pendingMarkers: null,
					_retryCache: null,
					_transitions: null
				}), r.mode === "hidden") {
					if (t.flags & 128) {
						if (a = a === null ? n : a.baseLanes | n, e !== null) {
							for (r = t.child = e.child, i = 0; r !== null;) i = i | r.lanes | r.childLanes, r = r.sibling;
							r = i & ~a;
						} else r = 0, t.child = null;
						return yr(e, t, a, n, r);
					}
					if (n & 536870912) t.memoizedState = {
						baseLanes: 0,
						cachePool: null
					}, e !== null && at(t, a === null ? null : a.cachePool), a === null ? Pt() : Nt(t, a), Rt(t);
					else return r = t.lanes = 536870912, yr(e, t, a === null ? n : a.baseLanes | n, n, r);
				} else a === null ? (e !== null && at(t, null), Pt(), zt()) : (at(t, a.cachePool), Nt(t, a), zt(), t.memoizedState = null);
				return O(e, t, i, n), t.child;
			}
			function vr(e, t) {
				return e !== null && e.tag === 22 || t.stateNode !== null || (t.stateNode = {
					_visibility: 1,
					_pendingMarkers: null,
					_retryCache: null,
					_transitions: null
				}), t.sibling;
			}
			function yr(e, t, n, r, i) {
				var a = it();
				return a = a === null ? null : {
					parent: ys ? R._currentValue : R._currentValue2,
					pool: a
				}, t.memoizedState = {
					baseLanes: n,
					cachePool: a
				}, e !== null && at(t, null), Pt(), Rt(t), e !== null && Le(e, t, r, !0), t.childLanes = i, null;
			}
			function br(e, t) {
				return t = Mr({
					mode: t.mode,
					children: t.children
				}, e.mode), t.ref = e.ref, e.child = t, t.return = e, t;
			}
			function xr(e, t, n) {
				return td(t, e.child, null, n), e = br(t, t.pendingProps), e.flags |= 2, Bt(t), t.memoizedState = null, e;
			}
			function Sr(e, t, n) {
				var i = t.pendingProps, a = !!(t.flags & 128);
				if (t.flags &= -129, e === null) {
					if (L) {
						if (i.mode === "hidden") return e = br(t, i), t.lanes = 536870912, e.memoizedState = {
							baseLanes: 0,
							cachePool: null
						}, vr(null, e);
						if (Lt(t), (e = I) ? (e = Zc(e, Du), e !== null && (t.memoizedState = {
							dehydrated: e,
							treeContext: yu === null ? null : {
								id: bu,
								overflow: xu
							},
							retryLane: 536870912,
							hydrationErrors: null
						}, n = Co(e), n.return = t, t.child = n, F = t, I = null)) : e = null, e === null) throw Ee(t);
						return t.lanes = 536870912, null;
					}
					return br(t, i);
				}
				var o = e.memoizedState;
				if (o !== null) {
					var s = o.dehydrated;
					if (Lt(t), a) {
						if (t.flags & 256) t.flags &= -257, t = xr(e, t, n);
						else if (t.memoizedState !== null) t.child = e.child, t.flags |= 128, t = null;
						else throw Error(r(558));
					} else if (H || Le(e, t, n, !1), a = (n & e.childLanes) !== 0, H || a) {
						if (cd.current === null) {
							if (i = J, i !== null && (s = ie(i, n), s !== 0 && s !== o.retryLane)) throw o.retryLane = s, bt(e, s), Aa(i, e, s), Ed;
							Ha();
						}
						t = xr(e, t, n);
					} else e = o.treeContext, xs && (I = Kc(s), F = t, L = !0, Eu = null, Du = !1, e !== null && xe(t, e)), t = br(t, i), t.flags |= 134221824;
					return t;
				}
				return e = vo(e.child, {
					mode: i.mode,
					children: i.children
				}), e.ref = t.ref, t.child = e, e.return = t, e;
			}
			function Cr(e, t) {
				var n = t.ref;
				if (n === null) e !== null && e.ref !== null && (t.flags |= 4194816);
				else {
					if (typeof n != "function" && typeof n != "object") throw Error(r(284));
					(e === null || e.ref !== n) && (t.flags |= 4194816);
				}
			}
			function wr(e, t, n, r, i) {
				return ze(t), n = Gt(e, t, n, r, void 0, i), r = Yt(), e !== null && !H ? (Xt(e, t, i), Vr(e, t, i)) : (L && r && ye(t), t.flags |= 1, O(e, t, n, i), t.child);
			}
			function Tr(e, t, n, r, i, a) {
				return ze(t), t.updateQueue = null, n = qt(t, r, n, i), Kt(e), r = Yt(), e !== null && !H ? (Xt(e, t, a), Vr(e, t, a)) : (L && r && ye(t), t.flags |= 1, O(e, t, n, a), t.child);
			}
			function Er(e, t, n, r, i) {
				if (ze(t), t.stateNode === null) {
					var a = zl, o = n.contextType;
					typeof o == "object" && o && (a = w(o)), a = new n(r, a), t.memoizedState = a.state !== null && a.state !== void 0 ? a.state : null, a.updater = Td, t.stateNode = a, a._reactInternals = t, a = t.stateNode, a.props = r, a.state = t.memoizedState, a.refs = {}, Ct(t), o = n.contextType, a.context = typeof o == "object" && o ? w(o) : zl, a.state = t.memoizedState, o = n.getDerivedStateFromProps, typeof o == "function" && (ir(t, n, o, r), a.state = t.memoizedState), typeof n.getDerivedStateFromProps == "function" || typeof a.getSnapshotBeforeUpdate == "function" || typeof a.UNSAFE_componentWillMount != "function" && typeof a.componentWillMount != "function" || (o = a.state, typeof a.componentWillMount == "function" && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == "function" && a.UNSAFE_componentWillMount(), o !== a.state && Td.enqueueReplaceState(a, a.state, null), At(t, r, a, i), kt(), a.state = t.memoizedState), typeof a.componentDidMount == "function" && (t.flags |= 4194308), r = !0;
				} else if (e === null) {
					a = t.stateNode;
					var s = t.memoizedProps, c = sr(n, s);
					a.props = c;
					var l = a.context, u = n.contextType;
					o = zl, typeof u == "object" && u && (o = w(u));
					var d = n.getDerivedStateFromProps;
					u = typeof d == "function" || typeof a.getSnapshotBeforeUpdate == "function", s = t.pendingProps !== s, u || typeof a.UNSAFE_componentWillReceiveProps != "function" && typeof a.componentWillReceiveProps != "function" || (s || l !== o) && or(t, a, r, o), od = !1;
					var f = t.memoizedState;
					a.state = f, At(t, r, a, i), kt(), l = t.memoizedState, s || f !== l || od ? (typeof d == "function" && (ir(t, n, d, r), l = t.memoizedState), (c = od || ar(t, n, c, r, f, l, o)) ? (u || typeof a.UNSAFE_componentWillMount != "function" && typeof a.componentWillMount != "function" || (typeof a.componentWillMount == "function" && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == "function" && a.UNSAFE_componentWillMount()), typeof a.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof a.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = l), a.props = r, a.state = l, a.context = o, r = c) : (typeof a.componentDidMount == "function" && (t.flags |= 4194308), r = !1);
				} else {
					a = t.stateNode, wt(e, t), o = t.memoizedProps, u = sr(n, o), a.props = u, d = t.pendingProps, f = a.context, l = n.contextType, c = zl, typeof l == "object" && l && (c = w(l)), s = n.getDerivedStateFromProps, (l = typeof s == "function" || typeof a.getSnapshotBeforeUpdate == "function") || typeof a.UNSAFE_componentWillReceiveProps != "function" && typeof a.componentWillReceiveProps != "function" || (o !== d || f !== c) && or(t, a, r, c), od = !1, f = t.memoizedState, a.state = f, At(t, r, a, i), kt();
					var p = t.memoizedState;
					o !== d || f !== p || od || e !== null && e.dependencies !== null && Re(e.dependencies) ? (typeof s == "function" && (ir(t, n, s, r), p = t.memoizedState), (u = od || ar(t, n, u, r, f, p, c) || e !== null && e.dependencies !== null && Re(e.dependencies)) ? (l || typeof a.UNSAFE_componentWillUpdate != "function" && typeof a.componentWillUpdate != "function" || (typeof a.componentWillUpdate == "function" && a.componentWillUpdate(r, p, c), typeof a.UNSAFE_componentWillUpdate == "function" && a.UNSAFE_componentWillUpdate(r, p, c)), typeof a.componentDidUpdate == "function" && (t.flags |= 4), typeof a.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof a.componentDidUpdate != "function" || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != "function" || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = p), a.props = r, a.state = p, a.context = c, r = u) : (typeof a.componentDidUpdate != "function" || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != "function" || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = !1);
				}
				return a = r, Cr(e, t), r = !!(t.flags & 128), a || r ? (a = t.stateNode, n = r && typeof n.getDerivedStateFromError != "function" ? null : a.render(), t.flags |= 1, e !== null && r ? (t.child = td(t, e.child, null, i), t.child = td(t, null, n, i)) : O(e, t, n, i), t.memoizedState = a.state, e = t.child) : e = Vr(e, t, i), e;
			}
			function Dr(e, t, n, r) {
				return Ae(), t.flags |= 256, O(e, t, n, r), t.child;
			}
			function Or(e) {
				return {
					baseLanes: e,
					cachePool: ot()
				};
			}
			function kr(e, t, n) {
				return e = e === null ? 0 : e.childLanes & ~n, t && (e |= of), e;
			}
			function Ar(e, t, n) {
				var r = t.pendingProps, i = !1, a = !!(t.flags & 128), o;
				if ((o = a) || (o = e !== null && e.memoizedState === null ? !1 : !!(fd.current & 2)), o && (i = !0, t.flags &= -129), o = !!(t.flags & 32), t.flags &= -33, e === null) {
					if (L) {
						if (i ? It(t) : zt(), (e = I) ? (e = Qc(e, Du), e !== null && (t.memoizedState = {
							dehydrated: e,
							treeContext: yu === null ? null : {
								id: bu,
								overflow: xu
							},
							retryLane: 536870912,
							hydrationErrors: null
						}, n = Co(e), n.return = t, t.child = n, F = t, I = null)) : e = null, e === null) throw Ee(t);
						return t.lanes = Lc(e) ? 32 : 536870912, null;
					}
					return a = r.children, r = r.fallback, i ? (zt(), i = t.mode, a = Mr({
						mode: "hidden",
						children: a
					}, i), r = xo(r, i, n, null), a.return = t, r.return = t, a.sibling = r, t.child = a, r = t.child, r.memoizedState = Or(n), r.childLanes = kr(e, o, n), t.memoizedState = Dd, vr(null, r)) : (It(t), jr(t, a));
				}
				var s = e.memoizedState;
				if (s !== null) {
					var c = s.dehydrated;
					if (c !== null) return Pr(e, t, a, o, r, c, s, n);
				}
				return i ? (zt(), i = r.fallback, a = t.mode, s = e.child, c = s.sibling, r = vo(s, {
					mode: "hidden",
					children: r.children
				}), r.subtreeFlags = s.subtreeFlags & 1206910976, c === null ? (i = xo(i, a, n, null), i.flags |= 2) : i = vo(c, i), i.return = t, r.return = t, r.sibling = i, t.child = r, vr(null, r), r = t.child, i = e.child.memoizedState, i === null ? i = Or(n) : (a = i.cachePool, a === null ? a = ot() : (s = ys ? R._currentValue : R._currentValue2, a = a.parent === s ? a : {
					parent: s,
					pool: s
				}), i = {
					baseLanes: i.baseLanes | n,
					cachePool: a
				}), r.memoizedState = i, r.childLanes = kr(e, o, n), t.memoizedState = Dd, vr(e.child, r)) : (It(t), n = e.child, e = n.sibling, n = vo(n, {
					mode: "visible",
					children: r.children
				}), n.return = t, n.sibling = null, e !== null && (o = t.deletions, o === null ? (t.deletions = [e], t.flags |= 16) : o.push(e)), t.child = n, t.memoizedState = null, n);
			}
			function jr(e, t) {
				return t = Mr({
					mode: "visible",
					children: t
				}, e.mode), t.return = e, e.child = t;
			}
			function Mr(e, n) {
				return e = t(22, e, null, n), e.lanes = 0, e;
			}
			function Nr(e, t, n) {
				return td(t, e.child, null, n), e = jr(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e;
			}
			function Pr(e, t, n, i, a, o, s, c) {
				if (n) return t.flags & 256 ? (It(t), t.flags &= -257, Nr(e, t, c)) : t.memoizedState === null ? (zt(), o = a.fallback, s = t.mode, a = Mr({
					mode: "visible",
					children: a.children
				}, s), o = xo(o, s, c, null), o.flags |= 2, a.return = t, o.return = t, a.sibling = o, t.child = a, td(t, e.child, null, c), a = t.child, a.memoizedState = Or(c), a.childLanes = kr(e, i, c), t.memoizedState = Dd, vr(null, a)) : (zt(), t.child = e.child, t.flags |= 128, null);
				if (It(t), Lc(o)) return i = Rc(o).digest, i !== "" && (a = Error(r(419)), a.stack = "", a.digest = i, Me({
					value: a,
					source: null,
					stack: null
				})), Nr(e, t, c);
				if (H || Le(e, t, c, !1), i = (c & e.childLanes) !== 0, H || i) {
					if (cd.current !== null) return Nr(e, t, c);
					if (i = J, i !== null && (a = ie(i, c), a !== 0 && a !== s.retryLane)) throw s.retryLane = a, bt(e, a), Aa(i, e, a), Ed;
					return Ic(o) || Ha(), Nr(e, t, c);
				}
				return Ic(o) ? (t.flags |= 192, t.child = e.child, null) : (e = s.treeContext, xs && (I = qc(o), F = t, L = !0, Eu = null, Du = !1, e !== null && xe(t, e)), t = jr(t, a.children), t.flags |= 134221824, t);
			}
			function Fr(e, t, n) {
				e.lanes |= t;
				var r = e.alternate;
				r !== null && (r.lanes |= t), Fe(e.return, t, n);
			}
			function Ir(e) {
				for (var t = null; e !== null;) {
					var n = e.alternate;
					n !== null && Ut(n) === null && (t = e), e = e.sibling;
				}
				return t;
			}
			function Lr(e, t, n, r, i, a) {
				var o = e.memoizedState;
				o === null ? e.memoizedState = {
					isBackwards: t,
					rendering: null,
					renderingStartTime: 0,
					last: r,
					tail: n,
					tailMode: i,
					treeForkCount: a
				} : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = i, o.treeForkCount = a);
			}
			function Rr(e) {
				var t = e.child;
				for (e.child = null; t !== null;) {
					var n = t.sibling;
					t.sibling = e.child, e.child = t, t = n;
				}
			}
			function zr(e, t, n) {
				var r = t.pendingProps, i = r.revealOrder, a = r.tail;
				r = r.children;
				var o = fd.current;
				if (t.flags & 128) return Vt(t, o), null;
				var s = !!(o & 2);
				if (s ? (o = o & 1 | 2, t.flags |= 128) : o &= 1, Vt(t, o), i === "backwards" && e !== null ? (Rr(e), O(e, t, r, n), Rr(e)) : O(e, t, r, n), r = L ? gu : 0, !s && e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
					if (e.tag === 13) e.memoizedState !== null && Fr(e, n, t);
					else if (e.tag === 19) Fr(e, n, t);
					else if (e.child !== null) {
						e.child.return = e, e = e.child;
						continue;
					}
					if (e === t) break e;
					for (; e.sibling === null;) {
						if (e.return === null || e.return === t) break e;
						e = e.return;
					}
					e.sibling.return = e.return, e = e.sibling;
				}
				switch (i) {
					case "backwards":
						n = Ir(t.child), n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null, Rr(t)), Lr(t, !0, i, null, a, r);
						break;
					case "unstable_legacy-backwards":
						for (n = null, i = t.child, t.child = null; i !== null;) {
							if (e = i.alternate, e !== null && Ut(e) === null) {
								t.child = i;
								break;
							}
							e = i.sibling, i.sibling = n, n = i, i = e;
						}
						Lr(t, !0, n, null, a, r);
						break;
					case "together":
						Lr(t, !1, null, null, void 0, r);
						break;
					case "independent":
						t.memoizedState = null;
						break;
					default: n = Ir(t.child), n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), Lr(t, !1, i, n, a, r);
				}
				return t.child;
			}
			function Br(e, t, n) {
				var r = t.pendingProps;
				return Ne(t, t.type, r.value), O(e, t, r.children, n), t.child;
			}
			function Vr(e, t, n) {
				if (e !== null && (t.dependencies = e.dependencies), nf |= t.lanes, (n & t.childLanes) === 0) {
					if (e !== null) {
						if (Le(e, t, n, !1), (n & t.childLanes) === 0) return null;
					} else return null;
				}
				if (e !== null && t.child !== e.child) throw Error(r(153));
				if (t.child !== null) {
					for (e = t.child, n = vo(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = vo(e, e.pendingProps), n.return = t;
					n.sibling = null;
				}
				return t.child;
			}
			function Hr(e, t) {
				return (e.lanes & t) !== 0 || (e = e.dependencies, !!(e !== null && Re(e)));
			}
			function Ur(e, t, n) {
				switch (t.tag) {
					case 3:
						Se(t, t.stateNode.containerInfo), Ne(t, R, e.memoizedState.cache), Ae();
						break;
					case 27:
					case 5:
						we(t);
						break;
					case 4:
						Se(t, t.stateNode.containerInfo);
						break;
					case 10:
						Ne(t, t.type, t.memoizedProps.value);
						break;
					case 31:
						if (t.memoizedState !== null) return t.flags |= 128, Lt(t), null;
						break;
					case 13:
						var r = t.memoizedState;
						if (r !== null) {
							if (r.dehydrated !== null) return It(t), t.flags |= 128, null;
							r = Le(e, t, n, !1);
							var i = t.child.childLanes;
							return r || (n & i) !== 0 ? Ar(e, t, n) : (It(t), e = Vr(e, t, n), e === null ? null : e.sibling);
						}
						It(t);
						break;
					case 19:
						if (t.flags & 128) return zr(e, t, n);
						if (i = !!(e.flags & 128), r = (n & t.childLanes) !== 0, r ||= (Le(e, t, n, !1), (n & t.childLanes) !== 0), i) {
							if (r) return zr(e, t, n);
							t.flags |= 128;
						}
						if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), Vt(t, fd.current), r) break;
						return null;
					case 22: return t.lanes = 0, _r(e, t, n, t.pendingProps);
					case 24: Ne(t, R, e.memoizedState.cache);
				}
				return Vr(e, t, n);
			}
			function Wr(e, t, n) {
				if (e !== null) {
					if (e.memoizedProps !== t.pendingProps) H = !0;
					else {
						if (!Hr(e, n) && !(t.flags & 128)) return H = !1, Ur(e, t, n);
						H = !!(e.flags & 131072);
					}
				} else H = !1, L && t.flags & 1048576 && ve(t, gu, t.index);
				switch (t.lanes = 0, t.tag) {
					case 16:
						e: {
							var i = t.pendingProps;
							if (e = ut(t.elementType), t.type = e, typeof e == "function") _o(e) ? (i = sr(e, i), t.tag = 1, t = Er(null, t, e, i, n)) : (t.tag = 0, t = wr(null, t, e, i, n));
							else {
								if (e != null) {
									var a = e.$$typeof;
									if (a === Uo) {
										t.tag = 11, t = mr(null, t, e, i, n);
										break e;
									}
									if (a === Ko) {
										t.tag = 14, t = hr(null, t, e, i, n);
										break e;
									}
									if (a === Ho) {
										t.tag = 10, t.type = e, t = Br(null, t, n);
										break e;
									}
								}
								throw t = u(e) || e, Error(r(306, t, ""));
							}
						}
						return t;
					case 0: return wr(e, t, t.type, t.pendingProps, n);
					case 1: return i = t.type, a = sr(i, t.pendingProps), Er(e, t, i, a, n);
					case 3:
						e: {
							if (Se(t, t.stateNode.containerInfo), e === null) throw Error(r(387));
							var o = t.pendingProps;
							a = t.memoizedState, i = a.element, wt(e, t), At(t, o, null, n);
							var s = t.memoizedState;
							if (o = s.cache, Ne(t, R, o), o !== a.cache && Ie(t, [R], n, !0), kt(), o = s.element, xs && a.isDehydrated) {
								if (a = {
									element: o,
									isDehydrated: !1,
									cache: s.cache
								}, t.updateQueue.baseState = a, t.memoizedState = a, t.flags & 256) {
									t = Dr(e, t, o, n);
									break e;
								}
								if (o !== i) {
									i = he(Error(r(424)), t), Me(i), t = Dr(e, t, o, n);
									break e;
								}
								for (xs && (I = Gc(t.stateNode.containerInfo), F = t, L = !0, Eu = null, Du = !0), n = nd(t, null, o, n), t.child = n; n;) n.flags = n.flags & -3 | 134221824, n = n.sibling;
							} else {
								if (Ae(), o === i) {
									t = Vr(e, t, n);
									break e;
								}
								O(e, t, o, n);
							}
							t = t.child;
						}
						return t;
					case 26: if (vl) return Cr(e, t), e === null ? (n = xl(t.type, null, t.pendingProps, null)) ? t.memoizedState = n : L || (t.stateNode = Dl(t.type, t.pendingProps, wu.current, t)) : t.memoizedState = xl(t.type, e.memoizedProps, t.pendingProps, e.memoizedState), null;
					case 27: if (P) return we(t), e === null && P && L && (i = t.stateNode = Ml(t.type, t.pendingProps, wu.current, Su.current, !1), F = t, Du = !0, I = Jc(t.type, i, I)), O(e, t, t.pendingProps.children, n), Cr(e, t), e === null && (t.flags |= 4194304), t.child;
					case 5: return e === null && L && (gl(t.type, t.pendingProps, Su.current), (a = i = I) && (i = Yc(i, t.type, t.pendingProps, Du), i === null ? a = !1 : (t.stateNode = i, F = t, I = Wc(i), Du = !1, a = !0)), a || Ee(t)), we(t), a = t.type, o = t.pendingProps, s = e === null ? null : e.memoizedProps, i = o.children, ms(a, o) ? i = null : s !== null && ms(a, s) && (t.flags |= 32), t.memoizedState !== null && (a = Gt(e, t, Jt, null, null, n), ys ? Rs._currentValue = a : Rs._currentValue2 = a), Cr(e, t), O(e, t, i, n), t.child;
					case 6: return e === null && L && (_l(t.pendingProps, Su.current), (e = n = I) && (n = Xc(n, t.pendingProps, Du), n === null ? e = !1 : (t.stateNode = n, F = t, I = null, e = !0)), e || Ee(t)), null;
					case 13: return Ar(e, t, n);
					case 4: return Se(t, t.stateNode.containerInfo), i = t.pendingProps, e === null ? t.child = td(t, null, i, n) : O(e, t, i, n), t.child;
					case 11: return mr(e, t, t.type, t.pendingProps, n);
					case 7: return i = t.pendingProps, Cr(e, t), O(e, t, i, n), t.child;
					case 8: return O(e, t, t.pendingProps.children, n), t.child;
					case 12: return O(e, t, t.pendingProps.children, n), t.child;
					case 10: return Br(e, t, n);
					case 9: return a = t.type._context, i = t.pendingProps.children, ze(t), a = w(a), i = i(a), t.flags |= 1, O(e, t, i, n), t.child;
					case 14: return hr(e, t, t.type, t.pendingProps, n);
					case 15: return gr(e, t, t.type, t.pendingProps, n);
					case 19: return zr(e, t, n);
					case 31: return Sr(e, t, n);
					case 22: return _r(e, t, n, t.pendingProps);
					case 24: return ze(t), i = w(R), e === null ? (a = it(), a === null && (a = J, o = He(), a.pooledCache = o, o.refCount++, o !== null && (a.pooledCacheLanes |= n), a = o), t.memoizedState = {
						parent: i,
						cache: a
					}, Ct(t), Ne(t, R, a)) : ((e.lanes & n) !== 0 && (wt(e, t), At(t, null, null, n), kt()), a = e.memoizedState, o = t.memoizedState, a.parent === i ? (i = o.cache, Ne(t, R, i), i !== a.cache && Ie(t, [R], n, !0)) : (a = {
						parent: i,
						cache: i
					}, t.memoizedState = a, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = a), Ne(t, R, i))), O(e, t, t.pendingProps.children, n), t.child;
					case 30: return t.stateNode === null && (t.stateNode = {
						autoName: null,
						paired: null,
						clones: null,
						ref: null
					}), i = t.pendingProps, i.name != null && i.name !== "auto" ? t.flags |= e === null ? 18882560 : 18874368 : L && ye(t), e !== null && e.memoizedProps.name !== i.name ? t.flags |= 4194816 : Cr(e, t), O(e, t, i.children, n), t.child;
					case 29: throw t.pendingProps;
				}
				throw Error(r(156, t.tag));
			}
			function Gr(e) {
				e.flags |= 4;
			}
			function Kr(e) {
				bs && (e.flags |= 8);
			}
			function qr(e, t) {
				if (e !== null && e.child === t.child) return !1;
				if (t.flags & 16) return !0;
				for (e = t.child; e !== null;) {
					if (e.flags & 8218 || e.subtreeFlags & 8218) return !0;
					e = e.sibling;
				}
				return !1;
			}
			function Jr(e, t, n, r) {
				if (N) for (n = t.child; n !== null;) {
					if (n.tag === 5 || n.tag === 6) fs(e, n.stateNode);
					else if (!(n.tag === 4 || P && n.tag === 27) && n.child !== null) {
						n.child.return = n, n = n.child;
						continue;
					}
					if (n === t) break;
					for (; n.sibling === null;) {
						if (n.return === null || n.return === t) return;
						n = n.return;
					}
					n.sibling.return = n.return, n = n.sibling;
				}
				else if (bs) for (var i = t.child; i !== null;) {
					if (i.tag === 5) {
						var a = i.stateNode;
						n && r && (a = Pc(a, i.type, i.memoizedProps)), fs(e, a);
					} else if (i.tag === 6) a = i.stateNode, n && r && (a = Fc(a, i.memoizedProps)), fs(e, a);
					else if (i.tag !== 4) {
						if (i.tag === 22 && i.memoizedState !== null) a = i.child, a !== null && (a.return = i), Jr(e, i, !0, !0);
						else if (i.child !== null) {
							i.child.return = i, i = i.child;
							continue;
						}
					}
					if (i === t) break;
					for (; i.sibling === null;) {
						if (i.return === null || i.return === t) return;
						i = i.return;
					}
					i.sibling.return = i.return, i = i.sibling;
				}
			}
			function Yr(e, t, n, r) {
				var i = !1;
				if (bs) for (var a = t.child; a !== null;) {
					if (a.tag === 5) {
						var o = a.stateNode;
						n && r && (o = Pc(o, a.type, a.memoizedProps)), jc(e, o);
					} else if (a.tag === 6) o = a.stateNode, n && r && (o = Fc(o, a.memoizedProps)), jc(e, o);
					else if (a.tag !== 4) {
						if (a.tag === 22 && a.memoizedState !== null) i = a.child, i !== null && (i.return = a), Yr(e, a, !0, !0), i = !0;
						else if (a.child !== null) {
							a.child.return = a, a = a.child;
							continue;
						}
					}
					if (a === t) break;
					for (; a.sibling === null;) {
						if (a.return === null || a.return === t) return i;
						a = a.return;
					}
					a.sibling.return = a.return, a = a.sibling;
				}
				return i;
			}
			function Xr(e, t) {
				if (bs && qr(e, t)) {
					e = t.stateNode;
					var n = e.containerInfo, r = Ac();
					Yr(r, t, !1, !1), e.pendingChildren = r, Gr(t), Mc(n, r);
				}
			}
			function Zr(e, t, n, r) {
				if (N) e.memoizedProps !== r && Gr(t);
				else if (bs) {
					var i = e.stateNode, a = e.memoizedProps;
					if ((e = qr(e, t)) || a !== r) {
						var o = Su.current;
						a = kc(i, n, a, r, !e, null), a === i ? t.stateNode = i : (Kr(t), ps(a, n, r, o) && Gr(t), t.stateNode = a, e && Jr(a, t, !1, !1));
					} else t.stateNode = i;
				}
			}
			function Qr(e, t, n, r, i) {
				if (e.mode & 32 && (n === null ? ks(t, r) : As(t, n, r))) {
					if (e.flags |= 16777216, (i & 335544128) === i || js(t, r)) {
						if (Ms(e.stateNode, t, r)) e.flags |= 8192;
						else if (za()) e.flags |= 8192;
						else throw Qu = Zu, Yu;
					}
				} else e.flags &= -16777217;
			}
			function $r(e, t) {
				if (kl(t)) {
					if (e.flags |= 16777216, !Al(t)) {
						if (za()) e.flags |= 8192;
						else throw Qu = Zu, Yu;
					}
				} else e.flags &= -16777217;
			}
			function ei(e, t) {
				t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag === 22 ? 536870912 : te(), e.lanes |= t, sf |= t);
			}
			function ti(e, t) {
				if (!L) switch (e.tailMode) {
					case "visible": break;
					case "collapsed":
						for (var n = e.tail, r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
						r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null;
						break;
					default:
						for (t = e.tail, n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
						n === null ? e.tail = null : n.sibling = null;
				}
			}
			function k(e) {
				var t = e.alternate !== null && e.alternate.child === e.child, n = 0, r = 0;
				if (t) for (var i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags & 1206910976, r |= i.flags & 1206910976, i.return = e, i = i.sibling;
				else for (i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
				return e.subtreeFlags |= r, e.childLanes = n, t;
			}
			function ni(e, t, n) {
				var i = t.pendingProps;
				switch (be(t), t.tag) {
					case 16:
					case 15:
					case 0:
					case 11:
					case 7:
					case 8:
					case 12:
					case 9:
					case 14: return k(t), null;
					case 1: return k(t), null;
					case 3: return n = t.stateNode, i = null, e !== null && (i = e.memoizedState.cache), t.memoizedState.cache !== i && (t.flags |= 2048), Pe(R), Ce(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (e === null || e.child === null) && (ke(t) ? Gr(t) : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, je())), Xr(e, t), k(t), null;
					case 26: if (vl) {
						var a = t.type, o = t.memoizedState;
						return e === null ? (Gr(t), o === null ? (k(t), Qr(t, a, null, i, n)) : (k(t), $r(t, o))) : o ? o === e.memoizedState ? (k(t), t.flags &= -16777217) : (Gr(t), k(t), $r(t, o)) : (o = e.memoizedProps, N ? o !== i && Gr(t) : Zr(e, t, a, i), k(t), Qr(t, a, o, i, n)), null;
					}
					case 27: if (P) {
						if (Te(t), n = wu.current, a = t.type, e !== null && t.stateNode != null) N ? e.memoizedProps !== i && Gr(t) : Zr(e, t, a, i);
						else {
							if (!i) {
								if (t.stateNode === null) throw Error(r(166));
								return k(t), t.subtreeFlags &= -33554433, null;
							}
							e = Su.current, ke(t) ? De(t, e) : (e = Ml(a, i, n, e, !0), t.stateNode = e, Gr(t));
						}
						return k(t), t.subtreeFlags &= -33554433, null;
					}
					case 5:
						if (Te(t), a = t.type, e !== null && t.stateNode != null) Zr(e, t, a, i);
						else {
							if (!i) {
								if (t.stateNode === null) throw Error(r(166));
								return k(t), t.subtreeFlags &= -33554433, null;
							}
							if (o = Su.current, ke(t)) De(t, o), ll(t.stateNode, a, i, o) && (t.flags |= 64);
							else {
								var s = ds(a, i, wu.current, o, t);
								Kr(t), Jr(s, t, !1, !1), t.stateNode = s, ps(s, a, i, o) && Gr(t);
							}
						}
						return k(t), t.subtreeFlags &= -33554433, Qr(t, t.type, e === null ? null : e.memoizedProps, t.pendingProps, n), null;
					case 6:
						if (e && t.stateNode != null) n = e.memoizedProps, N ? n !== i && Gr(t) : bs && (n === i ? t.stateNode = e.stateNode : (e = wu.current, n = Su.current, Kr(t), t.stateNode = hs(i, e, n, t)));
						else {
							if (typeof i != "string" && t.stateNode === null) throw Error(r(166));
							if (e = wu.current, n = Su.current, ke(t)) {
								if (!xs) throw Error(r(176));
								if (e = t.stateNode, n = t.memoizedProps, i = null, a = F, a !== null) switch (a.tag) {
									case 27:
									case 5: i = a.memoizedProps;
								}
								el(e, n, t, i) || Ee(t, !0);
							} else Kr(t), t.stateNode = hs(i, e, n, t);
						}
						return k(t), null;
					case 31:
						if (n = t.memoizedState, e === null || e.memoizedState !== null) {
							if (i = ke(t), n !== null) {
								if (e === null) {
									if (!i) throw Error(r(318));
									if (!xs) throw Error(r(556));
									if (e = t.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(r(557));
									tl(e, t);
								} else Ae(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
								k(t), e = !1;
							} else n = je(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = n), e = !0;
							if (!e) return t.flags & 256 ? (Bt(t), t) : (Bt(t), null);
							if (t.flags & 128) throw Error(r(558));
						}
						return k(t), null;
					case 13:
						if (i = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
							if (a = ke(t), i !== null && i.dehydrated !== null) {
								if (e === null) {
									if (!a) throw Error(r(318));
									if (!xs) throw Error(r(344));
									if (a = t.memoizedState, a = a === null ? null : a.dehydrated, !a) throw Error(r(317));
									nl(a, t);
								} else Ae(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
								k(t), a = !1;
							} else a = je(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = a), a = !0;
							if (!a) return t.flags & 256 ? (Bt(t), t) : (Bt(t), null);
						}
						return Bt(t), t.flags & 128 ? (t.lanes = n, t) : (n = i !== null, e = e !== null && e.memoizedState !== null, n && (i = t.child, a = null, i.alternate !== null && i.alternate.memoizedState !== null && i.alternate.memoizedState.cachePool !== null && (a = i.alternate.memoizedState.cachePool.pool), o = null, i.memoizedState !== null && i.memoizedState.cachePool !== null && (o = i.memoizedState.cachePool.pool), o !== a && (i.flags |= 2048)), n !== e && n && (t.child.flags |= 8192), ei(t, t.updateQueue), k(t), null);
					case 4: return Ce(), Xr(e, t), e === null && Cs(t.stateNode.containerInfo), t.flags |= 67108864, k(t), null;
					case 10: return Pe(t.type), k(t), null;
					case 19:
						if (Ht(t), i = t.memoizedState, i === null) return k(t), null;
						if (a = !!(t.flags & 128), o = i.rendering, o === null) {
							if (a) ti(i, !1);
							else {
								if (Q !== 0 || e !== null && e.flags & 128) for (e = t.child; e !== null;) {
									if (o = Ut(e), o !== null) {
										for (t.flags |= 128, ti(i, !1), e = o.updateQueue, t.updateQueue = e, ei(t, e), t.subtreeFlags = 0, e = n, n = t.child; n !== null;) yo(n, e), n = n.sibling;
										return Vt(t, fd.current & 1 | 2), L && _e(t, i.treeForkCount), t.child;
									}
									e = e.sibling;
								}
								i.tail !== null && Xl() > pf && (t.flags |= 128, a = !0, ti(i, !1), t.lanes = 4194304);
							}
						} else {
							if (!a) {
								if (e = Ut(o), e !== null) {
									if (t.flags |= 128, a = !0, e = e.updateQueue, t.updateQueue = e, ei(t, e), ti(i, !0), i.tail === null && i.tailMode !== "collapsed" && i.tailMode !== "visible" && !o.alternate && !L) return k(t), null;
								} else 2 * Xl() - i.renderingStartTime > pf && n !== 536870912 && (t.flags |= 128, a = !0, ti(i, !1), t.lanes = 4194304);
							}
							i.isBackwards ? (o.sibling = t.child, t.child = o) : (e = i.last, e === null ? t.child = o : e.sibling = o, i.last = o);
						}
						if (i.tail !== null) {
							e = i.tail;
							e: {
								for (n = e; n !== null;) {
									if (n.alternate !== null) {
										n = !1;
										break e;
									}
									n = n.sibling;
								}
								n = !0;
							}
							return i.rendering = e, i.tail = e.sibling, i.renderingStartTime = Xl(), e.sibling = null, o = fd.current, o = a ? o & 1 | 2 : o & 1, i.tailMode === "visible" || i.tailMode === "collapsed" || !n || L ? Vt(t, o) : (n = o, p(ud, t), p(fd, n), dd === null && (dd = t)), L && _e(t, i.treeForkCount), e;
						}
						return k(t), null;
					case 22:
					case 23: return Bt(t), Ft(), i = t.memoizedState !== null, e === null ? i && (t.flags |= 8192) : e.memoizedState !== null !== i && (t.flags |= 8192), i ? n & 536870912 && !(t.flags & 128) && (k(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : k(t), n = t.updateQueue, n !== null && ei(t, n.retryQueue), n = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), i = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (i = t.memoizedState.cachePool.pool), i !== n && (t.flags |= 2048), e !== null && f(qu), null;
					case 24: return n = null, e !== null && (n = e.memoizedState.cache), t.memoizedState.cache !== n && (t.flags |= 2048), Pe(R), k(t), null;
					case 25: return null;
					case 30: return t.flags |= 33554432, k(t), null;
				}
				throw Error(r(156, t.tag));
			}
			function ri(e, t) {
				switch (be(t), t.tag) {
					case 1: return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
					case 3: return Pe(R), Ce(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
					case 26:
					case 27:
					case 5: return Te(t), null;
					case 31:
						if (t.memoizedState !== null) {
							if (Bt(t), t.alternate === null) throw Error(r(340));
							Ae();
						}
						return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
					case 13:
						if (Bt(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
							if (t.alternate === null) throw Error(r(340));
							Ae();
						}
						return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
					case 19: return Ht(t), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, e = t.memoizedState, e !== null && (e.rendering = null, e.tail = null), t.flags |= 4, t) : null;
					case 4: return Ce(), null;
					case 10: return Pe(t.type), null;
					case 22:
					case 23: return Bt(t), Ft(), e !== null && f(qu), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
					case 24: return Pe(R), null;
					case 25: return null;
					default: return null;
				}
			}
			function ii(e, t) {
				switch (be(t), t.tag) {
					case 3:
						Pe(R), Ce();
						break;
					case 26:
					case 27:
					case 5:
						Te(t);
						break;
					case 4:
						Ce();
						break;
					case 31:
						t.memoizedState !== null && Bt(t);
						break;
					case 13:
						Bt(t);
						break;
					case 19:
						Ht(t);
						break;
					case 10:
						Pe(t.type);
						break;
					case 22:
					case 23:
						Bt(t), Ft(), e !== null && f(qu);
						break;
					case 24: Pe(R);
				}
			}
			function ai(e, t) {
				try {
					var n = t.updateQueue, r = n === null ? null : n.lastEffect;
					if (r !== null) {
						var i = r.next;
						n = i;
						do {
							if ((n.tag & e) === e) {
								r = void 0;
								var a = n.create, o = n.inst;
								r = a(), o.destroy = r;
							}
							n = n.next;
						} while (n !== i);
					}
				} catch (e) {
					A(t, t.return, e);
				}
			}
			function oi(e, t, n) {
				try {
					var r = t.updateQueue, i = r === null ? null : r.lastEffect;
					if (i !== null) {
						var a = i.next;
						r = a;
						do {
							if ((r.tag & e) === e) {
								var o = r.inst, s = o.destroy;
								if (s !== void 0) {
									o.destroy = void 0, i = t;
									var c = n, l = s;
									try {
										l();
									} catch (e) {
										A(i, c, e);
									}
								}
							}
							r = r.next;
						} while (r !== a);
					}
				} catch (e) {
					A(t, t.return, e);
				}
			}
			function si(e) {
				var t = e.updateQueue;
				if (t !== null) {
					var n = e.stateNode;
					try {
						Mt(t, n);
					} catch (t) {
						A(e, e.return, t);
					}
				}
			}
			function ci(e, t, n) {
				n.props = sr(e.type, e.memoizedProps), n.state = e.memoizedState;
				try {
					n.componentWillUnmount();
				} catch (n) {
					A(e, t, n);
				}
			}
			function li(e, t) {
				try {
					var n = e.ref;
					if (n !== null) {
						switch (e.tag) {
							case 26:
							case 27:
							case 5:
								var r = os(e.stateNode);
								break;
							case 30:
								var i = e.stateNode, a = ce(e.memoizedProps, i);
								(i.ref === null || i.ref.name !== a) && (i.ref = Cc(a)), r = i.ref;
								break;
							case 7:
								e.stateNode === null && (e.stateNode = Tc(e)), r = e.stateNode;
								break;
							default: r = e.stateNode;
						}
						typeof n == "function" ? e.refCleanup = n(r) : n.current = r;
					}
				} catch (n) {
					A(e, t, n);
				}
			}
			function ui(e, t) {
				var n = e.ref, r = e.refCleanup;
				if (n !== null) {
					if (typeof r == "function") try {
						r();
					} catch (n) {
						A(e, t, n);
					} finally {
						e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null);
					}
					else if (typeof n == "function") try {
						n(null);
					} catch (n) {
						A(e, t, n);
					}
					else n.current = null;
				}
			}
			function di() {
				var e = Od;
				return Od = !1, e;
			}
			function fi(e, t) {
				if ((e.tag === 5 || e.tag === 27 || e.tag === 6) && e.alternate === null && t !== null) for (var n = 0; n < t.length; n++) Dc(e.stateNode, t[n]);
			}
			function pi(e) {
				for (var t = e.return; t !== null && (gi(t) && Dc(e.stateNode, t.stateNode), !hi(t));) t = t.return;
			}
			function mi(e) {
				for (var t = e.return; t !== null && (gi(t) && Oc(e.stateNode, t.stateNode), !hi(t));) t = t.return;
			}
			function hi(e) {
				return e.tag === 5 || e.tag === 3 || (P ? e.tag === 27 : !1);
			}
			function gi(e) {
				return e && e.tag === 7 && e.stateNode !== null;
			}
			function _i(e) {
				var t = e.type, n = e.memoizedProps, r = e.stateNode;
				try {
					$s(r, t, n, e);
				} catch (t) {
					A(e, e.return, t);
				}
			}
			function vi(e, t, n) {
				try {
					ec(e.stateNode, e.type, n, t, e);
				} catch (t) {
					A(e, e.return, t);
				}
			}
			function yi(e) {
				return e.tag === 5 || e.tag === 3 || (vl ? e.tag === 26 : !1) || (P ? e.tag === 27 && Il(e.type) : !1) || e.tag === 4;
			}
			function bi(e) {
				e: for (;;) {
					for (; e.sibling === null;) {
						if (e.return === null || yi(e.return)) return null;
						e = e.return;
					}
					for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
						if (P && e.tag === 27 && Il(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue e;
						e.child.return = e, e = e.child;
					}
					if (!(e.flags & 2)) return e.stateNode;
				}
			}
			function xi(e, t, n, r) {
				var i = e.tag;
				if (i === 5 || i === 6) i = e.stateNode, t ? nc(n, i, t) : Zs(n, i), fi(e, r), Od = !0;
				else if (i !== 4 && (P && i === 27 && (fi(e, r), r = null, Il(e.type) && (n = e.stateNode, t = null)), e = e.child, e !== null)) for (xi(e, t, n, r), e = e.sibling; e !== null;) xi(e, t, n, r), e = e.sibling;
			}
			function Si(e, t, n, r) {
				var i = e.tag;
				if (i === 5 || i === 6) i = e.stateNode, t ? tc(n, i, t) : Xs(n, i), fi(e, r), Od = !0;
				else if (i !== 4 && (P && i === 27 && (fi(e, r), r = null, Il(e.type) && (n = e.stateNode)), e = e.child, e !== null)) for (Si(e, t, n, r), e = e.sibling; e !== null;) Si(e, t, n, r), e = e.sibling;
			}
			function Ci(e, t) {
				if (e.tag === 5 || P && e.tag === 27) fi(e, t);
				else if (e.tag !== 4 && (e = e.child, e !== null)) for (Ci(e, t), e = e.sibling; e !== null;) Ci(e, t), e = e.sibling;
			}
			function wi(e, t, n) {
				e = e.containerInfo;
				try {
					Nc(e, n);
				} catch (e) {
					A(t, t.return, e);
				}
			}
			function Ti(e) {
				var t = e.stateNode, n = e.memoizedProps;
				try {
					Nl(e.type, n, t, e);
				} catch (t) {
					A(e, e.return, t);
				}
			}
			function Ei(e) {
				(e.tag === 30 || e.subtreeFlags & 33554432) && (kd = !0);
			}
			function Di() {
				var e = jd;
				return jd = null, e;
			}
			function Oi(e, t, n, r, i) {
				return Md = 0, ki(e.child, t, n, r, i);
			}
			function ki(e, t, n, r, i) {
				if (!N) return !1;
				for (var a = !1; e !== null;) {
					if (e.tag === 5) {
						var o = e.stateNode;
						if (r !== null) {
							var s = hc(o);
							r.push(s), _c(s) && (a = !0);
						} else a || _c(hc(o)) && (a = !0);
						kd = !0, uc(o, Md === 0 ? t : t + "_" + Md, n), Md++;
					} else (e.tag !== 22 || e.memoizedState === null) && (e.tag === 30 && i || ki(e.child, t, n, r, i) && (a = !0));
					e = e.sibling;
				}
				return a;
			}
			function Ai(e, t) {
				if (N) for (; e !== null;) e.tag === 5 ? dc(e.stateNode, e.memoizedProps) : (e.tag !== 22 || e.memoizedState === null) && (e.tag === 30 && t || Ai(e.child, t)), e = e.sibling;
			}
			function ji(e) {
				if (e.subtreeFlags & 18874368) for (e = e.child; e !== null;) {
					if ((e.tag !== 22 || e.memoizedState === null) && (ji(e), e.tag === 30 && e.flags & 18874368 && e.stateNode.paired)) {
						var t = e.memoizedProps;
						if (t.name == null || t.name === "auto") throw Error(r(544));
						var n = t.name;
						t = C(t.default, t.share), t !== "none" && (Oi(e, n, t, null, !1) || Ai(e.child, !1));
					}
					e = e.sibling;
				}
			}
			function Mi(e, t) {
				if (e.tag === 30) {
					var n = e.stateNode, r = e.memoizedProps, i = ce(r, n), a = C(r.default, n.paired ? r.share : r.enter);
					a === "none" ? ji(e) : Oi(e, i, a, null, !1) ? (ji(e), n.paired || t || ka(e, r.onEnter)) : Ai(e.child, !1);
				} else if (e.subtreeFlags & 33554432) for (e = e.child; e !== null;) Mi(e, t), e = e.sibling;
				else ji(e);
			}
			function Ni(e) {
				if (Ad !== null && Ad.size !== 0) {
					var t = Ad;
					if (e.subtreeFlags & 18874368) for (e = e.child; e !== null;) {
						if (e.tag !== 22 || e.memoizedState === null) {
							if (e.tag === 30 && e.flags & 18874368) {
								var n = e.memoizedProps, r = n.name;
								if (r != null && r !== "auto") {
									var i = t.get(r);
									if (i !== void 0) {
										var a = C(n.default, n.share);
										if (a !== "none" && (Oi(e, r, a, null, !1) ? (a = e.stateNode, i.paired = a, a.paired = i, ka(e, n.onShare)) : Ai(e.child, !1)), t.delete(r), t.size === 0) break;
									}
								}
							}
							Ni(e);
						}
						e = e.sibling;
					}
				}
			}
			function Pi(e) {
				if (e.tag === 30) {
					var t = e.memoizedProps, n = ce(t, e.stateNode), r = Ad === null ? void 0 : Ad.get(n), i = C(t.default, r === void 0 ? t.exit : t.share);
					i !== "none" && (Oi(e, n, i, null, !1) ? r === void 0 ? ka(e, t.onExit) : (i = e.stateNode, r.paired = i, i.paired = r, Ad.delete(n), ka(e, t.onShare)) : Ai(e.child, !1)), Ad !== null && Ni(e);
				} else if (e.subtreeFlags & 33554432) for (e = e.child; e !== null;) Pi(e), e = e.sibling;
				else Ad !== null && Ni(e);
			}
			function Fi(e) {
				for (e = e.child; e !== null;) {
					if (e.tag === 30) {
						var t = e.memoizedProps, n = ce(t, e.stateNode);
						t = C(t.default, t.update), e.flags &= -5, t !== "none" && Oi(e, n, t, e.memoizedState = [], !1);
					} else e.subtreeFlags & 33554432 && Fi(e);
					e = e.sibling;
				}
			}
			function Ii(e) {
				if (e.subtreeFlags & 18874368) for (e = e.child; e !== null;) {
					if (e.tag !== 22 || e.memoizedState === null) {
						if (e.tag === 30 && e.flags & 18874368) {
							var t = e.stateNode;
							t.paired !== null && (t.paired = null, Ai(e.child, !1));
						}
						Ii(e);
					}
					e = e.sibling;
				}
			}
			function Li(e) {
				if (e.tag === 30) e.stateNode.paired = null, Ai(e.child, !1), Ii(e);
				else if (e.subtreeFlags & 33554432) for (e = e.child; e !== null;) Li(e), e = e.sibling;
				else Ii(e);
			}
			function Ri(e) {
				for (e = e.child; e !== null;) e.tag === 30 ? Ai(e.child, !1) : e.subtreeFlags & 33554432 && Ri(e), e = e.sibling;
			}
			function zi(e, t, n, r, i, a, o) {
				if (!N) return !1;
				for (var s = !1; t !== null;) {
					if (t.tag === 5) {
						var c = t.stateNode;
						if (a !== null && Md < a.length) {
							var l = a[Md], u = hc(c);
							(_c(l) || _c(u)) && (s = !0), !(e.flags & 4) && vc(l, u) && (e.flags |= 4), yc(l, u) && (e.flags |= 32);
						} else e.flags |= 32;
						e.flags & 4 && uc(c, Md === 0 ? n : n + "_" + Md, i), s && e.flags & 4 || (jd === null && (jd = []), jd.push(c, Md === 0 ? r : r + "_" + Md, t.memoizedProps)), Md++;
					} else (t.tag !== 22 || t.memoizedState === null) && (t.tag === 30 && o ? e.flags |= t.flags & 32 : zi(e, t.child, n, r, i, a, o) && (s = !0));
					t = t.sibling;
				}
				return s;
			}
			function Bi(e, t) {
				for (e = e.child; e !== null;) {
					if (e.tag === 30) {
						var n = e.memoizedProps, r = e.stateNode, i = ce(n, r), a = C(n.default, n.update);
						if (t) {
							r = r.clones;
							var o = r === null ? null : r.map(gc);
						} else o = e.memoizedState, e.memoizedState = null;
						r = e;
						var s = e.child;
						Md = 0, i = zi(r, s, i, i, a, o, !1), e.flags & 4 && i && (t || ka(e, n.onUpdate));
					} else e.subtreeFlags & 33554432 && Bi(e, t);
					e = e.sibling;
				}
			}
			function Vi(e, t, n) {
				for (ls(e.containerInfo), e = (n & 335544064) === n, G = t, t = e ? 9270 : 1024; G !== null;) {
					if (n = G, e) {
						var r = n.deletions;
						if (r !== null) for (var i = 0; i < r.length; i++) e && Pi(r[i]);
					}
					if (n.alternate === null && n.flags & 2) e && Ei(n), Hi(e);
					else {
						if (n.tag === 22) {
							if (r = n.alternate, n.memoizedState !== null) {
								r !== null && r.memoizedState === null && e && Pi(r), Hi(e);
								continue;
							}
							if (r !== null && r.memoizedState !== null) {
								e && Ei(n), Hi(e);
								continue;
							}
						}
						r = n.child, (n.subtreeFlags & t) !== 0 && r !== null ? (r.return = n, G = r) : (e && Fi(n), Hi(e));
					}
				}
				Ad = null;
			}
			function Hi(e) {
				for (; G !== null;) {
					var t = G, n = e, i = t.alternate, a = t.flags;
					switch (t.tag) {
						case 0:
						case 11:
						case 15: break;
						case 1:
							if (a & 1024 && i !== null) {
								n = void 0, a = i.memoizedProps, i = i.memoizedState;
								var o = t.stateNode;
								try {
									var s = sr(t.type, a);
									n = o.getSnapshotBeforeUpdate(s, i), o.__reactInternalSnapshotBeforeUpdate = n;
								} catch (e) {
									A(t, t.return, e);
								}
							}
							break;
						case 3:
							a & 1024 && N && wc(t.stateNode.containerInfo);
							break;
						case 5:
						case 26:
						case 27:
						case 6:
						case 4:
						case 17: break;
						case 30:
							n && i !== null && (n = ce(i.memoizedProps, i.stateNode), a = t.memoizedProps, a = C(a.default, a.update), a !== "none" && Oi(i, n, a, i.memoizedState = [], !0));
							break;
						default: if (a & 1024) throw Error(r(163));
					}
					if (i = t.sibling, i !== null) {
						i.return = t.return, G = i;
						break;
					}
					G = t.return;
				}
			}
			function Ui(e, t, n) {
				var r = n.flags;
				switch (n.tag) {
					case 0:
					case 11:
					case 15:
						oa(e, n), r & 4 && ai(5, n);
						break;
					case 1:
						if (oa(e, n), r & 4) {
							if (e = n.stateNode, t === null) try {
								e.componentDidMount();
							} catch (e) {
								A(n, n.return, e);
							}
							else {
								var i = sr(n.type, t.memoizedProps);
								t = t.memoizedState;
								try {
									e.componentDidUpdate(i, t, e.__reactInternalSnapshotBeforeUpdate);
								} catch (e) {
									A(n, n.return, e);
								}
							}
						}
						r & 64 && si(n), r & 512 && li(n, n.return);
						break;
					case 3:
						if (oa(e, n), r & 64 && (r = n.updateQueue, r !== null)) {
							if (e = null, n.child !== null) switch (n.child.tag) {
								case 27:
								case 5:
									e = os(n.child.stateNode);
									break;
								case 1: e = n.child.stateNode;
							}
							try {
								Mt(r, e);
							} catch (e) {
								A(n, n.return, e);
							}
						}
						break;
					case 27: P && t === null && r & 4 && Ti(n);
					case 26:
					case 5:
						if (oa(e, n), t === null) {
							if (r & 4) _i(n);
							else if (r & 64) {
								e = n.type, t = n.memoizedProps, i = n.stateNode;
								try {
									al(i, e, t, n);
								} catch (e) {
									A(n, n.return, e);
								}
							}
						}
						r & 512 && li(n, n.return);
						break;
					case 12:
						oa(e, n);
						break;
					case 31:
						oa(e, n), r & 4 && Xi(e, n);
						break;
					case 13:
						oa(e, n), r & 4 && Zi(e, n), r & 64 && (r = n.memoizedState, r !== null && (r = r.dehydrated, r !== null && (n = po.bind(null, n), zc(r, n))));
						break;
					case 22:
						if (r = n.memoizedState !== null || U, !r) {
							var a = t !== null && t.memoizedState !== null || W;
							t = U, i = W, U = r, (W = a) && !i ? (r = P ? 2 : 0, n.subtreeFlags & 8772 && (r |= 1), ca(e, n, r)) : oa(e, n), U = t, W = i;
						}
						break;
					case 30:
						oa(e, n), r & 512 && li(n, n.return);
						break;
					case 7: r & 512 && li(n, n.return);
					default: oa(e, n);
				}
			}
			function Wi(e, t) {
				if (N) for (e = e.child; e !== null;) Gi(e, t), e = e.sibling;
			}
			function Gi(e, t) {
				if (N) switch (e.tag) {
					case 5:
					case 26:
						try {
							var n = e.stateNode;
							t ? oc(n) : cc(e.stateNode, e.memoizedProps);
						} catch (t) {
							A(e, e.return, t);
						}
						Ki(e, t);
						break;
					case 6:
						try {
							var r = e.stateNode;
							t ? sc(r) : lc(r, e.memoizedProps), Od = !0;
						} catch (t) {
							A(e, e.return, t);
						}
						break;
					case 18:
						try {
							var i = e.stateNode;
							t ? pl(i) : ml(e.stateNode);
						} catch (t) {
							A(e, e.return, t);
						}
						break;
					case 22:
					case 23:
						e.memoizedState === null && Wi(e, t);
						break;
					default: Wi(e, t);
				}
			}
			function Ki(e, t) {
				if (N && e.subtreeFlags & 67108864) for (e = e.child; e !== null;) {
					var n = e, r = t;
					if (N) switch (n.tag) {
						case 4:
							Gi(n, r);
							break;
						case 22:
							n.memoizedState === null && Ki(n, r);
							break;
						default: Ki(n, r);
					}
					e = e.sibling;
				}
			}
			function qi(e) {
				var t = e.alternate;
				t !== null && (e.alternate = null, qi(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && Os(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
			}
			function Ji(e, t, n) {
				for (n = n.child; n !== null;) Yi(e, t, n), n = n.sibling;
			}
			function Yi(e, t, n) {
				if (iu && typeof iu.onCommitFiberUnmount == "function") try {
					iu.onCommitFiberUnmount(ru, n);
				} catch {}
				switch (n.tag) {
					case 26: if (vl) {
						W || ui(n, t), Ji(e, t, n), n.memoizedState ? Cl(n.memoizedState) : n.stateNode && (W || El(n.stateNode));
						break;
					}
					case 27: if (P) {
						W || ui(n, t), mi(n);
						var r = K, i = Bd;
						Il(n.type) && (K = n.stateNode, Bd = !1), Ji(e, t, n), Pl(n.stateNode, n.type, n.memoizedProps), K = r, Bd = i;
						break;
					}
					case 5: W || ui(n, t), mi(n);
					case 6:
						if (n.tag === 6 && mi(n), N) {
							if (r = K, i = Bd, K = null, Ji(e, t, n), K = r, Bd = i, K !== null) {
								if (Bd) try {
									ic(K, n.stateNode), Od = !0;
								} catch (e) {
									A(n, t, e);
								}
								else try {
									rc(K, n.stateNode), Od = !0;
								} catch (e) {
									A(n, t, e);
								}
							}
						} else Ji(e, t, n);
						break;
					case 18:
						N && K !== null && (Bd ? fl(K, n.stateNode) : dl(K, n.stateNode));
						break;
					case 4:
						N ? (r = K, i = Bd, K = n.stateNode.containerInfo, Bd = !0, Ji(e, t, n), K = r, Bd = i) : (bs && wi(n.stateNode, n, Ac()), Ji(e, t, n));
						break;
					case 0:
					case 11:
					case 14:
					case 15:
						oi(2, n, t), W || oi(4, n, t), Ji(e, t, n);
						break;
					case 1:
						W || (ui(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function" && ci(n, t, r)), Ji(e, t, n);
						break;
					case 21:
						Ji(e, t, n);
						break;
					case 22:
						W = (r = W) || n.memoizedState !== null, Ji(e, t, n), W = r;
						break;
					case 30:
						ui(n, t), Ji(e, t, n);
						break;
					case 7:
						W || ui(n, t), Ji(e, t, n);
						break;
					default: Ji(e, t, n);
				}
			}
			function Xi(e, t) {
				if (xs && t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null))) {
					e = e.dehydrated;
					try {
						sl(e);
					} catch (e) {
						A(t, t.return, e);
					}
				}
			}
			function Zi(e, t) {
				if (xs && t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null)))) try {
					cl(e);
				} catch (e) {
					A(t, t.return, e);
				}
			}
			function Qi(e) {
				switch (e.tag) {
					case 31:
					case 13:
					case 19:
						var t = e.stateNode;
						return t === null && (t = e.stateNode = new Fd()), t;
					case 22: return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new Fd()), t;
					default: throw Error(r(435, e.tag));
				}
			}
			function $i(e, t) {
				var n = Qi(e);
				t.forEach(function(t) {
					if (!n.has(t)) {
						n.add(t);
						var r = mo.bind(null, e, t);
						t.then(r, r);
					}
				});
			}
			function ea(e, t, n) {
				var i = t.deletions;
				if (i !== null) for (var a = 0; a < i.length; a++) {
					var o = i[a], s = e, c = t;
					if (N) {
						var l = c;
						e: for (; l !== null;) {
							switch (l.tag) {
								case 27: if (P) {
									if (Il(l.type)) {
										K = l.stateNode, Bd = !1;
										break e;
									}
									break;
								}
								case 5:
									K = l.stateNode, Bd = !1;
									break e;
								case 3:
								case 4:
									K = l.stateNode.containerInfo, Bd = !0;
									break e;
							}
							l = l.return;
						}
						if (K === null) throw Error(r(160));
						Yi(s, c, o), K = null, Bd = !1;
					} else Yi(s, c, o);
					s = o.alternate, s !== null && (s.return = null), o.return = null;
				}
				if (t.subtreeFlags & 13886) for (t = t.child; t !== null;) ta(t, e, n), t = t.sibling;
			}
			function ta(e, t, n) {
				var i = e.alternate, a = e.flags;
				switch (e.tag) {
					case 0:
					case 11:
					case 14:
					case 15:
						if (a & 4 && (i = e.updateQueue, i = i === null ? null : i.events, i !== null)) for (var o = 0; o < i.length; o++) {
							var s = i[o];
							s.ref.impl = s.nextImpl;
						}
						ea(t, e, n), na(e), a & 4 && (oi(3, e, e.return), ai(3, e), oi(5, e, e.return));
						break;
					case 1:
						ea(t, e, n), na(e), a & 512 && (W || i === null || ui(i, i.return)), a & 64 && U && (e = e.updateQueue, e !== null && (t = e.callbacks, t !== null && (a = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = a === null ? t : a.concat(t))));
						break;
					case 26: if (vl) {
						o = Vd, ea(t, e, n), na(e), a & 512 && (W || i === null || ui(i, i.return)), a & 4 && (n = i === null ? null : i.memoizedState, a = e.memoizedState, i === null ? a === null ? e.stateNode === null ? e.stateNode = U ? Dl(e.type, e.memoizedProps, t.containerInfo, e) : wl(o, e.type, e.memoizedProps, e) : U || Tl(o, e.type, e.stateNode) : e.stateNode = Sl(o, a, e.memoizedProps) : n === a ? a === null && e.stateNode !== null && vi(e, e.memoizedProps, i.memoizedProps) : (n === null ? (t = i.stateNode, t === null || W || El(t)) : Cl(n), a === null ? U || Tl(o, e.type, e.stateNode) : Sl(o, a, e.memoizedProps)));
						break;
					}
					case 27: if (P) {
						ea(t, e, n), na(e), a & 512 && (W || i === null || ui(i, i.return)), i !== null && a & 4 && vi(e, e.memoizedProps, i.memoizedProps);
						break;
					}
					case 5:
						if (o = Nd, Nd = !1, ea(t, e, n), Nd = o, na(e), a & 512 && (W || i === null || ui(i, i.return)), N) {
							if (e.flags & 32) {
								t = e.stateNode;
								try {
									ac(t), Od = !0;
								} catch (t) {
									A(e, e.return, t);
								}
							}
							a & 4 && e.stateNode != null && (t = e.memoizedProps, vi(e, t, i === null ? t : i.memoizedProps)), a & 1024 && (Pd = !0);
						} else bs && e.alternate !== null && (e.alternate.stateNode = e.stateNode);
						break;
					case 6:
						if (ea(t, e, n), na(e), a & 4 && N) {
							if (e.stateNode === null) throw Error(r(162));
							t = e.memoizedProps, a = i === null ? t : i.memoizedProps, n = e.stateNode;
							try {
								Qs(n, a, t), Od = !0;
							} catch (t) {
								A(e, e.return, t);
							}
						}
						break;
					case 3:
						if (Od = !1, vl ? (Ol(), o = Vd, Vd = bl(t.containerInfo), ea(t, e, n), Vd = o) : ea(t, e, n), na(e), a & 4) {
							if (N && xs && i !== null && i.memoizedState.isDehydrated) try {
								ol(t.containerInfo);
							} catch (t) {
								A(e, e.return, t);
							}
							if (bs) {
								a = t.containerInfo, t = t.pendingChildren;
								try {
									Nc(a, t), Od = !0;
								} catch (t) {
									A(e, e.return, t);
								}
							}
						}
						Pd && (Pd = !1, ra(e)), Od = !1;
						break;
					case 4:
						i = Nd, Nd = U, o = di(), vl ? (s = Vd, Vd = bl(e.stateNode.containerInfo), ea(t, e, n), na(e), Vd = s) : (ea(t, e, n), na(e)), Od && Ld && (Rd = !0), Od = o, Nd = i, a & 4 && bs && wi(e.stateNode, e, e.stateNode.pendingChildren);
						break;
					case 12:
						ea(t, e, n), na(e);
						break;
					case 31:
						ea(t, e, n), na(e), a & 4 && (t = e.updateQueue, t !== null && (e.updateQueue = null, $i(e, t)));
						break;
					case 13:
						ea(t, e, n), na(e), e.child.flags & 8192 && e.memoizedState !== null != (i !== null && i.memoizedState !== null) && (df = Xl()), a & 4 && (t = e.updateQueue, t !== null && (e.updateQueue = null, $i(e, t)));
						break;
					case 22:
						o = e.memoizedState !== null, s = i !== null && i.memoizedState !== null;
						var c = U, l = W, u = Nd;
						U = c || o, Nd = u || o, W = l || s, ea(t, e, n), W = l, Nd = u, U = c, na(e), a & 8192 && (t = e.stateNode, t._visibility = o ? t._visibility & -2 : t._visibility | 1, !o || i === null || s || U || W || (t = P ? 2 : 0, n = s || W, i = U, s = W, U = o || U, W = n, sa(e, t), U = i, W = s), N && (o || !Nd) && Wi(e, o)), a & 4 && (t = e.updateQueue, t !== null && (a = t.retryQueue, a !== null && (t.retryQueue = null, $i(e, a))));
						break;
					case 19:
						ea(t, e, n), na(e), a & 4 && (t = e.updateQueue, t !== null && (e.updateQueue = null, $i(e, t)));
						break;
					case 30:
						a & 512 && (W || i === null || ui(i, i.return)), a = di(), o = Ld, s = (n & 335544064) === n, c = e.memoizedProps, Ld = s && C(c.default, c.update) !== "none", ea(t, e, n), na(e), s && i !== null && Od && (e.flags |= 4), Ld = o, Od = a;
						break;
					case 21: break;
					case 7: a & 512 && (W || i === null || ui(i, i.return)), i && i.stateNode !== null && Ec(e, i.stateNode);
					default: ea(t, e, n), na(e);
				}
			}
			function na(e) {
				var t = e.flags;
				if (t & 2) {
					try {
						for (var n, i = e.return; i !== null;) {
							if (yi(i)) {
								n = i;
								break;
							}
							i = i.return;
						}
						i = null;
						for (var a = e.return; a !== null;) {
							if (gi(a)) {
								var o = a.stateNode;
								i === null ? i = [o] : i.push(o);
							}
							if (hi(a)) break;
							a = a.return;
						}
						var s = i;
						if (N) {
							if (n == null) throw Error(r(160));
							switch (n.tag) {
								case 27: if (P) {
									var c = n.stateNode;
									Si(e, bi(e), c, s);
									break;
								}
								case 5:
									var l = n.stateNode;
									n.flags & 32 && (ac(l), n.flags &= -33), Si(e, bi(e), l, s);
									break;
								case 3:
								case 4:
									var u = n.stateNode.containerInfo;
									xi(e, bi(e), u, s);
									break;
								default: throw Error(r(161));
							}
						} else Ci(e, s);
					} catch (t) {
						A(e, e.return, t);
					}
					e.flags &= -3;
				}
				t & 4096 && (e.flags &= -4097);
			}
			function ra(e) {
				if (e.subtreeFlags & 1024) for (e = e.child; e !== null;) {
					var t = e;
					ra(t), t.tag === 5 && t.flags & 1024 && zs(t.stateNode), e = e.sibling;
				}
			}
			function ia(e, t) {
				if (t.subtreeFlags & 9270) for (t = t.child; t !== null;) aa(t, e), t = t.sibling;
				else Bi(t, !1);
			}
			function aa(e, t) {
				var n = e.alternate;
				if (n === null) Mi(e, !1);
				else switch (e.tag) {
					case 3:
						if (zd = Id = !1, Di(), ia(t, e), !Id && !Rd) {
							if (e = jd, e !== null) for (var r = 0; r < e.length; r += 3) fc(e[r], e[r + 1], e[r + 2]);
							pc(t.containerInfo), zd = !0;
						}
						jd = null;
						break;
					case 5:
						ia(t, e);
						break;
					case 4:
						r = Id, Id = !1, ia(t, e), Id && (Rd = !0), Id = r;
						break;
					case 22:
						e.memoizedState === null && (n.memoizedState === null ? ia(t, e) : Mi(e, !1));
						break;
					case 30:
						r = Id;
						var i = Di();
						Id = !1, ia(t, e), Id && (e.flags |= 4);
						var a = e.memoizedProps, o = e.stateNode;
						t = ce(a, o), o = ce(n.memoizedProps, o);
						var s = C(a.default, a.update);
						s === "none" ? n = !1 : (a = n.memoizedState, n.memoizedState = null, n = e.child, Md = 0, n = zi(e, n, t, o, s, a, !0), Md !== (a === null ? 0 : a.length) && (e.flags |= 32)), e.flags & 4 && n ? (ka(e, e.memoizedProps.onUpdate), jd = i) : i !== null && (i.push.apply(i, jd), jd = i), Id = e.flags & 32 ? !0 : r;
						break;
					default: ia(t, e);
				}
			}
			function oa(e, t) {
				if (t.subtreeFlags & 8772) for (t = t.child; t !== null;) Ui(e, t.alternate, t), t = t.sibling;
			}
			function sa(e, t) {
				for (e = e.child; e !== null;) {
					var n = e, r = t;
					switch (n.tag) {
						case 0:
						case 11:
						case 14:
						case 15:
							oi(4, n, n.return), sa(n, r);
							break;
						case 1:
							ui(n, n.return);
							var i = n.stateNode;
							typeof i.componentWillUnmount == "function" && ci(n, n.return, i), sa(n, r);
							break;
						case 27: P && r & 2 && Pl(n.stateNode, n.type, n.memoizedProps);
						case 5:
							ui(n, n.return), n.tag !== 5 && n.tag !== 27 || mi(n), sa(n, r);
							break;
						case 6:
							mi(n);
							break;
						case 26:
							ui(n, n.return), vl && (i = n.stateNode, n.memoizedState !== null || i === null || W || El(i)), sa(n, r);
							break;
						case 22:
							n.memoizedState === null && sa(n, r);
							break;
						case 30:
							ui(n, n.return), sa(n, r);
							break;
						case 7: ui(n, n.return);
						default: sa(n, r);
					}
					e = e.sibling;
				}
			}
			function ca(e, t, n) {
				for (n = t.subtreeFlags & 8772 ? n : n & -2, t = t.child; t !== null;) {
					var r = t.alternate, i = e, a = t, o = a.flags, s = !!(n & 1);
					switch (a.tag) {
						case 0:
						case 11:
						case 15:
							ca(i, a, n), ai(4, a);
							break;
						case 1:
							if (ca(i, a, n), r = a, i = r.stateNode, typeof i.componentDidMount == "function") try {
								i.componentDidMount();
							} catch (e) {
								A(r, r.return, e);
							}
							if (r = a, i = r.updateQueue, i !== null) {
								var c = r.stateNode;
								try {
									var l = i.shared.hiddenCallbacks;
									if (l !== null) for (i.shared.hiddenCallbacks = null, i = 0; i < l.length; i++) jt(l[i], c);
								} catch (e) {
									A(r, r.return, e);
								}
							}
							s && o & 64 && si(a), li(a, a.return);
							break;
						case 27: P && n & 2 && Ti(a);
						case 5:
							a.tag !== 5 && a.tag !== 27 || pi(a), ca(i, a, n), s && r === null && o & 4 && _i(a), li(a, a.return);
							break;
						case 6:
							pi(a);
							break;
						case 26:
							vl && (c = a.stateNode, a.memoizedState !== null || c === null || U || Tl(bl(c.ownerDocument), a.type, c)), ca(i, a, n), s && r === null && o & 4 && _i(a), li(a, a.return);
							break;
						case 12:
							ca(i, a, n);
							break;
						case 31:
							ca(i, a, n), s && o & 4 && Xi(i, a);
							break;
						case 13:
							ca(i, a, n), s && o & 4 && Zi(i, a);
							break;
						case 22:
							a.memoizedState === null && ca(i, a, n), li(a, a.return);
							break;
						case 30:
							ca(i, a, n), li(a, a.return);
							break;
						case 7: li(a, a.return);
						default: ca(i, a, n);
					}
					t = t.sibling;
				}
			}
			function la(e, t) {
				var n = null;
				e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== n && (e != null && e.refCount++, n != null && Ue(n));
			}
			function ua(e, t) {
				e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && Ue(e));
			}
			function da(e, t, n, r) {
				var i = (n & 335544064) === n;
				if (t.subtreeFlags & (i ? 10262 : 10256)) for (t = t.child; t !== null;) fa(e, t, n, r), t = t.sibling;
				else i && Ri(t);
			}
			function fa(e, t, n, r) {
				var i = (n & 335544064) === n;
				i && t.alternate === null && t.return !== null && t.return.alternate !== null && Li(t);
				var a = t.flags;
				switch (t.tag) {
					case 0:
					case 11:
					case 15:
						da(e, t, n, r), a & 2048 && ai(9, t);
						break;
					case 1:
						da(e, t, n, r);
						break;
					case 3:
						da(e, t, n, r), i && N && zd && mc(e.containerInfo), a & 2048 && (e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && Ue(e)));
						break;
					case 12:
						if (a & 2048) {
							da(e, t, n, r), e = t.stateNode;
							try {
								var o = t.memoizedProps, s = o.id, c = o.onPostCommit;
								typeof c == "function" && c(s, t.alternate === null ? "mount" : "update", e.passiveEffectDuration, -0);
							} catch (e) {
								A(t, t.return, e);
							}
						} else da(e, t, n, r);
						break;
					case 31:
						da(e, t, n, r);
						break;
					case 13:
						da(e, t, n, r);
						break;
					case 23: break;
					case 22:
						o = t.stateNode, s = t.alternate, t.memoizedState === null ? (i && s !== null && s.memoizedState !== null && Li(t), o._visibility & 2 ? da(e, t, n, r) : (o._visibility |= 2, pa(e, t, n, r, !!(t.subtreeFlags & 10256) || !1))) : (i && s !== null && s.memoizedState === null && Li(s), o._visibility & 2 ? da(e, t, n, r) : ma(e, t)), a & 2048 && la(s, t);
						break;
					case 24:
						da(e, t, n, r), a & 2048 && ua(t.alternate, t);
						break;
					case 30:
						i && (i = t.alternate, i !== null && (Ai(i.child, !0), Ai(t.child, !0))), da(e, t, n, r);
						break;
					default: da(e, t, n, r);
				}
			}
			function pa(e, t, n, r, i) {
				for (i &&= !!(t.subtreeFlags & 10256) || !1, t = t.child; t !== null;) {
					var a = e, o = t, s = n, c = r, l = o.flags;
					switch (o.tag) {
						case 0:
						case 11:
						case 15:
							pa(a, o, s, c, i), ai(8, o);
							break;
						case 23: break;
						case 22:
							var u = o.stateNode;
							o.memoizedState === null ? (u._visibility |= 2, pa(a, o, s, c, i)) : u._visibility & 2 ? pa(a, o, s, c, i) : ma(a, o), i && l & 2048 && la(o.alternate, o);
							break;
						case 24:
							pa(a, o, s, c, i), i && l & 2048 && ua(o.alternate, o);
							break;
						default: pa(a, o, s, c, i);
					}
					t = t.sibling;
				}
			}
			function ma(e, t) {
				if (t.subtreeFlags & 10256) for (t = t.child; t !== null;) {
					var n = e, r = t, i = r.flags;
					switch (r.tag) {
						case 22:
							ma(n, r), i & 2048 && la(r.alternate, r);
							break;
						case 24:
							ma(n, r), i & 2048 && ua(r.alternate, r);
							break;
						default: ma(n, r);
					}
					t = t.sibling;
				}
			}
			function ha(e, t, n) {
				if (e.subtreeFlags & Hd) for (e = e.child; e !== null;) ga(e, t, n), e = e.sibling;
			}
			function ga(e, t, n) {
				switch (e.tag) {
					case 26:
						if (ha(e, t, n), e.flags & Hd) {
							if (e.memoizedState !== null) jl(n, Vd, e.memoizedState, e.memoizedProps);
							else {
								var r = e.stateNode, i = e.type;
								e = e.memoizedProps, ((t & 335544128) === t || js(i, e)) && Ps(n, r, i, e);
							}
						}
						break;
					case 5:
						ha(e, t, n), e.flags & Hd && (r = e.stateNode, i = e.type, e = e.memoizedProps, ((t & 335544128) === t || js(i, e)) && Ps(n, r, i, e));
						break;
					case 3:
					case 4:
						vl ? (r = Vd, Vd = bl(e.stateNode.containerInfo), ha(e, t, n), Vd = r) : ha(e, t, n);
						break;
					case 22:
						e.memoizedState === null && (r = e.alternate, r !== null && r.memoizedState !== null ? (r = Hd, Hd = 16777216, ha(e, t, n), Hd = r) : ha(e, t, n));
						break;
					case 30:
						(e.flags & Hd) !== 0 && (r = e.memoizedProps.name, r != null && r !== "auto" && (i = e.stateNode, i.paired = null, Ad === null && (Ad = /* @__PURE__ */ new Map()), Ad.set(r, i))), ha(e, t, n);
						break;
					default: ha(e, t, n);
				}
			}
			function _a(e) {
				var t = e.alternate;
				if (t !== null && (e = t.child, e !== null)) {
					t.child = null;
					do
						t = e.sibling, e.sibling = null, e = t;
					while (e !== null);
				}
			}
			function va(e) {
				var t = e.deletions;
				if (e.flags & 16) {
					if (t !== null) for (var n = 0; n < t.length; n++) {
						var r = t[n];
						G = r, xa(r, e);
					}
					_a(e);
				}
				if (e.subtreeFlags & 10256) for (e = e.child; e !== null;) ya(e), e = e.sibling;
			}
			function ya(e) {
				switch (e.tag) {
					case 0:
					case 11:
					case 15:
						va(e), e.flags & 2048 && oi(9, e, e.return);
						break;
					case 3:
						va(e);
						break;
					case 12:
						va(e);
						break;
					case 22:
						var t = e.stateNode;
						e.memoizedState !== null && t._visibility & 2 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -3, ba(e)) : va(e);
						break;
					default: va(e);
				}
			}
			function ba(e) {
				var t = e.deletions;
				if (e.flags & 16) {
					if (t !== null) for (var n = 0; n < t.length; n++) {
						var r = t[n];
						G = r, xa(r, e);
					}
					_a(e);
				}
				for (e = e.child; e !== null;) {
					switch (t = e, t.tag) {
						case 0:
						case 11:
						case 15:
							oi(8, t, t.return), ba(t);
							break;
						case 22:
							n = t.stateNode, n._visibility & 2 && (n._visibility &= -3, ba(t));
							break;
						default: ba(t);
					}
					e = e.sibling;
				}
			}
			function xa(e, t) {
				for (; G !== null;) {
					var n = G;
					switch (n.tag) {
						case 0:
						case 11:
						case 15:
							oi(8, n, t);
							break;
						case 23:
						case 22:
							if (n.memoizedState !== null && n.memoizedState.cachePool !== null) {
								var r = n.memoizedState.cachePool.pool;
								r != null && r.refCount++;
							}
							break;
						case 24: Ue(n.memoizedState.cache);
					}
					if (r = n.child, r !== null) r.return = n, G = r;
					else e: for (n = e; G !== null;) {
						r = G;
						var i = r.sibling, a = r.return;
						if (qi(r), r === n) {
							G = null;
							break e;
						}
						if (i !== null) {
							i.return = a, G = i;
							break e;
						}
						G = a;
					}
				}
			}
			function Sa(e) {
				var t = Ss(e);
				if (t != null) {
					if (typeof t.memoizedProps["data-testname"] != "string") throw Error(r(364));
					return t;
				}
				if (e = Us(e), e === null) throw Error(r(362));
				return e.stateNode.current;
			}
			function Ca(e, t) {
				var n = e.tag;
				switch (t.$$typeof) {
					case Wd:
						if (e.type === t.value) return !0;
						break;
					case Gd:
						e: {
							for (t = t.value, e = [e, 0], n = 0; n < e.length;) {
								var i = e[n++], a = i.tag, o = e[n++], s = t[o];
								if (a !== 5 && a !== 26 && a !== 27 || !Ks(i)) {
									for (; s != null && Ca(i, s);) o++, s = t[o];
									if (o === t.length) {
										t = !0;
										break e;
									}
									for (i = i.child; i !== null;) e.push(i, o), i = i.sibling;
								}
							}
							t = !1;
						}
						return t;
					case Kd:
						if ((n === 5 || n === 26 || n === 27) && qs(e.stateNode, t.value)) return !0;
						break;
					case Jd:
						if ((n === 5 || n === 6 || n === 26 || n === 27) && (e = Gs(e), e !== null && 0 <= e.indexOf(t.value))) return !0;
						break;
					case qd:
						if ((n === 5 || n === 26 || n === 27) && (e = e.memoizedProps["data-testname"], typeof e == "string" && e.toLowerCase() === t.value.toLowerCase())) return !0;
						break;
					default: throw Error(r(365));
				}
				return !1;
			}
			function wa(e) {
				switch (e.$$typeof) {
					case Wd: return "<" + (u(e.value) || "Unknown") + ">";
					case Gd: return ":has(" + (wa(e) || "") + ")";
					case Kd: return "[role=\"" + e.value + "\"]";
					case Jd: return "\"" + e.value + "\"";
					case qd: return "[data-testname=\"" + e.value + "\"]";
					default: throw Error(r(365));
				}
			}
			function Ta(e, t) {
				var n = [];
				e = [e, 0];
				for (var r = 0; r < e.length;) {
					var i = e[r++], a = i.tag, o = e[r++], s = t[o];
					if (a !== 5 && a !== 26 && a !== 27 || !Ks(i)) {
						for (; s != null && Ca(i, s);) o++, s = t[o];
						if (o === t.length) n.push(i);
						else for (i = i.child; i !== null;) e.push(i, o), i = i.sibling;
					}
				}
				return n;
			}
			function Ea(e, t) {
				if (!Hs) throw Error(r(363));
				e = Sa(e), e = Ta(e, t), t = [], e = Array.from(e);
				for (var n = 0; n < e.length;) {
					var i = e[n++], a = i.tag;
					if (a === 5 || a === 26 || a === 27) Ks(i) || t.push(i.stateNode);
					else for (i = i.child; i !== null;) e.push(i), i = i.sibling;
				}
				return t;
			}
			function Da() {
				return q & 2 && X !== 0 ? X & -X : M.T === null ? Es() : et();
			}
			function Oa() {
				if (of === 0) {
					if (!(X & 536870912) || L) {
						var e = Wl;
						Wl <<= 1, !(Wl & 3932160) && (Wl = 262144), of = e;
					} else of = 536870912;
				}
				return e = ud.current, e !== null && (e.flags |= 32), of;
			}
			function ka(e, t) {
				if (t != null) {
					var n = e.stateNode, r = n.ref;
					r === null && (r = n.ref = Cc(ce(e.memoizedProps, n))), Cf === null && (Cf = []), Cf.push(t.bind(null, r));
				}
			}
			function Aa(e, t, n) {
				(e === J && (Z === 2 || Z === 9) || e.cancelPendingCommit !== null) && (La(e, 0), Pa(e, X, of, !1)), y(e, n), (!(q & 2) || e !== J) && (e === J && (!(q & 2) && (rf |= n), Q === 4 && Pa(e, X, of, !1)), Ke(e));
			}
			function ja(e, t, n) {
				if (q & 6) throw Error(r(327));
				var i = !n && !(t & 127) && (t & e.expiredLanes) === 0 || _(e, t), a = i ? Ga(e, t) : Ua(e, t, !0), o = i;
				do {
					if (a === 0) {
						$d && !i && Pa(e, t, 0, !1);
						break;
					}
					if (n = e.current.alternate, o && !Na(n)) {
						a = Ua(e, t, !1), o = !1;
						continue;
					}
					if (a === 2) {
						if (o = t, e.errorRecoveryDisabledLanes & o) var s = 0;
						else s = e.pendingLanes & -536870913, s = s === 0 ? s & 536870912 ? 536870912 : 0 : s;
						if (s !== 0) {
							t = s;
							e: {
								var c = e;
								a = cf;
								var l = xs && c.current.memoizedState.isDehydrated;
								if (l && (La(c, s).flags |= 256), s = Ua(c, s, !1), s !== 2 && s !== 6) {
									if (ef && !l) {
										c.errorRecoveryDisabledLanes |= o, rf |= o, a = 4;
										break e;
									}
									o = lf, lf = a, o !== null && (lf === null ? lf = o : lf.push.apply(lf, o));
								}
								a = s;
							}
							if (o = !1, a !== 2) continue;
						}
					}
					if (a === 1) {
						La(e, 0), Pa(e, t, 0, !0);
						break;
					}
					e: {
						switch (i = e, o = a, o) {
							case 0:
							case 1: throw Error(r(345));
							case 4: if ((t & 4194048) !== t && (t & 62914560) !== t) break;
							case 6:
								Pa(i, t, of, !Qd);
								break e;
							case 2:
								lf = null;
								break;
							case 3:
							case 5: break;
							default: throw Error(r(329));
						}
						if ((t & 62914560) === t && (a = df + 300 - Xl(), 10 < a)) {
							if (Pa(i, t, of, !Qd), g(i, 0, !0) !== 0) break e;
							vf = t, i.timeoutHandle = gs(Ma.bind(null, i, n, lf, mf, uf, t, of, rf, sf, Qd, o, "Throttled", -0, 0), a);
							break e;
						}
						Ma(i, n, lf, mf, uf, t, of, rf, sf, Qd, o, null, -0, 0);
					}
					break;
				} while (1);
				Ke(e);
			}
			function Ma(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
				e.timeoutHandle = vs;
				var m = t.subtreeFlags, h = (a & 335544064) === a;
				if (d = null, (h || m & 8192 || (m & 16785408) == 16785408) && (d = Ns(), Ad = null, ga(t, a, d), h && Fs(d, e.containerInfo), m = (a & 62914560) === a ? df - Xl() : (a & 4194048) === a ? ff - Xl() : 0, m = Is(d, m), m !== null)) {
					vf = a, e.cancelPendingCommit = m(Qa.bind(null, e, t, a, n, r, i, o, s, c, l, u, d, null, f, p)), Pa(e, a, o, !l);
					return;
				}
				Qa(e, t, a, n, r, i, o, s, c, l, u, d);
			}
			function Na(e) {
				for (var t = e;;) {
					var n = t.tag;
					if ((n === 0 || n === 11 || n === 15) && t.flags & 16384 && (n = t.updateQueue, n !== null && (n = n.stores, n !== null))) for (var r = 0; r < n.length; r++) {
						var i = n[r], a = i.getSnapshot;
						i = i.value;
						try {
							if (!ou(a(), i)) return !1;
						} catch {
							return !1;
						}
					}
					if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
					else {
						if (t === e) break;
						for (; t.sibling === null;) {
							if (t.return === null || t.return === e) return !0;
							t = t.return;
						}
						t.sibling.return = t.return, t = t.sibling;
					}
				}
				return !0;
			}
			function Pa(e, t, n, r) {
				t = v(e, t), t &= ~af, t &= ~rf, e.suspendedLanes |= t, e.pingedLanes &= ~t, r && (e.warmLanes |= t), r = e.expirationTimes;
				for (var i = t; 0 < i;) {
					var a = 31 - Bl(i), o = 1 << a;
					r[a] = -1, i &= ~o;
				}
				n !== 0 && b(e, n, t);
			}
			function Fa() {
				return q & 6 ? !0 : (qe(0, !1), !1);
			}
			function Ia() {
				if (Y !== null) {
					if (Z === 0) var e = Y.return;
					else e = Y, ju = Au = null, Zt(e), $u = null, ed = 0, e = Y;
					for (; e !== null;) ii(e.alternate, e), e = e.return;
					Y = null;
				}
			}
			function La(e, t) {
				var n = e.timeoutHandle;
				return n !== vs && (e.timeoutHandle = vs, _s(n)), n = e.cancelPendingCommit, n !== null && (e.cancelPendingCommit = null, n()), vf = 0, Ia(), J = e, Y = n = vo(e.current, null), X = t, Z = 0, Zd = null, Qd = !1, $d = _(e, t), ef = !1, sf = of = af = rf = nf = Q = 0, lf = cf = null, uf = !1, tf = v(e, t), _t(), n;
			}
			function Ra(e, t) {
				z = null, M.H = xd, t === Ju || t === Xu ? (t = dt(), Z = 3) : t === Yu ? (t = dt(), Z = 4) : Z = t === Ed ? 8 : typeof t == "object" && t && typeof t.then == "function" ? 6 : 1, Zd = t, Y === null && (Q = 1, cr(e, he(t, e.current)));
			}
			function za() {
				var e = ud.current;
				return e === null ? !0 : (X & 4194048) === X ? dd === null : (X & 62914560) === X || X & 536870912 ? e === dd : !1;
			}
			function Ba() {
				var e = M.H;
				return M.H = xd, e === null ? xd : e;
			}
			function Va() {
				var e = M.A;
				return M.A = Ud, e;
			}
			function Ha() {
				Q = 4, Qd || (X & 4194048) !== X && ud.current !== null || ($d = !0), !(nf & 134217727) && !(rf & 134217727) || J === null || Pa(J, X, of, !1);
			}
			function Ua(e, t, n) {
				var r = q;
				q |= 2;
				var i = Ba(), a = Va();
				(J !== e || X !== t) && (mf = null, La(e, t)), t = !1;
				var o = Q;
				e: do
					try {
						if (Z !== 0 && Y !== null) {
							var s = Y, c = Zd;
							switch (Z) {
								case 8:
									Ia(), o = 6;
									break e;
								case 3:
								case 2:
								case 9:
								case 6:
									ud.current === null && (t = !0);
									var l = Z;
									if (Z = 0, Zd = null, Ya(e, s, c, l), n && $d) {
										o = 0;
										break e;
									}
									break;
								default: l = Z, Z = 0, Zd = null, Ya(e, s, c, l);
							}
						}
						Wa(), o = Q;
						break;
					} catch (t) {
						Ra(e, t);
					}
				while (1);
				return t && e.shellSuspendCounter++, ju = Au = null, q = r, M.H = i, M.A = a, Y === null && (J = null, X = 0, _t()), o;
			}
			function Wa() {
				for (; Y !== null;) qa(Y);
			}
			function Ga(e, t) {
				var n = q;
				q |= 2;
				var i = Ba(), a = Va();
				J !== e || X !== t ? (mf = null, pf = Xl() + 500, La(e, t)) : $d = _(e, t);
				e: do
					try {
						if (Z !== 0 && Y !== null) {
							t = Y;
							var o = Zd;
							n: switch (Z) {
								case 1:
									Z = 0, Zd = null, Ya(e, t, o, 1);
									break;
								case 2:
								case 9:
									if (ct(o)) {
										Z = 0, Zd = null, Ja(t);
										break;
									}
									t = function() {
										Z !== 2 && Z !== 9 || J !== e || (Z = 7), Ke(e);
									}, o.then(t, t);
									break e;
								case 3:
									Z = 7;
									break e;
								case 4:
									Z = 5;
									break e;
								case 7:
									ct(o) ? (Z = 0, Zd = null, Ja(t)) : (Z = 0, Zd = null, Ya(e, t, o, 7));
									break;
								case 5:
									var s = null;
									switch (Y.tag) {
										case 26: s = Y.memoizedState;
										case 5:
										case 27:
											var c = Y, l = c.type, u = c.pendingProps;
											if (s ? Al(s) : Ms(c.stateNode, l, u)) {
												Z = 0, Zd = null;
												var d = c.sibling;
												if (d !== null) Y = d;
												else {
													var f = c.return;
													f === null ? Y = null : (Y = f, Xa(f));
												}
												break n;
											}
									}
									Z = 0, Zd = null, Ya(e, t, o, 5);
									break;
								case 6:
									Z = 0, Zd = null, Ya(e, t, o, 6);
									break;
								case 8:
									Ia(), Q = 6;
									break e;
								default: throw Error(r(462));
							}
						}
						Ka();
						break;
					} catch (t) {
						Ra(e, t);
					}
				while (1);
				return ju = Au = null, M.H = i, M.A = a, q = n, Y === null ? (J = null, X = 0, _t(), Q) : 0;
			}
			function Ka() {
				for (; Y !== null && !Jl();) qa(Y);
			}
			function qa(e) {
				var t = Wr(e.alternate, e, tf);
				e.memoizedProps = e.pendingProps, t === null ? Xa(e) : Y = t;
			}
			function Ja(e) {
				var t = e, n = t.alternate;
				switch (t.tag) {
					case 15:
					case 0:
						t = Tr(n, t, t.pendingProps, t.type, void 0, X);
						break;
					case 11:
						t = Tr(n, t, t.pendingProps, t.type.render, t.ref, X);
						break;
					case 5:
						Zt(t);
						var r = t;
						xs && r === F && (L ? (Oe(r), r.tag === 5 && r.stateNode != null && (I = r.stateNode)) : (Oe(r), L = !0));
					default: ii(n, t), t = Y = yo(t, tf), t = Wr(n, t, tf);
				}
				e.memoizedProps = e.pendingProps, t === null ? Xa(e) : Y = t;
			}
			function Ya(e, t, n, r) {
				ju = Au = null, Zt(t), $u = null, ed = 0;
				var i = t.return;
				try {
					if (pr(e, i, t, n, X)) {
						Q = 1, cr(e, he(n, e.current)), Y = null;
						return;
					}
				} catch (t) {
					if (i !== null) throw Y = i, t;
					Q = 1, cr(e, he(n, e.current)), Y = null;
					return;
				}
				t.flags & 32768 ? (L || r === 1 ? e = !0 : $d || X & 536870912 ? e = !1 : (Qd = e = !0, (r === 2 || r === 9 || r === 3 || r === 6) && (r = ud.current, r !== null && r.tag === 13 && (r.flags |= 16384))), Za(t, e)) : Xa(t);
			}
			function Xa(e) {
				var t = e;
				do {
					if (t.flags & 32768) {
						Za(t, Qd);
						return;
					}
					e = t.return;
					var n = ni(t.alternate, t, tf);
					if (n !== null) {
						Y = n;
						return;
					}
					if (t = t.sibling, t !== null) {
						Y = t;
						return;
					}
					Y = t = e;
				} while (t !== null);
				Q === 0 && (Q = 5);
			}
			function Za(e, t) {
				do {
					var n = ri(e.alternate, e);
					if (n !== null) {
						n.flags &= 32767, Y = n;
						return;
					}
					if (n = e.return, n !== null && (n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null), !t && (e = e.sibling, e !== null)) {
						Y = e;
						return;
					}
					Y = e = n;
				} while (e !== null);
				Q = 6, Y = null;
			}
			function Qa(e, t, n, i, a, o, s, c, l, u, d, f) {
				e.cancelPendingCommit = null;
				do
					oo();
				while ($ !== 0);
				if (q & 6) throw Error(r(327));
				if (t !== null) {
					if (t === e.current) throw Error(r(177));
					e === J && (Y = J = null, X = 0), _f = t, gf = e, vf = n, bf = a, xf = i, $a(e, t, n, s, c, l, f);
				}
			}
			function $a(e, t, n, r, i, a, o) {
				var s = t.lanes | t.childLanes;
				if (yf = s, s |= ad, re(e, n, s, r, i, a), Cf = null, (n & 335544064) === n ? (wf = We(e), r = 10262) : (wf = null, r = 10256), (t.subtreeFlags & r) !== 0 || (t.flags & r) !== 0 ? (e.callbackNode = null, e.callbackPriority = 0, ho($l, function() {
					return so(), null;
				})) : (e.callbackNode = null, e.callbackPriority = 0), kd = !1, r = !!(t.flags & 13878), t.subtreeFlags & 13878 || r) {
					r = M.T, M.T = null, i = Ts(), ws(2), a = q, q |= 4;
					try {
						Vi(e, t, n);
					} finally {
						q = a, ws(i), M.T = r;
					}
				}
				$ = 1, kd ? Sf = bc(o, e.containerInfo, wf, no, ro, to, io, so, eo, null, null) : (no(), ro(), io());
			}
			function eo(e) {
				if ($ !== 0) {
					var t = gf.onRecoverableError;
					t(e, { componentStack: null });
				}
			}
			function to() {
				$ === 3 && ($ = 0, aa(_f, gf), $ = 4);
			}
			function no() {
				if ($ === 1) {
					$ = 0;
					var e = gf, t = _f, n = vf, r = !!(t.flags & 13878);
					if (t.subtreeFlags & 13878 || r) {
						r = M.T, M.T = null;
						var i = Ts();
						ws(2);
						var a = q;
						q |= 4;
						try {
							Ld = Rd = !1, ta(t, e, n), us(e.containerInfo);
						} finally {
							q = a, ws(i), M.T = r;
						}
					}
					e.current = t, $ = 2;
				}
			}
			function ro() {
				if ($ === 2) {
					$ = 0;
					var e = gf, t = _f, n = !!(t.flags & 8772);
					if (t.subtreeFlags & 8772 || n) {
						n = M.T, M.T = null;
						var r = Ts();
						ws(2);
						var i = q;
						q |= 4;
						try {
							Ui(e, t.alternate, t);
						} finally {
							q = i, ws(r), M.T = n;
						}
					}
					$ = 3;
				}
			}
			function io() {
				if ($ === 4 || $ === 3) {
					$ = 0;
					var e = Sf;
					Sf = null, Yl();
					var t = gf, n = _f, r = vf, i = xf, a = (r & 335544064) === r ? 10262 : 10256;
					if ((n.subtreeFlags & a) !== 0 || (n.flags & a) !== 0 ? $ = 5 : ($ = 0, _f = gf = null, ao(t, t.pendingLanes)), a = t.pendingLanes, a === 0 && (hf = null), oe(r), n = n.stateNode, iu && typeof iu.onCommitFiberRoot == "function") try {
						iu.onCommitFiberRoot(ru, n, void 0, (n.current.flags & 128) == 128);
					} catch {}
					if (i !== null) {
						n = M.T, a = Ts(), ws(2), M.T = null;
						try {
							for (var o = t.onRecoverableError, s = 0; s < i.length; s++) {
								var c = i[s];
								o(c.value, { componentStack: c.stack });
							}
						} finally {
							M.T = n, ws(a);
						}
					}
					if (i = Cf, o = wf, wf = null, i !== null && (Cf = null, o === null && (o = []), e !== null)) for (c = 0; c < i.length; c++) n = (0, i[c])(o), n !== void 0 && Sc(e, n);
					vf & 3 && oo(), Ke(t), a = t.pendingLanes, r & 261930 && a & 42 ? t === Ef ? Tf++ : (Tf = 0, Ef = t) : (Tf = 0, Ef = null), xs && ul(), qe(0, !1);
				}
			}
			function ao(e, t) {
				(e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, Ue(t)));
			}
			function oo() {
				return Sf !== null && (xc(Sf), Sf = null), no(), ro(), io(), so();
			}
			function so() {
				if ($ !== 5) return !1;
				var e = gf, t = yf;
				yf = 0;
				var n = oe(vf), i = 32 > n ? 32 : n;
				n = M.T;
				var a = Ts();
				try {
					ws(i), M.T = null, i = bf, bf = null;
					var o = gf, s = vf;
					if ($ = 0, _f = gf = null, vf = 0, q & 6) throw Error(r(331));
					var c = q;
					if (q |= 4, ya(o.current), fa(o, o.current, s, i), q = c, qe(0, !1), iu && typeof iu.onPostCommitFiberRoot == "function") try {
						iu.onPostCommitFiberRoot(ru, o);
					} catch {}
					return !0;
				} finally {
					ws(a), M.T = n, ao(e, t);
				}
			}
			function co(e, t, n) {
				t = he(n, t), t = ur(e.stateNode, t, 2), e = Et(e, t, 2), e !== null && (y(e, 2), Ke(e));
			}
			function A(e, t, n) {
				if (e.tag === 3) co(e, e, n);
				else for (; t !== null;) {
					if (t.tag === 3) {
						co(t, e, n);
						break;
					}
					if (t.tag === 1) {
						var r = t.stateNode;
						if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (hf === null || !hf.has(r))) {
							e = he(n, e), n = dr(2), r = Et(t, n, 2), r !== null && (fr(n, r, t, e), y(r, 2), Ke(r));
							break;
						}
					}
					t = t.return;
				}
			}
			function lo(e, t, n) {
				var r = e.pingCache;
				if (r === null) {
					r = e.pingCache = new Xd();
					var i = /* @__PURE__ */ new Set();
					r.set(t, i);
				} else i = r.get(t), i === void 0 && (i = /* @__PURE__ */ new Set(), r.set(t, i));
				i.has(n) || (ef = !0, i.add(n), e = uo.bind(null, e, t, n), t.then(e, e));
			}
			function uo(e, t, n) {
				var r = e.pingCache;
				r !== null && r.delete(t), e.pingedLanes |= e.suspendedLanes & n, e.warmLanes &= ~n, J === e && (X & n) === n && ((Q === 4 || Q === 3 && (X & 62914560) === X && 300 > Xl() - df) && !(q & 2) ? La(e, 0) : af |= n, sf === X && (sf = 0)), Ke(e);
			}
			function fo(e, t) {
				t === 0 && (t = te()), e = bt(e, t), e !== null && (y(e, t), Ke(e));
			}
			function po(e) {
				var t = e.memoizedState, n = 0;
				t !== null && (n = t.retryLane), fo(e, n);
			}
			function mo(e, t) {
				var n = 0;
				switch (e.tag) {
					case 31:
					case 13:
						var i = e.stateNode, a = e.memoizedState;
						a !== null && (n = a.retryLane);
						break;
					case 19:
						i = e.stateNode;
						break;
					case 22:
						i = e.stateNode._retryCache;
						break;
					default: throw Error(r(314));
				}
				i !== null && i.delete(t), fo(e, n);
			}
			function ho(e, t) {
				return Kl(e, t);
			}
			function go(e, t, n, r) {
				this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
			}
			function _o(e) {
				return e = e.prototype, !(!e || !e.isReactComponent);
			}
			function vo(e, n) {
				var r = e.alternate;
				return r === null ? (r = t(e.tag, n, e.key, e.mode), r.elementType = e.elementType, r.type = e.type, r.stateNode = e.stateNode, r.alternate = e, e.alternate = r) : (r.pendingProps = n, r.type = e.type, r.flags = 0, r.subtreeFlags = 0, r.deletions = null), r.flags = e.flags & 1206910976, r.childLanes = e.childLanes, r.lanes = e.lanes, r.child = e.child, r.memoizedProps = e.memoizedProps, r.memoizedState = e.memoizedState, r.updateQueue = e.updateQueue, n = e.dependencies, r.dependencies = n === null ? null : {
					lanes: n.lanes,
					firstContext: n.firstContext
				}, r.sibling = e.sibling, r.index = e.index, r.ref = e.ref, r.refCleanup = e.refCleanup, r;
			}
			function yo(e, t) {
				e.flags &= 1206910978;
				var n = e.alternate;
				return n === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = n.childLanes, e.lanes = n.lanes, e.child = n.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = n.memoizedProps, e.memoizedState = n.memoizedState, e.updateQueue = n.updateQueue, e.type = n.type, t = n.dependencies, e.dependencies = t === null ? null : {
					lanes: t.lanes,
					firstContext: t.firstContext
				}), e;
			}
			function bo(e, n, i, a, o, s) {
				var c = 0;
				if (a = e, typeof a == "function") _o(a) && (c = 1);
				else if (typeof a == "string") c = vl && P ? yl(e, i, Su.current) ? 26 : Fl(e) ? 27 : 5 : vl ? yl(e, i, Su.current) ? 26 : 5 : P && Fl(e) ? 27 : 5;
				else e: switch (a) {
					case Jo: return e = t(31, i, n, o), e.elementType = Jo, e.lanes = s, e;
					case Ro: return xo(i.children, o, s, n);
					case zo:
						c = 8, o |= 24;
						break;
					case Bo: return e = t(12, i, n, o | 2), e.elementType = Bo, e.lanes = s, e;
					case Wo: return e = t(13, i, n, o), e.elementType = Wo, e.lanes = s, e;
					case Go: return e = t(19, i, n, o), e.elementType = Go, e.lanes = s, e;
					case Yo:
					case Zo: return e = o | 32, e = t(30, i, n, e), e.elementType = Zo, e.lanes = s, e.stateNode = {
						autoName: null,
						paired: null,
						clones: null,
						ref: null
					}, e;
					default:
						if (typeof a == "object" && a) switch (a.$$typeof) {
							case Ho:
								c = 10;
								break e;
							case Vo:
								c = 9;
								break e;
							case Uo:
								c = 11;
								break e;
							case Ko:
								c = 14;
								break e;
							case qo:
								c = 16, a = null;
								break e;
						}
						c = 29, i = Error(r(130, e === null ? "null" : typeof e, "")), a = null;
				}
				return n = t(c, i, n, o), n.elementType = e, n.type = a, n.lanes = s, n;
			}
			function xo(e, n, r, i) {
				return e = t(7, e, i, n), e.lanes = r, e;
			}
			function So(e, n, r) {
				return e = t(6, e, null, n), e.lanes = r, e;
			}
			function Co(e) {
				var n = t(18, null, null, 0);
				return n.stateNode = e, n;
			}
			function wo(e, n, r) {
				return n = t(4, e.children === null ? [] : e.children, e.key, n), n.lanes = r, n.stateNode = {
					containerInfo: e.containerInfo,
					pendingChildren: null,
					implementation: e.implementation
				}, n;
			}
			function To(e, t, n, r, i, a, o, s, c) {
				this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = vs, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = ne(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = ne(0), this.hiddenUpdates = ne(null), this.identifierPrefix = r, this.onUncaughtError = i, this.onCaughtError = a, this.onRecoverableError = o, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = c, this.transitionTypes = null, this.incompleteTransitions = /* @__PURE__ */ new Map();
			}
			function Eo(e, n, r, i, a, o, s, c, l, u, d, f) {
				return e = new To(e, n, r, s, l, u, d, f, c), n = 1, o === !0 && (n |= 24), o = t(3, null, null, n), e.current = o, o.stateNode = e, n = He(), n.refCount++, e.pooledCache = n, n.refCount++, o.memoizedState = {
					element: i,
					isDehydrated: r,
					cache: n
				}, Ct(o), e;
			}
			function Do(e) {
				return e ? (e = zl, e) : zl;
			}
			function Oo(e) {
				var t = e._reactInternals;
				if (t === void 0) throw typeof e.render == "function" ? Error(r(188)) : (e = Object.keys(e).join(","), Error(r(268, e)));
				return e = o(t), e = e === null ? null : s(e), e === null ? null : os(e.stateNode);
			}
			function ko(e, t, n, r, i, a) {
				i = Do(i), r.context === null ? r.context = i : r.pendingContext = i, r = Tt(t), r.payload = { element: n }, a = a === void 0 ? null : a, a !== null && (r.callback = a), n = Et(e, r, t), n !== null && (Aa(n, e, t), Dt(n, e, t));
			}
			function Ao(e, t) {
				if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
					var n = e.retryLane;
					e.retryLane = n !== 0 && n < t ? n : t;
				}
			}
			function jo(e, t) {
				Ao(e, t), (e = e.alternate) && Ao(e, t);
			}
			var j = {}, Mo = S.default, No = ge.default, Po = Object.assign, Fo = Symbol.for("react.element"), Io = Symbol.for("react.transitional.element"), Lo = Symbol.for("react.portal"), Ro = Symbol.for("react.fragment"), zo = Symbol.for("react.strict_mode"), Bo = Symbol.for("react.profiler"), Vo = Symbol.for("react.consumer"), Ho = Symbol.for("react.context"), Uo = Symbol.for("react.forward_ref"), Wo = Symbol.for("react.suspense"), Go = Symbol.for("react.suspense_list"), Ko = Symbol.for("react.memo"), qo = Symbol.for("react.lazy"), Jo = Symbol.for("react.activity"), Yo = Symbol.for("react.legacy_hidden"), Xo = Symbol.for("react.memo_cache_sentinel"), Zo = Symbol.for("react.view_transition"), Qo = Symbol.for("react.recoverable"), $o = Symbol.iterator, es = Symbol.for("react.optimistic_key"), ts = Symbol.for("react.client.reference"), ns = Array.isArray, M = Mo.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, rs = e.rendererVersion, is = e.rendererPackageName, as = e.extraDevToolsConfig, os = e.getPublicInstance, ss = e.getRootHostContext, cs = e.getChildHostContext, ls = e.prepareForCommit, us = e.resetAfterCommit, ds = e.createInstance;
			e.cloneMutableInstance;
			var fs = e.appendInitialChild, ps = e.finalizeInitialChildren, ms = e.shouldSetTextContent, hs = e.createTextInstance;
			e.cloneMutableTextInstance;
			var gs = e.scheduleTimeout, _s = e.cancelTimeout, vs = e.noTimeout, ys = e.isPrimaryRenderer;
			e.warnsIfNotActing;
			var N = e.supportsMutation, bs = e.supportsPersistence, xs = e.supportsHydration, Ss = e.getInstanceFromNode;
			e.beforeActiveInstanceBlur;
			var Cs = e.preparePortalMount;
			e.prepareScopeUpdate, e.getInstanceFromScope;
			var ws = e.setCurrentUpdatePriority, Ts = e.getCurrentUpdatePriority, Es = e.resolveUpdatePriority;
			e.trackSchedulerEvent, e.resolveEventType, e.resolveEventTimeStamp;
			var Ds = e.shouldAttemptEagerTransition, Os = e.detachDeletedInstance;
			e.requestPostPaintCallback;
			var ks = e.maySuspendCommit, As = e.maySuspendCommitOnUpdate, js = e.maySuspendCommitInSyncRender, Ms = e.preloadInstance, Ns = e.startSuspendingCommit, Ps = e.suspendInstance, Fs = e.suspendOnActiveViewTransition, Is = e.waitForCommitToBeReady;
			e.getSuspendedCommitReason;
			var Ls = e.NotPendingTransition, Rs = e.HostTransitionContext, zs = e.resetFormInstance;
			e.bindToConsole;
			var Bs = e.supportsMicrotasks, Vs = e.scheduleMicrotask, Hs = e.supportsTestSelectors, Us = e.findFiberRoot, Ws = e.getBoundingRect, Gs = e.getTextContent, Ks = e.isHiddenSubtree, qs = e.matchAccessibilityRole, Js = e.setFocusIfFocusable, Ys = e.setupIntersectionObserver, Xs = e.appendChild, Zs = e.appendChildToContainer, Qs = e.commitTextUpdate, $s = e.commitMount, ec = e.commitUpdate, tc = e.insertBefore, nc = e.insertInContainerBefore, rc = e.removeChild, ic = e.removeChildFromContainer, ac = e.resetTextContent, oc = e.hideInstance, sc = e.hideTextInstance, cc = e.unhideInstance, lc = e.unhideTextInstance, uc = e.applyViewTransitionName, dc = e.restoreViewTransitionName, fc = e.cancelViewTransitionName, pc = e.cancelRootViewTransitionName, mc = e.restoreRootViewTransitionName;
			e.cloneRootViewTransitionContainer, e.removeRootViewTransitionClone;
			var hc = e.measureInstance, gc = e.measureClonedInstance, _c = e.wasInstanceInViewport, vc = e.hasInstanceChanged, yc = e.hasInstanceAffectedParent, bc = e.startViewTransition;
			e.startGestureTransition;
			var xc = e.stopViewTransition, Sc = e.addViewTransitionFinishedListener;
			e.getCurrentGestureOffset;
			var Cc = e.createViewTransitionInstance, wc = e.clearContainer, Tc = e.createFragmentInstance, Ec = e.updateFragmentInstanceFiber, Dc = e.commitNewChildToFragmentInstance, Oc = e.deleteChildFromFragmentInstance, kc = e.cloneInstance, Ac = e.createContainerChildSet, jc = e.appendChildToContainerChildSet, Mc = e.finalizeContainerChildren, Nc = e.replaceContainerChildren, Pc = e.cloneHiddenInstance, Fc = e.cloneHiddenTextInstance, Ic = e.isSuspenseInstancePending, Lc = e.isSuspenseInstanceFallback, Rc = e.getSuspenseInstanceFallbackErrorDetails, zc = e.registerSuspenseInstanceRetry, Bc = e.canHydrateFormStateMarker, Vc = e.isFormStateMarkerMatching, Hc = e.getNextHydratableSibling, Uc = e.getNextHydratableSiblingAfterSingleton, Wc = e.getFirstHydratableChild, Gc = e.getFirstHydratableChildWithinContainer, Kc = e.getFirstHydratableChildWithinActivityInstance, qc = e.getFirstHydratableChildWithinSuspenseInstance, Jc = e.getFirstHydratableChildWithinSingleton, Yc = e.canHydrateInstance, Xc = e.canHydrateTextInstance, Zc = e.canHydrateActivityInstance, Qc = e.canHydrateSuspenseInstance, $c = e.hydrateInstance, el = e.hydrateTextInstance, tl = e.hydrateActivityInstance, nl = e.hydrateSuspenseInstance, rl = e.getNextHydratableInstanceAfterActivityInstance, il = e.getNextHydratableInstanceAfterSuspenseInstance, al = e.commitHydratedInstance, ol = e.commitHydratedContainer, sl = e.commitHydratedActivityInstance, cl = e.commitHydratedSuspenseInstance, ll = e.finalizeHydratedChildren, ul = e.flushHydrationEvents;
			e.clearActivityBoundary;
			var dl = e.clearSuspenseBoundary;
			e.clearActivityBoundaryFromContainer;
			var fl = e.clearSuspenseBoundaryFromContainer, pl = e.hideDehydratedBoundary, ml = e.unhideDehydratedBoundary, hl = e.shouldDeleteUnhydratedTailInstances;
			e.diffHydratedPropsForDevWarnings, e.diffHydratedTextForDevWarnings, e.describeHydratableInstanceForDevWarnings;
			var gl = e.validateHydratableInstance, _l = e.validateHydratableTextInstance, vl = e.supportsResources, yl = e.isHostHoistableType, bl = e.getHoistableRoot, xl = e.getResource, Sl = e.acquireResource, Cl = e.releaseResource, wl = e.hydrateHoistable, Tl = e.mountHoistable, El = e.unmountHoistable, Dl = e.createHoistableInstance, Ol = e.prepareToCommitHoistables, kl = e.mayResourceSuspendCommit, Al = e.preloadResource, jl = e.suspendResource, P = e.supportsSingletons, Ml = e.resolveSingletonInstance, Nl = e.acquireSingletonInstance, Pl = e.releaseSingletonInstance, Fl = e.isHostSingletonType, Il = e.isSingletonScope, Ll = [], Rl = -1, zl = {}, Bl = Math.clz32 ? Math.clz32 : m, Vl = Math.log, Hl = Math.LN2, Ul = 256, Wl = 262144, Gl = 4194304, Kl = No.unstable_scheduleCallback, ql = No.unstable_cancelCallback, Jl = No.unstable_shouldYield, Yl = No.unstable_requestPaint, Xl = No.unstable_now, Zl = No.unstable_ImmediatePriority, Ql = No.unstable_UserBlockingPriority, $l = No.unstable_NormalPriority, eu = No.unstable_IdlePriority, tu = No.log, nu = No.unstable_setDisableYieldValue, ru = null, iu = null, au = 0, ou = typeof Object.is == "function" ? Object.is : ue, su = typeof reportError == "function" ? reportError : function(e) {
				if (typeof window == "object" && typeof window.ErrorEvent == "function") {
					var t = new window.ErrorEvent("error", {
						bubbles: !0,
						cancelable: !0,
						message: typeof e == "object" && e && typeof e.message == "string" ? String(e.message) : String(e),
						error: e
					});
					if (!window.dispatchEvent(t)) return;
				} else if (typeof process == "object" && typeof process.emit == "function") {
					process.emit("uncaughtException", e);
					return;
				}
				console.error(e);
			}, cu = Object.prototype.hasOwnProperty, lu, uu, du = !1, fu = /* @__PURE__ */ new WeakMap(), pu = [], mu = 0, hu = null, gu = 0, _u = [], vu = 0, yu = null, bu = 1, xu = "", Su = d(null), Cu = d(null), wu = d(null), Tu = d(null), F = null, I = null, L = !1, Eu = null, Du = !1, Ou = Error(r(519)), ku = d(null), Au = null, ju = null, Mu = typeof AbortController < "u" ? AbortController : function() {
				var e = [], t = this.signal = {
					aborted: !1,
					addEventListener: function(t, n) {
						e.push(n);
					}
				};
				this.abort = function() {
					t.aborted = !0, e.forEach(function(e) {
						return e();
					});
				};
			}, Nu = No.unstable_scheduleCallback, Pu = No.unstable_NormalPriority, R = {
				$$typeof: Ho,
				Consumer: null,
				Provider: null,
				_currentValue: null,
				_currentValue2: null,
				_threadCount: 0
			}, Fu = null, Iu = null, Lu = null, Ru = !1, zu = !1, Bu = !1, Vu = 0, Hu = null, Uu = 0, Wu = 0, Gu = null, Ku = M.S;
			M.S = function(e, t) {
				if (ff = Xl(), typeof t == "object" && t && typeof t.then == "function" && tt(e, t), Fu !== null) for (var n = Iu; n !== null;) T(n, Fu), n = n.next;
				if (n = e.types, n != null) {
					for (var r = Iu; r !== null;) T(r, n), r = r.next;
					if (Wu !== 0) {
						r = Fu, r === null && (r = Fu = []);
						for (var i = 0; i < n.length; i++) {
							var a = n[i];
							r.indexOf(a) === -1 && r.push(a);
						}
					}
				}
				Ku !== null && Ku(e, t);
			};
			var qu = d(null), Ju = Error(r(460)), Yu = Error(r(474)), Xu = Error(r(542)), Zu = { then: function() {} }, Qu = null, $u = null, ed = 0, td = gt(!0), nd = gt(!1), rd = [], id = 0, ad = 0, od = !1, sd = !1, cd = d(null), ld = d(0), ud = d(null), dd = null, fd = d(0), pd = 0, z = null, B = null, V = null, md = !1, hd = !1, gd = !1, _d = 0, vd = 0, yd = null, bd = 0, xd = {
				readContext: w,
				use: tn,
				useCallback: E,
				useContext: E,
				useEffect: E,
				useImperativeHandle: E,
				useLayoutEffect: E,
				useInsertionEffect: E,
				useMemo: E,
				useReducer: E,
				useRef: E,
				useState: E,
				useDebugValue: E,
				useDeferredValue: E,
				useTransition: E,
				useSyncExternalStore: E,
				useId: E,
				useHostTransitionStatus: E,
				useFormState: E,
				useActionState: E,
				useOptimistic: E,
				useMemoCache: E,
				useCacheRefresh: E,
				useEffectEvent: E
			}, Sd = {
				readContext: w,
				use: tn,
				useCallback: function(e, t) {
					return Qt().memoizedState = [e, t === void 0 ? null : t], e;
				},
				useContext: w,
				useEffect: Mn,
				useImperativeHandle: function(e, t, n) {
					n = n == null ? null : n.concat([e]), An(4194308, 4, Rn.bind(null, t, e), n);
				},
				useLayoutEffect: function(e, t) {
					return An(4194308, 4, e, t);
				},
				useInsertionEffect: function(e, t) {
					An(4, 2, e, t);
				},
				useMemo: function(e, t) {
					var n = Qt();
					t = t === void 0 ? null : t;
					var r = e();
					if (gd) {
						se(!0);
						try {
							e();
						} finally {
							se(!1);
						}
					}
					return n.memoizedState = [r, t], r;
				},
				useReducer: function(e, t, n) {
					var r = Qt();
					if (n !== void 0) {
						var i = n(t);
						if (gd) {
							se(!0);
							try {
								n(t);
							} finally {
								se(!1);
							}
						}
					} else i = t;
					return r.memoizedState = r.baseState = i, e = {
						pending: null,
						lanes: 0,
						dispatch: null,
						lastRenderedReducer: e,
						lastRenderedState: i
					}, r.queue = e, e = e.dispatch = Zn.bind(null, z, e), [r.memoizedState, e];
				},
				useRef: function(e) {
					var t = Qt();
					return e = { current: e }, t.memoizedState = e;
				},
				useState: function(e) {
					e = mn(e);
					var t = e.queue, n = Qn.bind(null, z, t);
					return t.dispatch = n, [e.memoizedState, n];
				},
				useDebugValue: Bn,
				useDeferredValue: function(e, t) {
					return Un(Qt(), e, t);
				},
				useTransition: function() {
					var e = mn(!1);
					return e = Gn.bind(null, z, e.queue, !0, !1), Qt().memoizedState = e, [!1, e];
				},
				useSyncExternalStore: function(e, t, n) {
					var i = z, a = Qt();
					if (L) {
						if (n === void 0) throw Error(r(407));
						n = n();
					} else {
						if (n = t(), J === null) throw Error(r(349));
						X & 127 || ln(i, t, n);
					}
					a.memoizedState = n;
					var o = {
						value: n,
						getSnapshot: t
					};
					return a.queue = o, Mn(dn.bind(null, i, o, e), [e]), i.flags |= 2048, On(9, { destroy: void 0 }, un.bind(null, i, o, n, t), null), n;
				},
				useId: function() {
					var e = Qt(), t = J.identifierPrefix;
					if (L) {
						var n = xu, r = bu;
						n = (r & ~(1 << 32 - Bl(r) - 1)).toString(32) + n, t = "_" + t + "R_" + n, n = _d++, 0 < n && (t += "H" + n.toString(32)), t += "_";
					} else n = bd++, t = "_" + t + "r_" + n.toString(32) + "_";
					return e.memoizedState = t;
				},
				useHostTransitionStatus: qn,
				useFormState: Cn,
				useActionState: Cn,
				useOptimistic: function(e) {
					var t = Qt();
					t.memoizedState = t.baseState = e;
					var n = {
						pending: null,
						lanes: 0,
						dispatch: null,
						lastRenderedReducer: null,
						lastRenderedState: null
					};
					return t.queue = n, t = er.bind(null, z, !0, n), n.dispatch = t, [e, t];
				},
				useMemoCache: nn,
				useCacheRefresh: function() {
					return Qt().memoizedState = Xn.bind(null, z);
				},
				useEffectEvent: function(e) {
					var t = Qt(), n = { impl: e };
					return t.memoizedState = n, function() {
						if (q & 2) throw Error(r(440));
						return n.impl.apply(void 0, arguments);
					};
				}
			}, Cd = {
				readContext: w,
				use: tn,
				useCallback: Vn,
				useContext: w,
				useEffect: Nn,
				useImperativeHandle: zn,
				useInsertionEffect: In,
				useLayoutEffect: Ln,
				useMemo: Hn,
				useReducer: an,
				useRef: kn,
				useState: function() {
					return an(rn);
				},
				useDebugValue: Bn,
				useDeferredValue: function(e, t) {
					return Wn(D(), B.memoizedState, e, t);
				},
				useTransition: function() {
					var e = an(rn)[0], t = D().memoizedState;
					return [typeof e == "boolean" ? e : en(e), t];
				},
				useSyncExternalStore: cn,
				useId: Jn,
				useHostTransitionStatus: qn,
				useFormState: wn,
				useActionState: wn,
				useOptimistic: function(e, t) {
					return hn(D(), B, e, t);
				},
				useMemoCache: nn,
				useCacheRefresh: Yn,
				useEffectEvent: Fn
			}, wd = {
				readContext: w,
				use: tn,
				useCallback: Vn,
				useContext: w,
				useEffect: Nn,
				useImperativeHandle: zn,
				useInsertionEffect: In,
				useLayoutEffect: Ln,
				useMemo: Hn,
				useReducer: sn,
				useRef: kn,
				useState: function() {
					return sn(rn);
				},
				useDebugValue: Bn,
				useDeferredValue: function(e, t) {
					var n = D();
					return B === null ? Un(n, e, t) : Wn(n, B.memoizedState, e, t);
				},
				useTransition: function() {
					var e = sn(rn)[0], t = D().memoizedState;
					return [typeof e == "boolean" ? e : en(e), t];
				},
				useSyncExternalStore: cn,
				useId: Jn,
				useHostTransitionStatus: qn,
				useFormState: Dn,
				useActionState: Dn,
				useOptimistic: function(e, t) {
					var n = D();
					return B === null ? (n.baseState = e, [e, n.queue.dispatch]) : hn(n, B, e, t);
				},
				useMemoCache: nn,
				useCacheRefresh: Yn,
				useEffectEvent: Fn
			}, Td = {
				enqueueSetState: function(e, t, n) {
					e = e._reactInternals;
					var r = Da(), i = Tt(r);
					i.payload = t, n != null && (i.callback = n), t = Et(e, i, r), t !== null && (Aa(t, e, r), Dt(t, e, r));
				},
				enqueueReplaceState: function(e, t, n) {
					e = e._reactInternals;
					var r = Da(), i = Tt(r);
					i.tag = 1, i.payload = t, n != null && (i.callback = n), t = Et(e, i, r), t !== null && (Aa(t, e, r), Dt(t, e, r));
				},
				enqueueForceUpdate: function(e, t) {
					e = e._reactInternals;
					var n = Da(), r = Tt(n);
					r.tag = 2, t != null && (r.callback = t), t = Et(e, r, n), t !== null && (Aa(t, e, n), Dt(t, e, n));
				}
			}, Ed = Error(r(461)), H = !1, Dd = {
				dehydrated: null,
				treeContext: null,
				retryLane: 0,
				hydrationErrors: null
			}, Od = !1, kd = !1, Ad = null, jd = null, Md = 0, U = !1, W = !1, Nd = !1, Pd = !1, Fd = typeof WeakSet == "function" ? WeakSet : Set, G = null, Id = !1, Ld = !1, Rd = !1, zd = !1, K = null, Bd = !1, Vd = null, Hd = 8192, Ud = {
				getCacheForType: function(e) {
					var t = w(R), n = t.data.get(e);
					return n === void 0 && (n = e(), t.data.set(e, n)), n;
				},
				cacheSignal: function() {
					return w(R).controller.signal;
				}
			}, Wd = 0, Gd = 1, Kd = 2, qd = 3, Jd = 4;
			if (typeof Symbol == "function" && Symbol.for) {
				var Yd = Symbol.for;
				Wd = Yd("selector.component"), Gd = Yd("selector.has_pseudo_class"), Kd = Yd("selector.role"), qd = Yd("selector.test_id"), Jd = Yd("selector.text");
			}
			var Xd = typeof WeakMap == "function" ? WeakMap : Map, q = 0, J = null, Y = null, X = 0, Z = 0, Zd = null, Qd = !1, $d = !1, ef = !1, tf = 0, Q = 0, nf = 0, rf = 0, af = 0, of = 0, sf = 0, cf = null, lf = null, uf = !1, df = 0, ff = 0, pf = 1 / 0, mf = null, hf = null, $ = 0, gf = null, _f = null, vf = 0, yf = 0, bf = null, xf = null, Sf = null, Cf = null, wf = null, Tf = 0, Ef = null;
			return j.attemptContinuousHydration = function(e) {
				if (e.tag === 13 || e.tag === 31) {
					var t = bt(e, 67108864);
					t !== null && Aa(t, e, 67108864), jo(e, 67108864);
				}
			}, j.attemptHydrationAtCurrentPriority = function(e) {
				if (e.tag === 13 || e.tag === 31) {
					var t = Da();
					t = ae(t);
					var n = bt(e, t);
					n !== null && Aa(n, e, t), jo(e, t);
				}
			}, j.attemptSynchronousHydration = function(e) {
				switch (e.tag) {
					case 3:
						if (e = e.stateNode, e.current.memoizedState.isDehydrated) {
							var t = h(e.pendingLanes);
							if (t !== 0) {
								for (e.pendingLanes |= 2, e.entangledLanes |= 2; t;) {
									var n = 1 << 31 - Bl(t);
									e.entanglements[1] |= n, t &= ~n;
								}
								Ke(e), !(q & 6) && (pf = Xl() + 500, qe(0, !1));
							}
						}
						break;
					case 31:
					case 13: t = bt(e, 2), t !== null && Aa(t, e, 2), Fa(), jo(e, 2);
				}
			}, j.batchedUpdates = function(e, t) {
				return e(t);
			}, j.createComponentSelector = function(e) {
				return {
					$$typeof: Wd,
					value: e
				};
			}, j.createContainer = function(e, t, n, r, i, a, o, s, c, l) {
				return Eo(e, t, !1, null, n, r, a, null, o, s, c, l);
			}, j.createHasPseudoClassSelector = function(e) {
				return {
					$$typeof: Gd,
					value: e
				};
			}, j.createHydrationContainer = function(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
				return e = Eo(n, r, !0, e, i, a, s, p, c, l, u, d), e.context = Do(null), n = e.current, r = Da(), r = ae(r), i = Tt(r), i.callback = t ?? null, Et(n, i, r), t = r, e.current.lanes = t, y(e, t), Ke(e), e;
			}, j.createPortal = function(e, t, n) {
				var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
				return {
					$$typeof: Lo,
					key: r == null ? null : r === es ? es : "" + r,
					children: e,
					containerInfo: t,
					implementation: n
				};
			}, j.createRoleSelector = function(e) {
				return {
					$$typeof: Kd,
					value: e
				};
			}, j.createTestNameSelector = function(e) {
				return {
					$$typeof: qd,
					value: e
				};
			}, j.createTextSelector = function(e) {
				return {
					$$typeof: Jd,
					value: e
				};
			}, j.defaultOnCaughtError = function(e) {
				console.error(e);
			}, j.defaultOnRecoverableError = function(e) {
				su(e);
			}, j.defaultOnUncaughtError = function(e) {
				su(e);
			}, j.deferredUpdates = function(e) {
				var t = M.T, n = Ts();
				try {
					return ws(32), M.T = null, e();
				} finally {
					ws(n), M.T = t;
				}
			}, j.discreteUpdates = function(e, t, n, r, i) {
				var a = M.T, o = Ts();
				try {
					return ws(2), M.T = null, e(t, n, r, i);
				} finally {
					ws(o), M.T = a, q === 0 && (pf = Xl() + 500);
				}
			}, j.findAllNodes = Ea, j.findBoundingRects = function(e, t) {
				if (!Hs) throw Error(r(363));
				t = Ea(e, t), e = [];
				for (var n = 0; n < t.length; n++) e.push(Ws(t[n]));
				for (t = e.length - 1; 0 < t; t--) {
					n = e[t];
					for (var i = n.x, a = i + n.width, o = n.y, s = o + n.height, c = t - 1; 0 <= c; c--) if (t !== c) {
						var l = e[c], u = l.x, d = u + l.width, f = l.y, p = f + l.height;
						if (i >= u && o >= f && a <= d && s <= p) {
							e.splice(t, 1);
							break;
						}
						if (i !== u || n.width !== l.width || p < o || f > s) {
							if (!(o !== f || n.height !== l.height || d < i || u > a)) {
								u > i && (l.width += u - i, l.x = i), d < a && (l.width = a - u), e.splice(t, 1);
								break;
							}
						} else {
							f > o && (l.height += f - o, l.y = o), p < s && (l.height = s - f), e.splice(t, 1);
							break;
						}
					}
				}
				return e;
			}, j.findHostInstance = Oo, j.findHostInstanceWithNoPortals = function(e) {
				return e = o(e), e = e === null ? null : c(e), e === null ? null : os(e.stateNode);
			}, j.findHostInstanceWithWarning = function(e) {
				return Oo(e);
			}, j.flushPassiveEffects = oo, j.flushSyncFromReconciler = function(e) {
				var t = q;
				q |= 1;
				var n = M.T, r = Ts();
				try {
					if (ws(2), M.T = null, e) return e();
				} finally {
					ws(r), M.T = n, q = t, !(q & 6) && qe(0, !1);
				}
			}, j.flushSyncWork = Fa, j.focusWithin = function(e, t) {
				if (!Hs) throw Error(r(363));
				for (e = Sa(e), t = Ta(e, t), t = Array.from(t), e = 0; e < t.length;) {
					var n = t[e++], i = n.tag;
					if (!Ks(n)) {
						if ((i === 5 || i === 26 || i === 27) && Js(n.stateNode)) return !0;
						for (n = n.child; n !== null;) t.push(n), n = n.sibling;
					}
				}
				return !1;
			}, j.getFindAllNodesFailureDescription = function(e, t) {
				if (!Hs) throw Error(r(363));
				var n = 0, i = [];
				e = [Sa(e), 0];
				for (var a = 0; a < e.length;) {
					var o = e[a++], s = o.tag, c = e[a++], l = t[c];
					if ((s !== 5 && s !== 26 && s !== 27 || !Ks(o)) && (Ca(o, l) && (i.push(wa(l)), c++, c > n && (n = c)), c < t.length)) for (o = o.child; o !== null;) e.push(o, c), o = o.sibling;
				}
				if (n < t.length) {
					for (e = []; n < t.length; n++) e.push(wa(t[n]));
					return "findAllNodes was able to match part of the selector:\n  " + (i.join(" > ") + "\n\nNo matching component was found for:\n  ") + e.join(" > ");
				}
				return null;
			}, j.getPublicRootInstance = function(e) {
				if (e = e.current, !e.child) return null;
				switch (e.child.tag) {
					case 27:
					case 5: return os(e.child.stateNode);
					default: return e.child.stateNode;
				}
			}, j.injectIntoDevTools = function() {
				var e = {
					bundleType: 0,
					version: rs,
					rendererPackageName: is,
					currentDispatcherRef: M,
					reconcilerVersion: "19.3.0"
				};
				if (as !== null && (e.rendererConfig = as), typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u") e = !1;
				else {
					var t = __REACT_DEVTOOLS_GLOBAL_HOOK__;
					if (t.isDisabled || !t.supportsFiber) e = !0;
					else {
						try {
							ru = t.inject(e), iu = t;
						} catch {}
						e = !!t.checkDCE;
					}
				}
				return e;
			}, j.isAlreadyRendering = function() {
				return !!(q & 6);
			}, j.observeVisibleRects = function(e, t, n, i) {
				if (!Hs) throw Error(r(363));
				e = Ea(e, t);
				var a = Ys(e, n, i).disconnect;
				return { disconnect: function() {
					a();
				} };
			}, j.shouldError = function() {
				return null;
			}, j.shouldSuspend = function() {
				return !1;
			}, j.startHostTransition = function(e, t, i, a) {
				if (e.tag !== 5) throw Error(r(476));
				var o = Kn(e).queue;
				Gn(e, o, t, Ls, i === null ? n : function() {
					var t = Kn(e);
					return t.next === null && (t = e.alternate.memoizedState), $n(e, t.next.queue, {}, Da()), i(a);
				});
			}, j.updateContainer = function(e, t, n, r) {
				var i = t.current, a = Da();
				return ko(i, a, e, t, n, r), a;
			}, j.updateContainerSync = function(e, t, n, r) {
				return ko(t.current, 2, e, t, n, r), 2;
			}, j;
		}, e.exports.default = e.exports, Object.defineProperty(e.exports, "__esModule", { value: !0 });
	}(Ht)), Ht.exports;
}
({ exports: {} }).exports;
var Wt;
function Gt() {
	return Wt || (Wt = 1, Vt.exports = E()), Vt.exports;
}
var Kt = Bt(Gt());
function qt(e) {
	let t = Kt(e);
	return t.injectIntoDevTools(), t;
}
var Jt = 0, Yt = {}, Xt = /^three(?=[A-Z])/, Zt = (e) => `${e[0].toUpperCase()}${e.slice(1)}`, Qt = 0, D = (e) => typeof e == "function";
function $t(e) {
	if (D(e)) {
		let t = `${Qt++}`;
		return Yt[t] = e, t;
	}
	Object.assign(Yt, e);
}
function en(e, t) {
	let n = Zt(e), r = Yt[n];
	if (e !== "primitive" && !r) throw Error(`R3F: ${n} is not part of the THREE namespace! Did you forget to extend? See: https://docs.pmnd.rs/react-three-fiber/api/objects#using-3rd-party-objects-declaratively`);
	if (e === "primitive" && !t.object) throw Error("R3F: Primitives without 'object' are invalid!");
	if (t.args !== void 0 && !Array.isArray(t.args)) throw Error("R3F: The args prop must be an array!");
}
function tn(e, t, n) {
	var r;
	return e = Zt(e) in Yt ? e : e.replace(Xt, ""), en(e, t), e === "primitive" && (r = t.object) != null && r.__r3f && delete t.object.__r3f, Je(t.object, n, e, t);
}
function nn(e) {
	if (!e.isHidden) {
		var t;
		e.props.attach && (t = e.parent) != null && t.object ? Qe(e.parent, e) : ct(e.object) && (e.previousVisible = e.object.visible, e.object.visible = !1), e.isHidden = !0, ot(e);
	}
}
function rn(e) {
	if (e.isHidden) {
		var t;
		e.props.attach && (t = e.parent) != null && t.object ? Ze(e.parent, e) : ct(e.object) && (e.object.visible = e.previousVisible ?? !0), e.previousVisible = void 0, e.isHidden = !1, ot(e);
	}
}
function an(e, t, n) {
	let r = t.root.getState();
	if (e.parent || e.object === r.scene) {
		if (!t.object) {
			let e = Yt[Zt(t.type)];
			t.object = t.props.object ?? new e(...t.props.args ?? []), t.object.__r3f = t;
		}
		if (at(t.object, t.props), t.props.attach) Ze(e, t);
		else if (ct(t.object) && ct(e.object)) {
			let r = e.object.children.indexOf(n?.object);
			if (n && r !== -1) {
				let n = e.object.children.indexOf(t.object);
				if (n !== -1) {
					e.object.children.splice(n, 1);
					let i = n < r ? r - 1 : r;
					e.object.children.splice(i, 0, t.object);
				} else t.object.parent = e.object, e.object.children.splice(r, 0, t.object), t.object.dispatchEvent({ type: "added" }), e.object.dispatchEvent({
					type: "childadded",
					child: t.object
				});
			} else e.object.add(t.object);
		}
		for (let e of t.children) an(t, e);
		ot(t);
	}
}
function on(e, t) {
	if (t) {
		if (t.parent === e) {
			let n = e.children.indexOf(t);
			n !== -1 && e.children.splice(n, 1);
		}
		t.parent = e, e.children.push(t), an(e, t);
	}
}
function sn(e, t, n) {
	if (!t || !n) return;
	if (t.parent === e) {
		let n = e.children.indexOf(t);
		n !== -1 && e.children.splice(n, 1);
	}
	t.parent = e;
	let r = e.children.indexOf(n);
	r === -1 ? e.children.push(t) : e.children.splice(r, 0, t), an(e, t, n);
}
function cn(e) {
	if (typeof e.dispose == "function") {
		let t = () => {
			try {
				e.dispose();
			} catch {}
		};
		typeof IS_REACT_ACT_ENVIRONMENT < "u" ? t() : (0, ge.unstable_scheduleCallback)(ge.unstable_IdlePriority, t);
	}
}
function ln(e, t, n) {
	if (!t) return;
	t.parent = null;
	let r = e.children.indexOf(t);
	r !== -1 && e.children.splice(r, 1), t.props.attach ? Qe(e, t) : ct(t.object) && ct(e.object) && (e.object.remove(t.object), ft(ke(t), t.object));
	let i = t.props.dispose !== null && n !== !1;
	for (let e = t.children.length - 1; e >= 0; e--) {
		let n = t.children[e];
		ln(t, n, i);
	}
	t.children.length = 0, delete t.object.__r3f, i && t.type !== "primitive" && t.object.type !== "Scene" && cn(t.object), n === void 0 && ot(t);
}
function un(e, t) {
	for (let n of [e, e.alternate]) if (n !== null) {
		if (typeof n.ref == "function") {
			n.refCleanup == null || n.refCleanup();
			let e = n.ref(t);
			typeof e == "function" && (n.refCleanup = e);
		} else n.ref && (n.ref.current = t);
	}
}
var dn = [];
function fn() {
	if (dn.length !== 0) try {
		pn();
	} finally {
		dn.length = 0;
	}
}
function pn() {
	for (let [e] of dn) {
		let t = e.parent;
		if (t) {
			e.props.attach ? Qe(t, e) : ct(e.object) && ct(t.object) && t.object.remove(e.object);
			for (let t of e.children) t.props.attach ? Qe(e, t) : ct(t.object) && ct(e.object) && e.object.remove(t.object);
		}
		e.isHidden && rn(e), e.object.__r3f && delete e.object.__r3f, e.type !== "primitive" && cn(e.object);
	}
	for (let [e, t, n] of dn) {
		e.props = t;
		let r = e.parent;
		if (r) {
			let t = Yt[Zt(e.type)], i = e.object;
			e.object = e.props.object ?? new t(...e.props.args ?? []), e.object.__r3f = e, un(n, e.object), dt(ke(e), i, e.object), at(e.object, e.props), e.props.attach ? Ze(r, e) : ct(e.object) && ct(r.object) && r.object.add(e.object);
			for (let t of e.children) t.props.attach ? Ze(e, t) : ct(t.object) && ct(e.object) && e.object.add(t.object);
			ot(e);
		}
	}
}
var mn = () => {}, hn = {}, gn = Jt;
function _n(e) {
	switch (e) {
		case "beforetoggle":
		case "cancel":
		case "click":
		case "close":
		case "contextmenu":
		case "copy":
		case "cut":
		case "auxclick":
		case "dblclick":
		case "dragend":
		case "dragstart":
		case "drop":
		case "focusin":
		case "focusout":
		case "input":
		case "invalid":
		case "keydown":
		case "keypress":
		case "keyup":
		case "mousedown":
		case "mouseup":
		case "paste":
		case "pause":
		case "play":
		case "pointercancel":
		case "pointerdown":
		case "pointerup":
		case "ratechange":
		case "reset":
		case "resize":
		case "seeked":
		case "submit":
		case "touchcancel":
		case "touchend":
		case "touchstart":
		case "volumechange":
		case "change":
		case "selectionchange":
		case "compositionstart":
		case "compositionend":
		case "compositionupdate":
		case "beforeinput":
		case "blur":
		case "fullscreenchange":
		case "focus":
		case "hashchange":
		case "popstate":
		case "select":
		case "selectstart": return kt;
		case "drag":
		case "dragenter":
		case "dragexit":
		case "dragleave":
		case "dragover":
		case "mousemove":
		case "mouseout":
		case "mouseover":
		case "pointermove":
		case "pointerout":
		case "pointerover":
		case "scroll":
		case "touchmove":
		case "wheel":
		case "mouseenter":
		case "mouseleave":
		case "pointerenter":
		case "pointerleave": return Dt;
		case "message": switch ((0, ge.unstable_getCurrentPriorityLevel)()) {
			case ge.unstable_ImmediatePriority: return kt;
			case ge.unstable_UserBlockingPriority: return Dt;
			case ge.unstable_NormalPriority:
			case ge.unstable_LowPriority: return Ot;
			case ge.unstable_IdlePriority: return At;
			default: return Ot;
		}
		default: return Ot;
	}
}
function vn(e) {
	typeof queueMicrotask == "function" ? queueMicrotask(e) : typeof Promise < "u" ? Promise.resolve().then(e).catch((e) => {
		setTimeout(() => {
			throw e;
		});
	}) : setTimeout(e);
}
var yn = /* @__PURE__ */ qt({
	isPrimaryRenderer: !1,
	warnsIfNotActing: !1,
	supportsMutation: !0,
	supportsPersistence: !1,
	supportsHydration: !1,
	createInstance: tn,
	removeChild: ln,
	appendChild: on,
	appendInitialChild: on,
	insertBefore: sn,
	appendChildToContainer(e, t) {
		let n = e.getState().scene.__r3f;
		t && n && on(n, t);
	},
	removeChildFromContainer(e, t) {
		let n = e.getState().scene.__r3f;
		t && n && ln(n, t);
	},
	insertInContainerBefore(e, t, n) {
		let r = e.getState().scene.__r3f;
		t && n && r && sn(r, t, n);
	},
	getRootHostContext: () => hn,
	getChildHostContext: () => hn,
	commitUpdate(e, t, n, r, i) {
		var a;
		en(t, r);
		let o = !1;
		if (e.type === "primitive" && n.object !== r.object ? o = !0 : r.args?.length === n.args?.length ? (a = r.args) != null && a.some((e, t) => e !== n.args?.[t]) && (o = !0) : o = !0, o) dn.push([
			e,
			qe(r),
			i
		]);
		else {
			let t = nt(e, r), n = e.props.attach;
			e.props = qe(r), n === void 0 ? delete e.props.attach : e.props.attach = n, Object.keys(t).length && at(e.object, t);
		}
	},
	finalizeInitialChildren: () => !1,
	commitMount() {},
	getPublicInstance: (e) => e?.object,
	prepareForCommit: () => null,
	preparePortalMount: (e) => Je(e.getState().scene, e, "", {}),
	resetAfterCommit: fn,
	shouldSetTextContent: () => !1,
	clearContainer: () => !1,
	hideInstance: nn,
	unhideInstance: rn,
	createTextInstance: mn,
	hideTextInstance: mn,
	unhideTextInstance: mn,
	supportsMicrotasks: !0,
	scheduleMicrotask: vn,
	scheduleTimeout: typeof setTimeout == "function" ? setTimeout : void 0,
	cancelTimeout: typeof clearTimeout == "function" ? clearTimeout : void 0,
	noTimeout: -1,
	getInstanceFromNode: () => null,
	beforeActiveInstanceBlur() {},
	afterActiveInstanceBlur() {},
	detachDeletedInstance() {},
	prepareScopeUpdate() {},
	getInstanceFromScope: () => null,
	shouldAttemptEagerTransition: () => !1,
	trackSchedulerEvent: () => {},
	resolveEventType: () => null,
	resolveEventTimeStamp: () => -1.1,
	requestPostPaintCallback() {},
	maySuspendCommit: () => !1,
	preloadInstance: () => !0,
	suspendInstance() {},
	waitForCommitToBeReady: () => null,
	NotPendingTransition: null,
	HostTransitionContext: /* @__PURE__ */ S.createContext(null),
	setCurrentUpdatePriority(e) {
		gn = e;
	},
	getCurrentUpdatePriority() {
		return gn;
	},
	resolveUpdatePriority() {
		if (gn !== Jt) return gn;
		let e = typeof window < "u" ? window.event?.type : void 0;
		return e === void 0 ? Ot : _n(e);
	},
	resetFormInstance() {},
	rendererPackageName: "@react-three/fiber",
	rendererVersion: zt.version,
	applyViewTransitionName(e, t, n) {},
	restoreViewTransitionName(e, t) {},
	cancelViewTransitionName(e, t, n) {},
	cancelRootViewTransitionName(e) {},
	restoreRootViewTransitionName(e) {},
	InstanceMeasurement: null,
	measureInstance: (e) => null,
	wasInstanceInViewport: (e) => !0,
	hasInstanceChanged: (e, t) => !1,
	hasInstanceAffectedParent: (e, t) => !1,
	suspendOnActiveViewTransition(e, t) {},
	startViewTransition(e, t, n, r, i, a, o, s, c, l, u) {
		return r(), i(), u?.(), o(), null;
	},
	startGestureTransition(e, t, n, r, i, a, o, s, c, l) {
		return o(), s(), l?.(), null;
	},
	stopViewTransition(e) {},
	addViewTransitionFinishedListener(e, t) {
		t();
	},
	createViewTransitionInstance: (e) => null,
	getCurrentGestureOffset(e) {
		throw Error("startGestureTransition is not yet supported in react-three-fiber.");
	},
	cloneMutableInstance(e, t) {
		return e;
	},
	cloneMutableTextInstance(e) {
		return e;
	},
	cloneRootViewTransitionContainer(e) {
		throw Error("Not implemented.");
	},
	removeRootViewTransitionClone(e, t) {
		throw Error("Not implemented.");
	},
	createFragmentInstance: (e) => null,
	updateFragmentInstanceFiber(e, t) {},
	commitNewChildToFragmentInstance(e, t) {},
	deleteChildFromFragmentInstance(e, t) {},
	measureClonedInstance: (e) => null,
	maySuspendCommitOnUpdate: (e, t, n) => !1,
	maySuspendCommitInSyncRender: (e, t) => !1,
	startSuspendingCommit: () => null,
	getSuspendedCommitReason: (e, t) => null
});
function bn(e) {
	return yn.flushSyncFromReconciler(e);
}
var xn = /* @__PURE__ */ new Map();
function Sn(e, t) {
	let n = e.state;
	switch (t.type) {
		case "use": return n.status !== "disposed" && (e.state = { status: "open" }, !0);
		case "unmount": return n.status !== "disposed" && (e.state = {
			status: "closing",
			token: t.token
		}, !0);
		case "dispose": return n.status !== "closing" || n.token !== t.token ? !1 : (e.state = { status: "disposed" }, !0);
	}
}
function Cn(e) {
	let t = xn.get(e), n = t?.fiber, r = t?.store;
	t && console.warn("R3F.createRoot should only be called once!");
	let i = typeof reportError == "function" ? reportError : console.error, a = r || gt(Kn, qn), o = n || yn.createContainer(a, Et, null, !1, null, "", i, i, i, null), s = t || {
		fiber: o,
		store: a,
		state: { status: "open" },
		ready: It(void 0),
		configuration: {},
		ownsRenderer: !1
	};
	t || xn.set(e, s);
	let c = !1;
	return {
		get ready() {
			return s.ready;
		},
		configure(t = {}) {
			if (!Sn(s, { type: "use" })) return Lt(/* @__PURE__ */ Error("R3F: Cannot configure a root after disposal has started."));
			let n = s.ready, { promise: r, resolve: i, reject: o } = Rt();
			s.ready = r;
			let c = (n) => {
				let r = a.getState();
				r.gl || (s.ownsRenderer = !mt(t.gl), r.set({ gl: n })), Pt(s, e, t), i(this);
			}, l = () => {
				try {
					let n = a.getState().gl ?? Mt(e, t.gl);
					Ft(n) ? Promise.resolve(n).then(c).catch(o) : c(n);
				} catch (e) {
					o(e);
				}
			};
			return n.status === "pending" ? n.then(l, o) : l(), r;
		},
		render(t) {
			if (!Sn(s, { type: "use" })) return a;
			if (!a.getState().gl && s.ready.status === "fulfilled" && this.configure(), s.ready.status === "rejected") throw s.ready.reason;
			let n = () => {
				if (s.state.status !== "open" || s.ready.status === "rejected") return;
				if (s.ready.status === "pending") {
					s.ready.then(n, i);
					return;
				}
				let r = s.configuration.previous?.onCreated, l = /*#__PURE__*/ (0, x.jsx)(wn, {
					store: a,
					children: t,
					onCreated: r,
					rootElement: e
				});
				if (c) {
					yn.updateContainer(l, o, null, Ie);
					return;
				}
				c = !0, yn.updateContainerSync(l, o, null, Ie), yn.flushSyncWork();
			};
			return n(), a;
		},
		unmount() {
			xn.get(e) === s && Dn(e);
		}
	};
}
function wn({ store: e, children: t, onCreated: n, rootElement: r }) {
	return Pe(() => {
		let t = e.getState();
		t.set((e) => ({ internal: {
			...e.internal,
			active: !0
		} })), n && n(t), e.getState().events.connected || t.events.connect == null || t.events.connect(r);
	}, []), /*#__PURE__*/ (0, x.jsx)(ht.Provider, {
		value: e,
		children: t
	});
}
function Tn(e) {
	if ((e.hasInitialized == null ? void 0 : e.hasInitialized()) === !1) return;
	let t = En(() => {
		var t;
		return e.dispose ? e.dispose() : (t = e.renderLists) == null || t.dispose == null ? void 0 : t.dispose();
	});
	if (Ft(t)) return Promise.resolve(t).catch((e) => console.warn("[R3F] Error disposing renderer", e)).then(() => En(() => e.forceContextLoss == null ? void 0 : e.forceContextLoss()));
	En(() => e.forceContextLoss == null ? void 0 : e.forceContextLoss());
}
function En(e) {
	try {
		return e();
	} catch (e) {
		console.warn("[R3F] Error while unmounting root; teardown may be incomplete:", e);
	}
}
function Dn(e, t) {
	let n = xn.get(e), r = Symbol("unmount");
	if (!n || !Sn(n, {
		type: "unmount",
		token: r
	})) return;
	let i = () => {
		var a;
		if (n.ready.status === "pending") {
			n.ready.then(i, i);
			return;
		}
		if (!Sn(n, {
			type: "dispose",
			token: r
		})) return;
		xn.delete(e);
		let o = n.store.getState();
		o.internal.active = !1, En(() => o.events.disconnect == null ? void 0 : o.events.disconnect()), (a = o.gl) != null && a.xr && En(() => o.xr.disconnect()), o.scene && En(() => Ge(o.scene));
		let s = o.gl, c;
		s && n.ownsRenderer ? c = En(() => Tn(s)) : s && (En(() => {
			var e;
			return (e = s.renderLists) == null || e.dispose == null ? void 0 : e.dispose();
		}), En(() => s.forceContextLoss == null ? void 0 : s.forceContextLoss())), Ft(c) ? c.then(() => t?.(e)) : t?.(e);
	};
	yn.updateContainer(null, n.fiber, null, () => {
		n.state.status === "closing" && n.state.token === r && yn.updateContainer(null, n.fiber, null, i);
	});
}
function On(e, t) {
	let n = { callback: e };
	return t.add(n), () => void t.delete(n);
}
var kn = /* @__PURE__ */ new Set(), An = /* @__PURE__ */ new Set(), jn = /* @__PURE__ */ new Set(), Mn = (e) => On(e, kn), Nn = (e) => On(e, An), Pn = (e) => On(e, jn);
function Fn(e, t) {
	if (e.size) for (let { callback: n } of e.values()) n(t);
}
function In(e, t) {
	switch (e) {
		case "before": return Fn(kn, t);
		case "after": return Fn(An, t);
		case "tail": return Fn(jn, t);
	}
}
var Ln, Rn;
function zn(e, t, n) {
	let r = t.clock.getDelta();
	t.frameloop === "never" && typeof e == "number" && (r = e - t.clock.elapsedTime, t.clock.oldTime = t.clock.elapsedTime, t.clock.elapsedTime = e), Ln = t.internal.subscribers;
	for (let e = 0; e < Ln.length; e++) Rn = Ln[e], Rn.ref.current(Rn.store.getState(), r, n);
	return !t.internal.priority && t.gl.render && t.gl.render(t.scene, t.camera), t.internal.frames = Math.max(0, t.internal.frames - 1), t.frameloop === "always" ? 1 : t.internal.frames;
}
var Bn = !1, Vn = !1, Hn, Un, Wn;
function Gn(e) {
	Un = requestAnimationFrame(Gn), Bn = !0, Hn = 0, In("before", e), Vn = !0;
	for (let n of xn.values()) {
		var t;
		Wn = n.store.getState(), Wn.internal.active && (Wn.frameloop === "always" || Wn.internal.frames > 0) && !((t = Wn.gl.xr) != null && t.isPresenting) && (Hn += zn(e, Wn));
	}
	if (Vn = !1, In("after", e), Hn === 0) return In("tail", e), Bn = !1, cancelAnimationFrame(Un);
}
function Kn(e, t = 1) {
	var n;
	if (!e) return xn.forEach((e) => Kn(e.store.getState(), t));
	(n = e.gl.xr) != null && n.isPresenting || !e.internal.active || e.frameloop === "never" || (t > 1 ? e.internal.frames = Math.min(60, e.internal.frames + t) : Vn ? e.internal.frames = 2 : e.internal.frames = 1, Bn || (Bn = !0, requestAnimationFrame(Gn)));
}
function qn(e, t = !0, n, r) {
	if (t && In("before", e), n) zn(e, n, r);
	else for (let t of xn.values()) zn(e, t.store.getState());
	t && In("after", e);
}
function Jn(e, t, n) {
	return /*#__PURE__*/ (0, x.jsx)(Yn, {
		children: e,
		container: t,
		state: n
	});
}
function Yn({ state: e = {}, children: t, container: n }) {
	let { events: r, size: i, ...a } = e, o = vt(), [s] = S.useState(() => new d()), [c] = S.useState(() => new h()), l = Fe((e, t) => {
		let a;
		if (t.camera && i) {
			let n = t.camera;
			a = e.viewport.getCurrentViewport(n, new _(), i), n !== e.camera && st(n, i);
		}
		return {
			...e,
			...t,
			scene: n,
			raycaster: s,
			pointer: c,
			mouse: c,
			previousRoot: o,
			events: {
				...e.events,
				...t.events,
				...r
			},
			size: {
				...e.size,
				...i
			},
			viewport: {
				...e.viewport,
				...a
			},
			setEvents: (e) => t.set((t) => ({
				...t,
				events: {
					...t.events,
					...e
				}
			}))
		};
	}), u = S.useMemo(() => {
		let e = ce((e, t) => ({
			...a,
			set: e,
			get: t
		})), t = (t) => e.setState((e) => l.current(t, e));
		return t(o.getState()), o.subscribe(t), e;
	}, [o, n]);
	return /*#__PURE__*/ (0, x.jsx)(x.Fragment, { children: yn.createPortal(/*#__PURE__*/ (0, x.jsx)(ht.Provider, {
		value: u,
		children: t
	}), u, null) });
}
var Xn = {
	onClick: ["click", !1],
	onContextMenu: ["contextmenu", !1],
	onDoubleClick: ["dblclick", !1],
	onWheel: ["wheel", !0],
	onPointerDown: ["pointerdown", !0],
	onPointerUp: ["pointerup", !0],
	onPointerLeave: ["pointerleave", !0],
	onPointerMove: ["pointermove", !0],
	onPointerCancel: ["pointercancel", !0],
	onLostPointerCapture: ["lostpointercapture", !0]
};
function Zn(e) {
	let { handlePointer: t } = pt(e);
	return {
		priority: 1,
		enabled: !0,
		compute(e, t, n) {
			t.pointer.set(e.offsetX / t.size.width * 2 - 1, -(e.offsetY / t.size.height) * 2 + 1), t.raycaster.setFromCamera(t.pointer, t.camera);
		},
		connected: void 0,
		handlers: Object.keys(Xn).reduce((e, n) => ({
			...e,
			[n]: t(n)
		}), {}),
		update: () => {
			var t;
			let { events: n, internal: r } = e.getState();
			(t = r.lastEvent) != null && t.current && n.handlers && n.handlers.onPointerMove(r.lastEvent.current);
		},
		connect: (t) => {
			let { set: n, events: r } = e.getState();
			if (r.disconnect == null || r.disconnect(), n((e) => ({ events: {
				...e.events,
				connected: t
			} })), r.handlers) for (let e in r.handlers) {
				let n = r.handlers[e], [i, a] = Xn[e];
				t.addEventListener(i, n, { passive: a });
			}
		},
		disconnect: () => {
			let { set: t, events: n } = e.getState();
			if (n.connected) {
				if (n.handlers) for (let e in n.handlers) {
					let t = n.handlers[e], [r] = Xn[e];
					n.connected.removeEventListener(r, t);
				}
				t((e) => ({ events: {
					...e.events,
					connected: void 0
				} }));
			}
		}
	};
}
//#endregion
//#region node_modules/react-use-measure/dist/index.js
function Qn(e, t) {
	let n;
	return (...r) => {
		window.clearTimeout(n), n = window.setTimeout(() => e(...r), t);
	};
}
function $n({ debounce: e, scroll: t, polyfill: n, offsetSize: r } = {
	debounce: 0,
	scroll: !1,
	offsetSize: !1
}) {
	let i = n || (typeof window > "u" ? class {} : window.ResizeObserver);
	if (!i) throw Error("This browser does not support ResizeObserver out of the box. See: https://github.com/react-spring/react-use-measure/#resize-observer-polyfills");
	let [a, o] = (0, S.useState)({
		left: 0,
		top: 0,
		width: 0,
		height: 0,
		bottom: 0,
		right: 0,
		x: 0,
		y: 0
	}), s = (0, S.useRef)({
		element: null,
		scrollContainers: null,
		resizeObserver: null,
		lastBounds: a,
		orientationHandler: null
	}), c = e ? typeof e == "number" ? e : e.scroll : null, l = e ? typeof e == "number" ? e : e.resize : null, u = (0, S.useRef)(!1);
	(0, S.useEffect)(() => (u.current = !0, () => void (u.current = !1)));
	let [d, f, p] = (0, S.useMemo)(() => {
		let e = () => {
			if (!s.current.element) return;
			let { left: e, top: t, width: n, height: i, bottom: a, right: c, x: l, y: d } = s.current.element.getBoundingClientRect(), f = {
				left: e,
				top: t,
				width: n,
				height: i,
				bottom: a,
				right: c,
				x: l,
				y: d
			};
			s.current.element instanceof HTMLElement && r && (f.height = s.current.element.offsetHeight, f.width = s.current.element.offsetWidth), Object.freeze(f), u.current && !ir(s.current.lastBounds, f) && o(s.current.lastBounds = f);
		};
		return [
			e,
			l ? Qn(e, l) : e,
			c ? Qn(e, c) : e
		];
	}, [
		o,
		r,
		c,
		l
	]);
	function m() {
		s.current.scrollContainers && (s.current.scrollContainers.forEach((e) => e.removeEventListener("scroll", p, !0)), s.current.scrollContainers = null), s.current.resizeObserver && (s.current.resizeObserver.disconnect(), s.current.resizeObserver = null), s.current.orientationHandler && ("orientation" in screen && "removeEventListener" in screen.orientation ? screen.orientation.removeEventListener("change", s.current.orientationHandler) : "onorientationchange" in window && window.removeEventListener("orientationchange", s.current.orientationHandler));
	}
	function h() {
		s.current.element && (s.current.resizeObserver = new i(p), s.current.resizeObserver.observe(s.current.element), t && s.current.scrollContainers && s.current.scrollContainers.forEach((e) => e.addEventListener("scroll", p, {
			capture: !0,
			passive: !0
		})), s.current.orientationHandler = () => {
			p();
		}, "orientation" in screen && "addEventListener" in screen.orientation ? screen.orientation.addEventListener("change", s.current.orientationHandler) : "onorientationchange" in window && window.addEventListener("orientationchange", s.current.orientationHandler));
	}
	return tr(p, !!t), er(f), (0, S.useEffect)(() => {
		m(), h();
	}, [
		t,
		p,
		f
	]), (0, S.useEffect)(() => m, []), [
		(e) => {
			!e || e === s.current.element || (m(), s.current.element = e, s.current.scrollContainers = nr(e), h());
		},
		a,
		d
	];
}
function er(e) {
	(0, S.useEffect)(() => {
		let t = e;
		return window.addEventListener("resize", t), () => void window.removeEventListener("resize", t);
	}, [e]);
}
function tr(e, t) {
	(0, S.useEffect)(() => {
		if (t) {
			let t = e;
			return window.addEventListener("scroll", t, {
				capture: !0,
				passive: !0
			}), () => void window.removeEventListener("scroll", t, !0);
		}
	}, [e, t]);
}
function nr(e) {
	let t = [];
	if (!e || e === document.body) return t;
	let { overflow: n, overflowX: r, overflowY: i } = window.getComputedStyle(e);
	return [
		n,
		r,
		i
	].some((e) => e === "auto" || e === "scroll") && t.push(e), [...t, ...nr(e.parentElement)];
}
var rr = [
	"x",
	"y",
	"top",
	"bottom",
	"left",
	"right",
	"width",
	"height"
], ir = (e, t) => rr.every((n) => e[n] === t[n]), ar = /* @__PURE__ */ e({
	Canvas: () => sr,
	ReactThreeFiber: () => Oe,
	_roots: () => xn,
	act: () => Ae,
	addAfterEffect: () => Nn,
	addEffect: () => Mn,
	addTail: () => Pn,
	advance: () => qn,
	applyProps: () => at,
	buildGraph: () => We,
	context: () => ht,
	createEvents: () => pt,
	createPortal: () => Jn,
	createRoot: () => Cn,
	dispose: () => Ge,
	events: () => Zn,
	extend: () => $t,
	flushGlobalEffects: () => In,
	flushSync: () => bn,
	getRootState: () => Ue,
	invalidate: () => Kn,
	reconciler: () => yn,
	unmountComponentAtNode: () => Dn,
	useFrame: () => bt,
	useGraph: () => xt,
	useInstanceHandle: () => _t,
	useLoader: () => Tt,
	useStore: () => vt,
	useThree: () => yt
});
function or({ ref: e, children: t, fallback: n, resize: r, style: i, gl: a, events: o = Zn, eventSource: s, eventPrefix: c, shadows: l, linear: u, flat: d, legacy: f, orthographic: p, frameloop: h, dpr: g, performance: _, raycaster: v, camera: ee, scene: te, onPointerMissed: ne, onCreated: y, ...re }) {
	S.useMemo(() => $t(m), []);
	let b = w(), [ie, ae] = $n({
		scroll: !0,
		debounce: {
			scroll: 50,
			resize: 0
		},
		...r
	}), oe = S.useRef(null), se = S.useRef(null);
	S.useImperativeHandle(e, () => oe.current);
	let ce = Fe(ne), le = S.useCallback((e) => ce.current == null ? void 0 : ce.current(e), [ce]), [C, ue] = S.useState(!1), [de, fe] = S.useState(!1);
	if (C) throw C;
	if (de) throw de;
	let pe = S.useRef(null), [me, he] = Re(), ge = S.useRef(null), _e = () => s ? Me(s) ? s.current : s : se.current;
	return S.useInsertionEffect(() => () => {
		let e = pe.current;
		pe.current = null, e?.unmount();
	}, []), Pe(() => {
		let e = oe.current;
		ae.width > 0 && ae.height > 0 && e && (pe.current ||= Cn(e), pe.current.configure({
			gl: a,
			scene: te,
			events: o,
			shadows: l,
			linear: u,
			flat: d,
			legacy: f,
			orthographic: p,
			frameloop: h,
			dpr: g,
			performance: _,
			raycaster: v,
			camera: ee,
			size: ae,
			onPointerMissed: le,
			onCreated: (e) => {
				ge.current = e, e.events.connect == null || e.events.connect(_e() ?? se.current), c && e.setEvents({ compute: (e, t) => {
					let n = e[c + "X"], r = e[c + "Y"];
					t.pointer.set(n / t.size.width * 2 - 1, -(r / t.size.height) * 2 + 1), t.raycaster.setFromCamera(t.pointer, t.camera);
				} }), y?.(e);
			}
		}).catch(fe), pe.current.ready.status === "fulfilled" ? pe.current.render(/*#__PURE__*/ (0, x.jsx)(b, { children: /*#__PURE__*/ (0, x.jsx)(Ve, {
			set: fe,
			children: /*#__PURE__*/ (0, x.jsx)(S.Suspense, {
				fallback: /*#__PURE__*/ (0, x.jsx)(Be, { set: ue }),
				children: t ?? null
			})
		}) })) : pe.current.ready.status === "pending" && he(pe.current.ready));
	}), S.useEffect(() => {
		let e = ge.current?.get(), t = _e();
		e && t && e.events.connected !== t && (e.events.connect == null || e.events.connect(t));
	}), S.useEffect(() => {
		let e = oe.current;
		return () => {
			var t;
			e.isConnected || (t = pe.current) == null || t.unmount();
		};
	}, []), /*#__PURE__*/ (0, x.jsxs)("div", {
		ref: se,
		style: {
			position: "relative",
			width: "100%",
			height: "100%",
			overflow: "hidden",
			pointerEvents: s ? "none" : "auto",
			...i
		},
		...re,
		children: [/*#__PURE__*/ (0, x.jsx)("div", {
			ref: ie,
			style: {
				width: "100%",
				height: "100%"
			},
			children: /*#__PURE__*/ (0, x.jsx)("canvas", {
				ref: oe,
				style: { display: "block" },
				children: n
			})
		}), me]
	});
}
function sr(e) {
	return /*#__PURE__*/ (0, x.jsx)(be, { children: /*#__PURE__*/ (0, x.jsx)(or, { ...e }) });
}
//#endregion
export { yt as A, Oe as C, _t as D, xt as E, Tt as O, yn as S, bt as T, $t as _, Nn as a, Ue as b, qn as c, ht as d, pt as f, Ge as g, Cn as h, Ae as i, vt as k, at as l, Jn as m, ar as n, Mn as o, Zn as p, xn as r, Pn as s, sr as t, We as u, In as v, Dn as w, Kn as x, bn as y };
