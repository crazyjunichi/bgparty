import { n as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
//#region node_modules/zod/v4/core/util.js
var t = /* @__PURE__ */ e({
	BIGINT_FORMAT_RANGES: () => be,
	CONSTANT_CATCH: () => Ze,
	Class: () => Ue,
	NUMBER_FORMAT_RANGES: () => ye,
	aborted: () => S,
	allowsEval: () => ue,
	assert: () => s,
	assertEqual: () => n,
	assertIs: () => a,
	assertNever: () => o,
	assertNotEqual: () => r,
	assignProp: () => h,
	attachSchema: () => ke,
	base64ToUint8Array: () => Le,
	base64urlToUint8Array: () => ze,
	cached: () => d,
	captureStackTrace: () => le,
	cleanEnum: () => Ie,
	cleanRegex: () => p,
	clone: () => b,
	cloneDef: () => re,
	codePointLength: () => Me,
	constantCatch: () => Qe,
	createTransparentProxy: () => ge,
	defineLazy: () => te,
	defineLazyInternal: () => O,
	esc: () => se,
	escapeRegex: () => y,
	explicitlyAborted: () => Oe,
	extend: () => Ce,
	finalizeIssue: () => T,
	floatSafeRemainder: () => m,
	getElementAtPath: () => ie,
	getEnumValues: () => c,
	getLengthableOrigin: () => Ne,
	getParsedType: () => pe,
	getSizableOrigin: () => Ae,
	hexToUint8Array: () => Ve,
	hide: () => Ge,
	installLazyProp: () => Xe,
	isObject: () => _,
	isPlainObject: () => v,
	issue: () => Fe,
	joinValues: () => l,
	jsonStringifyReplacer: () => u,
	members: () => We,
	merge: () => Te,
	mergeDefs: () => g,
	normalizeParams: () => x,
	nullish: () => f,
	numKeys: () => fe,
	objectClone: () => ne,
	omit: () => Se,
	optionalKeys: () => ve,
	own: () => E,
	parsedType: () => Pe,
	partial: () => Ee,
	pick: () => xe,
	prefixIssues: () => C,
	primitiveTypes: () => he,
	promiseAllObject: () => ae,
	propertyKeyTypes: () => me,
	randomString: () => oe,
	required: () => De,
	safeExtend: () => we,
	shallowClone: () => de,
	slugify: () => ce,
	stringifyPrimitive: () => _e,
	toZod: () => i,
	uint8ArrayToBase64: () => Re,
	uint8ArrayToBase64url: () => Be,
	uint8ArrayToHex: () => He,
	unwrapMessage: () => w
});
function n(e) {
	return e;
}
function r(e) {
	return e;
}
function i() {
	return (e) => e;
}
function a(e) {}
function o(e) {
	throw Error("Unexpected value in exhaustive check");
}
function s(e) {}
function c(e) {
	let t = Object.values(e).filter((e) => typeof e == "number");
	return Object.entries(e).filter(([e, n]) => t.indexOf(+e) === -1).map(([e, t]) => t);
}
function l(e, t = "|") {
	return e.map((e) => _e(e)).join(t);
}
function u(e, t) {
	return typeof t == "bigint" ? t.toString() : t;
}
function d(e) {
	return { get value() {
		{
			let t = e();
			return Object.defineProperty(this, "value", { value: t }), t;
		}
	} };
}
function f(e) {
	return e == null;
}
function p(e) {
	let t = +!!e.startsWith("^"), n = e.endsWith("$") ? e.length - 1 : e.length;
	return e.slice(t, n);
}
function m(e, t) {
	let n = e / t, r = Math.round(n), i = 4 * 2 ** -52 * Math.max(Math.abs(n), 1);
	return Math.abs(n - r) < i ? 0 : n - r;
}
var ee = /* @__PURE__*/ Symbol("evaluating");
function te(e, t, n) {
	let r;
	Object.defineProperty(e, t, {
		get() {
			if (r !== ee) return r === void 0 && (r = ee, r = n()), r;
		},
		set(n) {
			Object.defineProperty(e, t, { value: n });
		},
		configurable: !0
	});
}
function ne(e) {
	return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
function h(e, t, n) {
	Object.defineProperty(e, t, {
		value: n,
		writable: !0,
		enumerable: !0,
		configurable: !0
	});
}
function g(...e) {
	let t = {};
	for (let n of e) {
		let e = Object.getOwnPropertyDescriptors(n);
		Object.assign(t, e);
	}
	return Object.defineProperties({}, t);
}
function re(e) {
	return g(e._zod.def);
}
function ie(e, t) {
	return t ? t.reduce((e, t) => e?.[t], e) : e;
}
function ae(e) {
	let t = Object.keys(e), n = t.map((t) => e[t]);
	return Promise.all(n).then((e) => {
		let n = {};
		for (let r = 0; r < t.length; r++) n[t[r]] = e[r];
		return n;
	});
}
function oe(e = 10) {
	let t = "";
	for (let n = 0; n < e; n++) t += "abcdefghijklmnopqrstuvwxyz"[Math.floor(Math.random() * 26)];
	return t;
}
function se(e) {
	return JSON.stringify(e);
}
function ce(e) {
	return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var le = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {};
function _(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var ue = /* @__PURE__*/ d(() => {
	if (j.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare")) return !1;
	try {
		return Function(""), !0;
	} catch {
		return !1;
	}
});
function v(e) {
	if (_(e) === !1) return !1;
	let t = e.constructor;
	if (t === void 0 || typeof t != "function") return !0;
	let n = t.prototype;
	return _(n) !== !1 && Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") !== !1;
}
function de(e) {
	return v(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
function fe(e) {
	let t = 0;
	for (let n in e) Object.prototype.hasOwnProperty.call(e, n) && t++;
	return t;
}
var pe = (e) => {
	let t = typeof e;
	switch (t) {
		case "undefined": return "undefined";
		case "string": return "string";
		case "number": return Number.isNaN(e) ? "nan" : "number";
		case "boolean": return "boolean";
		case "function": return "function";
		case "bigint": return "bigint";
		case "symbol": return "symbol";
		case "object": return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
		default: throw Error(`Unknown data type: ${t}`);
	}
}, me = /* @__PURE__*/ new Set([
	"string",
	"number",
	"symbol"
]), he = /* @__PURE__*/ new Set([
	"string",
	"number",
	"bigint",
	"boolean",
	"symbol",
	"undefined"
]);
function y(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function b(e, t, n) {
	let r = new e._zod.constr(t ?? e._zod.def);
	return (!t || n?.parent) && (r._zod.parent = e), r;
}
function x(e) {
	let t = e;
	if (!t) return {};
	if (typeof t == "string") return { error: () => t };
	if (t?.message !== void 0) {
		if (t?.error !== void 0) throw Error("Cannot specify both `message` and `error` params");
		t.error = t.message;
	}
	return delete t.message, typeof t.error == "string" ? {
		...t,
		error: () => t.error
	} : t;
}
function ge(e) {
	let t;
	return new Proxy({}, {
		get(n, r, i) {
			return t ??= e(), Reflect.get(t, r, i);
		},
		set(n, r, i, a) {
			return t ??= e(), Reflect.set(t, r, i, a);
		},
		has(n, r) {
			return t ??= e(), Reflect.has(t, r);
		},
		deleteProperty(n, r) {
			return t ??= e(), Reflect.deleteProperty(t, r);
		},
		ownKeys(n) {
			return t ??= e(), Reflect.ownKeys(t);
		},
		getOwnPropertyDescriptor(n, r) {
			return t ??= e(), Reflect.getOwnPropertyDescriptor(t, r);
		},
		defineProperty(n, r, i) {
			return t ??= e(), Reflect.defineProperty(t, r, i);
		}
	});
}
function _e(e) {
	return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
function ve(e) {
	return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
var ye = {
	safeint: [-(2 ** 53 - 1), 2 ** 53 - 1],
	int32: [-2147483648, 2147483647],
	uint32: [0, 4294967295],
	float32: [-34028234663852886e22, 34028234663852886e22],
	float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, be = {
	int64: [/* @__PURE__*/ BigInt("-9223372036854775808"), /* @__PURE__*/ BigInt("9223372036854775807")],
	uint64: [/* @__PURE__*/ BigInt(0), /* @__PURE__*/ BigInt("18446744073709551615")]
};
function xe(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".pick() cannot be used on object schemas containing refinements");
	return b(e, g(e._zod.def, {
		get shape() {
			let e = {};
			for (let r of Reflect.ownKeys(t)) {
				if (!Object.prototype.hasOwnProperty.call(n.shape, r)) throw Error(`Unrecognized key: "${String(r)}"`);
				t[r] && h(e, r, n.shape[r]);
			}
			return h(this, "shape", e), e;
		},
		checks: []
	}));
}
function Se(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".omit() cannot be used on object schemas containing refinements");
	return b(e, g(e._zod.def, {
		get shape() {
			let r = { ...e._zod.def.shape };
			for (let e of Reflect.ownKeys(t)) {
				if (!Object.prototype.hasOwnProperty.call(n.shape, e)) throw Error(`Unrecognized key: "${String(e)}"`);
				t[e] && delete r[e];
			}
			return h(this, "shape", r), r;
		},
		checks: []
	}));
}
function Ce(e, t) {
	if (!v(t)) throw Error("Invalid input to extend: expected a plain object");
	let n = e._zod.def.checks;
	if (n && n.length > 0) {
		let n = e._zod.def.shape;
		for (let e of Reflect.ownKeys(t)) if (Object.getOwnPropertyDescriptor(n, e) !== void 0) throw Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
	}
	return b(e, g(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return h(this, "shape", n), n;
	} }));
}
function we(e, t) {
	if (!v(t)) throw Error("Invalid input to safeExtend: expected a plain object");
	return b(e, g(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return h(this, "shape", n), n;
	} }));
}
function Te(e, t) {
	if (!t?._zod?.def) throw Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
	if (e._zod.def.checks?.length) throw Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
	return b(e, g(e._zod.def, {
		get shape() {
			let n = {
				...e._zod.def.shape,
				...t._zod.def.shape
			};
			return h(this, "shape", n), n;
		},
		get catchall() {
			return t._zod.def.catchall;
		},
		checks: t._zod.def.checks ?? []
	}));
}
function Ee(e, t, n, r = "partial") {
	let i = t._zod.def.checks;
	if (i && i.length > 0) throw Error(`.${r}() cannot be used on object schemas containing refinements`);
	return b(t, g(t._zod.def, {
		get shape() {
			let r = t._zod.def.shape, i = { ...r };
			if (n) for (let t of Reflect.ownKeys(n)) {
				if (!Object.prototype.hasOwnProperty.call(r, t)) throw Error(`Unrecognized key: "${String(t)}"`);
				n[t] && (i[t] = e ? new e({
					type: "optional",
					innerType: r[t]
				}) : r[t]);
			}
			else for (let t of Reflect.ownKeys(r)) i[t] = e ? new e({
				type: "optional",
				innerType: r[t]
			}) : r[t];
			return h(this, "shape", i), i;
		},
		checks: []
	}));
}
function De(e, t, n) {
	return b(t, g(t._zod.def, { get shape() {
		let r = t._zod.def.shape, i = { ...r };
		if (n) for (let t of Reflect.ownKeys(n)) {
			if (!Object.prototype.hasOwnProperty.call(i, t)) throw Error(`Unrecognized key: "${String(t)}"`);
			n[t] && (i[t] = new e({
				type: "nonoptional",
				innerType: r[t]
			}));
		}
		else for (let t of Reflect.ownKeys(r)) i[t] = new e({
			type: "nonoptional",
			innerType: r[t]
		});
		return h(this, "shape", i), i;
	} }));
}
function S(e, t = 0) {
	if (e.aborted === !0) return !0;
	for (let n = t; n < e.issues.length; n++) if (e.issues[n]?.continue !== !0) return !0;
	return !1;
}
function Oe(e, t = 0) {
	if (e.aborted === !0) return !0;
	for (let n = t; n < e.issues.length; n++) if (e.issues[n]?.continue === !1) return !0;
	return !1;
}
function C(e, t) {
	return t.map((t) => {
		var n;
		return (n = t).path ?? (n.path = []), t.path.unshift(e), t;
	});
}
function w(e) {
	return typeof e == "string" ? e : e?.message;
}
function ke(e, t, n) {
	var r;
	for (let i = t; i < e.length; i++) (r = e[i]).schema ?? (r.schema = n);
}
function T(e, t, n) {
	var r;
	let i = e.inst?._zod?.traits;
	i?.has("$ZodType") && (i.has("$ZodCheck") ? (r = e).schema ?? (r.schema = e.inst) : e.schema = e.inst);
	let a = e.schema === e.inst ? void 0 : e.schema?._zod.def?.error, o = e.message ? e.message : w(e.inst?._zod.def?.error?.(e)) ?? w(a?.(e)) ?? w(t?.error?.(e)) ?? w(n.customError?.(e)) ?? w(n.localeError?.(e)) ?? "Invalid input", { inst: s, schema: c, continue: l, input: u, ...d } = e;
	return d.path ??= [], d.message = o, t?.reportInput && (d.input = u), d;
}
function Ae(e) {
	return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
var je = /[\uD800-\uDBFF]/;
function Me(e) {
	let t = e.length;
	if (!je.test(e)) return t;
	let n = t;
	for (let r = 0; r < t - 1; r++) (e.charCodeAt(r) & 64512) == 55296 && (e.charCodeAt(r + 1) & 64512) == 56320 && (n--, r++);
	return n;
}
function Ne(e) {
	return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function Pe(e) {
	let t = typeof e;
	switch (t) {
		case "number": return Number.isNaN(e) ? "nan" : "number";
		case "object": {
			if (e === null) return "null";
			if (Array.isArray(e)) return "array";
			let t = e;
			if (t && Object.getPrototypeOf(t) !== Object.prototype && "constructor" in t && t.constructor) return t.constructor.name;
		}
	}
	return t;
}
function Fe(...e) {
	let [t, n, r] = e;
	return typeof t == "string" ? {
		message: t,
		code: "custom",
		input: n,
		inst: r
	} : { ...t };
}
function Ie(e) {
	return Object.entries(e).filter(([e, t]) => Number.isNaN(Number.parseInt(e, 10))).map((e) => e[1]);
}
function Le(e) {
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
	return n;
}
function Re(e) {
	let t = "";
	for (let n = 0; n < e.length; n++) t += String.fromCharCode(e[n]);
	return btoa(t);
}
function ze(e) {
	let t = e.replace(/-/g, "+").replace(/_/g, "/");
	return Le(t + "=".repeat((4 - t.length % 4) % 4));
}
function Be(e) {
	return Re(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
function Ve(e) {
	let t = e.replace(/^0x/, "");
	if (t.length % 2 != 0) throw Error("Invalid hex string length");
	let n = new Uint8Array(t.length / 2);
	for (let e = 0; e < t.length; e += 2) n[e / 2] = Number.parseInt(t.slice(e, e + 2), 16);
	return n;
}
function He(e) {
	return Array.from(e).map((e) => e.toString(16).padStart(2, "0")).join("");
}
var Ue = class {
	constructor(...e) {}
};
function We(e, t) {
	for (let n in t) {
		let r = Object.getOwnPropertyDescriptor(t, n);
		r.get ? Object.defineProperty(e, n, {
			...r,
			enumerable: !1
		}) : Ke(e, n, r.value);
	}
}
function E(e, t, n, r = !0) {
	return Object.defineProperty(e, t, {
		configurable: !0,
		writable: !0,
		enumerable: r,
		value: n
	}), n;
}
function Ge(e, t, n) {
	return E(e, t, n, !1);
}
function Ke(e, t, n) {
	Object.defineProperty(e, t, {
		configurable: !0,
		get() {
			return this == null ? n : E(this, t, n.bind(this));
		},
		set(e) {
			E(this, t, e);
		}
	});
}
function qe(e, t) {
	let n = Object.getPrototypeOf(e);
	return t in n ? void 0 : n;
}
var Je, D = !1, Ye = {
	configurable: !0,
	get() {
		D = !0;
	}
};
function O(e, t, n) {
	let r = Object.getPrototypeOf(e._zod);
	if (t in r && Je !== e._zod) {
		Je = void 0;
		return;
	}
	Je = e._zod, Object.defineProperty(r, t, {
		configurable: !0,
		get() {
			Object.defineProperty(this, t, Ye);
			let e = D;
			D = !1;
			try {
				let r = n(this);
				return D ? delete this[t] : Object.defineProperty(this, t, {
					configurable: !0,
					writable: !0,
					value: r
				}), D ||= e, r;
			} catch (n) {
				throw delete this[t], D ||= e, n;
			}
		},
		set(e) {
			Object.defineProperty(this, t, {
				configurable: !0,
				writable: !0,
				value: e
			});
		}
	});
}
function Xe(e, t, n, r) {
	let i = qe(e, t);
	i && Object.defineProperty(i, t, {
		configurable: !0,
		get() {
			let e = {
				configurable: !0,
				writable: !0,
				enumerable: r,
				value: void 0
			};
			return Object.defineProperty(this, t, e), e.value = n(this), Object.defineProperty(this, t, e), e.value;
		},
		set(e) {
			Object.defineProperty(this, t, {
				configurable: !0,
				writable: !0,
				enumerable: r,
				value: e
			});
		}
	});
}
var Ze = "~constantCatch";
function Qe(e) {
	let t = () => e;
	return t[Ze] = !0, t;
}
//#endregion
//#region node_modules/zod/v4/core/core.js
var $e, et = /*@__PURE__*/ Object.freeze({ status: "aborted" }), tt = {
	value: void 0,
	enumerable: !1
}, nt = "captureStackTrace" in Error ? Error : null;
function rt(e) {
	let t = nt;
	if (t) {
		let n = t.stackTraceLimit;
		if (typeof n == "number") {
			try {
				t.stackTraceLimit = 0;
			} catch {
				return nt = null, new e();
			}
			try {
				return new e();
			} finally {
				t.stackTraceLimit = n;
			}
		}
	}
	return new e();
}
function k(e, t, n, r) {
	let i = {};
	function a(e) {
		this.def = e, this.constr = d, this.traits = /* @__PURE__ */ new Set();
	}
	a.prototype = i;
	let o = n, s = o && /* @__PURE__ */ new WeakSet();
	function c(n, r) {
		if (!n._zod) {
			tt.value = new a(r);
			try {
				Object.defineProperty(n, "_zod", tt);
			} finally {
				tt.value = void 0;
			}
		}
		if (n._zod.traits.has(e)) return;
		if (n._zod.traits.add(e), t(n, r), s) {
			let e = Object.getPrototypeOf(n), t = n._zod.constr.prototype, r = e;
			for (; r && r !== t;) r = Object.getPrototypeOf(r);
			let i = r ?? e;
			s.has(i) || (s.add(i), We(i, o));
		}
		let i = d.prototype;
		for (let e in i) Object.prototype.hasOwnProperty.call(i, e) && (e in n || (n[e] = i[e].bind(n)));
	}
	let l = r?.Parent ?? Object;
	class u extends l {}
	Object.defineProperty(u, "name", { value: e });
	function d(e) {
		let t = r?.Parent ? rt(u) : this;
		c(t, e);
		let n = t._zod.deferred;
		if (n) {
			for (let e of n) e();
			t._zod.deferred = void 0;
		}
		let i = globalThis.__zod_globalConfig?.postProcessor;
		return i && i(t), t;
	}
	return Object.defineProperty(d, "init", { value: c }), Object.defineProperty(d, Symbol.hasInstance, { value: (t) => r?.Parent && t instanceof r.Parent ? !0 : t?._zod?.traits?.has(e) }), Object.defineProperty(d, "name", { value: e }), d;
}
var it = /*@__PURE__*/ Symbol("zod_brand"), A = class extends Error {
	constructor() {
		super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
	}
}, at = class extends Error {
	constructor(e) {
		super(`Encountered unidirectional transform during encode: ${e}`), this.name = "ZodEncodeError";
	}
};
($e = globalThis).__zod_globalConfig ?? ($e.__zod_globalConfig = {});
var j = globalThis.__zod_globalConfig;
function M(e) {
	return e && Object.assign(j, e), j;
}
//#endregion
//#region node_modules/zod/v4/core/errors.js
function ot() {
	let e = this._zod;
	return e.message ??= JSON.stringify(e.def, u, 2), e.message;
}
function st(e) {
	this._zod.message = e;
}
var ct = {
	get: ot,
	set: st,
	enumerable: !0,
	configurable: !0
}, lt = {
	value: void 0,
	enumerable: !1
}, ut = {
	value: void 0,
	enumerable: !1
}, dt = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), ft = (e, t) => {
	e.name = "$ZodError", lt.value = e._zod, Object.defineProperty(e, "_zod", lt), ut.value = t, Object.defineProperty(e, "issues", ut), lt.value = void 0, ut.value = void 0, Object.defineProperty(e, "message", ct);
	let n = Object.getPrototypeOf(e);
	dt.has(n) || (dt.add(n), Object.defineProperty(n, "toString", {
		configurable: !0,
		enumerable: !1,
		get() {
			let e = () => this.message;
			return Object.defineProperty(this, "toString", {
				value: e,
				configurable: !0,
				writable: !0
			}), e;
		},
		set(e) {
			Object.defineProperty(this, "toString", {
				value: e,
				configurable: !0,
				writable: !0
			});
		}
	}));
}, pt = k("$ZodError", ft), N = k("$ZodError", ft, void 0, { Parent: Error });
function mt(e, t, n) {
	return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, {
		value: n(),
		writable: !0,
		enumerable: !0,
		configurable: !0
	}) : e[t] = n()), e[t];
}
function ht(e, t = (e) => e.message) {
	let n = {}, r = [];
	for (let i of e.issues) i.path.length > 0 ? mt(n, i.path[0], () => []).push(t(i)) : r.push(t(i));
	return {
		formErrors: r,
		fieldErrors: n
	};
}
function gt(e, t = (e) => e.message) {
	let n = { _errors: [] }, r = (e, i = []) => {
		for (let a of e.issues) if (a.code === "invalid_union" && a.errors.length) a.errors.map((e) => r({ issues: e }, [...i, ...a.path]));
		else if (a.code === "invalid_key") r({ issues: a.issues }, [...i, ...a.path]);
		else if (a.code === "invalid_element") r({ issues: a.issues }, [...i, ...a.path]);
		else {
			let e = [...i, ...a.path];
			if (e.length === 0) n._errors.push(t(a));
			else {
				let r = n, i = 0;
				for (; i < e.length;) {
					let n = e[i], o = i === e.length - 1;
					if (n === "_errors") {
						o && r._errors.push(t(a)), i++;
						continue;
					}
					Object.prototype.hasOwnProperty.call(r, n) || Object.defineProperty(r, n, {
						value: { _errors: [] },
						enumerable: !0,
						writable: !0,
						configurable: !0
					});
					let s = r[n];
					o && s._errors.push(t(a)), r = s, i++;
				}
			}
		}
	};
	return r(e), n;
}
function _t(e, t = (e) => e.message) {
	let n = { errors: [] }, r = (e, i = []) => {
		var a;
		for (let o of e.issues) if (o.code === "invalid_union" && o.errors.length) o.errors.map((e) => r({ issues: e }, [...i, ...o.path]));
		else if (o.code === "invalid_key") r({ issues: o.issues }, [...i, ...o.path]);
		else if (o.code === "invalid_element") r({ issues: o.issues }, [...i, ...o.path]);
		else {
			let e = [...i, ...o.path];
			if (e.length === 0) {
				n.errors.push(t(o));
				continue;
			}
			let r = n, s = 0;
			for (; s < e.length;) {
				let n = e[s], i = s === e.length - 1;
				typeof n == "string" ? (r.properties ?? (r.properties = {}), Object.prototype.hasOwnProperty.call(r.properties, n) || Object.defineProperty(r.properties, n, {
					value: { errors: [] },
					enumerable: !0,
					writable: !0,
					configurable: !0
				}), r = r.properties[n]) : (r.items ?? (r.items = []), (a = r.items)[n] ?? (a[n] = { errors: [] }), r = r.items[n]), i && r.errors.push(t(o)), s++;
			}
		}
	};
	return r(e), n;
}
function vt(e) {
	let t = [], n = e.map((e) => typeof e == "object" ? e.key : e);
	for (let e of n) typeof e == "number" ? t.push(`[${e}]`) : typeof e == "symbol" ? t.push(`[${JSON.stringify(String(e))}]`) : /[^\w$]/.test(e) ? t.push(`[${JSON.stringify(e)}]`) : (t.length && t.push("."), t.push(e));
	return t.join("");
}
function yt(e) {
	let t = [], n = [...e.issues].sort((e, t) => (e.path ?? []).length - (t.path ?? []).length);
	for (let e of n) t.push(`✖ ${e.message}`), e.path?.length && t.push(`  → at ${vt(e.path)}`);
	return t.join("\n");
}
//#endregion
//#region node_modules/zod/v4/core/parse.js
function bt(e, t) {
	return {
		callee: t?.callee ?? e,
		Err: t?.Err
	};
}
var xt = (e) => {
	let t = (n, r, i, a) => {
		let o = i ? {
			...i,
			async: !1
		} : { async: !1 }, s = n._zod.run({
			value: r,
			issues: []
		}, o);
		if (s instanceof Promise) throw new A();
		if (s.issues.length) {
			let n = new ((a?.Err) ?? e)(s.issues.map((e) => T(e, o, M())));
			throw le(n, a?.callee ?? t), n;
		}
		return s.value;
	};
	return t;
}, St = /* @__PURE__*/ xt(N), Ct = (e) => {
	let t = async (n, r, i, a) => {
		let o = i ? {
			...i,
			async: !0
		} : { async: !0 }, s = n._zod.run({
			value: r,
			issues: []
		}, o);
		if (s instanceof Promise && (s = await s), s.issues.length) {
			let n = new ((a?.Err) ?? e)(s.issues.map((e) => T(e, o, M())));
			throw le(n, a?.callee ?? t), n;
		}
		return s.value;
	};
	return t;
}, wt = /* @__PURE__*/ Ct(N), Tt = (e) => (t, n, r) => {
	let i = r ? {
		...r,
		async: !1
	} : { async: !1 }, a = t._zod.run({
		value: n,
		issues: []
	}, i);
	if (a instanceof Promise) throw new A();
	return a.issues.length ? {
		success: !1,
		error: new (e ?? pt)(a.issues.map((e) => T(e, i, M())))
	} : {
		success: !0,
		data: a.value
	};
}, Et = /* @__PURE__*/ Tt(N), Dt = (e) => async (t, n, r) => {
	let i = r ? {
		...r,
		async: !0
	} : { async: !0 }, a = t._zod.run({
		value: n,
		issues: []
	}, i);
	return a instanceof Promise && (a = await a), a.issues.length ? {
		success: !1,
		error: new e(a.issues.map((e) => T(e, i, M())))
	} : {
		success: !0,
		data: a.value
	};
}, Ot = /* @__PURE__*/ Dt(N), kt = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), At = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), jt = ((e, t, n) => {
	let r = e._zod.bag.validator;
	return r !== void 0 && r(t) !== kt || Mt(e, t, n);
});
function Mt(e, t, n) {
	let r = n ? {
		...n,
		async: !1
	} : { async: !1 }, i = e._zod.bag.fallbackRun, a;
	if (i ? (r[At] = !0, a = i({
		value: t,
		issues: []
	}, r)) : a = e._zod.run({
		value: t,
		issues: []
	}, r), a instanceof Promise) throw new A();
	return a.issues.length === 0;
}
var Nt = async (e, t, n) => {
	let r = n ? {
		...n,
		async: !0
	} : { async: !0 }, i = e._zod.run({
		value: t,
		issues: []
	}, r);
	return i instanceof Promise && (i = await i), i.issues.length === 0;
}, Pt = (e) => {
	let t = xt(e), n = (e, r, i, a) => {
		let o = i ? {
			...i,
			direction: "backward"
		} : { direction: "backward" };
		return t(e, r, o, bt(n, a));
	};
	return n;
}, Ft = /* @__PURE__*/ Pt(N), It = (e) => {
	let t = xt(e), n = (e, r, i, a) => t(e, r, i, bt(n, a));
	return n;
}, Lt = /* @__PURE__*/ It(N), Rt = (e) => {
	let t = Ct(e), n = async (e, r, i, a) => {
		let o = i ? {
			...i,
			direction: "backward"
		} : { direction: "backward" };
		return await t(e, r, o, bt(n, a));
	};
	return n;
}, zt = /* @__PURE__*/ Rt(N), Bt = (e) => {
	let t = Ct(e), n = async (e, r, i, a) => await t(e, r, i, bt(n, a));
	return n;
}, Vt = /* @__PURE__*/ Bt(N), Ht = (e) => (t, n, r) => {
	let i = r ? {
		...r,
		direction: "backward"
	} : { direction: "backward" };
	return Tt(e)(t, n, i);
}, Ut = /* @__PURE__*/ Ht(N), Wt = (e) => (t, n, r) => Tt(e)(t, n, r), Gt = /* @__PURE__*/ Wt(N), Kt = (e) => async (t, n, r) => {
	let i = r ? {
		...r,
		direction: "backward"
	} : { direction: "backward" };
	return Dt(e)(t, n, i);
}, qt = /* @__PURE__*/ Kt(N), Jt = (e) => async (t, n, r) => Dt(e)(t, n, r), Yt = /* @__PURE__*/ Jt(N), Xt = /* @__PURE__ */ e({
	base64: () => wn,
	base64url: () => Tn,
	bigint: () => Rn,
	boolean: () => Vn,
	browserEmail: () => gn,
	cidrv4: () => Sn,
	cidrv6: () => Cn,
	creditCard: () => An,
	cuid: () => Zt,
	cuid2: () => Qt,
	date: () => Nn,
	datetime: () => In,
	domain: () => Dn,
	duration: () => an,
	e164: () => kn,
	email: () => dn,
	emoji: () => vn,
	extendedDuration: () => on,
	guid: () => sn,
	hex: () => Kn,
	hostname: () => En,
	html5Email: () => fn,
	httpProtocol: () => On,
	idnEmail: () => hn,
	integer: () => zn,
	ipv4: () => yn,
	ipv6: () => bn,
	ksuid: () => tn,
	lowercase: () => Wn,
	mac: () => xn,
	md5_base64: () => Xn,
	md5_base64url: () => Zn,
	md5_hex: () => Yn,
	nanoid: () => nn,
	nanoidOfLength: () => rn,
	null: () => Hn,
	number: () => Bn,
	rfc5322Email: () => pn,
	sha1_base64: () => $n,
	sha1_base64url: () => er,
	sha1_hex: () => Qn,
	sha256_base64: () => nr,
	sha256_base64url: () => rr,
	sha256_hex: () => tr,
	sha384_base64: () => ar,
	sha384_base64url: () => or,
	sha384_hex: () => ir,
	sha512_base64: () => cr,
	sha512_base64url: () => lr,
	sha512_hex: () => sr,
	string: () => Ln,
	time: () => Fn,
	ulid: () => $t,
	undefined: () => Un,
	unicodeEmail: () => mn,
	uppercase: () => Gn,
	uuid: () => P,
	uuid4: () => cn,
	uuid6: () => ln,
	uuid7: () => un,
	xid: () => en
}), Zt = /^[cC][0-9a-z]{6,}$/, Qt = /^[0-9a-z]+$/, $t = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, en = /^[0-9a-vA-V]{20}$/, tn = /^[A-Za-z0-9]{27}$/, nn = /^[a-zA-Z0-9_-]{21}$/;
function rn(e) {
	return RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
var an = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, on = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, sn = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, P = (e) => e ? RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, cn = /*@__PURE__*/ P(4), ln = /*@__PURE__*/ P(6), un = /*@__PURE__*/ P(7), dn = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, fn = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, pn = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, mn = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, hn = mn, gn = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, _n = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function vn() {
	return new RegExp(_n, "u");
}
var yn = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, bn = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, xn = (e) => {
	let t = y(e ?? ":");
	return RegExp(`^(?:[0-9A-F]{2}${t}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${t}){5}[0-9a-f]{2}$`);
}, Sn = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Cn = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, wn = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Tn = /^[A-Za-z0-9_-]*$/, En = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, Dn = /^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/, On = /^https?$/, kn = /^\+[1-9]\d{6,14}$/, An = /^\d(?:[ -]?\d){11,18}$/, jn = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function Mn(e) {
	return RegExp(`^${e}$`);
}
var Nn = /*@__PURE__*/ Mn(jn);
function Pn(e) {
	let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
	return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function Fn(e) {
	return RegExp(`^${Pn(e)}$`);
}
function In(e) {
	let t = ["Z"];
	e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
	let n = `${Pn({
		precision: e.precision,
		seconds: !0
	})}(?:${t.join("|")})`, r = e.local ? `${n}|${Pn({ precision: e.precision })}` : n;
	return RegExp(`^${jn}T(?:${r})$`);
}
var Ln = (e) => {
	let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
	return RegExp(`^${t}$`);
}, Rn = /^-?\d+n?$/, zn = /^-?\d+$/, Bn = /^-?\d+(?:\.\d+)?$/, Vn = /^(?:true|false)$/i, Hn = /^null$/i, Un = /^undefined$/i, Wn = /^[^A-Z]*$/, Gn = /^[^a-z]*$/, Kn = /^[0-9a-fA-F]*$/;
function qn(e, t) {
	return RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
}
function Jn(e) {
	return RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
var Yn = /^[0-9a-fA-F]{32}$/, Xn = /*@__PURE__*/ qn(22, "=="), Zn = /*@__PURE__*/ Jn(22), Qn = /^[0-9a-fA-F]{40}$/, $n = /*@__PURE__*/ qn(27, "="), er = /*@__PURE__*/ Jn(27), tr = /^[0-9a-fA-F]{64}$/, nr = /*@__PURE__*/ qn(43, "="), rr = /*@__PURE__*/ Jn(43), ir = /^[0-9a-fA-F]{96}$/, ar = /*@__PURE__*/ qn(64, ""), or = /*@__PURE__*/ Jn(64), sr = /^[0-9a-fA-F]{128}$/, cr = /*@__PURE__*/ qn(86, "=="), lr = /*@__PURE__*/ Jn(86), F = /*@__PURE__*/ k("$ZodCheck", (e, t) => {
	var n;
	e._zod ??= {}, e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), ur = (e) => {
	let t = e.value;
	return !f(t) && t.size !== void 0;
}, dr = (e) => {
	let t = e.value;
	return !f(t) && t.length !== void 0;
}, fr = {
	number: "number",
	bigint: "bigint",
	object: "date"
}, pr = /*@__PURE__*/ k("$ZodCheckLessThan", (e, t) => {
	F.init(e, t);
	let n = fr[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.maximum : n.exclusiveMaximum) ?? Infinity;
		t.value < r && (t.inclusive ? n.maximum = t.value : n.exclusiveMaximum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value <= t.value : r.value < t.value) || r.issues.push({
			origin: fr[typeof r.value] ?? n,
			code: "too_big",
			maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), mr = /*@__PURE__*/ k("$ZodCheckGreaterThan", (e, t) => {
	F.init(e, t);
	let n = fr[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.minimum : n.exclusiveMinimum) ?? -Infinity;
		t.value > r && (t.inclusive ? n.minimum = t.value : n.exclusiveMinimum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value >= t.value : r.value > t.value) || r.issues.push({
			origin: fr[typeof r.value] ?? n,
			code: "too_small",
			minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), hr = /*@__PURE__*/ k("$ZodCheckMultipleOf", (e, t) => {
	F.init(e, t), e._zod.onattach.push((e) => {
		var n;
		(n = e._zod.bag).multipleOf ?? (n.multipleOf = t.value);
	}), e._zod.check = (n) => {
		if (typeof n.value != typeof t.value) throw Error("Cannot mix number and bigint in multiple_of check.");
		(typeof n.value == "bigint" ? t.value !== BigInt(0) && n.value % t.value === BigInt(0) : m(n.value, t.value) === 0) || n.issues.push({
			origin: typeof n.value,
			code: "not_multiple_of",
			divisor: t.value,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), gr = /*@__PURE__*/ k("$ZodCheckNumberFormat", (e, t) => {
	F.init(e, t), t.format = t.format || "float64";
	let n = t.format?.includes("int"), r = n ? "int" : "number", [i, a] = ye[t.format];
	e._zod.onattach.push((e) => {
		let r = e._zod.bag;
		r.format = t.format, r.minimum = i, r.maximum = a, n && (r.pattern = zn);
	}), e._zod.check = (o) => {
		let s = o.value;
		if (n) {
			if (!Number.isInteger(s)) {
				o.issues.push({
					expected: r,
					format: t.format,
					code: "invalid_type",
					continue: !1,
					input: s,
					inst: e
				});
				return;
			}
			if (!Number.isSafeInteger(s)) {
				s > 0 ? o.issues.push({
					input: s,
					code: "too_big",
					maximum: 2 ** 53 - 1,
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				}) : o.issues.push({
					input: s,
					code: "too_small",
					minimum: -(2 ** 53 - 1),
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				});
				return;
			}
		}
		s < i && o.issues.push({
			origin: "number",
			input: s,
			code: "too_small",
			minimum: i,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		}), s > a && o.issues.push({
			origin: "number",
			input: s,
			code: "too_big",
			maximum: a,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		});
	};
}), _r = /*@__PURE__*/ k("$ZodCheckBigIntFormat", (e, t) => {
	F.init(e, t);
	let [n, r] = be[t.format];
	e._zod.onattach.push((e) => {
		let i = e._zod.bag;
		i.format = t.format, i.minimum = n, i.maximum = r;
	}), e._zod.check = (i) => {
		let a = i.value;
		a < n && i.issues.push({
			origin: "bigint",
			input: a,
			code: "too_small",
			minimum: n,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		}), a > r && i.issues.push({
			origin: "bigint",
			input: a,
			code: "too_big",
			maximum: r,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		});
	};
}), vr = /*@__PURE__*/ k("$ZodCheckMaxSize", (e, t) => {
	var n;
	F.init(e, t), (n = e._zod.def).when ?? (n.when = ur), e._zod.onattach.push((e) => {
		let n = e._zod.bag.maximum ?? Infinity;
		t.maximum < n && (e._zod.bag.maximum = t.maximum);
	}), e._zod.check = (n) => {
		let r = n.value;
		r.size <= t.maximum || n.issues.push({
			origin: Ae(r),
			code: "too_big",
			maximum: t.maximum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), yr = /*@__PURE__*/ k("$ZodCheckMinSize", (e, t) => {
	var n;
	F.init(e, t), (n = e._zod.def).when ?? (n.when = ur), e._zod.onattach.push((e) => {
		let n = e._zod.bag.minimum ?? -Infinity;
		t.minimum > n && (e._zod.bag.minimum = t.minimum);
	}), e._zod.check = (n) => {
		let r = n.value;
		r.size >= t.minimum || n.issues.push({
			origin: Ae(r),
			code: "too_small",
			minimum: t.minimum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), br = /*@__PURE__*/ k("$ZodCheckSizeEquals", (e, t) => {
	var n;
	F.init(e, t), (n = e._zod.def).when ?? (n.when = ur), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.minimum = t.size, n.maximum = t.size, n.size = t.size;
	}), e._zod.check = (n) => {
		let r = n.value, i = r.size;
		if (i === t.size) return;
		let a = i > t.size;
		n.issues.push({
			origin: Ae(r),
			...a ? {
				code: "too_big",
				maximum: t.size
			} : {
				code: "too_small",
				minimum: t.size
			},
			inclusive: !0,
			exact: !0,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), xr = /*@__PURE__*/ k("$ZodCheckMaxLength", (e, t) => {
	var n;
	F.init(e, t), (n = e._zod.def).when ?? (n.when = dr), e._zod.onattach.push((e) => {
		let n = e._zod.bag.maximum ?? Infinity;
		t.maximum < n && (e._zod.bag.maximum = t.maximum);
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length;
		if ((typeof r == "string" && i > t.maximum ? Me(r) : i) <= t.maximum) return;
		let a = Ne(r);
		n.issues.push({
			origin: a,
			code: "too_big",
			maximum: t.maximum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), Sr = /*@__PURE__*/ k("$ZodCheckMinLength", (e, t) => {
	var n;
	F.init(e, t), (n = e._zod.def).when ?? (n.when = dr), e._zod.onattach.push((e) => {
		let n = e._zod.bag.minimum ?? -Infinity;
		t.minimum > n && (e._zod.bag.minimum = t.minimum);
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length;
		if ((typeof r == "string" && i >= t.minimum && i < t.minimum * 2 ? Me(r) : i) >= t.minimum) return;
		let a = Ne(r);
		n.issues.push({
			origin: a,
			code: "too_small",
			minimum: t.minimum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), Cr = /*@__PURE__*/ k("$ZodCheckLengthEquals", (e, t) => {
	var n;
	F.init(e, t), (n = e._zod.def).when ?? (n.when = dr), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.minimum = t.length, n.maximum = t.length, n.length = t.length;
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length, a = typeof r == "string" && i >= t.length && i <= t.length * 2 ? Me(r) : i;
		if (a === t.length) return;
		let o = Ne(r), s = a > t.length;
		n.issues.push({
			origin: o,
			...s ? {
				code: "too_big",
				maximum: t.length
			} : {
				code: "too_small",
				minimum: t.length
			},
			inclusive: !0,
			exact: !0,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), wr = /*@__PURE__*/ k("$ZodCheckStringFormat", (e, t) => {
	var n, r;
	F.init(e, t), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.format = t.format, t.pattern && (n.patterns ??= /* @__PURE__ */ new Set(), n.patterns.add(t.pattern));
	}), t.pattern ? (n = e._zod).check ?? (n.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: t.format,
			input: n.value,
			...t.pattern ? { pattern: t.pattern.toString() } : {},
			inst: e,
			continue: !t.abort
		});
	}) : (r = e._zod).check ?? (r.check = () => {});
}), Tr = /*@__PURE__*/ k("$ZodCheckRegex", (e, t) => {
	wr.init(e, t), e._zod.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "regex",
			input: n.value,
			pattern: t.pattern.toString(),
			inst: e,
			continue: !t.abort
		});
	};
}), Er = /*@__PURE__*/ k("$ZodCheckLowerCase", (e, t) => {
	t.pattern ??= Wn, wr.init(e, t);
}), Dr = /*@__PURE__*/ k("$ZodCheckUpperCase", (e, t) => {
	t.pattern ??= Gn, wr.init(e, t);
}), Or = /*@__PURE__*/ k("$ZodCheckIncludes", (e, t) => {
	F.init(e, t);
	let n = y(t.includes), r = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
	t.pattern = r, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(r);
	}), e._zod.check = (n) => {
		n.value.includes(t.includes, t.position) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "includes",
			includes: t.includes,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), kr = /*@__PURE__*/ k("$ZodCheckStartsWith", (e, t) => {
	F.init(e, t);
	let n = RegExp(`^${y(t.prefix)}.*`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.startsWith(t.prefix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "starts_with",
			prefix: t.prefix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Ar = /*@__PURE__*/ k("$ZodCheckEndsWith", (e, t) => {
	F.init(e, t);
	let n = RegExp(`.*${y(t.suffix)}$`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.endsWith(t.suffix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "ends_with",
			suffix: t.suffix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function jr(e, t, n) {
	e.issues.length && t.issues.push(...C(n, e.issues));
}
var Mr = /*@__PURE__*/ k("$ZodCheckProperty", (e, t) => {
	F.init(e, t), e._zod.check = (e) => {
		let n = t.schema._zod.run({
			value: e.value[t.property],
			issues: []
		}, {});
		if (n instanceof Promise) return n.then((n) => jr(n, e, t.property));
		jr(n, e, t.property);
	};
}), Nr = /*@__PURE__*/ k("$ZodCheckMimeType", (e, t) => {
	F.init(e, t);
	let n = new Set(t.mime);
	e._zod.onattach.push((e) => {
		e._zod.bag.mime = t.mime;
	}), e._zod.check = (r) => {
		n.has(r.value.type) || r.issues.push({
			code: "invalid_value",
			values: t.mime,
			input: r.value.type,
			inst: e,
			continue: !t.abort
		});
	};
}), Pr = /*@__PURE__*/ k("$ZodCheckOverwrite", (e, t) => {
	F.init(e, t), e._zod.check = (e) => {
		e.value = t.tx(e.value);
	};
}), Fr = class {
	constructor(e = [], t = {}) {
		this.content = [], this.indent = 0, this.args = e, this.closed = t;
	}
	indented(e) {
		this.indent += 1, e(this), --this.indent;
	}
	write(e) {
		if (typeof e == "function") {
			e(this, { execution: "sync" }), e(this, { execution: "async" });
			return;
		}
		let t = e.split("\n").filter((e) => e), n = Math.min(...t.map((e) => e.length - e.trimStart().length)), r = t.map((e) => e.slice(n)).map((e) => " ".repeat(this.indent * 2) + e);
		for (let e of r) this.content.push(e);
	}
	compile() {
		let e = Function, t = this?.content ?? [""];
		return new e(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {\n${t.join("\n")}\n};`)(...Object.values(this.closed));
	}
}, Ir = {
	major: 4,
	minor: 5,
	patch: 4
}, I = /*@__PURE__*/ k("$ZodType", (e, t) => {
	var n;
	e ??= {}, e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Ir;
	let r = e._zod.def.checks, i = e._zod.traits.has("$ZodCheck") ? [e, ...r ?? []] : r?.length ? [...r] : [];
	for (let t of i) for (let n of t._zod.onattach) n(e);
	if (i.length === 0) (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
		e._zod.run = e._zod.parse;
	});
	else {
		let t = (t, n, r) => {
			if (t.memo) return t;
			let i = S(t), a;
			for (let o of n) {
				if (o._zod.def.when) {
					if (Oe(t) || !o._zod.def.when(t)) continue;
				} else if (i) continue;
				let n = t.issues.length, s = o._zod.check(t);
				if (s instanceof Promise && r?.async === !1) throw new A();
				if (a || s instanceof Promise) a = (a ?? Promise.resolve()).then(async () => {
					await s, t.issues.length !== n && (ke(t.issues, n, e), i ||= S(t, n));
				});
				else {
					if (t.issues.length === n) continue;
					ke(t.issues, n, e), i ||= S(t, n);
				}
			}
			return a ? a.then(() => t) : t;
		}, n = (n, r, a) => {
			if (S(n)) return n.aborted = !0, n;
			let o = t(r, i, a);
			if (o instanceof Promise) {
				if (a.async === !1) throw new A();
				return o.then((t) => e._zod.parse(t, a));
			}
			return e._zod.parse(o, a);
		};
		e._zod.run = (r, a) => {
			if (a.skipChecks) return e._zod.parse(r, a);
			if (a.direction === "backward") {
				let t = e._zod.parse({
					value: r.value,
					issues: []
				}, {
					...a,
					skipChecks: !0
				});
				return t instanceof Promise ? t.then((e) => n(e, r, a)) : n(t, r, a);
			}
			let o = e._zod.parse(r, a);
			if (o instanceof Promise) {
				if (a.async === !1) throw new A();
				return o.then((e) => t(e, i, a));
			}
			return t(o, i, a);
		};
	}
}, {
	get "~standard"() {
		return Ge(this, "~standard", Rr(this));
	},
	set "~standard"(e) {
		E(this, "~standard", e);
	}
}), Lr = (e) => e.success ? { value: e.data } : { issues: e.error?.issues };
function Rr(e) {
	return {
		validate: (t) => {
			try {
				return Lr(Et(e, t));
			} catch {
				return Ot(e, t).then(Lr);
			}
		},
		vendor: "zod",
		version: 1
	};
}
var zr = /*@__PURE__*/ k("$ZodString", (e, t) => {
	I.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Ln(e._zod.bag), e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = String(n.value);
		} catch {}
		return typeof n.value == "string" || n.issues.push({
			expected: "string",
			code: "invalid_type",
			input: n.value,
			inst: e
		}), n;
	};
}), L = /*@__PURE__*/ k("$ZodStringFormat", (e, t) => {
	wr.init(e, t), zr.init(e, t);
}), Br = /*@__PURE__*/ k("$ZodGUID", (e, t) => {
	t.pattern ??= sn, L.init(e, t);
}), Vr = /*@__PURE__*/ k("$ZodUUID", (e, t) => {
	if (t.version) {
		let e = {
			v1: 1,
			v2: 2,
			v3: 3,
			v4: 4,
			v5: 5,
			v6: 6,
			v7: 7,
			v8: 8
		}[t.version];
		if (e === void 0) throw Error(`Invalid UUID version: "${t.version}"`);
		t.pattern ??= P(e);
	} else t.pattern ??= P();
	L.init(e, t);
}), Hr = /*@__PURE__*/ k("$ZodEmail", (e, t) => {
	t.pattern ??= dn, L.init(e, t);
});
function Ur(e, t) {
	if (!t.normalize && t.protocol?.source === On.source && !/^https?:\/\//i.test(e)) return 1;
	try {
		return new URL(e);
	} catch {
		return 2;
	}
}
var Wr = /[\t\n\r]/g;
function Gr(e) {
	return e.replace(Wr, "");
}
function Kr(e, t) {
	return t.lastIndex = 0, t.test(e.hostname);
}
function qr(e, t) {
	return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
var Jr = /*@__PURE__*/ k("$ZodURL", (e, t) => {
	L.init(e, t), e._zod.check = (n) => {
		try {
			let r = n.value.trim(), i = Ur(r, t);
			if (i === 1) {
				n.issues.push({
					code: "invalid_format",
					format: "url",
					note: "Invalid URL format",
					input: n.value,
					inst: e,
					continue: !t.abort
				});
				return;
			}
			if (i === 2) {
				n.issues.push({
					code: "invalid_format",
					format: "url",
					input: n.value,
					inst: e,
					continue: !t.abort
				});
				return;
			}
			t.hostname && !Kr(i, t.hostname) && n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid hostname",
				pattern: t.hostname.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			}), t.protocol && !qr(i, t.protocol) && n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid protocol",
				pattern: t.protocol.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			}), n.value = t.normalize ? i.href : Gr(r);
			return;
		} catch {
			n.issues.push({
				code: "invalid_format",
				format: "url",
				input: n.value,
				inst: e,
				continue: !t.abort
			});
		}
	};
}), Yr = /*@__PURE__*/ k("$ZodEmoji", (e, t) => {
	t.pattern ??= vn(), L.init(e, t);
}), Xr = /*@__PURE__*/ k("$ZodNanoID", (e, t) => {
	if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1)) throw Error(`Invalid nanoid length: ${t.length}`);
	t.pattern ??= t.length === void 0 ? nn : rn(t.length), L.init(e, t);
}), Zr = /*@__PURE__*/ k("$ZodCUID", (e, t) => {
	t.pattern ??= Zt, L.init(e, t);
}), Qr = /*@__PURE__*/ k("$ZodCUID2", (e, t) => {
	t.pattern ??= Qt, L.init(e, t);
}), $r = /*@__PURE__*/ k("$ZodULID", (e, t) => {
	t.pattern ??= $t, L.init(e, t);
}), ei = /*@__PURE__*/ k("$ZodXID", (e, t) => {
	t.pattern ??= en, L.init(e, t);
}), ti = /*@__PURE__*/ k("$ZodKSUID", (e, t) => {
	t.pattern ??= tn, L.init(e, t);
}), ni = /*@__PURE__*/ k("$ZodISODateTime", (e, t) => {
	t.pattern ??= In(t), L.init(e, t), (t.local || t.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((e) => {
		e._zod.bag.laxFormat = !0;
	}));
}), ri = /*@__PURE__*/ k("$ZodISODate", (e, t) => {
	t.pattern ??= Nn, L.init(e, t);
}), ii = /*@__PURE__*/ k("$ZodISOTime", (e, t) => {
	t.pattern ??= Fn(t), L.init(e, t);
}), ai = /*@__PURE__*/ k("$ZodISODuration", (e, t) => {
	t.pattern ??= an, L.init(e, t);
}), oi = /*@__PURE__*/ k("$ZodIPv4", (e, t) => {
	t.pattern ??= yn, L.init(e, t), e._zod.bag.format = "ipv4";
}), si = /^[0-9a-fA-F:.]+$/;
function ci(e) {
	if (!si.test(e)) return !1;
	try {
		return new URL(`http://[${e}]`), !0;
	} catch {
		return !1;
	}
}
var li = /*@__PURE__*/ k("$ZodIPv6", (e, t) => {
	t.pattern ??= bn, L.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
		ci(n.value) || n.issues.push({
			code: "invalid_format",
			format: "ipv6",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), ui = /*@__PURE__*/ k("$ZodMAC", (e, t) => {
	t.pattern ??= xn(t.delimiter), L.init(e, t), e._zod.bag.format = "mac";
}), di = /*@__PURE__*/ k("$ZodCIDRv4", (e, t) => {
	t.pattern ??= Sn, L.init(e, t);
});
function fi(e) {
	let t = e.split("/");
	if (t.length !== 2) return !1;
	let [n, r] = t;
	if (!r) return !1;
	let i = Number(r);
	return `${i}` !== r || i < 0 || i > 128 ? !1 : ci(n);
}
var pi = /*@__PURE__*/ k("$ZodCIDRv6", (e, t) => {
	t.pattern ??= Cn, L.init(e, t), e._zod.check = (n) => {
		fi(n.value) || n.issues.push({
			code: "invalid_format",
			format: "cidrv6",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function mi(e) {
	if (e === "") return !0;
	if (/\s/.test(e) || e.length % 4 != 0) return !1;
	try {
		return atob(e), !0;
	} catch {
		return !1;
	}
}
var hi = /*@__PURE__*/ k("$ZodBase64", (e, t) => {
	t.pattern ??= wn, L.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
		mi(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function gi(e) {
	if (!Tn.test(e)) return !1;
	let t = e.replace(/[-_]/g, (e) => e === "-" ? "+" : "/");
	return mi(t.padEnd(Math.ceil(t.length / 4) * 4, "="));
}
var _i = /*@__PURE__*/ k("$ZodBase64URL", (e, t) => {
	t.pattern ??= Tn, L.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
		gi(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64url",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), vi = /*@__PURE__*/ k("$ZodE164", (e, t) => {
	t.pattern ??= kn, L.init(e, t);
}), yi = /[- ]/g;
function bi(e) {
	let t = e.length, n = 1, r = 0;
	for (; t;) {
		let i = +e[--t];
		n ^= 1, r += n ? [
			0,
			2,
			4,
			6,
			8,
			1,
			3,
			5,
			7,
			9
		][i] : i;
	}
	return r % 10 == 0;
}
function xi(e) {
	return An.test(e) ? bi(e.replace(yi, "")) : !1;
}
var Si = /*@__PURE__*/ k("$ZodCreditCard", (e, t) => {
	t.pattern ??= An, L.init(e, t), e._zod.check = (n) => {
		xi(n.value) || n.issues.push({
			code: "invalid_format",
			format: "credit_card",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function Ci(e, t = null) {
	try {
		let n = e.split(".");
		if (n.length !== 3) return !1;
		let [r] = n;
		if (!r) return !1;
		let i = JSON.parse(atob(r));
		return !("typ" in i && i?.typ !== "JWT" || !i.alg || t && (!("alg" in i) || i.alg !== t));
	} catch {
		return !1;
	}
}
var wi = /*@__PURE__*/ k("$ZodJWT", (e, t) => {
	L.init(e, t), e._zod.check = (n) => {
		Ci(n.value, t.alg) || n.issues.push({
			code: "invalid_format",
			format: "jwt",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Ti = /*@__PURE__*/ k("$ZodCustomStringFormat", (e, t) => {
	L.init(e, t), e._zod.check = (n) => {
		t.fn(n.value) || n.issues.push({
			code: "invalid_format",
			format: t.format,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Ei = /*@__PURE__*/ k("$ZodNumber", (e, t) => {
	I.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? Bn, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = Number(n.value);
		} catch {}
		let i = n.value;
		if (typeof i == "number" && !Number.isNaN(i) && Number.isFinite(i)) return n;
		let a = typeof i == "number" ? Number.isNaN(i) ? "NaN" : Number.isFinite(i) ? void 0 : String(i) : void 0;
		return n.issues.push({
			expected: "number",
			code: "invalid_type",
			input: i,
			inst: e,
			...a ? { received: a } : {}
		}), n;
	};
}), Di = /*@__PURE__*/ k("$ZodNumberFormat", (e, t) => {
	gr.init(e, t), Ei.init(e, t);
}), Oi = /*@__PURE__*/ k("$ZodBoolean", (e, t) => {
	I.init(e, t), e._zod.pattern = Vn, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = !!n.value;
		} catch {}
		let i = n.value;
		return typeof i == "boolean" || n.issues.push({
			expected: "boolean",
			code: "invalid_type",
			input: i,
			inst: e
		}), n;
	};
}), ki = /*@__PURE__*/ k("$ZodBigInt", (e, t) => {
	I.init(e, t), e._zod.pattern = Rn, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = BigInt(n.value);
		} catch {}
		return typeof n.value == "bigint" || n.issues.push({
			expected: "bigint",
			code: "invalid_type",
			input: n.value,
			inst: e
		}), n;
	};
}), Ai = /*@__PURE__*/ k("$ZodBigIntFormat", (e, t) => {
	_r.init(e, t), ki.init(e, t);
}), ji = /*@__PURE__*/ k("$ZodSymbol", (e, t) => {
	I.init(e, t), e._zod.parse = (t, n) => {
		let r = t.value;
		return typeof r == "symbol" || t.issues.push({
			expected: "symbol",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), Mi = /*@__PURE__*/ k("$ZodUndefined", (e, t) => {
	I.init(e, t), e._zod.pattern = Un, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (t, n) => {
		let r = t.value;
		return r === void 0 || t.issues.push({
			expected: "undefined",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), Ni = /*@__PURE__*/ k("$ZodNull", (e, t) => {
	I.init(e, t), e._zod.pattern = Hn, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (t, n) => {
		let r = t.value;
		return r === null || t.issues.push({
			expected: "null",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), Pi = /*@__PURE__*/ k("$ZodAny", (e, t) => {
	I.init(e, t), e._zod.parse = (e) => e;
}), Fi = /*@__PURE__*/ k("$ZodUnknown", (e, t) => {
	I.init(e, t), e._zod.parse = (e) => e;
}), Ii = /*@__PURE__*/ k("$ZodNever", (e, t) => {
	I.init(e, t), e._zod.parse = (t, n) => (t.issues.push({
		expected: "never",
		code: "invalid_type",
		input: t.value,
		inst: e
	}), t);
}), Li = /*@__PURE__*/ k("$ZodVoid", (e, t) => {
	I.init(e, t), e._zod.parse = (t, n) => {
		let r = t.value;
		return r === void 0 || t.issues.push({
			expected: "void",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), Ri = /*@__PURE__*/ k("$ZodDate", (e, t) => {
	I.init(e, t), e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = new Date(n.value);
		} catch {}
		let i = n.value, a = i instanceof Date;
		return a && !Number.isNaN(i.getTime()) || n.issues.push({
			expected: "date",
			code: "invalid_type",
			input: i,
			...a ? { received: "Invalid Date" } : {},
			inst: e
		}), n;
	};
});
function zi(e, t, n) {
	e.issues.length && t.issues.push(...C(n, e.issues)), t.value[n] = e.value;
}
var Bi = /*@__PURE__*/ k("$ZodArray", (e, t) => {
	I.init(e, t);
	let n = j.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!Array.isArray(a)) return r.issues.push({
			expected: "array",
			code: "invalid_type",
			input: a,
			inst: e
		}), r;
		r.value = n ? n.alloc(e, r, Array(a.length), i) : Array(a.length);
		let o = [];
		for (let e = 0; e < a.length; e++) {
			let n = a[e], s = t.element._zod.run({
				value: n,
				issues: []
			}, i);
			s instanceof Promise ? o.push(s.then((t) => zi(t, r, e))) : zi(s, r, e);
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
});
function Vi(e, t, n, r, i, a) {
	let o = n in r, s = a === "optional";
	if (o || !s || i !== "optional") {
		if (e.issues.length) {
			if (i !== void 0 && s && !o) return;
			t.issues.push(...C(n, e.issues));
		}
		if (!o && i === void 0) {
			e.issues.length || t.issues.push({
				code: "invalid_type",
				expected: "nonoptional",
				input: void 0,
				path: [n]
			});
			return;
		}
		e.value === void 0 ? o && (t.value[n] = void 0) : t.value[n] = e.value;
	}
}
var Hi = [];
function Ui(e) {
	let t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), r = n.length ? n : Hi, i = r.length ? [...t, ...r] : t;
	for (let t of i) if (!e.shape?.[t]?._zod?.traits?.has("$ZodType")) throw Error(`Invalid element at key "${String(t)}": expected a Zod schema`);
	let a = ve(e.shape);
	return {
		...e,
		allKeys: i,
		symbolKeys: r,
		keySet: new Set(t),
		numKeys: t.length,
		optionalKeys: new Set(a)
	};
}
function Wi(e, t, n, r, i, a) {
	let o = [], s = i.keySet, c = i.catchall._zod, l = c.def.type, u = c.optin, d = c.optout;
	for (let i in t) {
		if (s.has(i)) continue;
		if (i === "__proto__") {
			l === "never" && o.push(i);
			continue;
		}
		if (l === "never") {
			o.push(i);
			continue;
		}
		let a = c.run({
			value: t[i],
			issues: []
		}, r);
		a instanceof Promise ? e.push(a.then((e) => Vi(e, n, i, t, u, d))) : Vi(a, n, i, t, u, d);
	}
	return o.length && n.issues.push({
		code: "unrecognized_keys",
		keys: o,
		input: t,
		inst: a,
		continue: !0
	}), e.length ? Promise.all(e).then(() => n) : n;
}
var Gi = /* @__PURE__ */ new WeakMap(), Ki = /*@__PURE__*/ k("$ZodObject", (e, t) => {
	if (I.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
		let e = t.shape;
		Gi.set(t, e), Object.defineProperty(t, "shape", { get: () => {
			let n = { ...e };
			return Object.defineProperty(t, "shape", { value: n }), Gi.set(t, n), n;
		} });
	}
	let n = d(() => Ui(t));
	O(e, "propValues", (e) => {
		let t = e.def.shape, n = {};
		for (let e in t) {
			let r = t[e]._zod;
			if (r.values) {
				Object.prototype.hasOwnProperty.call(n, e) || h(n, e, /* @__PURE__ */ new Set());
				for (let t of r.values) n[e].add(t);
				r.optin !== void 0 && n[e].add(void 0);
			}
		}
		return n;
	});
	let r = _, i = t.catchall, a, o = j.memoizer;
	o?.attach(e), e._zod.parse = (t, s) => {
		a ??= n.value;
		let c = t.value;
		if (!r(c)) return t.issues.push({
			expected: "object",
			code: "invalid_type",
			input: c,
			inst: e
		}), t;
		t.value = o ? o.alloc(e, t, {}, s) : {};
		let l = [], u = a.shape;
		for (let e of a.allKeys) {
			if (e === "__proto__") continue;
			let n = u[e], r = n._zod.optin, i = n._zod.optout, a = n._zod.run({
				value: c[e],
				issues: []
			}, s);
			a instanceof Promise ? l.push(a.then((n) => Vi(n, t, e, c, r, i))) : Vi(a, t, e, c, r, i);
		}
		return i ? Wi(l, c, t, s, n.value, e) : l.length ? Promise.all(l).then(() => t) : t;
	};
}), qi = /*@__PURE__*/ k("$ZodObjectJIT", (e, t) => {
	Ki.init(e, t);
	let n = e._zod.parse, r = d(() => Ui(t)), i = j.memoizer, a = (t) => {
		let n = r.value, a = n.symbolKeys, o = new Fr(["payload", "ctx"], {
			shape: t,
			inst: e,
			memo: i,
			syms: a
		}), s = (e) => `shape[${e}]._zod.run({ value: input[${e}], issues: [] }, ctx)`, c = (e, t) => `
          for (let i = 0; i < ${e}.issues.length; i++) {
            const iss = ${e}.issues[i];
            iss.path = iss.path ? [${t}, ...iss.path] : [${t}];
            payload.issues.push(iss);
          }`;
		o.write("const input = payload.value;");
		let l = Object.create(null), u = 0;
		for (let e of n.allKeys) l[e] = `key_${u++}`;
		o.write(i ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
		for (let e of n.allKeys) {
			if (e === "__proto__") continue;
			let n = l[e], r = typeof e == "symbol" ? `syms[${a.indexOf(e)}]` : se(e), i = `${r} in input`, u = t[e], d = u?._zod?.optin, f = d !== void 0, p = u?._zod?.optout === "optional";
			if (o.write(`const ${n} = ${s(r)};`), f && p) {
				let e = d === "optional" ? `${n}_present` : `${n}.value !== undefined || ${n}_present`;
				o.write(`
        const ${n}_present = ${i};
        if (!${n}.issues.length || ${n}_present) {
          if (${n}.issues.length) {${c(n, r)}
          }

          if (${e}) {
            newResult[${r}] = ${n}.value;
          }
        }

      `);
			} else f ? o.write(`
        if (${n}.issues.length) {${c(n, r)}
        }
        
        if (${n}.value === undefined) {
          if (${i}) {
            newResult[${r}] = undefined;
          }
        } else {
          newResult[${r}] = ${n}.value;
        }

      `) : o.write(`
        const ${n}_present = ${i};
        if (${n}.issues.length) {${c(n, r)}
        }
        if (!${n}_present && !${n}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${r}]
          });
        }

        if (${n}_present) {
          newResult[${r}] = ${n}.value;
        }

      `);
		}
		return o.write("payload.value = newResult;"), o.write("return payload;"), o.compile();
	}, o, s = _, c = !j.jitless, l = c && ue.value, u = t.catchall, f;
	e._zod.parse = (i, d) => {
		f ??= r.value;
		let p = i.value;
		return s(p) ? c && l && d?.async === !1 && d.jitless !== !0 ? (o ||= a(t.shape), i = o(i, d), u ? Wi([], p, i, d, f, e) : i) : n(i, d) : (i.issues.push({
			expected: "object",
			code: "invalid_type",
			input: p,
			inst: e
		}), i);
	};
});
function Ji(e, t, n, r) {
	for (let n of e) if (n.issues.length === 0) return t.value = n.value, t;
	let i = e.filter((e) => !S(e));
	return i.length === 1 ? (t.value = i[0].value, i[0]) : (t.issues.push({
		code: "invalid_union",
		input: t.value,
		inst: n,
		errors: e.map((e) => e.issues.map((e) => T(e, r, M())))
	}), t);
}
var Yi = /*@__PURE__*/ k("$ZodUnion", (e, t) => {
	I.init(e, t), O(e, "optin", (e) => e.def.options.some((e) => e._zod.optin === "defaulted") ? "defaulted" : e.def.options.some((e) => e._zod.optin !== void 0) ? "optional" : void 0), O(e, "optout", (e) => e.def.options.some((e) => e._zod.optout === "optional") ? "optional" : void 0), O(e, "values", (e) => {
		if (e.def.options.every((e) => e._zod.values)) return new Set(e.def.options.flatMap((e) => Array.from(e._zod.values)));
	}), O(e, "pattern", (e) => {
		if (e.def.options.every((e) => e._zod.pattern)) {
			let t = e.def.options.map((e) => e._zod.pattern);
			return RegExp(`^(${t.map((e) => p(e.source)).join("|")})$`);
		}
	});
	let n = t.options.length === 1 ? t.options[0]._zod.run : null;
	e._zod.parse = (r, i) => {
		if (n) return n(r, i);
		let a = !1, o = [];
		for (let e of t.options) {
			let t = e._zod.run({
				value: r.value,
				issues: []
			}, i);
			if (t instanceof Promise) o.push(t), a = !0;
			else {
				if (t.issues.length === 0) return t;
				o.push(t);
			}
		}
		return a ? Promise.all(o).then((t) => Ji(t, r, e, i)) : Ji(o, r, e, i);
	};
});
function Xi(e, t, n, r) {
	let i = [];
	for (let t = 0; t < e.length; t++) e[t].issues.length === 0 && i.push(t);
	return i.length === 1 ? (t.value = e[i[0]].value, t) : (i.length === 0 ? t.issues.push({
		code: "invalid_union",
		input: t.value,
		inst: n,
		errors: e.map((e) => e.issues.map((e) => T(e, r, M())))
	}) : t.issues.push({
		code: "invalid_union",
		input: t.value,
		inst: n,
		errors: [],
		inclusive: !1,
		matches: i
	}), t);
}
var Zi = /*@__PURE__*/ k("$ZodXor", (e, t) => {
	Yi.init(e, t), t.inclusive = !1;
	let n = t.options.length === 1 ? t.options[0]._zod.run : null;
	e._zod.parse = (r, i) => {
		if (n) return n(r, i);
		let a = !1, o = [];
		for (let e of t.options) {
			let t = e._zod.run({
				value: r.value,
				issues: []
			}, i);
			t instanceof Promise ? (o.push(t), a = !0) : o.push(t);
		}
		return a ? Promise.all(o).then((t) => Xi(t, r, e, i)) : Xi(o, r, e, i);
	};
});
function Qi(e, t) {
	let n = e._zod, r = n.bag.optionsMap;
	if (!r) {
		r = /* @__PURE__ */ new Map();
		let { options: e, discriminator: t } = n.def;
		for (let n of e) for (let e of n._zod.propValues?.[t] ?? []) r.has(e) || r.set(e, n);
		n.bag.optionsMap = r;
	}
	return r.get(t);
}
var $i = /*@__PURE__*/ k("$ZodDiscriminatedUnion", (e, t) => {
	t.inclusive = !1, Yi.init(e, t);
	let n = e._zod.parse;
	O(e, "propValues", (e) => {
		let t = {};
		for (let n of e.def.options) {
			let r = n._zod.propValues;
			if (!r || Object.keys(r).length === 0) throw Error(`Invalid discriminated union option at index "${e.def.options.indexOf(n)}"`);
			for (let [e, n] of Object.entries(r)) {
				Object.prototype.hasOwnProperty.call(t, e) || h(t, e, /* @__PURE__ */ new Set());
				for (let r of n) t[e].add(r);
			}
		}
		return t;
	}), t.options.forEach((e, n) => {
		let r = Gi.get(e._zod.def);
		if (r && !Object.prototype.hasOwnProperty.call(r, t.discriminator)) throw Error(`Invalid discriminated union option at index "${n}"`);
	});
	let r = d(() => {
		let e = t.options, n = /* @__PURE__ */ new Map();
		for (let r of e) {
			let e = r._zod.propValues?.[t.discriminator];
			if (!e || e.size === 0) throw Error(`Invalid discriminated union option at index "${t.options.indexOf(r)}"`);
			for (let t of e) {
				if (n.has(t)) throw Error(`Duplicate discriminator value "${String(t)}"`);
				n.set(t, r);
			}
		}
		return n;
	});
	e._zod.parse = (i, a) => {
		let o = i.value;
		if (!_(o)) return i.issues.push({
			code: "invalid_type",
			expected: "object",
			input: o,
			inst: e
		}), i;
		let s = r.value.get(o?.[t.discriminator]);
		return s ? s._zod.run(i, a) : t.unionFallback || a.direction === "backward" ? n(i, a) : (i.issues.push({
			code: "invalid_union",
			errors: [],
			note: "No matching discriminator",
			discriminator: t.discriminator,
			options: Array.from(r.value.keys()),
			input: o,
			path: [t.discriminator],
			inst: e
		}), i);
	};
}), ea = /*@__PURE__*/ k("$ZodIntersection", (e, t) => {
	I.init(e, t), e._zod.parse = (e, n) => {
		let r = e.value, i = t.left._zod.run({
			value: r,
			issues: []
		}, n), a = t.right._zod.run({
			value: r,
			issues: []
		}, n);
		return i instanceof Promise || a instanceof Promise ? Promise.all([i, a]).then(([t, n]) => na(e, t, n)) : na(e, i, a);
	};
});
function ta(e, t) {
	if (e === t || e instanceof Date && t instanceof Date && +e == +t) return {
		valid: !0,
		data: e
	};
	if (v(e) && v(t)) {
		let n = Object.keys(t), r = Object.keys(e).filter((e) => n.indexOf(e) !== -1), i = {
			...e,
			...t
		};
		Object.prototype.hasOwnProperty.call(i, "__proto__") && delete i.__proto__;
		for (let n of r) {
			if (n === "__proto__") continue;
			let r = ta(e[n], t[n]);
			if (!r.valid) return {
				valid: !1,
				mergeErrorPath: [n, ...r.mergeErrorPath]
			};
			i[n] = r.data;
		}
		return {
			valid: !0,
			data: i
		};
	}
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return {
			valid: !1,
			mergeErrorPath: []
		};
		let n = [];
		for (let r = 0; r < e.length; r++) {
			let i = e[r], a = t[r], o = ta(i, a);
			if (!o.valid) return {
				valid: !1,
				mergeErrorPath: [r, ...o.mergeErrorPath]
			};
			n.push(o.data);
		}
		return {
			valid: !0,
			data: n
		};
	}
	return {
		valid: !1,
		mergeErrorPath: []
	};
}
function na(e, t, n) {
	let r = /* @__PURE__ */ new Map(), i, a = /* @__PURE__ */ new Map(), o = (e, t) => {
		let n;
		if (e.code === "unrecognized_keys" && !e.path?.length) i ??= e, n = e.keys;
		else if (e.code === "invalid_key" && e.origin === "record" && e.path?.length === 1) {
			let t = String(e.path[0]);
			a.has(t) || a.set(t, e), n = [t];
		} else return !1;
		for (let e of n) r.has(e) || r.set(e, {}), r.get(e)[t] = !0;
		return !0;
	};
	for (let n of t.issues) o(n, "l") || e.issues.push(n);
	for (let t of n.issues) o(t, "r") || e.issues.push(t);
	let s = [...r].filter(([, e]) => e.l && e.r).map(([e]) => e);
	if (s.length) {
		let t = i ? s.filter((e) => i.keys.includes(e)) : [];
		t.length && e.issues.push({
			...i,
			keys: t
		});
		for (let n of s) !t.includes(n) && a.has(n) && e.issues.push(a.get(n));
	}
	let c = ta(t.value, n.value);
	if (!c.valid) {
		if (S(e)) return e;
		throw Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
	}
	return e.value = c.data, e;
}
var ra = /*@__PURE__*/ k("$ZodTuple", (e, t) => {
	I.init(e, t);
	let n = t.items, r = j.memoizer;
	r?.attach(e), e._zod.parse = (i, a) => {
		let o = i.value;
		if (!Array.isArray(o)) return i.issues.push({
			input: o,
			inst: e,
			expected: "tuple",
			code: "invalid_type"
		}), i;
		i.value = r ? r.alloc(e, i, [], a) : [];
		let s = [], c = ia(n, "optin"), l = ia(n, "optout");
		if (!t.rest) {
			if (o.length < c) return i.issues.push({
				code: "too_small",
				minimum: c,
				inclusive: !0,
				input: o,
				inst: e,
				origin: "array"
			}), i;
			o.length > n.length && i.issues.push({
				code: "too_big",
				maximum: n.length,
				inclusive: !0,
				input: o,
				inst: e,
				origin: "array"
			});
		}
		let u = Array(n.length);
		for (let e = 0; e < n.length; e++) {
			let t = n[e]._zod.run({
				value: o[e],
				issues: []
			}, a);
			t instanceof Promise ? s.push(t.then((t) => {
				u[e] = t;
			})) : u[e] = t;
		}
		if (t.rest) {
			let e = n.length - 1, r = o.slice(n.length);
			for (let n of r) {
				e++;
				let r = t.rest._zod.run({
					value: n,
					issues: []
				}, a);
				r instanceof Promise ? s.push(r.then((t) => aa(t, i, e))) : aa(r, i, e);
			}
		}
		return s.length ? Promise.all(s).then(() => oa(u, i, n, o, l)) : oa(u, i, n, o, l);
	};
});
function ia(e, t) {
	for (let n = e.length - 1; n >= 0; n--) if (!(t === "optin" ? e[n]._zod.optin !== void 0 : e[n]._zod.optout === "optional")) return n + 1;
	return 0;
}
function aa(e, t, n) {
	e.issues.length && t.issues.push(...C(n, e.issues)), t.value[n] = e.value;
}
function oa(e, t, n, r, i) {
	for (let a = 0; a < n.length; a++) {
		let o = e[a], s = a < r.length;
		if (!s && a >= i && n[a]._zod.optin === "optional") {
			t.value.length = a;
			break;
		}
		if (o.issues.length) {
			if (!s && a >= i) {
				t.value.length = a;
				break;
			}
			t.issues.push(...C(a, o.issues));
		}
		t.value[a] = o.value;
	}
	for (let e = t.value.length - 1; e >= r.length && n[e]._zod.optout === "optional" && t.value[e] === void 0; e--) t.value.length = e;
	return t;
}
var sa = /*@__PURE__*/ k("$ZodRecord", (e, t) => {
	I.init(e, t);
	let n = j.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!v(a)) return r.issues.push({
			expected: "record",
			code: "invalid_type",
			input: a,
			inst: e
		}), r;
		let o = [], s = t.keyType._zod.values;
		if (s && !t.partial) {
			r.value = n ? n.alloc(e, r, {}, i) : {};
			let c = /* @__PURE__ */ new Set();
			for (let n of s) if (typeof n == "string" || typeof n == "number" || typeof n == "symbol") {
				if (c.add(typeof n == "number" ? n.toString() : n), n === "__proto__") continue;
				let s = t.keyType._zod.run({
					value: n,
					issues: []
				}, i);
				if (s instanceof Promise) throw Error("Async schemas not supported in object keys currently");
				if (s.issues.length) {
					r.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: s.issues.map((e) => T(e, i, M())),
						input: n,
						path: [n],
						inst: e
					});
					continue;
				}
				let l = s.value;
				if (l === "__proto__") continue;
				let u = t.valueType._zod.run({
					value: a[n],
					issues: []
				}, i);
				u instanceof Promise ? o.push(u.then((e) => {
					e.issues.length && r.issues.push(...C(n, e.issues)), r.value[l] = e.value;
				})) : (u.issues.length && r.issues.push(...C(n, u.issues)), r.value[l] = u.value);
			}
			let l;
			for (let e in a) if (!c.has(e)) {
				if (t.mode === "loose") {
					if (e === "__proto__") continue;
					r.value[e] = a[e];
				} else l ??= [], l.push(e);
			}
			l && l.length > 0 && r.issues.push({
				code: "unrecognized_keys",
				input: a,
				inst: e,
				keys: l,
				continue: !0
			});
		} else {
			r.value = n ? n.alloc(e, r, {}, i) : {};
			let c;
			for (let n of Reflect.ownKeys(a)) {
				if (n === "__proto__" || !Object.prototype.propertyIsEnumerable.call(a, n)) continue;
				let l = t.keyType._zod.run({
					value: n,
					issues: []
				}, i);
				if (l instanceof Promise) throw Error("Async schemas not supported in object keys currently");
				if (typeof n == "string" && Bn.test(n) && l.issues.length) {
					let e = t.keyType._zod.run({
						value: Number(n),
						issues: []
					}, i);
					if (e instanceof Promise) throw Error("Async schemas not supported in object keys currently");
					e.issues.length === 0 && (l = e);
				}
				if (l.issues.length) {
					t.mode === "loose" ? r.value[n] = a[n] : s ? (c ??= [], c.push(n)) : r.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: l.issues.map((e) => T(e, i, M())),
						input: n,
						path: [n],
						inst: e
					});
					continue;
				}
				let u = l.value;
				if (u === "__proto__") continue;
				let d = t.valueType._zod.run({
					value: a[n],
					issues: []
				}, i);
				d instanceof Promise ? o.push(d.then((e) => {
					e.issues.length && r.issues.push(...C(n, e.issues)), r.value[u] = e.value;
				})) : (d.issues.length && r.issues.push(...C(n, d.issues)), r.value[u] = d.value);
			}
			c && c.length > 0 && r.issues.push({
				code: "unrecognized_keys",
				input: a,
				inst: e,
				keys: c,
				continue: !0
			});
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
}), ca = /*@__PURE__*/ k("$ZodMap", (e, t) => {
	I.init(e, t);
	let n = j.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!(a instanceof Map)) return r.issues.push({
			expected: "map",
			code: "invalid_type",
			input: a,
			inst: e
		}), r;
		let o = [];
		r.value = n ? n.alloc(e, r, /* @__PURE__ */ new Map(), i) : /* @__PURE__ */ new Map();
		for (let [n, s] of a) {
			let c = t.keyType._zod.run({
				value: n,
				issues: []
			}, i), l = t.valueType._zod.run({
				value: s,
				issues: []
			}, i);
			c instanceof Promise || l instanceof Promise ? o.push(Promise.all([c, l]).then(([t, o]) => {
				la(t, o, r, n, a, e, i);
			})) : la(c, l, r, n, a, e, i);
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
});
function la(e, t, n, r, i, a, o) {
	e.issues.length && (me.has(typeof r) ? n.issues.push(...C(r, e.issues)) : n.issues.push({
		code: "invalid_key",
		origin: "map",
		input: i,
		inst: a,
		issues: e.issues.map((e) => T(e, o, M()))
	})), t.issues.length && (me.has(typeof r) ? n.issues.push(...C(r, t.issues)) : n.issues.push({
		origin: "map",
		code: "invalid_element",
		input: i,
		inst: a,
		key: r,
		issues: t.issues.map((e) => T(e, o, M()))
	})), n.value.set(e.value, t.value);
}
var ua = /*@__PURE__*/ k("$ZodSet", (e, t) => {
	I.init(e, t);
	let n = j.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!(a instanceof Set)) return r.issues.push({
			input: a,
			inst: e,
			expected: "set",
			code: "invalid_type"
		}), r;
		let o = [];
		r.value = n ? n.alloc(e, r, /* @__PURE__ */ new Set(), i) : /* @__PURE__ */ new Set();
		for (let e of a) {
			let n = t.valueType._zod.run({
				value: e,
				issues: []
			}, i);
			n instanceof Promise ? o.push(n.then((e) => da(e, r))) : da(n, r);
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
});
function da(e, t) {
	e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
var fa = /*@__PURE__*/ k("$ZodEnum", (e, t) => {
	I.init(e, t);
	let n = c(t.entries), r = new Set(n);
	e._zod.values = r;
	let i = n.filter((e) => me.has(typeof e));
	e._zod.pattern = RegExp(i.length ? `^(${i.map((e) => y(e.toString())).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (t, i) => {
		let a = t.value;
		return r.has(a) || t.issues.push({
			code: "invalid_value",
			values: n,
			input: a,
			inst: e
		}), t;
	};
}), pa = /*@__PURE__*/ k("$ZodLiteral", (e, t) => {
	I.init(e, t);
	let n = new Set(t.values);
	e._zod.values = n, e._zod.pattern = RegExp(t.values.length ? `^(${t.values.map((e) => typeof e == "string" ? y(e) : e ? y(e.toString()) : String(e)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (r, i) => {
		let a = r.value;
		return n.has(a) || r.issues.push({
			code: "invalid_value",
			values: t.values,
			input: a,
			inst: e
		}), r;
	};
}), ma = /*@__PURE__*/ k("$ZodFile", (e, t) => {
	I.init(e, t), e._zod.parse = (t, n) => {
		let r = t.value;
		return r instanceof File || t.issues.push({
			expected: "file",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), ha = /*@__PURE__*/ k("$ZodTransform", (e, t) => {
	I.init(e, t), e._zod.optin = "optional", j.memoizer?.guard(e), e._zod.parse = (n, r) => {
		if (r.direction === "backward") throw new at(e.constructor.name);
		let i = t.transform(n.value, n);
		if (r.async) return (i instanceof Promise ? i : Promise.resolve(i)).then((e) => (n.value = e, n));
		if (i instanceof Promise) throw new A();
		return n.value = i, n;
	};
});
function ga(e, t) {
	return e.value = t.issues.length ? void 0 : t.value, e;
}
var _a = /*@__PURE__*/ k("$ZodOptional", (e, t) => {
	I.init(e, t), O(e, "optin", (e) => e.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", O(e, "values", (e) => {
		let t = e.def.innerType._zod.values;
		return t ? /* @__PURE__ */ new Set([...t, void 0]) : void 0;
	}), O(e, "pattern", (e) => {
		let t = e.def.innerType._zod.pattern;
		return t ? RegExp(`^(${p(t.source)})?$`) : void 0;
	}), e._zod.parse = (e, n) => {
		if (e.value === void 0) {
			if (t.innerType._zod.optin !== "defaulted") return e;
			let r = t.innerType._zod.run({
				value: e.value,
				issues: []
			}, n);
			return r instanceof Promise ? r.then((t) => ga(e, t)) : ga(e, r);
		}
		return t.innerType._zod.run(e, n);
	};
}), va = /*@__PURE__*/ k("$ZodExactOptional", (e, t) => {
	_a.init(e, t), O(e, "values", (e) => e.def.innerType._zod.values), O(e, "pattern", (e) => e.def.innerType._zod.pattern), e._zod.parse = (e, n) => t.innerType._zod.run(e, n);
}), ya = /*@__PURE__*/ k("$ZodNullable", (e, t) => {
	I.init(e, t), O(e, "optin", (e) => e.def.innerType._zod.optin), O(e, "optout", (e) => e.def.innerType._zod.optout), O(e, "pattern", (e) => {
		let t = e.def.innerType._zod.pattern;
		return t ? RegExp(`^(${p(t.source)}|null)$`) : void 0;
	}), O(e, "values", (e) => e.def.innerType._zod.values ? /* @__PURE__ */ new Set([...e.def.innerType._zod.values, null]) : void 0), e._zod.parse = (e, n) => e.value === null ? e : t.innerType._zod.run(e, n);
}), ba = /*@__PURE__*/ k("$ZodDefault", (e, t) => {
	I.init(e, t), e._zod.optin = "defaulted", O(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		if (e.value === void 0) return e.value = t.defaultValue, e;
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => xa(e, t)) : xa(r, t);
	};
});
function xa(e, t) {
	return e.value === void 0 && (e.value = t.defaultValue), e;
}
var Sa = /*@__PURE__*/ k("$ZodPrefault", (e, t) => {
	I.init(e, t), e._zod.optin = "defaulted", O(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => (n.direction === "backward" || e.value === void 0 && (e.value = t.defaultValue), t.innerType._zod.run(e, n));
}), Ca = /*@__PURE__*/ k("$ZodNonOptional", (e, t) => {
	I.init(e, t), O(e, "values", (e) => {
		let t = e.def.innerType._zod.values;
		return t ? new Set([...t].filter((e) => e !== void 0)) : void 0;
	}), e._zod.parse = (n, r) => {
		let i = t.innerType._zod.run(n, r);
		return i instanceof Promise ? i.then((t) => wa(t, e)) : wa(i, e);
	};
});
function wa(e, t) {
	return !e.issues.length && e.value === void 0 && e.issues.push({
		code: "invalid_type",
		expected: "nonoptional",
		input: e.value,
		inst: t
	}), e;
}
var Ta = /*@__PURE__*/ k("$ZodSuccess", (e, t) => {
	I.init(e, t), e._zod.parse = (e, n) => {
		if (n.direction === "backward") throw new at("ZodSuccess");
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then((t) => (e.value = t.issues.length === 0, e)) : (e.value = r.issues.length === 0, e);
	};
});
function Ea(e, t, n, r) {
	return t.issues.length ? (e.value = n.catchValue({
		...t,
		value: e.value,
		error: { issues: t.issues.map((e) => T(e, r, M())) },
		input: e.value
	}), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
var Da = /*@__PURE__*/ k("$ZodCatch", (e, t) => {
	I.init(e, t), O(e, "optin", (e) => e.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), O(e, "optout", (e) => e.def.innerType._zod.optout), O(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run({
			value: e.value,
			issues: []
		}, n);
		return r instanceof Promise ? r.then((r) => Ea(e, r, t, n)) : Ea(e, r, t, n);
	};
}), Oa = /*@__PURE__*/ k("$ZodNaN", (e, t) => {
	I.init(e, t), e._zod.parse = (t, n) => ((typeof t.value != "number" || !Number.isNaN(t.value)) && t.issues.push({
		input: t.value,
		inst: e,
		expected: "nan",
		code: "invalid_type"
	}), t);
}), ka = /*@__PURE__*/ k("$ZodPipe", (e, t) => {
	I.init(e, t), O(e, "values", (e) => e.def.in._zod.values), O(e, "optin", (e) => e.def.in._zod.optin), O(e, "optout", (e) => e.def.out._zod.optout), O(e, "propValues", (e) => e.def.in._zod.propValues), e._zod.parse = (e, n) => {
		if (n.direction === "backward") {
			let r = t.out._zod.run(e, n);
			return r instanceof Promise ? r.then((e) => Aa(e, t.in, n)) : Aa(r, t.in, n);
		}
		let r = t.in._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => Aa(e, t.out, n)) : Aa(r, t.out, n);
	};
});
function Aa(e, t, n) {
	return e.issues.some((e) => e.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({
		value: e.value,
		issues: e.issues
	}, n);
}
var ja = /*@__PURE__*/ k("$ZodCodec", (e, t) => {
	I.init(e, t), O(e, "values", (e) => e.def.in._zod.values), O(e, "optin", (e) => e.def.in._zod.optin), O(e, "optout", (e) => e.def.out._zod.optout), O(e, "propValues", (e) => e.def.in._zod.propValues), e._zod.parse = (e, n) => {
		if ((n.direction || "forward") === "forward") {
			let r = t.in._zod.run(e, n);
			return r instanceof Promise ? r.then((e) => Ma(e, t, n)) : Ma(r, t, n);
		}
		{
			let r = t.out._zod.run(e, n);
			return r instanceof Promise ? r.then((e) => Ma(e, t, n)) : Ma(r, t, n);
		}
	};
});
function Ma(e, t, n) {
	if (e.issues.length) return e.aborted = !0, e;
	if ((n.direction || "forward") === "forward") {
		let r = t.transform(e.value, e);
		return r instanceof Promise ? r.then((r) => Na(e, r, t.out, n)) : Na(e, r, t.out, n);
	}
	{
		let r = t.reverseTransform(e.value, e);
		return r instanceof Promise ? r.then((r) => Na(e, r, t.in, n)) : Na(e, r, t.in, n);
	}
}
function Na(e, t, n, r) {
	return e.issues.length ? (e.aborted = !0, e) : n._zod.run({
		value: t,
		issues: e.issues
	}, r);
}
var Pa = /*@__PURE__*/ k("$ZodPreprocess", (e, t) => {
	ka.init(e, t);
}), Fa = /*@__PURE__*/ k("$ZodReadonly", (e, t) => {
	I.init(e, t), O(e, "propValues", (e) => e.def.innerType._zod.propValues), O(e, "values", (e) => e.def.innerType._zod.values), O(e, "optin", (e) => e.def.innerType?._zod?.optin), O(e, "optout", (e) => e.def.innerType?._zod?.optout), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then(Ia) : Ia(r);
	};
});
function Ia(e) {
	return e.memo || (e.value = Object.freeze(e.value)), e;
}
var La = /*@__PURE__*/ k("$ZodTemplateLiteral", (e, t) => {
	I.init(e, t);
	let n = [];
	for (let e of t.parts) if (typeof e == "object" && e) {
		if (!e._zod.pattern) throw Error(`Invalid template literal part, no pattern found: ${[...e._zod.traits].shift()}`);
		let t = e._zod.pattern instanceof RegExp ? e._zod.pattern.source : e._zod.pattern;
		if (!t) throw Error(`Invalid template literal part: ${e._zod.traits}`);
		let r = +!!t.startsWith("^"), i = t.endsWith("$") ? t.length - 1 : t.length;
		n.push(t.slice(r, i));
	} else if (e === null || he.has(typeof e)) n.push(y(`${e}`));
	else throw Error(`Invalid template literal part: ${e}`);
	e._zod.pattern = RegExp(`^${n.join("")}$`), e._zod.parse = (n, r) => typeof n.value == "string" ? (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(n.value) || n.issues.push({
		input: n.value,
		inst: e,
		code: "invalid_format",
		format: t.format ?? "template_literal",
		pattern: e._zod.pattern.source
	}), n) : (n.issues.push({
		input: n.value,
		inst: e,
		expected: "string",
		code: "invalid_type"
	}), n);
}), Ra = /*@__PURE__*/ k("$ZodFunction", (e, t) => (I.init(e, t), Object.defineProperty(e, "_def", { value: t }), e._zod.def = t, e.implement = (t) => {
	if (typeof t != "function") throw Error("implement() must be called with a function");
	return Object.defineProperty(function(...n) {
		let r = e._def.input ? St(e._def.input, n) : n, i = Reflect.apply(t, this, r);
		return e._def.output ? St(e._def.output, i) : i;
	}, "_zod", {
		value: e._zod,
		enumerable: !1
	});
}, e.implementAsync = (t) => {
	if (typeof t != "function") throw Error("implementAsync() must be called with a function");
	return Object.defineProperty(async function(...n) {
		let r = e._def.input ? await wt(e._def.input, n) : n, i = await Reflect.apply(t, this, r);
		return e._def.output ? await wt(e._def.output, i) : i;
	}, "_zod", {
		value: e._zod,
		enumerable: !1
	});
}, e._zod.parse = (t, n) => typeof t.value == "function" ? (t.value = e._def.output && e._def.output._zod.def.type === "promise" ? e.implementAsync(t.value) : e.implement(t.value), t) : (t.issues.push({
	code: "invalid_type",
	expected: "function",
	input: t.value,
	inst: e
}), t), e.input = (...t) => {
	let n = e.constructor;
	return Array.isArray(t[0]) ? new n({
		type: "function",
		input: new ra({
			type: "tuple",
			items: t[0],
			rest: t[1]
		}),
		output: e._def.output
	}) : new n({
		type: "function",
		input: t[0],
		output: e._def.output
	});
}, e.output = (t) => {
	let n = e.constructor;
	return new n({
		type: "function",
		input: e._def.input,
		output: t
	});
}, e)), za = /*@__PURE__*/ k("$ZodPromise", (e, t) => {
	I.init(e, t), e._zod.parse = (e, n) => Promise.resolve(e.value).then((e) => t.innerType._zod.run({
		value: e,
		issues: []
	}, n));
}), Ba = /*@__PURE__*/ k("$ZodLazy", (e, t) => {
	I.init(e, t), te(e._zod, "innerType", () => {
		let e = t;
		return e._cachedInner ||= t.getter(), e._cachedInner;
	}), O(e, "pattern", (e) => e.innerType?._zod?.pattern), O(e, "propValues", (e) => e.innerType?._zod?.propValues), O(e, "optin", (e) => e.innerType?._zod?.optin ?? void 0), O(e, "optout", (e) => e.innerType?._zod?.optout ?? void 0), e._zod.parse = (t, n) => e._zod.innerType._zod.run(t, n);
}), Va = /*@__PURE__*/ k("$ZodCustom", (e, t) => {
	F.init(e, t), I.init(e, t), e._zod.parse = (e, t) => e, e._zod.check = (n) => {
		let r = n.value, i = t.fn(r);
		if (i instanceof Promise) return i.then((t) => Ha(t, n, r, e));
		Ha(i, n, r, e);
	};
});
function Ha(e, t, n, r) {
	if (!e) {
		let e = {
			code: "custom",
			input: n,
			inst: r,
			path: [...r._zod.def.path ?? []],
			continue: !r._zod.def.abort
		};
		r._zod.def.params && (e.params = r._zod.def.params), t.issues.push(Fe(e));
	}
}
//#endregion
//#region node_modules/zod/v4/core/memoizer.js
var Ua = class extends Error {
	constructor() {
		super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
	}
}, Wa = "~memo", Ga = [];
function Ka(e) {
	return e.map((e) => e.path ? {
		...e,
		path: e.path.slice()
	} : { ...e });
}
var qa = /*@__PURE__*/ new WeakMap();
function Ja(e, t) {
	let n = qa.get(e);
	if (n !== void 0) return n;
	if (t.has(e)) return !0;
	t.add(e);
	let r = !1, i = (e) => {
		!r && e?._zod && Ja(e, t) && (r = !0);
	}, a = e._zod.def;
	switch (a.type) {
		case "object":
			for (let e of Reflect.ownKeys(a.shape)) i(a.shape[e]);
			i(a.catchall);
			break;
		case "array":
			i(a.element);
			break;
		case "tuple":
			for (let e of a.items) i(e);
			i(a.rest);
			break;
		case "record":
		case "map":
			i(a.keyType), i(a.valueType);
			break;
		case "set":
			i(a.valueType);
			break;
		case "union":
			for (let e of a.options) i(e);
			break;
		case "intersection":
			i(a.left), i(a.right);
			break;
		case "optional":
		case "nullable":
		case "default":
		case "prefault":
		case "catch":
		case "readonly":
		case "nonoptional":
		case "promise":
		case "success":
			i(a.innerType);
			break;
		case "pipe":
			i(a.in), i(a.out);
			break;
		case "function":
			i(a.input), i(a.output);
			break;
		case "lazy":
			i(e._zod.innerType);
			break;
		case "template_literal":
		case "string":
		case "number":
		case "int":
		case "boolean":
		case "bigint":
		case "symbol":
		case "undefined":
		case "null":
		case "void":
		case "never":
		case "any":
		case "unknown":
		case "date":
		case "nan":
		case "enum":
		case "literal":
		case "file":
		case "transform":
		case "custom": break;
		default: for (let e in a) {
			let t = Object.getOwnPropertyDescriptor(a, e);
			if (!t || t.get) continue;
			let n = t.value;
			if (n && typeof n == "object") {
				if (n._zod) i(n);
				else if (Array.isArray(n)) for (let e of n) i(e);
			}
		}
	}
	return t.delete(e), qa.set(e, r), r;
}
function Ya(e) {
	return Ja(e, /* @__PURE__ */ new Set());
}
function Xa(e, t) {
	let n = e.buckets.get(t);
	return n || (n = /* @__PURE__ */ new Map(), e.buckets.set(t, n)), n;
}
var Za, Qa = [], $a = {
	alloc(e, t, n) {
		let r = Za;
		if (!r) return n;
		Za = void 0;
		let i = {
			value: n,
			issues: null
		};
		return r.set(t.value, i), Qa.push(i), n;
	},
	guard(e) {
		var t;
		(t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
			let t = e._zod.parse, n = (e, n) => {
				if (n.direction !== "backward" && to(n, e.value)) throw new Ua();
				return t(e, n);
			};
			e._zod.parse = n, e._zod.run === t && (e._zod.run = n);
		});
	},
	attach(e) {
		var t;
		let n, r, i;
		(t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
			let t = e._zod.parse, a = (o, s) => {
				if (n === void 0 && (n = Ja(e, /* @__PURE__ */ new Set()), !n)) return e._zod.parse = t, e._zod.run === a && (e._zod.run = t), t(o, s);
				let c = o.value;
				if (typeof c != "object" || !c) return t(o, s);
				let l = s[Wa];
				l || (l = {
					buckets: /* @__PURE__ */ new Map(),
					backEdges: void 0
				}, s[Wa] = l);
				let u;
				r === s ? u = i : (u = Xa(l, e), r = s, i = u);
				let d = u.get(c);
				if (d) return o.value = d.value, d.issues ? d.issues.length && o.issues.push(...Ka(d.issues)) : (o.memo = !0, l.backEdges ?? (l.backEdges = /* @__PURE__ */ new Set()), l.backEdges.add(d.value)), o;
				Za = u;
				let f = Qa.length, p = t(o, s);
				Za = void 0;
				let m = Qa.length > f ? Qa.pop() : void 0;
				return p instanceof Promise ? p.then((e) => (m && (m.issues = e.issues.length ? Ka(e.issues) : Ga), e)) : (m && (m.issues = p.issues.length ? Ka(p.issues) : Ga), p);
			};
			e._zod.parse = a, e._zod.run === t && (e._zod.run = a);
		});
	}
};
function eo() {
	return $a;
}
function to(e, t) {
	let n = e[Wa]?.backEdges;
	return n !== void 0 && typeof t == "object" && !!t && n.has(t);
}
//#endregion
//#region node_modules/zod/v4/locales/en.js
var no = () => {
	let e = {
		string: {
			unit: "characters",
			verb: "to have"
		},
		file: {
			unit: "bytes",
			verb: "to have"
		},
		array: {
			unit: "items",
			verb: "to have"
		},
		set: {
			unit: "items",
			verb: "to have"
		},
		map: {
			unit: "entries",
			verb: "to have"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		credit_card: "credit card number",
		jwt: "JWT",
		template_literal: "input"
	}, r = { nan: "NaN" };
	function i(e, t) {
		return e === "number" && typeof t == "number" && !Number.isFinite(t) ? String(t) : r[e] ?? e;
	}
	return (e) => {
		switch (e.code) {
			case "invalid_type": return `Invalid input: expected ${i(e.expected)}, received ${i(Pe(e.input), e.input)}`;
			case "invalid_value": return e.values.length === 1 ? `Invalid input: expected ${_e(e.values[0])}` : `Invalid option: expected one of ${l(e.values, "|")}`;
			case "too_big": {
				let n = e.exact ? "exactly " : e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Too big: expected ${e.origin ?? "value"} to have ${n}${e.maximum.toString()} ${r.unit ?? "elements"}` : `Too big: expected ${e.origin ?? "value"} to be ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.exact ? "exactly " : e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Too small: expected ${e.origin} to have ${n}${e.minimum.toString()} ${r.unit}` : `Too small: expected ${e.origin} to be ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Invalid string: must start with "${t.prefix}"` : t.format === "ends_with" ? `Invalid string: must end with "${t.suffix}"` : t.format === "includes" ? `Invalid string: must include "${t.includes}"` : t.format === "regex" ? `Invalid string: must match pattern ${t.pattern}` : `Invalid ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Invalid number: must be a multiple of ${e.divisor}`;
			case "unrecognized_keys": return `Unrecognized key${e.keys.length > 1 ? "s" : ""}: ${l(e.keys, ", ")}`;
			case "invalid_key": return `Invalid key in ${e.origin}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `Invalid discriminator value. Expected ${e.options.map((e) => `'${e}'`).join(" | ")}` : e.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
			case "invalid_element": return `Invalid value in ${e.origin}`;
			default: return "Invalid input";
		}
	};
};
function ro() {
	return { localeError: no() };
}
//#endregion
//#region node_modules/zod/v4/core/registries.js
var io, ao = /*@__PURE__*/ Symbol("ZodOutput"), oo = /*@__PURE__*/ Symbol("ZodInput"), so = class {
	constructor() {
		this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
	}
	add(e, ...t) {
		let n = t[0];
		return this._map.set(e, n), n && typeof n == "object" && "id" in n && this._idmap.set(n.id, e), this;
	}
	clear() {
		return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
	}
	remove(e) {
		let t = this._map.get(e);
		return t && typeof t == "object" && "id" in t && this._idmap.delete(t.id), this._map.delete(e), this;
	}
	get(e) {
		let t = e._zod.parent;
		if (t) {
			let n = { ...this.get(t) ?? {} };
			delete n.id;
			let r = {
				...n,
				...this._map.get(e)
			};
			return Object.keys(r).length ? r : void 0;
		}
		return this._map.get(e);
	}
	has(e) {
		return this._map.has(e);
	}
};
function co() {
	return new so();
}
(io = globalThis).__zod_globalRegistry ?? (io.__zod_globalRegistry = co());
var R = globalThis.__zod_globalRegistry;
//#endregion
//#region node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function lo(e, t) {
	return new e({
		type: "string",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function uo(e, t) {
	return new e({
		type: "string",
		coerce: !0,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function fo(e, t) {
	return new e({
		type: "string",
		format: "email",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function po(e, t) {
	return new e({
		type: "string",
		format: "guid",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function mo(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ho(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v4",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function go(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v6",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function _o(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v7",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function vo(e, t) {
	return new e({
		type: "string",
		format: "url",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function yo(e, t) {
	return new e({
		type: "string",
		format: "emoji",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function bo(e, t) {
	return new e({
		type: "string",
		format: "nanoid",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function xo(e, t) {
	return new e({
		type: "string",
		format: "cuid",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function So(e, t) {
	return new e({
		type: "string",
		format: "cuid2",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Co(e, t) {
	return new e({
		type: "string",
		format: "ulid",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function wo(e, t) {
	return new e({
		type: "string",
		format: "xid",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function To(e, t) {
	return new e({
		type: "string",
		format: "ksuid",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Eo(e, t) {
	return new e({
		type: "string",
		format: "ipv4",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Do(e, t) {
	return new e({
		type: "string",
		format: "ipv6",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Oo(e, t) {
	return new e({
		type: "string",
		format: "mac",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ko(e, t) {
	return new e({
		type: "string",
		format: "cidrv4",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ao(e, t) {
	return new e({
		type: "string",
		format: "cidrv6",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function jo(e, t) {
	return new e({
		type: "string",
		format: "base64",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Mo(e, t) {
	return new e({
		type: "string",
		format: "base64url",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function No(e, t) {
	return new e({
		type: "string",
		format: "e164",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Po(e, t) {
	return new e({
		type: "string",
		format: "credit_card",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Fo(e, t) {
	return new e({
		type: "string",
		format: "jwt",
		check: "string_format",
		abort: !1,
		...x(t)
	});
}
var Io = {
	Any: null,
	Minute: -1,
	Second: 0,
	Millisecond: 3,
	Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function Lo(e, t) {
	return new e({
		type: "string",
		format: "datetime",
		check: "string_format",
		offset: !1,
		local: !1,
		precision: null,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ro(e, t) {
	return new e({
		type: "string",
		format: "date",
		check: "string_format",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function zo(e, t) {
	return new e({
		type: "string",
		format: "time",
		check: "string_format",
		precision: null,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Bo(e, t) {
	return new e({
		type: "string",
		format: "duration",
		check: "string_format",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Vo(e, t) {
	return new e({
		type: "number",
		checks: [],
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ho(e, t) {
	return new e({
		type: "number",
		coerce: !0,
		checks: [],
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Uo(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "safeint",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Wo(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "float32",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Go(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "float64",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ko(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "int32",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function qo(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "uint32",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Jo(e, t) {
	return new e({
		type: "boolean",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Yo(e, t) {
	return new e({
		type: "boolean",
		coerce: !0,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Xo(e, t) {
	return new e({
		type: "bigint",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Zo(e, t) {
	return new e({
		type: "bigint",
		coerce: !0,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Qo(e, t) {
	return new e({
		type: "bigint",
		check: "bigint_format",
		abort: !1,
		format: "int64",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function $o(e, t) {
	return new e({
		type: "bigint",
		check: "bigint_format",
		abort: !1,
		format: "uint64",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function es(e, t) {
	return new e({
		type: "symbol",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ts(e, t) {
	return new e({
		type: "undefined",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ns(e, t) {
	return new e({
		type: "null",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function rs(e) {
	return new e({ type: "any" });
}
// @__NO_SIDE_EFFECTS__
function is(e) {
	return new e({ type: "unknown" });
}
// @__NO_SIDE_EFFECTS__
function as(e, t) {
	return new e({
		type: "never",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function os(e, t) {
	return new e({
		type: "void",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ss(e, t) {
	return new e({
		type: "date",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function cs(e, t) {
	return new e({
		type: "date",
		coerce: !0,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ls(e, t) {
	return new e({
		type: "nan",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function us(e, t) {
	return new pr({
		check: "less_than",
		...x(t),
		value: e,
		inclusive: !1
	});
}
// @__NO_SIDE_EFFECTS__
function z(e, t) {
	return new pr({
		check: "less_than",
		...x(t),
		value: e,
		inclusive: !0
	});
}
// @__NO_SIDE_EFFECTS__
function B(e, t) {
	return new mr({
		check: "greater_than",
		...x(t),
		value: e,
		inclusive: !1
	});
}
// @__NO_SIDE_EFFECTS__
function V(e, t) {
	return new mr({
		check: "greater_than",
		...x(t),
		value: e,
		inclusive: !0
	});
}
// @__NO_SIDE_EFFECTS__
function ds(e) {
	return /* @__PURE__ */ B(0, e);
}
// @__NO_SIDE_EFFECTS__
function fs(e) {
	return /* @__PURE__ */ us(0, e);
}
// @__NO_SIDE_EFFECTS__
function ps(e) {
	return /* @__PURE__ */ z(0, e);
}
// @__NO_SIDE_EFFECTS__
function ms(e) {
	return /* @__PURE__ */ V(0, e);
}
// @__NO_SIDE_EFFECTS__
function hs(e, t) {
	return new hr({
		check: "multiple_of",
		...x(t),
		value: e
	});
}
// @__NO_SIDE_EFFECTS__
function gs(e, t) {
	return new vr({
		check: "max_size",
		...x(t),
		maximum: e
	});
}
// @__NO_SIDE_EFFECTS__
function _s(e, t) {
	return new yr({
		check: "min_size",
		...x(t),
		minimum: e
	});
}
// @__NO_SIDE_EFFECTS__
function vs(e, t) {
	return new br({
		check: "size_equals",
		...x(t),
		size: e
	});
}
// @__NO_SIDE_EFFECTS__
function ys(e, t) {
	return new xr({
		check: "max_length",
		...x(t),
		maximum: e
	});
}
// @__NO_SIDE_EFFECTS__
function bs(e, t) {
	return new Sr({
		check: "min_length",
		...x(t),
		minimum: e
	});
}
// @__NO_SIDE_EFFECTS__
function xs(e, t) {
	return new Cr({
		check: "length_equals",
		...x(t),
		length: e
	});
}
// @__NO_SIDE_EFFECTS__
function Ss(e, t) {
	return new Tr({
		check: "string_format",
		format: "regex",
		...x(t),
		pattern: e
	});
}
// @__NO_SIDE_EFFECTS__
function Cs(e) {
	return new Er({
		check: "string_format",
		format: "lowercase",
		...x(e)
	});
}
// @__NO_SIDE_EFFECTS__
function ws(e) {
	return new Dr({
		check: "string_format",
		format: "uppercase",
		...x(e)
	});
}
// @__NO_SIDE_EFFECTS__
function Ts(e, t) {
	return new Or({
		check: "string_format",
		format: "includes",
		...x(t),
		includes: e
	});
}
// @__NO_SIDE_EFFECTS__
function Es(e, t) {
	return new kr({
		check: "string_format",
		format: "starts_with",
		...x(t),
		prefix: e
	});
}
// @__NO_SIDE_EFFECTS__
function Ds(e, t) {
	return new Ar({
		check: "string_format",
		format: "ends_with",
		...x(t),
		suffix: e
	});
}
// @__NO_SIDE_EFFECTS__
function Os(e, t, n) {
	return new Mr({
		check: "property",
		property: e,
		schema: t,
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function ks(e) {
	return Object.entries(e).map(([e, t]) => new Mr({
		check: "property",
		property: e,
		schema: t
	}));
}
// @__NO_SIDE_EFFECTS__
function As(e, t) {
	return new Nr({
		check: "mime_type",
		mime: e,
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function H(e) {
	return new Pr({
		check: "overwrite",
		tx: e
	});
}
// @__NO_SIDE_EFFECTS__
function js(e) {
	return /* @__PURE__ */ H((t) => t.normalize(e));
}
// @__NO_SIDE_EFFECTS__
function Ms() {
	return /* @__PURE__ */ H((e) => e.trim());
}
// @__NO_SIDE_EFFECTS__
function Ns() {
	return /* @__PURE__ */ H((e) => e.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function Ps() {
	return /* @__PURE__ */ H((e) => e.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function Fs() {
	return /* @__PURE__ */ H((e) => ce(e));
}
// @__NO_SIDE_EFFECTS__
function Is(e, t, n) {
	return new e({
		type: "array",
		element: t,
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function Ls(e, t, n) {
	return new e({
		type: "union",
		options: t,
		...x(n)
	});
}
function Rs(e, t, n) {
	return new e({
		type: "union",
		options: t,
		inclusive: !1,
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function zs(e, t, n, r) {
	return new e({
		type: "union",
		options: n,
		discriminator: t,
		...x(r)
	});
}
// @__NO_SIDE_EFFECTS__
function Bs(e, t, n) {
	return new e({
		type: "intersection",
		left: t,
		right: n
	});
}
// @__NO_SIDE_EFFECTS__
function Vs(e, t, n, r) {
	let i = n instanceof I;
	return new e({
		type: "tuple",
		items: t,
		rest: i ? n : null,
		...x(i ? r : n)
	});
}
// @__NO_SIDE_EFFECTS__
function Hs(e, t, n, r) {
	return new e({
		type: "record",
		keyType: t,
		valueType: n,
		...x(r)
	});
}
// @__NO_SIDE_EFFECTS__
function Us(e, t, n, r) {
	return new e({
		type: "map",
		keyType: t,
		valueType: n,
		...x(r)
	});
}
// @__NO_SIDE_EFFECTS__
function Ws(e, t, n) {
	return new e({
		type: "set",
		valueType: t,
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function Gs(e, t, n) {
	return new e({
		type: "enum",
		entries: Array.isArray(t) ? Object.fromEntries(t.map((e) => [e, e])) : t,
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function Ks(e, t, n) {
	return new e({
		type: "enum",
		entries: t,
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function qs(e, t, n) {
	return new e({
		type: "literal",
		values: Array.isArray(t) ? t : [t],
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function Js(e, t) {
	return new e({
		type: "file",
		...x(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ys(e, t) {
	return new e({
		type: "transform",
		transform: t
	});
}
// @__NO_SIDE_EFFECTS__
function Xs(e, t) {
	return new e({
		type: "optional",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function Zs(e, t) {
	return new e({
		type: "nullable",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function Qs(e, t, n) {
	return new e({
		type: "default",
		innerType: t,
		get defaultValue() {
			return typeof n == "function" ? n() : de(n);
		}
	});
}
// @__NO_SIDE_EFFECTS__
function $s(e, t, n) {
	return new e({
		type: "nonoptional",
		innerType: t,
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function ec(e, t) {
	return new e({
		type: "success",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function tc(e, t, n) {
	return new e({
		type: "catch",
		innerType: t,
		catchValue: typeof n == "function" ? n : Qe(n)
	});
}
// @__NO_SIDE_EFFECTS__
function nc(e, t, n) {
	return new e({
		type: "pipe",
		in: t,
		out: n
	});
}
// @__NO_SIDE_EFFECTS__
function rc(e, t) {
	return new e({
		type: "readonly",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function ic(e, t, n) {
	return new e({
		type: "template_literal",
		parts: t,
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function ac(e, t) {
	return new e({
		type: "lazy",
		getter: t
	});
}
// @__NO_SIDE_EFFECTS__
function oc(e, t) {
	return new e({
		type: "promise",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function sc(e, t, n) {
	let r = x(n);
	return r.abort ??= !0, new e({
		type: "custom",
		check: "custom",
		fn: t,
		...r
	});
}
// @__NO_SIDE_EFFECTS__
function cc(e, t, n) {
	return new e({
		type: "custom",
		check: "custom",
		fn: t,
		...x(n)
	});
}
// @__NO_SIDE_EFFECTS__
function lc(e, t) {
	let n = /* @__PURE__ */ uc((t) => (t.addIssue = (e) => {
		if (typeof e == "string") t.issues.push(Fe(e, t.value, n._zod.def));
		else {
			let r = e;
			r.fatal && (r.continue = !1), r.code ??= "custom", "input" in r || (r.input = t.value), r.inst ??= n, r.continue ??= !n._zod.def.abort, t.issues.push(Fe(r));
		}
	}, e(t.value, t)), t);
	return n;
}
// @__NO_SIDE_EFFECTS__
function uc(e, t) {
	let n = new F({
		check: "custom",
		...x(t)
	});
	return n._zod.check = e, n;
}
// @__NO_SIDE_EFFECTS__
function dc(e) {
	let t = new F({ check: "describe" });
	return t._zod.onattach = [(t) => {
		let n = R.get(t) ?? {};
		R.add(t, {
			...n,
			description: e
		});
	}], t._zod.check = () => {}, t;
}
// @__NO_SIDE_EFFECTS__
function fc(e) {
	let t = new F({ check: "meta" });
	return t._zod.onattach = [(t) => {
		let n = R.get(t) ?? {};
		R.add(t, {
			...n,
			...e
		});
	}], t._zod.check = () => {}, t;
}
// @__NO_SIDE_EFFECTS__
function pc(e, t) {
	let n = x(t), r = n.truthy ?? [
		"true",
		"1",
		"yes",
		"on",
		"y",
		"enabled"
	], i = n.falsy ?? [
		"false",
		"0",
		"no",
		"off",
		"n",
		"disabled"
	];
	n.case !== "sensitive" && (r = r.map((e) => typeof e == "string" ? e.toLowerCase() : e), i = i.map((e) => typeof e == "string" ? e.toLowerCase() : e));
	let a = new Set(r), o = new Set(i), s = e.Codec ?? ja, c = e.Boolean ?? Oi, l = new s({
		type: "pipe",
		in: new (e.String ?? zr)({
			type: "string",
			error: n.error
		}),
		out: new c({
			type: "boolean",
			error: n.error
		}),
		transform: ((e, t) => {
			let r = e;
			return n.case !== "sensitive" && (r = r.toLowerCase()), a.has(r) ? !0 : !o.has(r) && (t.issues.push({
				code: "invalid_value",
				expected: "stringbool",
				values: [...a, ...o],
				input: t.value,
				inst: l,
				continue: !1
			}), {});
		}),
		reverseTransform: ((e, t) => e === !0 ? r[0] || "true" : i[0] || "false"),
		error: n.error
	});
	return l._zod.bag.truthy = r, l._zod.bag.falsy = i, l._zod.bag.case = n.case ?? "insensitive", l;
}
// @__NO_SIDE_EFFECTS__
function mc(e, t, n, r = {}) {
	let i = x(r), a = {
		check: "string_format",
		type: "string",
		format: t,
		fn: typeof n == "function" ? n : (e) => n.test(e),
		...i
	};
	return n instanceof RegExp && (a.pattern = n), new e(a);
}
//#endregion
//#region node_modules/zod/v4/core/to-json-schema.js
function hc(e, ...t) {
	for (let n of t) for (let t of Reflect.ownKeys(n)) Object.prototype.propertyIsEnumerable.call(n, t) && h(e, t, n[t]);
	return e;
}
function gc(e) {
	let t = e?.target ?? "draft-2020-12";
	return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
		processors: e.processors ?? {},
		metadataRegistry: e?.metadata ?? R,
		target: t,
		unrepresentable: e?.unrepresentable ?? "throw",
		override: e?.override ?? (() => {}),
		io: e?.io ?? "output",
		counter: 0,
		seen: /* @__PURE__ */ new Map(),
		sharedDefsExtractedFor: void 0,
		sharedEmitDoneFor: void 0,
		cycles: e?.cycles ?? "ref",
		reused: e?.reused ?? "inline",
		intersections: [],
		deferred: [],
		external: e?.external ?? void 0
	};
}
function U(e, t, n, r, i) {
	let a = typeof t.unrepresentable == "function" ? t.unrepresentable({
		zodSchema: e,
		path: r.path,
		message: i
	}) : t.unrepresentable;
	if (a === "any") return !1;
	if (a === void 0 || a === "throw") throw Error(i);
	return Object.assign(n, a), !0;
}
function W(e, t, n = {
	path: [],
	schemaPath: []
}) {
	var r;
	let i = e._zod.def, a = t.seen.get(e);
	if (a) return a.count++, n.schemaPath.includes(e) && (a.cycle = n.path), a.schema;
	let o = {
		schema: {},
		count: 1,
		cycle: void 0,
		path: n.path
	};
	t.seen.set(e, o), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
	let s = e._zod.toJSONSchema?.();
	if (s) o.schema = s;
	else {
		let r = {
			...n,
			schemaPath: [...n.schemaPath, e],
			path: n.path
		};
		if (e._zod.processJSONSchema) e._zod.processJSONSchema(t, o.schema, r);
		else {
			let n = o.schema, a = t.processors[i.type];
			if (!a) throw Error(`[toJSONSchema]: Non-representable type encountered: ${i.type}`);
			a(e, t, n, r);
		}
		let a = e._zod.parent;
		a && (o.ref ||= a, W(a, t, r), t.seen.get(a).isParent = !0);
	}
	let c = t.metadataRegistry.get(e);
	return c && hc(o.schema, c), t.io === "input" && G(e) && (delete o.schema.examples, delete o.schema.default), t.io === "input" && "_prefault" in o.schema && ((r = o.schema).default ?? (r.default = o.schema._prefault)), delete o.schema._prefault, t.seen.get(e).schema;
}
function _c(e) {
	return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
function vc(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	if (e.external && e.sharedDefsExtractedFor === e.external) return;
	let r = /* @__PURE__ */ new Map();
	for (let t of e.seen.entries()) {
		let n = e.metadataRegistry.get(t[0])?.id;
		if (n) {
			let e = r.get(n);
			if (e && e !== t[0]) throw Error(`Duplicate schema id "${n}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
			r.set(n, t[0]);
		}
	}
	let i = (t) => {
		let r = e.target === "draft-2020-12" ? "$defs" : "definitions";
		if (e.external) {
			let n = e.external.registry.get(t[0])?.id, i = e.external.uri ?? ((e) => e);
			if (n) return { ref: i(n) };
			let a = t[1].defId ?? t[1].schema.id ?? `schema${e.counter++}`;
			return t[1].defId = a, {
				defId: a,
				ref: `${i("__shared")}#/${r}/${_c(a)}`
			};
		}
		let i = `#/${r}/`;
		if (t[1] === n && !t[1].schema.id) return { ref: "#" };
		let a = t[1].schema.id ?? `__schema${e.counter++}`;
		return {
			defId: a,
			ref: i + _c(a)
		};
	}, a = (e) => {
		if (e[1].schema.$ref) return;
		let t = e[1], { ref: n, defId: r } = i(e);
		t.def = { ...t.schema }, r && (t.defId = r);
		let a = t.schema;
		for (let e in a) delete a[e];
		a.$ref = n;
	};
	if (e.cycles === "throw") for (let t of e.seen.entries()) {
		let e = t[1];
		if (e.cycle) throw Error(`Cycle detected: #/${e.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
	}
	for (let n of e.seen.entries()) {
		let r = n[1];
		if (t === n[0]) {
			a(n);
			continue;
		}
		if (e.external) {
			let r = e.external.registry.get(n[0])?.id;
			if (t !== n[0] && r) {
				a(n);
				continue;
			}
		}
		if (e.metadataRegistry.get(n[0])?.id) {
			a(n);
			continue;
		}
		if (r.cycle) {
			a(n);
			continue;
		}
		if (r.count > 1 && e.reused === "ref") {
			a(n);
			continue;
		}
	}
	e.external && (e.sharedDefsExtractedFor = e.external);
}
function yc(e) {
	let t = e.anyOf;
	if (!Array.isArray(t) || t.length === 0 || e.type !== void 0) return;
	let n = [];
	for (let e of t) {
		if (!e || typeof e != "object") return;
		yc(e);
		let t = Object.keys(e);
		if (t.length !== 1 || t[0] !== "type") return;
		let r = e.type;
		for (let e of Array.isArray(r) ? r : [r]) {
			if (typeof e != "string") return;
			n.includes(e) || n.push(e);
		}
	}
	delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
var bc = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties"
]), xc = ["oneOf", "anyOf"];
function Sc(e) {
	let t = e.additionalProperties;
	return t === void 0 || t === !1 || typeof t != "object" || !t ? null : Object.keys(t).length ? t : null;
}
function Cc(e) {
	let t = [];
	for (let n of e) {
		if (typeof n != "object" || n.type !== "object") return null;
		for (let e in n) if (!bc.has(e)) return null;
		t.push(n);
	}
	let n = {}, r = /* @__PURE__ */ new Set();
	for (let e of t) {
		for (let r in e.properties) {
			if (Object.prototype.hasOwnProperty.call(n, r)) continue;
			let e = [];
			for (let n of t) {
				let t = n.properties?.[r] ?? Sc(n);
				t != null && (e.some((e) => JSON.stringify(e) === JSON.stringify(t)) || e.push(t));
			}
			h(n, r, e.length === 1 ? e[0] : Cc(e) ?? { allOf: e });
		}
		for (let t of e.required ?? []) r.add(t);
	}
	let i = {
		type: "object",
		properties: n
	};
	if (r.size && (i.required = [...r]), t.every((e) => e.additionalProperties === !1)) i.additionalProperties = !1;
	else {
		let e = [];
		for (let n of t) {
			let t = Sc(n);
			t && !e.some((e) => JSON.stringify(e) === JSON.stringify(t)) && e.push(t);
		}
		e.length === 1 ? i.additionalProperties = e[0] : e.length > 1 && (i.additionalProperties = { allOf: e });
	}
	return i;
}
function wc(e) {
	let t = e.allOf;
	if (!Array.isArray(t) || t.length < 2) return;
	for (let t of bc) if (t in e) return;
	let n = t.filter((e) => xc.some((t) => Array.isArray(e[t]))), r = null;
	if (!n.length) r = Cc(t);
	else {
		let e = n[0], i = xc.find((t) => Array.isArray(e[t]));
		if (Object.keys(e).length !== 1) return;
		let a = t.filter((t) => t !== e), o = e[i].map((e) => Cc([...a, e]));
		if (o.some((e) => !e)) return;
		r = { [i]: o };
	}
	r && (delete e.allOf, hc(e, r));
}
function Tc(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	let r = (t) => {
		let n = e.seen.get(t);
		if (n.ref === null) return;
		let i = n.def ?? n.schema, a = { ...i }, o = n.ref;
		if (n.ref = null, o) {
			r(o);
			let n = e.seen.get(o), s = n.schema;
			if (s.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (i.allOf = i.allOf ?? [], i.allOf.push(s)) : hc(i, s), hc(i, a), t._zod.parent === o) for (let e in i) e !== "$ref" && e !== "allOf" && (e in a || delete i[e]);
			if (s.$ref && n.def) for (let e in i) e !== "$ref" && e !== "allOf" && e in n.def && JSON.stringify(i[e]) === JSON.stringify(n.def[e]) && delete i[e];
		}
		let s = t._zod.parent;
		if (s && s !== o) {
			r(s);
			let t = e.seen.get(s);
			if (t?.schema.$ref && (i.$ref = t.schema.$ref, t.def)) for (let e in i) e !== "$ref" && e !== "allOf" && e in t.def && JSON.stringify(i[e]) === JSON.stringify(t.def[e]) && delete i[e];
		}
		e.override({
			zodSchema: t,
			jsonSchema: i,
			path: n.path ?? []
		});
	};
	if (!e.external || e.sharedEmitDoneFor !== e.external) {
		for (let t of [...e.seen.entries()].reverse()) r(t[0]);
		if (e.target !== "openapi-3.0") for (let t of e.seen.entries()) yc(t[1].def ?? t[1].schema);
		for (let t of e.deferred) t();
		if (e.intersections.length) {
			let t = /* @__PURE__ */ new Map();
			for (let n of e.seen.values()) for (let e of [n.schema, n.def]) {
				let n = e?.allOf;
				if (!Array.isArray(n)) continue;
				let r = t.get(n);
				r ? r.push(e) : t.set(n, [e]);
			}
			for (let n of e.intersections) for (let e of t.get(n) ?? []) wc(e);
		}
	}
	let i = {};
	if (e.target === "draft-2020-12" ? i.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? i.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? i.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
		let n = e.external.registry.get(t)?.id;
		if (!n) throw Error("Schema is missing an `id` property");
		i.$id = e.external.uri(n);
	}
	hc(i, n.defId ? n.schema : n.def ?? n.schema);
	let a = e.metadataRegistry.get(t)?.id;
	a !== void 0 && i.id === a && delete i.id;
	let o = e.external?.defs ?? {};
	if (!e.external || e.sharedEmitDoneFor !== e.external) for (let t of e.seen.entries()) {
		let e = t[1];
		e.def && e.defId && (e.def.id === e.defId && delete e.def.id, h(o, e.defId, e.def));
	}
	e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(o).length > 0 && (e.target === "draft-2020-12" ? i.$defs = o : i.definitions = o);
	try {
		let n = JSON.parse(JSON.stringify(i));
		return Object.defineProperty(n, "~standard", {
			value: {
				...t["~standard"],
				jsonSchema: {
					input: Dc(t, "input", e.processors),
					output: Dc(t, "output", e.processors)
				}
			},
			enumerable: !1,
			writable: !1
		}), n;
	} catch {
		throw Error("Error converting schema to JSON.");
	}
}
function G(e, t) {
	let n = t ?? { seen: /* @__PURE__ */ new Set() };
	if (n.seen.has(e)) return !1;
	n.seen.add(e);
	let r = e._zod.def;
	if (r.type === "transform") return !0;
	if (r.type === "array") return G(r.element, n);
	if (r.type === "set") return G(r.valueType, n);
	if (r.type === "lazy") return G(r.getter(), n);
	if (r.type === "promise" || r.type === "optional" || r.type === "nonoptional" || r.type === "nullable" || r.type === "readonly" || r.type === "default" || r.type === "prefault" || r.type === "catch") return G(r.innerType, n);
	if (r.type === "intersection") return G(r.left, n) || G(r.right, n);
	if (r.type === "record" || r.type === "map") return G(r.keyType, n) || G(r.valueType, n);
	if (r.type === "pipe") return e._zod.traits.has("$ZodCodec") ? !0 : G(r.in, n) || G(r.out, n);
	if (r.type === "object") {
		for (let e in r.shape) if (G(r.shape[e], n)) return !0;
		return !1;
	}
	if (r.type === "union") {
		for (let e of r.options) if (G(e, n)) return !0;
		return !1;
	}
	if (r.type === "tuple") {
		for (let e of r.items) if (G(e, n)) return !0;
		return !!(r.rest && G(r.rest, n));
	}
	return !1;
}
var Ec = (e, t = {}) => (n) => {
	let r = gc({
		...n,
		processors: t
	});
	return W(e, r), vc(r, e), Tc(r, e);
}, Dc = (e, t, n = {}) => (r) => {
	let { libraryOptions: i, target: a } = r ?? {}, o = gc({
		...i ?? {},
		target: a,
		io: t,
		processors: n
	});
	return W(e, o), vc(o, e), Tc(o, e);
}, Oc = {
	guid: "uuid",
	url: "uri",
	datetime: "date-time",
	json_string: "json-string",
	regex: ""
}, kc = (e, t, n, r) => {
	let i = n;
	i.type = "string";
	let { minimum: a, maximum: o, format: s, patterns: c, contentEncoding: l, laxFormat: u } = e._zod.bag;
	if (typeof a == "number" && (i.minLength = a), typeof o == "number" && (i.maxLength = o), s && (i.format = Oc[s] ?? s, i.format === "" && delete i.format, (s === "time" || u) && delete i.format), l && (i.contentEncoding = l), c && c.size > 0) {
		let e = [...c];
		e.length === 1 ? i.pattern = e[0].source : e.length > 1 && (i.allOf = [...e.map((e) => ({
			...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
			pattern: e.source
		}))]);
	}
}, Ac = (e, t, n, r) => {
	let i = n, { minimum: a, maximum: o, format: s, multipleOf: c, exclusiveMaximum: l, exclusiveMinimum: u } = e._zod.bag;
	i.type = typeof s == "string" && s.includes("int") ? "integer" : "number";
	let d = typeof u == "number" && u >= (a ?? -Infinity), f = typeof l == "number" && l <= (o ?? Infinity), p = t.target === "draft-04" || t.target === "openapi-3.0";
	d ? p ? (i.minimum = u, i.exclusiveMinimum = !0) : i.exclusiveMinimum = u : typeof a == "number" && (i.minimum = a), f ? p ? (i.maximum = l, i.exclusiveMaximum = !0) : i.exclusiveMaximum = l : typeof o == "number" && (i.maximum = o), typeof c == "number" && (Number.isFinite(c) && c !== 0 ? i.multipleOf = Math.abs(c) : U(e, t, i, r, `A multipleOf divisor of ${c} cannot be represented in JSON Schema`));
}, jc = (e, t, n, r) => {
	n.type = "boolean";
}, Mc = (e, t, n, r) => {
	U(e, t, n, r, "BigInt cannot be represented in JSON Schema");
}, Nc = (e, t, n, r) => {
	U(e, t, n, r, "Symbols cannot be represented in JSON Schema");
}, Pc = (e, t, n, r) => {
	t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, Fc = (e, t, n, r) => {
	U(e, t, n, r, "Undefined cannot be represented in JSON Schema");
}, Ic = (e, t, n, r) => {
	U(e, t, n, r, "Void cannot be represented in JSON Schema");
}, Lc = (e, t, n, r) => {
	n.not = {};
}, Rc = (e, t, n, r) => {}, zc = (e, t, n, r) => {}, Bc = (e, t, n, r) => {
	U(e, t, n, r, "Date cannot be represented in JSON Schema");
}, Vc = (e, t, n, r) => {
	let i = e._zod.def, a = c(i.entries);
	if (a.length === 0) {
		n.not = {};
		return;
	}
	a.every((e) => typeof e == "number") && (n.type = "number"), a.every((e) => typeof e == "string") && (n.type = "string"), n.enum = a;
}, Hc = (e, t, n, r) => {
	let i = e._zod.def;
	if (i.values.length === 0) {
		n.not = {};
		return;
	}
	let a = [];
	for (let o of i.values) if (o === void 0) {
		if (U(e, t, n, r, "Literal `undefined` cannot be represented in JSON Schema")) return;
	} else if (typeof o == "bigint") {
		if (U(e, t, n, r, "BigInt literals cannot be represented in JSON Schema")) return;
		a.push(Number(o));
	} else a.push(o);
	if (a.length !== 0) {
		if (a.length === 1) {
			let e = a[0];
			n.type = e === null ? "null" : typeof e, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [e] : n.const = e;
		} else a.every((e) => typeof e == "number") && (n.type = "number"), a.every((e) => typeof e == "string") && (n.type = "string"), a.every((e) => typeof e == "boolean") && (n.type = "boolean"), a.every((e) => e === null) && (n.type = "null"), n.enum = a;
	}
}, Uc = (e, t, n, r) => {
	U(e, t, n, r, "NaN cannot be represented in JSON Schema");
}, Wc = (e, t, n, r) => {
	let i = n, a = e._zod.pattern;
	if (!a) throw Error("Pattern not found in template literal");
	i.type = "string", i.pattern = a.source;
}, Gc = (e, t, n, r) => {
	let i = n, a = {
		type: "string",
		format: "binary",
		contentEncoding: "binary"
	}, { minimum: o, maximum: s, mime: c } = e._zod.bag;
	o !== void 0 && (a.minLength = o), s !== void 0 && (a.maxLength = s), c ? c.length === 1 ? (a.contentMediaType = c[0], Object.assign(i, a)) : (Object.assign(i, a), i.anyOf = c.map((e) => ({ contentMediaType: e }))) : Object.assign(i, a);
}, Kc = (e, t, n, r) => {
	n.type = "boolean";
}, qc = (e, t, n, r) => {
	U(e, t, n, r, "Custom types cannot be represented in JSON Schema");
}, Jc = (e, t, n, r) => {
	U(e, t, n, r, "Function types cannot be represented in JSON Schema");
}, Yc = (e, t, n, r) => {
	U(e, t, n, r, "Transforms cannot be represented in JSON Schema");
}, Xc = (e, t, n, r) => {
	U(e, t, n, r, "Map cannot be represented in JSON Schema");
}, Zc = (e, t, n, r) => {
	U(e, t, n, r, "Set cannot be represented in JSON Schema");
}, Qc = (e, t, n, r) => {
	let i = n, a = e._zod.def, { minimum: o, maximum: s } = e._zod.bag;
	typeof o == "number" && (i.minItems = o), typeof s == "number" && (i.maxItems = s), i.type = "array", i.items = W(a.element, t, {
		...r,
		path: [...r.path, "items"]
	});
};
function $c(e) {
	let t = e._zod.def;
	return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? $c(t.out) : t.type === "catch" ? $c(t.innerType) : e._zod.optin;
}
var el = (e, t, n, r) => {
	let i = n, a = e._zod.def, o = a.shape;
	if (Object.getOwnPropertySymbols(o).length && U(e, t, i, r, "Symbol keys cannot be represented in JSON Schema")) return;
	i.type = "object", i.properties = {};
	for (let e in o) h(i.properties, e, W(o[e], t, {
		...r,
		path: [
			...r.path,
			"properties",
			e
		]
	}));
	let s = new Set(Object.keys(o)), c = new Set([...s].filter((e) => {
		let n = a.shape[e];
		return t.io === "input" ? $c(n) === void 0 : n._zod.optout === void 0;
	}));
	c.size > 0 && (i.required = Array.from(c)), a.catchall?._zod.def.type === "never" ? i.additionalProperties = !1 : a.catchall ? a.catchall && (i.additionalProperties = W(a.catchall, t, {
		...r,
		path: [...r.path, "additionalProperties"]
	})) : t.io === "output" && (i.additionalProperties = !1);
}, tl = (e, t, n, r) => {
	let i = e._zod.def, a = i.inclusive === !1, o = i.options.map((e, n) => W(e, t, {
		...r,
		path: [
			...r.path,
			a ? "oneOf" : "anyOf",
			n
		]
	}));
	a ? n.oneOf = o : n.anyOf = o;
}, nl = (e, t, n, r) => {
	let i = e._zod.def, a = W(i.left, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			0
		]
	}), o = W(i.right, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			1
		]
	}), s = (e) => "allOf" in e && Object.keys(e).length === 1, c = [...s(a) ? a.allOf : [a], ...s(o) ? o.allOf : [o]];
	n.allOf = c, t.intersections.push(c);
}, rl = (e, t, n, r) => {
	let i = n, a = e._zod.def;
	i.type = "array";
	let o = t.target === "draft-2020-12" ? "prefixItems" : "items", s = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", c = a.items.map((e, n) => W(e, t, {
		...r,
		path: [
			...r.path,
			o,
			n
		]
	})), l = a.rest ? W(a.rest, t, {
		...r,
		path: [
			...r.path,
			s,
			...t.target === "openapi-3.0" ? [a.items.length] : []
		]
	}) : null, u = a.items.length;
	for (; u > 0;) {
		let e = a.items[u - 1];
		if (!(t.io === "input" ? $c(e) !== void 0 : e._zod.optout === "optional")) break;
		u--;
	}
	let d = a.items.length, f = !a.rest;
	t.target === "draft-2020-12" ? (i.prefixItems = c, f ? i.items = !1 : l && (i.items = l), u > 0 && (i.minItems = u), f && (i.maxItems = d)) : t.target === "openapi-3.0" ? (i.items = { anyOf: c }, l && i.items.anyOf.push(l), u > 0 && (i.minItems = u), f && (i.maxItems = d)) : (i.items = c, f ? i.additionalItems = !1 : l && (i.additionalItems = l), u > 0 && (i.minItems = u), f && (i.maxItems = d));
	let { minimum: p, maximum: m } = e._zod.bag;
	typeof p == "number" && (i.minItems = p), typeof m == "number" && (i.maxItems = m);
};
function il(e, t, n) {
	if (t.$ref) {
		if (n.has(t)) return t;
		n.add(t);
		let r = e.get(t)?.def;
		if (!r) return t;
		let i = il(e, r, n);
		return i === r ? t : i;
	}
	for (let r of ["anyOf", "oneOf"]) {
		let i = t[r];
		if (!Array.isArray(i)) continue;
		let a = i.map((t) => il(e, t, n));
		a.some((e, t) => e !== i[t]) && (t = {
			...t,
			[r]: a
		});
	}
	let r = Array.isArray(t.type) ? t.type : [t.type], i = !r.includes("string") && r.some((e) => e === "number" || e === "integer"), a = t.enum ?? (t.const === void 0 ? void 0 : [t.const]);
	if (!i && !a?.some((e) => typeof e == "number")) return t;
	let { minimum: o, maximum: s, exclusiveMinimum: c, exclusiveMaximum: l, multipleOf: u, format: d, id: f, ...p } = t;
	return p.enum ? p.enum = p.enum.map((e) => typeof e == "number" ? String(e) : e) : typeof p.const == "number" && (p.const = String(p.const)), i ? (p.type = "string", a || (p.pattern = (r.includes("number") ? Bn : zn).source), p) : p;
}
var al = /* @__PURE__ */ new WeakMap();
function ol(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.seen.values()) n.def && !t.has(n.schema) && t.set(n.schema, n);
	let n = /* @__PURE__ */ new Map();
	for (let r of al.get(e) ?? []) {
		let i = e.seen.get(r), a = (i?.def ?? i?.schema)?.propertyNames;
		if (!a || a === !0 || n.has(a)) continue;
		let o = il(t, a, /* @__PURE__ */ new Set());
		o !== a && n.set(a, o);
	}
	if (n.size) for (let t of e.seen.values()) for (let e of [t.schema, t.def]) {
		let t = e && n.get(e.propertyNames);
		t && (e.propertyNames = t);
	}
}
var sl = (e, t, n, r) => {
	let i = n, a = e._zod.def;
	i.type = "object";
	let o = a.keyType, s = o._zod.bag?.patterns;
	if (a.mode === "loose" && s && s.size > 0) {
		let e = W(a.valueType, t, {
			...r,
			path: [
				...r.path,
				"patternProperties",
				"*"
			]
		});
		i.patternProperties = {};
		for (let t of s) h(i.patternProperties, t.source, e);
	} else {
		if (t.target === "draft-07" || t.target === "draft-2020-12") {
			i.propertyNames = W(a.keyType, t, {
				...r,
				path: [...r.path, "propertyNames"]
			});
			let n = al.get(t);
			n || (n = [], al.set(t, n), t.deferred.push(() => ol(t))), n.push(e);
		}
		i.additionalProperties = W(a.valueType, t, {
			...r,
			path: [...r.path, "additionalProperties"]
		});
	}
	let c = o._zod.values, l = t.io === "input" && $c(a.valueType) !== void 0;
	if (c && !a.partial && !l) {
		let e = [...c].filter((e) => typeof e == "string" || typeof e == "number");
		e.length > 0 && (i.required = e.map(String));
	}
}, cl = (e, t, n, r) => {
	let i = e._zod.def, a = W(i.innerType, t, r), o = t.seen.get(e);
	t.target === "openapi-3.0" ? (o.ref = i.innerType, n.nullable = !0) : n.anyOf = [a, { type: "null" }];
}, ll = (e, t, n, r) => {
	let i = e._zod.def;
	W(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, ul = Symbol();
function dl(e, t, n, r, i) {
	let a = !1, o = JSON.stringify(e, (e, t) => typeof t == "bigint" ? (a = !0, null) : t);
	return a ? (U(t, n, r, i, "BigInt defaults cannot be represented in JSON Schema"), ul) : JSON.parse(o);
}
var fl = (e, t, n, r) => {
	let i = e._zod.def;
	W(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
	let o = dl(i.defaultValue, e, t, n, r);
	o !== ul && (n.default = o);
}, pl = (e, t, n, r) => {
	let i = e._zod.def;
	W(i.innerType, t, r);
	let a = t.seen.get(e);
	if (a.ref = i.innerType, t.io !== "input") return;
	let o = dl(i.defaultValue, e, t, n, r);
	o !== ul && (n._prefault = o);
}, ml = (e, t, n, r) => {
	let i = e._zod.def;
	W(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
	let o;
	try {
		o = i.catchValue(void 0);
	} catch {
		U(e, t, n, r, "Dynamic catch values are not supported in JSON Schema");
		return;
	}
	n.default = o;
}, hl = (e, t, n, r) => {
	let i = e._zod.def, a = i.in._zod.traits.has("$ZodTransform"), o = t.io === "input" ? a ? i.out : i.in : i.out;
	W(o, t, r);
	let s = t.seen.get(e);
	s.ref = o;
}, gl = (e, t, n, r) => {
	let i = e._zod.def;
	W(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType, n.readOnly = !0;
}, _l = (e, t, n, r) => {
	let i = e._zod.def;
	W(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, vl = (e, t, n, r) => {
	let i = e._zod.def;
	W(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, yl = (e, t, n, r) => {
	let i = e._zod.innerType;
	W(i, t, r);
	let a = t.seen.get(e);
	a.ref = i;
}, bl = {
	string: kc,
	number: Ac,
	boolean: jc,
	bigint: Mc,
	symbol: Nc,
	null: Pc,
	undefined: Fc,
	void: Ic,
	never: Lc,
	any: Rc,
	unknown: zc,
	date: Bc,
	enum: Vc,
	literal: Hc,
	nan: Uc,
	template_literal: Wc,
	file: Gc,
	success: Kc,
	custom: qc,
	function: Jc,
	transform: Yc,
	map: Xc,
	set: Zc,
	array: Qc,
	object: el,
	union: tl,
	intersection: nl,
	tuple: rl,
	record: sl,
	nullable: cl,
	nonoptional: ll,
	default: fl,
	prefault: pl,
	catch: ml,
	pipe: hl,
	readonly: gl,
	promise: _l,
	optional: vl,
	lazy: yl
};
function xl(e, t) {
	if ("_idmap" in e) {
		let n = e, r = gc({
			...t,
			processors: bl
		}), i = {};
		for (let e of n._idmap.entries()) {
			let [t, n] = e;
			W(n, r);
		}
		let a = {};
		r.external = {
			registry: n,
			uri: t?.uri,
			defs: i
		};
		for (let e of n._idmap.entries()) {
			let [t, n] = e;
			vc(r, n), h(a, t, Tc(r, n));
		}
		return Object.keys(i).length > 0 && (a.__shared = { [r.target === "draft-2020-12" ? "$defs" : "definitions"]: i }), { schemas: a };
	}
	let n = gc({
		...t,
		processors: bl
	});
	return W(e, n), vc(n, e), Tc(n, e);
}
//#endregion
//#region node_modules/zod/v4/classic/errors.js
var Sl = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function Cl(e, t, n) {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		get() {
			let e = n(this);
			return Object.defineProperty(this, t, {
				value: e,
				configurable: !0,
				writable: !0
			}), e;
		},
		set(e) {
			Object.defineProperty(this, t, {
				value: e,
				configurable: !0,
				writable: !0
			});
		}
	});
}
var wl = (e, t) => {
	pt.init(e, t), e.name = "ZodError";
	let n = Object.getPrototypeOf(e);
	Sl.has(n) || (Sl.add(n), Cl(n, "format", (e) => (t) => gt(e, t)), Cl(n, "flatten", (e) => (t) => ht(e, t)), Cl(n, "addIssue", (e) => (t) => {
		e.issues.push(t), e.message = JSON.stringify(e.issues, u, 2);
	}), Cl(n, "addIssues", (e) => (t) => {
		e.issues.push(...t), e.message = JSON.stringify(e.issues, u, 2);
	}), Object.defineProperty(n, "isEmpty", {
		configurable: !0,
		enumerable: !1,
		get() {
			return this.issues.length === 0;
		}
	}));
}, Tl = /*@__PURE__*/ k("ZodError", wl), K = /*@__PURE__*/ k("ZodError", wl, void 0, { Parent: Error }), El = /* @__PURE__ */ xt(K), Dl = /* @__PURE__ */ Ct(K), Ol = /* @__PURE__ */ Tt(K), kl = /* @__PURE__ */ Dt(K), Al = /* @__PURE__ */ Pt(K), jl = /* @__PURE__ */ It(K), Ml = /* @__PURE__ */ Rt(K), Nl = /* @__PURE__ */ Bt(K), Pl = /* @__PURE__ */ Ht(K), Fl = /* @__PURE__ */ Wt(K), Il = /* @__PURE__ */ Kt(K), Ll = /* @__PURE__ */ Jt(K), Rl = /* @__PURE__ */ e({
	ZodAny: () => cd,
	ZodArray: () => _d,
	ZodBase64: () => Ou,
	ZodBase64URL: () => Au,
	ZodBigInt: () => Zu,
	ZodBigIntFormat: () => $u,
	ZodBoolean: () => Yu,
	ZodCIDRv4: () => wu,
	ZodCIDRv6: () => Eu,
	ZodCUID: () => cu,
	ZodCUID2: () => uu,
	ZodCatch: () => pf,
	ZodCodec: () => yf,
	ZodCreditCard: () => Pu,
	ZodCustom: () => Nf,
	ZodCustomStringFormat: () => Z,
	ZodDate: () => hd,
	ZodDefault: () => af,
	ZodDiscriminatedUnion: () => Od,
	ZodE164: () => Mu,
	ZodEmail: () => ql,
	ZodEmoji: () => iu,
	ZodEnum: () => Hd,
	ZodExactOptional: () => $d,
	ZodFile: () => qd,
	ZodFunction: () => jf,
	ZodGUID: () => Yl,
	ZodIPv4: () => vu,
	ZodIPv6: () => Su,
	ZodISODate: () => Wl,
	ZodISODateTime: () => Ul,
	ZodISODuration: () => Kl,
	ZodISOTime: () => Gl,
	ZodIntersection: () => Ad,
	ZodJWT: () => Iu,
	ZodKSUID: () => gu,
	ZodLazy: () => Df,
	ZodLiteral: () => Gd,
	ZodMAC: () => bu,
	ZodMap: () => Rd,
	ZodNaN: () => hf,
	ZodNanoID: () => ou,
	ZodNever: () => dd,
	ZodNonOptional: () => lf,
	ZodNull: () => od,
	ZodNullable: () => tf,
	ZodNumber: () => Hu,
	ZodNumberFormat: () => Q,
	ZodObject: () => bd,
	ZodOptional: () => Zd,
	ZodPipe: () => _f,
	ZodPrefault: () => sf,
	ZodPreprocess: () => Sf,
	ZodPromise: () => kf,
	ZodReadonly: () => Cf,
	ZodRecord: () => Pd,
	ZodSet: () => Bd,
	ZodString: () => Vl,
	ZodStringFormat: () => Y,
	ZodSuccess: () => df,
	ZodSymbol: () => nd,
	ZodTemplateLiteral: () => Tf,
	ZodTransform: () => Yd,
	ZodTuple: () => Md,
	ZodType: () => J,
	ZodULID: () => fu,
	ZodURL: () => tu,
	ZodUUID: () => X,
	ZodUndefined: () => id,
	ZodUnion: () => wd,
	ZodUnknown: () => ud,
	ZodVoid: () => pd,
	ZodXID: () => mu,
	ZodXor: () => Ed,
	_ZodString: () => Bl,
	_default: () => of,
	_function: () => Mf,
	any: () => ld,
	array: () => vd,
	base64: () => ku,
	base64url: () => ju,
	bigint: () => Qu,
	boolean: () => Xu,
	catch: () => mf,
	check: () => Pf,
	cidrv4: () => Tu,
	cidrv6: () => Du,
	codec: () => bf,
	creditCard: () => Fu,
	cuid: () => lu,
	cuid2: () => du,
	custom: () => Ff,
	date: () => gd,
	describe: () => Rf,
	discriminatedUnion: () => kd,
	e164: () => Nu,
	email: () => Jl,
	emoji: () => au,
	enum: () => Ud,
	exactOptional: () => ef,
	file: () => Jd,
	float32: () => Gu,
	float64: () => Ku,
	function: () => Mf,
	guid: () => Xl,
	hash: () => Vu,
	hex: () => Bu,
	hostname: () => zu,
	httpUrl: () => ru,
	instanceof: () => Bf,
	int: () => Wu,
	int32: () => qu,
	int64: () => ed,
	intersection: () => jd,
	invertCodec: () => xf,
	ipv4: () => yu,
	ipv6: () => Cu,
	json: () => Hf,
	jwt: () => Lu,
	keyof: () => yd,
	ksuid: () => _u,
	lazy: () => Of,
	literal: () => Kd,
	looseObject: () => Cd,
	looseRecord: () => Ld,
	mac: () => xu,
	map: () => zd,
	meta: () => zf,
	nan: () => gf,
	nanoid: () => su,
	nativeEnum: () => Wd,
	never: () => fd,
	nonoptional: () => uf,
	null: () => sd,
	nullable: () => nf,
	nullish: () => rf,
	number: () => Uu,
	object: () => xd,
	optional: () => Qd,
	partialRecord: () => Id,
	pipe: () => vf,
	prefault: () => cf,
	preprocess: () => Uf,
	promise: () => Af,
	readonly: () => wf,
	record: () => Fd,
	refine: () => If,
	set: () => Vd,
	strictObject: () => Sd,
	string: () => Hl,
	stringFormat: () => Ru,
	stringbool: () => Vf,
	success: () => ff,
	superRefine: () => Lf,
	symbol: () => rd,
	templateLiteral: () => Ef,
	transform: () => Xd,
	tuple: () => Nd,
	uint32: () => Ju,
	uint64: () => td,
	ulid: () => pu,
	undefined: () => ad,
	union: () => Td,
	unknown: () => $,
	url: () => nu,
	uuid: () => Zl,
	uuidv4: () => Ql,
	uuidv6: () => $l,
	uuidv7: () => eu,
	void: () => md,
	xid: () => hu,
	xor: () => Dd
});
function zl() {
	j.localeError || M(ro());
}
function q() {
	j.memoizer || M({ memoizer: eo() });
}
var J = /*@__PURE__*/ k("ZodType", (e, t) => (zl(), I.init(e, t), e.def = t, e.type = t.type, e), {
	check(...e) {
		let t = this.def;
		return this.clone(g(t, { checks: [...t.checks ?? [], ...e.map((e) => typeof e == "function" ? { _zod: {
			check: e,
			def: { check: "custom" },
			onattach: []
		} } : e)] }), { parent: !0 });
	},
	with(...e) {
		return this.check(...e);
	},
	clone(e, t) {
		return b(this, e, t);
	},
	brand() {
		return this;
	},
	register(e, t) {
		return e.add(this, t), this;
	},
	refine(e, t) {
		return this.check(If(e, t));
	},
	superRefine(e, t) {
		return this.check(Lf(e, t));
	},
	overwrite(e) {
		return this.check(/* @__PURE__ */ H(e));
	},
	optional() {
		return Qd(this);
	},
	exactOptional() {
		return ef(this);
	},
	nullable() {
		return nf(this);
	},
	nullish() {
		return Qd(nf(this));
	},
	nonoptional(e) {
		return uf(this, e);
	},
	array() {
		return vd(this);
	},
	or(e) {
		return Td([this, e]);
	},
	and(e) {
		return jd(this, e);
	},
	transform(e) {
		return vf(this, Xd(e));
	},
	default(e) {
		return of(this, e);
	},
	prefault(e) {
		return cf(this, e);
	},
	catch(e) {
		return mf(this, e);
	},
	pipe(e) {
		return vf(this, e);
	},
	readonly() {
		return wf(this);
	},
	describe(e) {
		let t = this.clone();
		return R.add(t, { description: e }), t;
	},
	meta(...e) {
		if (e.length === 0) return R.get(this);
		let t = this.clone();
		return R.add(t, e[0]), t;
	},
	isOptional() {
		return this.safeParse(void 0).success;
	},
	isNullable() {
		return this.safeParse(null).success;
	},
	apply(e, ...t) {
		return t.length === 0 ? e(this) : e(this, ...t);
	},
	get "~standard"() {
		return Ge(this, "~standard", {
			...Rr(this),
			jsonSchema: {
				input: Dc(this, "input"),
				output: Dc(this, "output")
			}
		});
	},
	set "~standard"(e) {
		E(this, "~standard", e);
	},
	parse: function e(t, n) {
		return El(this, t, n, { callee: e });
	},
	parseAsync: async function e(t, n) {
		return await Dl(this, t, n, { callee: e });
	},
	safeParse(e, t) {
		return Ol(this, e, t);
	},
	async safeParseAsync(e, t) {
		return kl(this, e, t);
	},
	get spa() {
		return this?.safeParseAsync;
	},
	set spa(e) {
		E(this, "spa", e);
	},
	encode: function e(t, n) {
		return Al(this, t, n, { callee: e });
	},
	decode: function e(t, n) {
		return jl(this, t, n, { callee: e });
	},
	encodeAsync: async function e(t, n) {
		return await Ml(this, t, n, { callee: e });
	},
	decodeAsync: async function e(t, n) {
		return await Nl(this, t, n, { callee: e });
	},
	safeEncode(e, t) {
		return Pl(this, e, t);
	},
	safeDecode(e, t) {
		return Fl(this, e, t);
	},
	async safeEncodeAsync(e, t) {
		return Il(this, e, t);
	},
	async safeDecodeAsync(e, t) {
		return Ll(this, e, t);
	},
	toJSONSchema(e) {
		return Ec(this, {})(e);
	},
	get description() {
		return R.get(this)?.description;
	},
	get _def() {
		return this._zod.def;
	}
}), Bl = /*@__PURE__*/ k("_ZodString", (e, t) => {
	zr.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => kc(e, t, n, r);
	let n = e._zod.bag;
	e.format = n.format ?? null, e.minLength = n.minimum ?? null, e.maxLength = n.maximum ?? null;
}, {
	regex(...e) {
		return this.check(/* @__PURE__ */ Ss(...e));
	},
	includes(...e) {
		return this.check(/* @__PURE__ */ Ts(...e));
	},
	startsWith(...e) {
		return this.check(/* @__PURE__ */ Es(...e));
	},
	endsWith(...e) {
		return this.check(/* @__PURE__ */ Ds(...e));
	},
	min(...e) {
		return this.check(/* @__PURE__ */ bs(...e));
	},
	max(...e) {
		return this.check(/* @__PURE__ */ ys(...e));
	},
	length(...e) {
		return this.check(/* @__PURE__ */ xs(...e));
	},
	nonempty(...e) {
		return this.check(/* @__PURE__ */ bs(1, ...e));
	},
	lowercase(e) {
		return this.check(/* @__PURE__ */ Cs(e));
	},
	uppercase(e) {
		return this.check(/* @__PURE__ */ ws(e));
	},
	trim() {
		return this.check(/* @__PURE__ */ Ms());
	},
	normalize(...e) {
		return this.check(/* @__PURE__ */ js(...e));
	},
	toLowerCase() {
		return this.check(/* @__PURE__ */ Ns());
	},
	toUpperCase() {
		return this.check(/* @__PURE__ */ Ps());
	},
	slugify() {
		return this.check(/* @__PURE__ */ Fs());
	}
}), Vl = /*@__PURE__*/ k("ZodString", (e, t) => {
	zr.init(e, t), Bl.init(e, t);
}, {
	email(e) {
		return this.check(/* @__PURE__ */ fo(ql, e));
	},
	url(e) {
		return this.check(/* @__PURE__ */ vo(tu, e));
	},
	jwt(e) {
		return this.check(/* @__PURE__ */ Fo(Iu, e));
	},
	emoji(e) {
		return this.check(/* @__PURE__ */ yo(iu, e));
	},
	guid(e) {
		return this.check(/* @__PURE__ */ po(Yl, e));
	},
	uuid(e) {
		return this.check(/* @__PURE__ */ mo(X, e));
	},
	uuidv4(e) {
		return this.check(/* @__PURE__ */ ho(X, e));
	},
	uuidv6(e) {
		return this.check(/* @__PURE__ */ go(X, e));
	},
	uuidv7(e) {
		return this.check(/* @__PURE__ */ _o(X, e));
	},
	nanoid(e) {
		return this.check(/* @__PURE__ */ bo(ou, e));
	},
	cuid(e) {
		return this.check(/* @__PURE__ */ xo(cu, e));
	},
	cuid2(e) {
		return this.check(/* @__PURE__ */ So(uu, e));
	},
	ulid(e) {
		return this.check(/* @__PURE__ */ Co(fu, e));
	},
	base64(e) {
		return this.check(/* @__PURE__ */ jo(Ou, e));
	},
	base64url(e) {
		return this.check(/* @__PURE__ */ Mo(Au, e));
	},
	xid(e) {
		return this.check(/* @__PURE__ */ wo(mu, e));
	},
	ksuid(e) {
		return this.check(/* @__PURE__ */ To(gu, e));
	},
	ipv4(e) {
		return this.check(/* @__PURE__ */ Eo(vu, e));
	},
	ipv6(e) {
		return this.check(/* @__PURE__ */ Do(Su, e));
	},
	cidrv4(e) {
		return this.check(/* @__PURE__ */ ko(wu, e));
	},
	cidrv6(e) {
		return this.check(/* @__PURE__ */ Ao(Eu, e));
	},
	e164(e) {
		return this.check(/* @__PURE__ */ No(Mu, e));
	},
	datetime(e) {
		return this.check(/* @__PURE__ */ Lo(Ul, e));
	},
	date(e) {
		return this.check(/* @__PURE__ */ Ro(Wl, e));
	},
	time(e) {
		return this.check(/* @__PURE__ */ zo(Gl, e));
	},
	duration(e) {
		return this.check(/* @__PURE__ */ Bo(Kl, e));
	}
});
function Hl(e) {
	return /* @__PURE__ */ lo(Vl, e);
}
var Y = /*@__PURE__*/ k("ZodStringFormat", (e, t) => {
	L.init(e, t), Bl.init(e, t);
}), Ul = /*@__PURE__*/ k("ZodISODateTime", (e, t) => {
	ni.init(e, t), Y.init(e, t);
}), Wl = /*@__PURE__*/ k("ZodISODate", (e, t) => {
	ri.init(e, t), Y.init(e, t);
}), Gl = /*@__PURE__*/ k("ZodISOTime", (e, t) => {
	ii.init(e, t), Y.init(e, t);
}), Kl = /*@__PURE__*/ k("ZodISODuration", (e, t) => {
	ai.init(e, t), Y.init(e, t);
}), ql = /*@__PURE__*/ k("ZodEmail", (e, t) => {
	Hr.init(e, t), Y.init(e, t);
});
function Jl(e) {
	return /* @__PURE__ */ fo(ql, e);
}
var Yl = /*@__PURE__*/ k("ZodGUID", (e, t) => {
	Br.init(e, t), Y.init(e, t);
});
function Xl(e) {
	return /* @__PURE__ */ po(Yl, e);
}
var X = /*@__PURE__*/ k("ZodUUID", (e, t) => {
	Vr.init(e, t), Y.init(e, t);
});
function Zl(e) {
	return /* @__PURE__ */ mo(X, e);
}
function Ql(e) {
	return /* @__PURE__ */ ho(X, e);
}
function $l(e) {
	return /* @__PURE__ */ go(X, e);
}
function eu(e) {
	return /* @__PURE__ */ _o(X, e);
}
var tu = /*@__PURE__*/ k("ZodURL", (e, t) => {
	Jr.init(e, t), Y.init(e, t);
});
function nu(e) {
	return /* @__PURE__ */ vo(tu, e);
}
function ru(e) {
	return /* @__PURE__ */ vo(tu, {
		protocol: On,
		hostname: Dn,
		...x(e)
	});
}
var iu = /*@__PURE__*/ k("ZodEmoji", (e, t) => {
	Yr.init(e, t), Y.init(e, t);
});
function au(e) {
	return /* @__PURE__ */ yo(iu, e);
}
var ou = /*@__PURE__*/ k("ZodNanoID", (e, t) => {
	Xr.init(e, t), Y.init(e, t);
});
function su(e) {
	return /* @__PURE__ */ bo(ou, e);
}
var cu = /*@__PURE__*/ k("ZodCUID", (e, t) => {
	Zr.init(e, t), Y.init(e, t);
});
function lu(e) {
	return /* @__PURE__ */ xo(cu, e);
}
var uu = /*@__PURE__*/ k("ZodCUID2", (e, t) => {
	Qr.init(e, t), Y.init(e, t);
});
function du(e) {
	return /* @__PURE__ */ So(uu, e);
}
var fu = /*@__PURE__*/ k("ZodULID", (e, t) => {
	$r.init(e, t), Y.init(e, t);
});
function pu(e) {
	return /* @__PURE__ */ Co(fu, e);
}
var mu = /*@__PURE__*/ k("ZodXID", (e, t) => {
	ei.init(e, t), Y.init(e, t);
});
function hu(e) {
	return /* @__PURE__ */ wo(mu, e);
}
var gu = /*@__PURE__*/ k("ZodKSUID", (e, t) => {
	ti.init(e, t), Y.init(e, t);
});
function _u(e) {
	return /* @__PURE__ */ To(gu, e);
}
var vu = /*@__PURE__*/ k("ZodIPv4", (e, t) => {
	oi.init(e, t), Y.init(e, t);
});
function yu(e) {
	return /* @__PURE__ */ Eo(vu, e);
}
var bu = /*@__PURE__*/ k("ZodMAC", (e, t) => {
	ui.init(e, t), Y.init(e, t);
});
function xu(e) {
	return /* @__PURE__ */ Oo(bu, e);
}
var Su = /*@__PURE__*/ k("ZodIPv6", (e, t) => {
	li.init(e, t), Y.init(e, t);
});
function Cu(e) {
	return /* @__PURE__ */ Do(Su, e);
}
var wu = /*@__PURE__*/ k("ZodCIDRv4", (e, t) => {
	di.init(e, t), Y.init(e, t);
});
function Tu(e) {
	return /* @__PURE__ */ ko(wu, e);
}
var Eu = /*@__PURE__*/ k("ZodCIDRv6", (e, t) => {
	pi.init(e, t), Y.init(e, t);
});
function Du(e) {
	return /* @__PURE__ */ Ao(Eu, e);
}
var Ou = /*@__PURE__*/ k("ZodBase64", (e, t) => {
	hi.init(e, t), Y.init(e, t);
});
function ku(e) {
	return /* @__PURE__ */ jo(Ou, e);
}
var Au = /*@__PURE__*/ k("ZodBase64URL", (e, t) => {
	_i.init(e, t), Y.init(e, t);
});
function ju(e) {
	return /* @__PURE__ */ Mo(Au, e);
}
var Mu = /*@__PURE__*/ k("ZodE164", (e, t) => {
	vi.init(e, t), Y.init(e, t);
});
function Nu(e) {
	return /* @__PURE__ */ No(Mu, e);
}
var Pu = /*@__PURE__*/ k("ZodCreditCard", (e, t) => {
	Si.init(e, t), Y.init(e, t);
});
function Fu(e) {
	return /* @__PURE__ */ Po(Pu, e);
}
var Iu = /*@__PURE__*/ k("ZodJWT", (e, t) => {
	wi.init(e, t), Y.init(e, t);
});
function Lu(e) {
	return /* @__PURE__ */ Fo(Iu, e);
}
var Z = /*@__PURE__*/ k("ZodCustomStringFormat", (e, t) => {
	Ti.init(e, t), Y.init(e, t);
});
function Ru(e, t, n = {}) {
	return /* @__PURE__ */ mc(Z, e, t, n);
}
function zu(e) {
	return /* @__PURE__ */ mc(Z, "hostname", En, e);
}
function Bu(e) {
	return /* @__PURE__ */ mc(Z, "hex", Kn, e);
}
function Vu(e, t) {
	let n = `${e}_${t?.enc ?? "hex"}`, r = Xt[n];
	if (!r) throw Error(`Unrecognized hash format: ${n}`);
	return /* @__PURE__ */ mc(Z, n, r, t);
}
var Hu = /*@__PURE__*/ k("ZodNumber", (e, t) => {
	Ei.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ac(e, t, n, r);
	let n = e._zod.bag;
	e.minValue = Math.max(n.minimum ?? -Infinity, n.exclusiveMinimum ?? -Infinity) ?? null, e.maxValue = Math.min(n.maximum ?? Infinity, n.exclusiveMaximum ?? Infinity) ?? null, e.isInt = (n.format ?? "").includes("int") || Number.isSafeInteger(n.multipleOf ?? .5), e.isFinite = !0, e.format = n.format ?? null;
}, {
	gt(e, t) {
		return this.check(/* @__PURE__ */ B(e, t));
	},
	gte(e, t) {
		return this.check(/* @__PURE__ */ V(e, t));
	},
	min(e, t) {
		return this.check(/* @__PURE__ */ V(e, t));
	},
	lt(e, t) {
		return this.check(/* @__PURE__ */ us(e, t));
	},
	lte(e, t) {
		return this.check(/* @__PURE__ */ z(e, t));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ z(e, t));
	},
	int(e) {
		return this.check(Wu(e));
	},
	safe(e) {
		return this.check(Wu(e));
	},
	positive(e) {
		return this.check(/* @__PURE__ */ B(0, e));
	},
	nonnegative(e) {
		return this.check(/* @__PURE__ */ V(0, e));
	},
	negative(e) {
		return this.check(/* @__PURE__ */ us(0, e));
	},
	nonpositive(e) {
		return this.check(/* @__PURE__ */ z(0, e));
	},
	multipleOf(e, t) {
		return this.check(/* @__PURE__ */ hs(e, t));
	},
	step(e, t) {
		return this.check(/* @__PURE__ */ hs(e, t));
	},
	finite() {
		return this;
	}
});
function Uu(e) {
	return /* @__PURE__ */ Vo(Hu, e);
}
var Q = /*@__PURE__*/ k("ZodNumberFormat", (e, t) => {
	Di.init(e, t), Hu.init(e, t);
});
function Wu(e) {
	return /* @__PURE__ */ Uo(Q, e);
}
function Gu(e) {
	return /* @__PURE__ */ Wo(Q, e);
}
function Ku(e) {
	return /* @__PURE__ */ Go(Q, e);
}
function qu(e) {
	return /* @__PURE__ */ Ko(Q, e);
}
function Ju(e) {
	return /* @__PURE__ */ qo(Q, e);
}
var Yu = /*@__PURE__*/ k("ZodBoolean", (e, t) => {
	Oi.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => jc(e, t, n, r);
});
function Xu(e) {
	return /* @__PURE__ */ Jo(Yu, e);
}
var Zu = /*@__PURE__*/ k("ZodBigInt", (e, t) => {
	ki.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Mc(e, t, n, r);
	let n = e._zod.bag;
	e.minValue = n.minimum ?? null, e.maxValue = n.maximum ?? null, e.format = n.format ?? null;
}, {
	gte(e, t) {
		return this.check(/* @__PURE__ */ V(e, t));
	},
	min(e, t) {
		return this.check(/* @__PURE__ */ V(e, t));
	},
	gt(e, t) {
		return this.check(/* @__PURE__ */ B(e, t));
	},
	lt(e, t) {
		return this.check(/* @__PURE__ */ us(e, t));
	},
	lte(e, t) {
		return this.check(/* @__PURE__ */ z(e, t));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ z(e, t));
	},
	positive(e) {
		return this.check(/* @__PURE__ */ B(BigInt(0), e));
	},
	negative(e) {
		return this.check(/* @__PURE__ */ us(BigInt(0), e));
	},
	nonpositive(e) {
		return this.check(/* @__PURE__ */ z(BigInt(0), e));
	},
	nonnegative(e) {
		return this.check(/* @__PURE__ */ V(BigInt(0), e));
	},
	multipleOf(e, t) {
		return this.check(/* @__PURE__ */ hs(e, t));
	}
});
function Qu(e) {
	return /* @__PURE__ */ Xo(Zu, e);
}
var $u = /*@__PURE__*/ k("ZodBigIntFormat", (e, t) => {
	Ai.init(e, t), Zu.init(e, t);
});
function ed(e) {
	return /* @__PURE__ */ Qo($u, e);
}
function td(e) {
	return /* @__PURE__ */ $o($u, e);
}
var nd = /*@__PURE__*/ k("ZodSymbol", (e, t) => {
	ji.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Nc(e, t, n, r);
});
function rd(e) {
	return /* @__PURE__ */ es(nd, e);
}
var id = /*@__PURE__*/ k("ZodUndefined", (e, t) => {
	Mi.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Fc(e, t, n, r);
});
function ad(e) {
	return /* @__PURE__ */ ts(id, e);
}
var od = /*@__PURE__*/ k("ZodNull", (e, t) => {
	Ni.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Pc(e, t, n, r);
});
function sd(e) {
	return /* @__PURE__ */ ns(od, e);
}
var cd = /*@__PURE__*/ k("ZodAny", (e, t) => {
	Pi.init(e, t), J.init(e, t), e._zod.processJSONSchema = (e, t, n) => void 0;
});
function ld() {
	return /* @__PURE__ */ rs(cd);
}
var ud = /*@__PURE__*/ k("ZodUnknown", (e, t) => {
	Fi.init(e, t), J.init(e, t), e._zod.processJSONSchema = (e, t, n) => void 0;
});
function $() {
	return /* @__PURE__ */ is(ud);
}
var dd = /*@__PURE__*/ k("ZodNever", (e, t) => {
	Ii.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Lc(e, t, n, r);
});
function fd(e) {
	return /* @__PURE__ */ as(dd, e);
}
var pd = /*@__PURE__*/ k("ZodVoid", (e, t) => {
	Li.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ic(e, t, n, r);
});
function md(e) {
	return /* @__PURE__ */ os(pd, e);
}
var hd = /*@__PURE__*/ k("ZodDate", (e, t) => {
	Ri.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Bc(e, t, n, r), e.min = (t, n) => e.check(/* @__PURE__ */ V(t, n)), e.max = (t, n) => e.check(/* @__PURE__ */ z(t, n));
	let n = e._zod.bag;
	e.minDate = n.minimum ? new Date(n.minimum) : null, e.maxDate = n.maximum ? new Date(n.maximum) : null;
});
function gd(e) {
	return /* @__PURE__ */ ss(hd, e);
}
var _d = /*@__PURE__*/ k("ZodArray", (e, t) => {
	q(), Bi.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Qc(e, t, n, r), e.element = t.element;
}, {
	min(e, t) {
		return this.check(/* @__PURE__ */ bs(e, t));
	},
	nonempty(e) {
		return this.check(/* @__PURE__ */ bs(1, e));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ ys(e, t));
	},
	length(e, t) {
		return this.check(/* @__PURE__ */ xs(e, t));
	},
	unwrap() {
		return this.element;
	}
});
function vd(e, t) {
	return /* @__PURE__ */ Is(_d, e, t);
}
function yd(e) {
	let t = e._zod.def.shape;
	return Ud(Object.keys(t));
}
var bd = /*@__PURE__*/ k("ZodObject", (e, t) => {
	q(), qi.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => el(e, t, n, r), Xe(e, "shape", (e) => e._zod.def.shape, !1);
}, {
	keyof() {
		return Ud(Object.keys(this._zod.def.shape));
	},
	catchall(e) {
		return this.clone({
			...this._zod.def,
			catchall: e
		});
	},
	passthrough() {
		return this.clone({
			...this._zod.def,
			catchall: $()
		});
	},
	loose() {
		return this.clone({
			...this._zod.def,
			catchall: $()
		});
	},
	strict() {
		return this.clone({
			...this._zod.def,
			catchall: fd()
		});
	},
	strip() {
		return this.clone({
			...this._zod.def,
			catchall: void 0
		});
	},
	extend(e) {
		return Ce(this, e);
	},
	safeExtend(e) {
		return we(this, e);
	},
	merge(e) {
		return Te(this, e);
	},
	pick(e) {
		return xe(this, e);
	},
	omit(e) {
		return Se(this, e);
	},
	partial(...e) {
		return Ee(Zd, this, e[0]);
	},
	exactPartial(...e) {
		return Ee($d, this, e[0], "exactPartial");
	},
	required(...e) {
		return De(lf, this, e[0]);
	}
});
function xd(e, t) {
	return new bd({
		type: "object",
		shape: e ?? {},
		...x(t)
	});
}
function Sd(e, t) {
	return new bd({
		type: "object",
		shape: e,
		catchall: fd(),
		...x(t)
	});
}
function Cd(e, t) {
	return new bd({
		type: "object",
		shape: e,
		catchall: $(),
		...x(t)
	});
}
var wd = /*@__PURE__*/ k("ZodUnion", (e, t) => {
	Yi.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => tl(e, t, n, r), e.options = t.options;
});
function Td(e, t) {
	return new wd({
		type: "union",
		options: e,
		...x(t)
	});
}
var Ed = /*@__PURE__*/ k("ZodXor", (e, t) => {
	wd.init(e, t), Zi.init(e, t), e._zod.processJSONSchema = (t, n, r) => tl(e, t, n, r), e.options = t.options;
});
function Dd(e, t) {
	return new Ed({
		type: "union",
		options: e,
		inclusive: !1,
		...x(t)
	});
}
var Od = /*@__PURE__*/ k("ZodDiscriminatedUnion", (e, t) => {
	wd.init(e, t), $i.init(e, t);
});
function kd(e, t, n) {
	return new Od({
		type: "union",
		options: t,
		discriminator: e,
		...x(n)
	});
}
var Ad = /*@__PURE__*/ k("ZodIntersection", (e, t) => {
	ea.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => nl(e, t, n, r);
});
function jd(e, t) {
	return new Ad({
		type: "intersection",
		left: e,
		right: t
	});
}
var Md = /*@__PURE__*/ k("ZodTuple", (e, t) => {
	q(), ra.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => rl(e, t, n, r);
}, {
	rest(e) {
		return this.clone({
			...this._zod.def,
			rest: e
		});
	},
	partial() {
		let e = this._zod.def;
		if (e.checks?.length) throw Error(".partial() cannot be used on tuple schemas containing refinements");
		return this.clone({
			...e,
			items: e.items.map((e) => new Zd({
				type: "optional",
				innerType: e
			}))
		});
	}
});
function Nd(e, t, n) {
	let r = t instanceof I;
	return new Md({
		type: "tuple",
		items: e,
		rest: r ? t : null,
		...x(r ? n : t)
	});
}
var Pd = /*@__PURE__*/ k("ZodRecord", (e, t) => {
	q(), sa.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => sl(e, t, n, r), e.keyType = t.keyType, e.valueType = t.valueType;
});
function Fd(e, t, n) {
	return !t || !t._zod ? new Pd({
		type: "record",
		keyType: Hl(),
		valueType: e,
		...x(t)
	}) : new Pd({
		type: "record",
		keyType: e,
		valueType: t,
		...x(n)
	});
}
function Id(e, t, n) {
	return new Pd({
		type: "record",
		keyType: e,
		valueType: t,
		...x(n),
		partial: !0
	});
}
function Ld(e, t, n) {
	return new Pd({
		type: "record",
		keyType: e,
		valueType: t,
		mode: "loose",
		...x(n)
	});
}
var Rd = /*@__PURE__*/ k("ZodMap", (e, t) => {
	q(), ca.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Xc(e, t, n, r), e.keyType = t.keyType, e.valueType = t.valueType, e.min = (...t) => e.check(/* @__PURE__ */ _s(...t)), e.nonempty = (t) => e.check(/* @__PURE__ */ _s(1, t)), e.max = (...t) => e.check(/* @__PURE__ */ gs(...t)), e.size = (...t) => e.check(/* @__PURE__ */ vs(...t));
});
function zd(e, t, n) {
	return new Rd({
		type: "map",
		keyType: e,
		valueType: t,
		...x(n)
	});
}
var Bd = /*@__PURE__*/ k("ZodSet", (e, t) => {
	q(), ua.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Zc(e, t, n, r), e.min = (...t) => e.check(/* @__PURE__ */ _s(...t)), e.nonempty = (t) => e.check(/* @__PURE__ */ _s(1, t)), e.max = (...t) => e.check(/* @__PURE__ */ gs(...t)), e.size = (...t) => e.check(/* @__PURE__ */ vs(...t));
});
function Vd(e, t) {
	return new Bd({
		type: "set",
		valueType: e,
		...x(t)
	});
}
var Hd = /*@__PURE__*/ k("ZodEnum", (e, t) => {
	fa.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Vc(e, t, n, r), e.enum = t.entries, e.options = Object.values(t.entries);
	let n = new Set(Object.keys(t.entries));
	e.extract = (e, r) => {
		let i = {};
		for (let r of e) if (n.has(r)) i[r] = t.entries[r];
		else throw Error(`Key ${r} not found in enum`);
		return new Hd({
			...t,
			checks: [],
			...x(r),
			entries: i
		});
	}, e.exclude = (e, r) => {
		let i = { ...t.entries };
		for (let t of e) if (n.has(t)) delete i[t];
		else throw Error(`Key ${t} not found in enum`);
		return new Hd({
			...t,
			checks: [],
			...x(r),
			entries: i
		});
	};
});
function Ud(e, t) {
	return new Hd({
		type: "enum",
		entries: Array.isArray(e) ? Object.fromEntries(e.map((e) => [e, e])) : e,
		...x(t)
	});
}
function Wd(e, t) {
	return new Hd({
		type: "enum",
		entries: e,
		...x(t)
	});
}
var Gd = /*@__PURE__*/ k("ZodLiteral", (e, t) => {
	pa.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Hc(e, t, n, r), e.values = new Set(t.values), Object.defineProperty(e, "value", { get() {
		if (t.values.length > 1) throw Error("This schema contains multiple valid literal values. Use `.values` instead.");
		return t.values[0];
	} });
});
function Kd(e, t) {
	return new Gd({
		type: "literal",
		values: Array.isArray(e) ? e : [e],
		...x(t)
	});
}
var qd = /*@__PURE__*/ k("ZodFile", (e, t) => {
	ma.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Gc(e, t, n, r), e.min = (t, n) => e.check(/* @__PURE__ */ _s(t, n)), e.max = (t, n) => e.check(/* @__PURE__ */ gs(t, n)), e.mime = (t, n) => e.check(/* @__PURE__ */ As(Array.isArray(t) ? t : [t], n));
});
function Jd(e) {
	return /* @__PURE__ */ Js(qd, e);
}
var Yd = /*@__PURE__*/ k("ZodTransform", (e, t) => {
	q(), ha.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Yc(e, t, n, r), e._zod.parse = (n, r) => {
		if (r.direction === "backward") throw new at(e.constructor.name);
		n.addIssue = (r) => {
			if (typeof r == "string") n.issues.push(Fe(r, n.value, t));
			else {
				let t = r;
				t.fatal && (t.continue = !1), t.code ??= "custom", "input" in t || (t.input = n.value), t.inst ??= e, n.issues.push(Fe(t));
			}
		};
		let i = t.transform(n.value, n);
		return i instanceof Promise ? i.then((e) => (n.value = e, n)) : (n.value = i, n);
	};
});
function Xd(e) {
	return new Yd({
		type: "transform",
		transform: e
	});
}
var Zd = /*@__PURE__*/ k("ZodOptional", (e, t) => {
	_a.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => vl(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Qd(e) {
	return new Zd({
		type: "optional",
		innerType: e
	});
}
var $d = /*@__PURE__*/ k("ZodExactOptional", (e, t) => {
	va.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => vl(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function ef(e) {
	return new $d({
		type: "optional",
		innerType: e
	});
}
var tf = /*@__PURE__*/ k("ZodNullable", (e, t) => {
	ya.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => cl(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function nf(e) {
	return new tf({
		type: "nullable",
		innerType: e
	});
}
function rf(e) {
	return Qd(nf(e));
}
var af = /*@__PURE__*/ k("ZodDefault", (e, t) => {
	ba.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => fl(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function of(e, t) {
	return new af({
		type: "default",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : de(t);
		}
	});
}
var sf = /*@__PURE__*/ k("ZodPrefault", (e, t) => {
	Sa.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => pl(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function cf(e, t) {
	return new sf({
		type: "prefault",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : de(t);
		}
	});
}
var lf = /*@__PURE__*/ k("ZodNonOptional", (e, t) => {
	Ca.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => ll(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function uf(e, t) {
	return new lf({
		type: "nonoptional",
		innerType: e,
		...x(t)
	});
}
var df = /*@__PURE__*/ k("ZodSuccess", (e, t) => {
	Ta.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Kc(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function ff(e) {
	return new df({
		type: "success",
		innerType: e
	});
}
var pf = /*@__PURE__*/ k("ZodCatch", (e, t) => {
	Da.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => ml(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function mf(e, t) {
	return new pf({
		type: "catch",
		innerType: e,
		catchValue: typeof t == "function" ? t : Qe(t)
	});
}
var hf = /*@__PURE__*/ k("ZodNaN", (e, t) => {
	Oa.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Uc(e, t, n, r);
});
function gf(e) {
	return /* @__PURE__ */ ls(hf, e);
}
var _f = /*@__PURE__*/ k("ZodPipe", (e, t) => {
	ka.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => hl(e, t, n, r), e.in = t.in, e.out = t.out;
});
function vf(e, t) {
	return new _f({
		type: "pipe",
		in: e,
		out: t
	});
}
var yf = /*@__PURE__*/ k("ZodCodec", (e, t) => {
	_f.init(e, t), ja.init(e, t);
});
function bf(e, t, n) {
	return new yf({
		type: "pipe",
		in: e,
		out: t,
		transform: n.decode,
		reverseTransform: n.encode
	});
}
function xf(e) {
	let t = e._zod.def;
	return new yf({
		type: "pipe",
		in: t.out,
		out: t.in,
		transform: t.reverseTransform,
		reverseTransform: t.transform
	});
}
var Sf = /*@__PURE__*/ k("ZodPreprocess", (e, t) => {
	_f.init(e, t), Pa.init(e, t);
}), Cf = /*@__PURE__*/ k("ZodReadonly", (e, t) => {
	Fa.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => gl(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function wf(e) {
	return new Cf({
		type: "readonly",
		innerType: e
	});
}
var Tf = /*@__PURE__*/ k("ZodTemplateLiteral", (e, t) => {
	La.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Wc(e, t, n, r);
});
function Ef(e, t) {
	return new Tf({
		type: "template_literal",
		parts: e,
		...x(t)
	});
}
var Df = /*@__PURE__*/ k("ZodLazy", (e, t) => {
	Ba.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => yl(e, t, n, r), e.unwrap = () => e._zod.def.getter();
});
function Of(e) {
	return new Df({
		type: "lazy",
		getter: e
	});
}
var kf = /*@__PURE__*/ k("ZodPromise", (e, t) => {
	za.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => _l(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Af(e) {
	return new kf({
		type: "promise",
		innerType: e
	});
}
var jf = /*@__PURE__*/ k("ZodFunction", (e, t) => {
	Ra.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => Jc(e, t, n, r);
});
function Mf(e) {
	return new jf({
		type: "function",
		input: Array.isArray(e?.input) ? Nd(e?.input) : e?.input ?? vd($()),
		output: e?.output ?? $()
	});
}
var Nf = /*@__PURE__*/ k("ZodCustom", (e, t) => {
	Va.init(e, t), J.init(e, t), e._zod.processJSONSchema = (t, n, r) => qc(e, t, n, r);
});
function Pf(e) {
	let t = new F({ check: "custom" });
	return t._zod.check = e, t;
}
function Ff(e, t) {
	return /* @__PURE__ */ sc(Nf, e ?? (() => !0), t);
}
function If(e, t = {}) {
	return /* @__PURE__ */ cc(Nf, e, t);
}
function Lf(e, t) {
	return /* @__PURE__ */ lc(e, t);
}
var Rf = dc, zf = fc;
function Bf(e, t = {}) {
	let n = new Nf({
		type: "custom",
		check: "custom",
		fn: (t) => t instanceof e,
		abort: !0,
		...x(t)
	});
	return n._zod.bag.Class = e, n._zod.check = (t) => {
		t.value instanceof e || t.issues.push({
			code: "invalid_type",
			expected: e.name,
			input: t.value,
			inst: n,
			path: [...n._zod.def.path ?? []]
		});
	}, n;
}
var Vf = (...e) => /* @__PURE__ */ pc({
	Codec: yf,
	Boolean: Yu,
	String: Vl
}, ...e);
function Hf(e) {
	let t = Of(() => Td([
		Hl(e),
		Uu(),
		Xu(),
		sd(),
		vd(t),
		Fd(Hl(), t)
	]));
	return t;
}
function Uf(e, t) {
	return new Sf({
		type: "pipe",
		in: Xd(e),
		out: t
	});
}
//#endregion
export { Sf as $, Pi as $a, g as $c, Xs as $i, Ju as $n, za as $o, sc as $r, br as $s, Ku as $t, Wl as A, Ls as Aa, Nt as Ac, Cs as Ai, Uu as An, ai as Ao, Tc as Ar, Gr as As, ld as At, Rd as B, Rs as Ba, it as Bc, hs as Bi, If as Bn, Xr as Bo, Jo as Br, Cr as Bs, Fu as Bt, Hd as C, Ys as Ca, Gt as Cc, Bo as Ci, gf as Cn, ma as Co, Tl as Cr, fi as Cs, of as Ct, Yl as D, $o as Da, Et as Dc, ac as Di, uf as Dn, li as Do, Dc as Dr, ta as Ds, sd as Dt, jf as E, qo as Ea, qt as Ec, To as Ei, fd as En, oi as Eo, xl as Er, Ci as Es, Bf as Et, Iu as F, ho as Fa, yt as Fc, ys as Fi, cf as Fn, Ba as Fo, rs as Fr, F as Fs, Xu as Ft, od as G, ao as Ga, Ze as Gc, as as Gi, Ru as Gn, Ei as Go, Zo as Gr, Nr as Gs, Rf as Gt, ou as H, fc as Ha, et as Hc, bo as Hi, Vd as Hn, Ca as Ho, uc as Hr, Er as Hs, du as Ht, gu as I, go as Ia, vt as Ic, gs as Ii, Uf as In, pa as Io, Is as Ir, _r as Is, Pf as It, Q as J, ro as Ja, Me as Jc, ps as Ji, Lf as Jn, qi as Jo, Ho as Jr, hr as Js, Jl as Jt, tf as K, R as Ka, h as Kc, ms as Ki, Vf as Kn, Di as Ko, Yo as Kr, Sr as Ks, kd as Kt, Df as L, _o as La, _t as Lc, As as Li, Af as Ln, ui as Lo, jo as Lr, Ar as Ls, Tu as Lt, Kl as M, ws as Ma, N as Mc, z as Mi, Qd as Mn, ea as Mo, gc as Mr, qr as Ms, ku as Mt, Gl as N, vo as Na, ht as Nc, Oo as Ni, Id as Nn, wi as No, W as Nr, Ir as Ns, ju as Nt, vu as O, Co as Oa, Ot as Oc, xs as Oi, nf as On, ri as Oo, Ec as Or, Ur as Os, ad as Ot, Ad as P, mo as Pa, gt as Pc, Us as Pi, vf as Pn, ti as Po, Io as Pr, Fr as Ps, Qu as Pt, sf as Q, eo as Qa, l as Qc, Vo as Qi, Nd as Qn, Pa as Qo, So as Qr, Tr as Qs, Gu as Qt, Gd as R, os as Ra, A as Rc, bs as Ri, wf as Rn, ca as Ro, Mo as Rr, mr as Rs, Du as Rt, iu as S, Ps as Sa, wt as Sc, Lo as Si, zf as Sn, va as So, kl as Sr, gi as Ss, mf as St, qd as T, Vs as Ta, Ut as Tc, Fo as Ti, Wd as Tn, Br as To, bl as Tr, ci as Ts, Mf as Tt, dd as U, so as Ua, M as Uc, Ks as Ui, Sd as Un, Ni as Uo, ko as Ur, xr as Us, Ff as Ut, hf as V, dc as Va, k as Vc, ls as Vi, Rl as Vn, Ii as Vo, tc as Vr, pr as Vs, lu as Vt, lf as W, oo as Wa, j as Wc, fs as Wi, Hl as Wn, ya as Wo, Ao as Wr, vr as Ws, gd as Wt, Zd as X, to as Xa, m as Xc, ns as Xi, Ef as Xn, ka as Xo, Po as Xr, Pr as Xs, ef as Xt, bd as Y, Ua as Ya, se as Yc, js as Yi, rd as Yn, _a as Yo, uo as Yr, gr as Ys, au as Yt, _f as Z, Ya as Za, v as Zc, Zs as Zi, Xd as Zn, Sa as Zo, xo as Zr, Mr as Zs, Jd as Zt, hd as _, ec as _a, Lt as _c, Qo as _i, Kd as _n, $i as _o, Fl as _r, Li as _s, ud as _t, Zu as a, Os as aa, It as ac, yo as ai, Wu as an, Oi as ao, Zl as ar, Ta as as, Y as at, Mu as b, ic as ba, zt as bc, Do as bi, xu as bn, Yr as bo, Il as br, Qi as bs, Ed as bt, wu as c, cc as ca, Rt as cc, Js as ci, jd as cn, Zr as co, eu as cr, ha as cs, Tf as ct, uu as d, vs as da, Wt as dc, B as di, Cu as dn, ja as do, jl as dr, $r as ds, J as dt, H as ea, kr as ec, ss as ei, Pe as el, Xl as en, Bi as eo, td as er, Fa as es, kf as et, pf as f, Fs as fa, Jt as fc, V as fi, Hf as fn, Si as fo, Nl as fr, Jr as fs, fu as ft, Z as g, pc as ga, Dt as gc, Ko as gi, Of as gn, ba as go, Dl as gr, Fi as gs, wd as gt, Nf as h, mc as ha, Tt as hc, Uo as hi, _u as hn, Ri as ho, El as hr, Yi as hs, id as ht, Au as i, ks as ia, Xt as ic, fo as ii, t as il, ru as in, Ai as io, nu as ir, L as is, Vl as it, Ul as j, is as ja, pt as jc, us as ji, xd as jn, ii as jo, U as jr, Kr as js, vd as jt, Su as k, ts as ka, jt as kc, qs as ki, rf as kn, ni as ko, vc as kr, Rr as ks, md as kt, Eu as l, Ss as la, xt as lc, Wo as li, xf as ln, Qr as lo, hu as lr, ra as ls, Yd as lt, Pu as m, lo as ma, Kt as mc, Ts as mi, yd as mn, Ti as mo, Ml as mr, Mi as ms, X as mt, _d as n, ds as na, Dr as nc, zs as ni, _e as nl, Bu as nn, _i as no, Td as nr, ua as ns, Pd as nt, $u as o, rc as oa, Bt as oc, Ds as oi, qu as on, di as oo, Ql as or, ji as os, df as ot, yf as p, Es as pa, Ht as pc, po as pi, Lu as pn, Va as po, Al as pr, Vr as ps, tu as pt, Hu as q, co as qa, b as qc, $s as qi, ff as qn, Ki as qo, cs as qr, yr as qs, Nu as qt, Ou as r, oc as ra, Bn as rc, No as ri, i as rl, zu as rn, ki as ro, $ as rr, zr as rs, Bd as rt, Yu as s, Hs as sa, Pt as sc, Gs as si, ed as sn, pi as so, $l as sr, La as ss, nd as st, cd as t, nc as ta, wr as tc, Qs as ti, de as tl, Vu as tn, hi as to, pu as tr, sa as ts, Cf as tt, cu as u, Ws as ua, Ct as uc, Go as ui, yu as un, Da as uo, Dd as ur, I as us, Md as ut, af as v, lc as va, Vt as vc, Bs as vi, Cd as vn, vi as vo, Ll as vr, ei as vs, pd as vt, $d as w, Ms as wa, Yt as wc, zo as wi, su as wn, Ra as wo, K as wr, xi as ws, Ud as wt, ql as x, Ns as xa, St as xc, Ro as xi, zd as xn, fa as xo, Ol as xr, mi as xs, Bl as xt, Od as y, es as ya, Ft as yc, Eo as yi, Ld as yn, Hr as yo, Pl as yr, Zi as ys, mu as yt, bu as z, wo as za, at as zc, _s as zi, Fd as zn, Oa as zo, Xo as zr, Or as zs, bf as zt };
