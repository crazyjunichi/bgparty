//#region packages/sdk/src/storage-context.ts
var e;
function t(t) {
	e = t;
}
function n(t, n) {
	return e ? e(t, n) : Promise.reject(/* @__PURE__ */ Error("Game storage is not connected"));
}
//#endregion
export { n, t };
