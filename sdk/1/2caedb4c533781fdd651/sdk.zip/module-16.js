import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
//#region src/shared/fx/use-reduced-motion.ts
var n = /* @__PURE__ */ e(t(), 1), r = "(prefers-reduced-motion: reduce)";
function i() {
	return (0, n.useSyncExternalStore)((e) => {
		let t = window.matchMedia(r);
		return t.addEventListener("change", e), () => t.removeEventListener("change", e);
	}, () => window.matchMedia(r).matches);
}
//#endregion
export { i as usePrefersReducedMotion };
