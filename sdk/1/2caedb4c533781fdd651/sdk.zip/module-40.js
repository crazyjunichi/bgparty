import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { playTurn as n, useSoundEdge as r } from "@bgparty/sdk/_/module-25.js";
//#region src/games/ui/phase-banner.tsx
var i = /* @__PURE__ */ e(t(), 1), a = {
	info: "bg-info-soft text-info-ink",
	warn: "bg-warn-soft text-warn-ink",
	done: "bg-done-soft text-done-ink",
	accent: "text-white"
};
function o({ tone: e, text: t, sub: o, chip: s, accent: c }) {
	return r(e === "accent", n), /* @__PURE__ */ (0, i.jsxs)("div", {
		role: "status",
		className: `game-phase-banner flex min-h-13 items-center gap-2 rounded-2xl border-2 border-ink px-3 py-1.5 ${a[e]}`,
		style: e === "accent" && c ? { background: c } : void 0,
		children: [s && /* @__PURE__ */ (0, i.jsx)("span", {
			className: "game-phase-chip flex-none rounded-lg border-2 border-ink bg-surface px-1.5 py-0.5 font-display text-xs font-extrabold text-ink",
			children: s
		}), /* @__PURE__ */ (0, i.jsxs)("div", {
			className: "tile-enter min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, i.jsx)("p", {
				className: "game-phase-text truncate text-sm font-extrabold",
				children: t
			}), o && /* @__PURE__ */ (0, i.jsx)("p", {
				className: "game-phase-sub truncate text-[11px] leading-4 font-bold opacity-80",
				children: o
			})]
		}, t)]
	});
}
//#endregion
export { o as PhaseBanner };
