import { a as e, c as t, d as n, i as r, l as i, n as a, o, r as s, s as c, t as l, u } from "@bgparty/sdk/_/chunks/protocol-yBuNV27A.js";
export { l as botAvatarOf, a as botRidOf, s as gameResultSchema, r as isAiBotRid, e as isBotRid, o as isLocalRid, c as lobbyMemberSchema, t as lobbyUpSchema, i as localAvatarOf, u as localRidOf, n as roomViewSchema };
