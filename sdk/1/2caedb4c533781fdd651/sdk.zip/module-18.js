import { a as e, i as t, n, o as r, r as i, t as a } from "@bgparty/sdk/_/chunks/i18n-BrDyMwni.js";
//#region packages/sdk/src/i18n.ts
function o(e) {
	let t = r();
	return (n, r) => t(`games.${e}.${n}`, r);
}
//#endregion
export { a as avatarNameAt, n as registerGameMessages, i as registerMessages, t as translate, o as useGameT, e as useI18nSettings, r as useT };
