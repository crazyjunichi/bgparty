import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-dom-D_kQfkJE.js";
var n = (/* @__PURE__ */ e(t())).default, r = n.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, i = n.createPortal, a = n.flushSync, o = n.preconnect, s = n.prefetchDNS, c = n.preinit, l = n.preinitModule, u = n.preload, d = n.preloadModule, f = n.requestFormReset, p = n.unstable_batchedUpdates, m = n.useFormState, h = n.useFormStatus, g = n.version;
//#endregion
export { r as __DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, i as createPortal, n as default, a as flushSync, o as preconnect, s as prefetchDNS, c as preinit, l as preinitModule, u as preload, d as preloadModule, f as requestFormReset, p as unstable_batchedUpdates, m as useFormState, h as useFormStatus, g as version };
