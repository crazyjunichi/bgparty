import { an as e, jn as t, jt as n } from "@bgparty/sdk/_/chunks/schemas-BpsPIIob.js";
//#region src/shared/drawing/strokes.ts
var r = 1e3, i = [
	"#1c1917",
	"#dc2626",
	"#ea580c",
	"#eab308",
	"#16a34a",
	"#0284c7",
	"#7c3aed",
	"#db2777"
], a = [
	8,
	16,
	32
], o = t({
	c: e().min(0).max(i.length - 1),
	w: e().min(0).max(a.length - 1),
	pts: n(e().min(0).max(r)).min(2).max(1e3).refine((e) => e.length % 2 == 0, "pts 必须是 x,y 点对")
});
//#endregion
export { r as CANVAS_SIZE, i as PALETTE, a as STROKE_WIDTHS, o as strokeSchema };
