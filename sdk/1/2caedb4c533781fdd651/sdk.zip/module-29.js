import { n as e } from "@bgparty/sdk/_/chunks/storage-context-D1XLdEh-.js";
//#region packages/sdk/src/storage.ts
function t() {
	return e("storage.read", void 0);
}
function n(t) {
	return e("storage.write", t);
}
//#endregion
export { t as readGameStorage, n as writeGameStorage };
