import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { t as n } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { t as r } from "@bgparty/sdk/_/chunks/react-three-fiber.esm-6er3L47x.js";
//#region src/shared/three/resilient-canvas.tsx
var i = /* @__PURE__ */ e(t(), 1), a = /* @__PURE__ */ e(n(), 1), o = [
	400,
	1600,
	4e3
], s = class extends i.Component {
	state = { failed: !1 };
	static getDerivedStateFromError() {
		return { failed: !0 };
	}
	componentDidCatch() {
		this.props.onFailed();
	}
	render() {
		return this.state.failed ? this.props.fallback : this.props.children;
	}
};
function c({ recoveryFallback: e = null, onRecoveryChange: t, onCreated: n, ...c }) {
	let [l, u] = (0, i.useState)(0), [d, f] = (0, i.useState)(!1), [p, m] = (0, i.useState)(null), h = (0, i.useRef)(null), g = (0, i.useRef)(!1), _ = (0, i.useRef)(0), v = (0, i.useRef)(null), y = (0, i.useRef)(null), b = (0, i.useCallback)(() => {
		v.current !== null && window.clearTimeout(v.current), v.current = null;
	}, []), x = (0, i.useCallback)(() => {
		document.hidden || v.current !== null || _.current >= o.length || (v.current = window.setTimeout(() => {
			v.current = null, _.current += 1, g.current = !1, m(null), u((e) => e + 1), f(!1);
		}, o[_.current]));
	}, []), S = (0, i.useCallback)(() => {
		g.current || (g.current = !0, h.current = null, y.current !== null && window.clearTimeout(y.current), y.current = null, f(!0), t?.(!0), x());
	}, [t, x]), C = (0, i.useCallback)((e) => {
		h.current = e, m(e), y.current !== null && window.clearTimeout(y.current), y.current = window.setTimeout(() => {
			h.current === e && (_.current = 0), y.current = null;
		}, 3e3), t?.(!1), n?.(e);
	}, [n, t]);
	return (0, i.useEffect)(() => {
		if (!p) return;
		let e = p.gl.domElement, t = (t) => {
			t.preventDefault(), h.current === p && e.isConnected && S();
		}, n = () => {
			requestAnimationFrame(() => {
				h.current === p && e.isConnected && !p.gl.getContext().isContextLost() && p.invalidate();
			});
		};
		e.addEventListener("webglcontextlost", t), e.addEventListener("webglcontextrestored", n);
		let r = requestAnimationFrame(() => {
			h.current === p && e.isConnected && p.gl.getContext().isContextLost() && S();
		});
		return () => {
			cancelAnimationFrame(r), e.removeEventListener("webglcontextlost", t), e.removeEventListener("webglcontextrestored", n);
		};
	}, [p, S]), (0, i.useEffect)(() => {
		let e = () => {
			if (document.hidden) {
				b();
				return;
			}
			if (g.current) {
				_.current >= o.length && (_.current = 0), x();
				return;
			}
			let e = h.current;
			e && requestAnimationFrame(() => {
				h.current === e && e.gl.domElement.isConnected && (e.gl.getContext().isContextLost() ? S() : e.invalidate());
			});
		};
		return document.addEventListener("visibilitychange", e), window.addEventListener("pageshow", e), window.addEventListener("focus", e), () => {
			document.removeEventListener("visibilitychange", e), window.removeEventListener("pageshow", e), window.removeEventListener("focus", e), b(), y.current !== null && window.clearTimeout(y.current);
		};
	}, [
		b,
		S,
		x
	]), d ? e : /* @__PURE__ */ (0, a.jsx)(s, {
		fallback: e,
		onFailed: S,
		children: /* @__PURE__ */ (0, a.jsx)(r, {
			...c,
			onCreated: C
		})
	}, l);
}
//#endregion
export { c as ResilientCanvas };
