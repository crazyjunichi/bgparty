import { randomIntAt as e } from "@bgparty/sdk/_/module-9.js";
//#region packages/sdk/src/core.ts
function t(e) {
	return e;
}
//#endregion
export { t as defineGame, e as randomIntAt };
