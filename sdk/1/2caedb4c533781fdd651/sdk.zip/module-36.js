import { r as e } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { AVATARS as t } from "@bgparty/sdk/_/module-1.js";
import { a as n, o as r, t as i } from "@bgparty/sdk/_/chunks/i18n-BrDyMwni.js";
import { i as a } from "@bgparty/sdk/_/chunks/icons-DzpZGOit.js";
import { t as o } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { PLAYER_COLORS as s } from "@bgparty/sdk/_/module-22.js";
import { t as c } from "@bgparty/sdk/_/chunks/protocol-yBuNV27A.js";
import { playGameOver as l, useSoundEdge as u } from "@bgparty/sdk/_/module-25.js";
import { Confetti as d } from "@bgparty/sdk/_/module-34.js";
//#region src/games/ui/game-over-screen.tsx
var f = /* @__PURE__ */ e(o(), 1);
function p() {
	return u(!0, l), null;
}
var m = [
	"🥇",
	"🥈",
	"🥉"
];
function h({ result: e, members: t, myRid: i, accent: a, onPlayAgain: o, onBackToLobby: s, renderRowExtra: c, hintCount: l }) {
	let u = r(), p = n((e) => e.locale), m = o ?? s;
	return /* @__PURE__ */ (0, f.jsxs)("div", {
		className: "relative flex h-full min-h-0 flex-col items-center gap-3",
		children: [
			/* @__PURE__ */ (0, f.jsx)(d, {}),
			/* @__PURE__ */ (0, f.jsx)("h1", {
				className: "font-display text-2xl font-extrabold",
				children: u("session.result.title")
			}),
			l !== void 0 && /* @__PURE__ */ (0, f.jsx)("p", {
				className: "-my-1 text-xs font-bold opacity-70",
				children: u("session.hint.usedCount", { n: l })
			}),
			/* @__PURE__ */ (0, f.jsx)("ol", {
				className: "flex min-h-0 w-full max-w-sm flex-1 flex-col gap-2 overflow-y-auto",
				children: e.ranking.map((n, r) => /* @__PURE__ */ (0, f.jsx)(g, {
					rank: r + 1,
					rid: n,
					result: e,
					member: t.find((e) => e.rid === n),
					myRid: i,
					accent: a,
					locale: p,
					youLabel: u("lobby.you"),
					apShareLabel: (e) => u("session.autopilot.share", { n: e }),
					children: c?.(n)
				}, n))
			}),
			m ? /* @__PURE__ */ (0, f.jsxs)("div", {
				className: "safe-b flex w-full max-w-sm flex-col gap-2 pb-1",
				children: [o && /* @__PURE__ */ (0, f.jsx)("button", {
					className: "btn-base w-full text-white",
					style: { background: a },
					onClick: o,
					children: u("session.result.playAgain")
				}), s && /* @__PURE__ */ (0, f.jsx)("button", {
					className: "btn-quiet w-full",
					onClick: s,
					children: u("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ (0, f.jsx)("p", {
				className: "safe-b pb-1 text-sm font-bold opacity-70",
				children: u("session.result.waitHost")
			})
		]
	});
}
function g({ rank: e, rid: n, result: r, member: o, myRid: l, accent: u, locale: d, youLabel: p, apShareLabel: h, children: g }) {
	let _ = r.winner.includes(n), v = s[(o?.colorIndex ?? 0) % s.length], y = o ? c(o.rid) === null ? o.name : i(d, o.avatar) : n, b = r.scores?.[n], x = r.autopilot?.[n];
	return /* @__PURE__ */ (0, f.jsxs)("li", {
		className: `rounded-xl border-3 px-2.5 py-2 ${_ ? "bg-surface" : "border-ink bg-surface shadow-[2px_2px_0_var(--color-ink)]"}`,
		style: _ ? {
			borderColor: u,
			boxShadow: `3px 3px 0 ${u}`
		} : void 0,
		children: [/* @__PURE__ */ (0, f.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, f.jsx)("span", {
					className: "w-7 flex-none text-center font-display text-lg font-extrabold",
					children: m[e - 1] ?? e
				}),
				/* @__PURE__ */ (0, f.jsxs)("span", {
					className: "relative grid size-10 flex-none place-items-center rounded-full border-2 border-ink",
					style: { backgroundColor: v.hex },
					children: [o && /* @__PURE__ */ (0, f.jsx)("img", {
						src: t[o.avatar % t.length],
						alt: "",
						draggable: !1,
						className: "size-8 object-contain"
					}), _ && /* @__PURE__ */ (0, f.jsx)("span", {
						"aria-hidden": !0,
						className: "absolute -top-2.5 -right-2.5 text-base",
						children: "👑"
					})]
				}),
				/* @__PURE__ */ (0, f.jsxs)("span", {
					className: "min-w-0 flex-1 truncate text-sm font-bold",
					children: [
						y,
						n === l && /* @__PURE__ */ (0, f.jsx)("span", {
							className: "ml-1 rounded-md bg-info-soft px-1 py-0.5 text-[10px] font-bold text-info-ink",
							children: p
						}),
						x !== void 0 && x > 0 && /* @__PURE__ */ (0, f.jsxs)("span", {
							className: "ml-1 inline-flex items-center gap-0.5 rounded-md bg-info-soft px-1 py-0.5 text-[10px] font-bold text-info-ink",
							children: [/* @__PURE__ */ (0, f.jsx)(a, { size: 10 }), h(Math.round(x * 100))]
						})
					]
				}),
				b !== void 0 && /* @__PURE__ */ (0, f.jsx)("span", {
					className: "flex-none font-mono text-base font-bold tabular-nums",
					children: b
				})
			]
		}), g]
	});
}
//#endregion
export { p as GameOverChime, h as GameOverScreen };
