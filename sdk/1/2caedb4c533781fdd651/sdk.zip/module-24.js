import { r as e, t } from "@bgparty/sdk/_/chunks/rolldown-runtime-B0aSnxlc.js";
import { t as n } from "@bgparty/sdk/_/chunks/react-CQGhINdb.js";
import { a as r, i, r as a } from "@bgparty/sdk/_/chunks/i18n-BrDyMwni.js";
import { t as o } from "@bgparty/sdk/_/chunks/jsx-runtime-m5EtjF4a.js";
import { FxAnchorsProvider as s, useFxAnchors as c } from "@bgparty/sdk/_/module-10.js";
import { usePrefersReducedMotion as l } from "@bgparty/sdk/_/module-16.js";
import { t as u } from "@bgparty/sdk/_/chunks/client-Dxrn1NRL.js";
import { t as d } from "@bgparty/sdk/_/chunks/react-dom-D_kQfkJE.js";
import { GameOverScreen as f } from "@bgparty/sdk/_/module-36.js";
import { t as p } from "@bgparty/sdk/_/chunks/storage-context-D1XLdEh-.js";
//#region src/index.css
var m = /* @__PURE__ */ e(n(), 1), h = /* @__PURE__ */ t(((e) => {
	var t = n(), r = d();
	function i(e) {
		var t = "https://react.dev/errors/" + e;
		if (1 < arguments.length) {
			t += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var n = 2; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
		}
		return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
	}
	var a = Symbol.for("react.transitional.element"), o = Symbol.for("react.portal"), s = Symbol.for("react.fragment"), c = Symbol.for("react.strict_mode"), l = Symbol.for("react.profiler"), u = Symbol.for("react.consumer"), f = Symbol.for("react.context"), p = Symbol.for("react.forward_ref"), m = Symbol.for("react.suspense"), h = Symbol.for("react.suspense_list"), g = Symbol.for("react.memo"), _ = Symbol.for("react.lazy"), v = Symbol.for("react.scope"), y = Symbol.for("react.activity"), b = Symbol.for("react.legacy_hidden"), x = Symbol.for("react.memo_cache_sentinel"), S = Symbol.for("react.view_transition"), C = Symbol.iterator;
	function w(e) {
		return typeof e != "object" || !e ? null : (e = C && e[C] || e["@@iterator"], typeof e == "function" ? e : null);
	}
	var T = Array.isArray;
	function E(e, t) {
		var n = e.length & 3, r = e.length - n, i = t;
		for (t = 0; t < r;) {
			var a = e.charCodeAt(t) & 255 | (e.charCodeAt(++t) & 255) << 8 | (e.charCodeAt(++t) & 255) << 16 | (e.charCodeAt(++t) & 255) << 24;
			++t, a = 3432918353 * (a & 65535) + ((3432918353 * (a >>> 16) & 65535) << 16) & 4294967295, a = a << 15 | a >>> 17, a = 461845907 * (a & 65535) + ((461845907 * (a >>> 16) & 65535) << 16) & 4294967295, i ^= a, i = i << 13 | i >>> 19, i = 5 * (i & 65535) + ((5 * (i >>> 16) & 65535) << 16) & 4294967295, i = (i & 65535) + 27492 + (((i >>> 16) + 58964 & 65535) << 16);
		}
		switch (a = 0, n) {
			case 3: a ^= (e.charCodeAt(t + 2) & 255) << 16;
			case 2: a ^= (e.charCodeAt(t + 1) & 255) << 8;
			case 1: a ^= e.charCodeAt(t) & 255, a = 3432918353 * (a & 65535) + ((3432918353 * (a >>> 16) & 65535) << 16) & 4294967295, a = a << 15 | a >>> 17, i ^= 461845907 * (a & 65535) + ((461845907 * (a >>> 16) & 65535) << 16) & 4294967295;
		}
		return i ^= e.length, i ^= i >>> 16, i = 2246822507 * (i & 65535) + ((2246822507 * (i >>> 16) & 65535) << 16) & 4294967295, i ^= i >>> 13, i = 3266489909 * (i & 65535) + ((3266489909 * (i >>> 16) & 65535) << 16) & 4294967295, (i ^ i >>> 16) >>> 0;
	}
	var D = Object.assign, O = Object.prototype.hasOwnProperty, k = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), A = {}, j = {};
	function ee(e) {
		return O.call(j, e) ? !0 : O.call(A, e) ? !1 : k.test(e) ? j[e] = !0 : (A[e] = !0, !1);
	}
	var M = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" ")), N = /* @__PURE__ */ new Map([
		["acceptCharset", "accept-charset"],
		["htmlFor", "for"],
		["httpEquiv", "http-equiv"],
		["crossOrigin", "crossorigin"],
		["accentHeight", "accent-height"],
		["alignmentBaseline", "alignment-baseline"],
		["arabicForm", "arabic-form"],
		["baselineShift", "baseline-shift"],
		["capHeight", "cap-height"],
		["clipPath", "clip-path"],
		["clipRule", "clip-rule"],
		["colorInterpolation", "color-interpolation"],
		["colorInterpolationFilters", "color-interpolation-filters"],
		["colorProfile", "color-profile"],
		["colorRendering", "color-rendering"],
		["dominantBaseline", "dominant-baseline"],
		["enableBackground", "enable-background"],
		["fillOpacity", "fill-opacity"],
		["fillRule", "fill-rule"],
		["floodColor", "flood-color"],
		["floodOpacity", "flood-opacity"],
		["fontFamily", "font-family"],
		["fontSize", "font-size"],
		["fontSizeAdjust", "font-size-adjust"],
		["fontStretch", "font-stretch"],
		["fontStyle", "font-style"],
		["fontVariant", "font-variant"],
		["fontWeight", "font-weight"],
		["glyphName", "glyph-name"],
		["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
		["glyphOrientationVertical", "glyph-orientation-vertical"],
		["horizAdvX", "horiz-adv-x"],
		["horizOriginX", "horiz-origin-x"],
		["imageRendering", "image-rendering"],
		["letterSpacing", "letter-spacing"],
		["lightingColor", "lighting-color"],
		["markerEnd", "marker-end"],
		["markerMid", "marker-mid"],
		["markerStart", "marker-start"],
		["overlinePosition", "overline-position"],
		["overlineThickness", "overline-thickness"],
		["paintOrder", "paint-order"],
		["panose-1", "panose-1"],
		["pointerEvents", "pointer-events"],
		["renderingIntent", "rendering-intent"],
		["shapeRendering", "shape-rendering"],
		["stopColor", "stop-color"],
		["stopOpacity", "stop-opacity"],
		["strikethroughPosition", "strikethrough-position"],
		["strikethroughThickness", "strikethrough-thickness"],
		["strokeDasharray", "stroke-dasharray"],
		["strokeDashoffset", "stroke-dashoffset"],
		["strokeLinecap", "stroke-linecap"],
		["strokeLinejoin", "stroke-linejoin"],
		["strokeMiterlimit", "stroke-miterlimit"],
		["strokeOpacity", "stroke-opacity"],
		["strokeWidth", "stroke-width"],
		["textAnchor", "text-anchor"],
		["textDecoration", "text-decoration"],
		["textRendering", "text-rendering"],
		["transformOrigin", "transform-origin"],
		["underlinePosition", "underline-position"],
		["underlineThickness", "underline-thickness"],
		["unicodeBidi", "unicode-bidi"],
		["unicodeRange", "unicode-range"],
		["unitsPerEm", "units-per-em"],
		["vAlphabetic", "v-alphabetic"],
		["vHanging", "v-hanging"],
		["vIdeographic", "v-ideographic"],
		["vMathematical", "v-mathematical"],
		["vectorEffect", "vector-effect"],
		["vertAdvY", "vert-adv-y"],
		["vertOriginX", "vert-origin-x"],
		["vertOriginY", "vert-origin-y"],
		["wordSpacing", "word-spacing"],
		["writingMode", "writing-mode"],
		["xmlnsXlink", "xmlns:xlink"],
		["xHeight", "x-height"]
	]), P = /["'&<>]/;
	function F(e) {
		if (typeof e == "boolean" || typeof e == "number" || typeof e == "bigint") return "" + e;
		e = "" + e;
		var t = P.exec(e);
		if (t) {
			var n = "", r, i = 0;
			for (r = t.index; r < e.length; r++) {
				switch (e.charCodeAt(r)) {
					case 34:
						t = "&quot;";
						break;
					case 38:
						t = "&amp;";
						break;
					case 39:
						t = "&#x27;";
						break;
					case 60:
						t = "&lt;";
						break;
					case 62:
						t = "&gt;";
						break;
					default: continue;
				}
				i !== r && (n += e.slice(i, r)), i = r + 1, n += t;
			}
			e = i === r ? n : n + e.slice(i, r);
		}
		return e;
	}
	var te = /([A-Z])/g, ne = /^ms-/, I = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
	function L(e) {
		return I.test("" + e) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : e;
	}
	var re = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, ie = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, R = {
		pending: !1,
		data: null,
		method: null,
		action: null
	}, z = ie.d;
	ie.d = {
		f: z.f,
		r: z.r,
		D: rt,
		C: it,
		L: at,
		m: ot,
		X: ct,
		S: st,
		M: lt
	};
	var ae = [], oe = null, se = /(<\/|<)(s)(cript)/gi;
	function ce(e, t, n, r) {
		return "" + t + (n === "s" ? "\\u0073" : "\\u0053") + r;
	}
	function le(e, t, n, r, i) {
		return {
			idPrefix: e === void 0 ? "" : e,
			nextFormID: 0,
			streamingFormat: 0,
			bootstrapScriptContent: n,
			bootstrapScripts: r,
			bootstrapModules: i,
			instructions: 0,
			hasBody: !1,
			hasHtml: !1,
			unknownResources: {},
			dnsResources: {},
			connectResources: {
				default: {},
				anonymous: {},
				credentials: {}
			},
			imageResources: {},
			styleResources: {},
			scriptResources: {},
			moduleUnknownResources: {},
			moduleScriptResources: {}
		};
	}
	function B(e, t, n, r) {
		return {
			insertionMode: e,
			selectedValue: t,
			tagScope: n,
			viewTransition: r
		};
	}
	function ue(e, t, n) {
		var r = e.tagScope & -25;
		switch (t) {
			case "noscript": return B(2, null, r | 1, null);
			case "select": return B(2, n.value == null ? n.defaultValue : n.value, r, null);
			case "svg": return B(4, null, r, null);
			case "picture": return B(2, null, r | 2, null);
			case "math": return B(5, null, r, null);
			case "foreignObject": return B(2, null, r, null);
			case "table": return B(6, null, r, null);
			case "thead":
			case "tbody":
			case "tfoot": return B(7, null, r, null);
			case "colgroup": return B(9, null, r, null);
			case "tr": return B(8, null, r, null);
			case "head":
				if (2 > e.insertionMode) return B(3, null, r, null);
				break;
			case "html": if (e.insertionMode === 0) return B(1, null, r, null);
		}
		return 6 <= e.insertionMode || 2 > e.insertionMode ? B(2, null, r, null) : e.tagScope === r ? e : B(e.insertionMode, e.selectedValue, r, null);
	}
	function V(e) {
		return e === null ? null : {
			update: e.update,
			enter: "none",
			exit: "none",
			share: e.update,
			name: e.autoName,
			autoName: e.autoName,
			nameIdx: 0
		};
	}
	function de(e, t) {
		return t.tagScope & 32 && (e.instructions |= 128), B(t.insertionMode, t.selectedValue, t.tagScope | 12, V(t.viewTransition));
	}
	function fe(e, t) {
		e = V(t.viewTransition);
		var n = t.tagScope | 16;
		return e !== null && e.share !== "none" && (n |= 64), B(t.insertionMode, t.selectedValue, n, e);
	}
	var pe = /* @__PURE__ */ new Map();
	function me(e, t) {
		if (typeof t != "object") throw Error(i(62));
		var n = !0, r;
		for (r in t) if (O.call(t, r)) {
			var a = t[r];
			if (a != null && typeof a != "boolean" && a !== "") {
				if (r.indexOf("--") === 0) {
					var o = F(r);
					a = F(("" + a).trim());
				} else o = pe.get(r), o === void 0 && (o = F(r.replace(te, "-$1").toLowerCase().replace(ne, "-ms-")), pe.set(r, o)), a = typeof a == "number" ? a === 0 || M.has(r) ? "" + a : a + "px" : F(("" + a).trim());
				n ? (n = !1, e.push(" style=\"", o, ":", a)) : e.push(";", o, ":", a);
			}
		}
		n || e.push("\"");
	}
	function he(e, t, n) {
		n && typeof n != "function" && typeof n != "symbol" && e.push(" ", t, "=\"\"");
	}
	function ge(e, t, n) {
		typeof n != "function" && typeof n != "symbol" && typeof n != "boolean" && e.push(" ", t, "=\"", F(n), "\"");
	}
	var _e = F("javascript:throw new Error('React form unexpectedly submitted.')");
	function ve(e, t) {
		this.push("<input type=\"hidden\""), ye(e), ge(this, "name", t), ge(this, "value", e), this.push("/>");
	}
	function ye(e) {
		if (typeof e != "string") throw Error(i(480));
	}
	function be(e, t) {
		if (typeof t.$$FORM_ACTION == "function") {
			var n = e.nextFormID++;
			e = e.idPrefix + n;
			try {
				var r = t.$$FORM_ACTION(e);
				return r && r.data?.forEach(ye), r;
			} catch (e) {
				if (typeof e == "object" && e && typeof e.then == "function") throw e;
			}
		}
		return null;
	}
	function xe(e, t, n, r, i, a, o, s) {
		var c = null;
		if (typeof r == "function") {
			var l = be(t, r);
			l === null ? (e.push(" ", "formAction", "=\"", _e, "\""), o = a = i = r = s = null, we(t, n)) : (s = l.name, r = l.action || "", i = l.encType, a = l.method, o = l.target, c = l.data);
		}
		return s != null && H(e, "name", s), r != null && H(e, "formAction", r), i != null && H(e, "formEncType", i), a != null && H(e, "formMethod", a), o != null && H(e, "formTarget", o), c;
	}
	function H(e, t, n) {
		switch (t) {
			case "className":
				ge(e, "class", n);
				break;
			case "tabIndex":
				ge(e, "tabindex", n);
				break;
			case "dir":
			case "role":
			case "viewBox":
			case "width":
			case "height":
				ge(e, t, n);
				break;
			case "style":
				me(e, n);
				break;
			case "src":
			case "href": if (n === "") break;
			case "action":
			case "formAction":
				if (n == null || typeof n == "function" || typeof n == "symbol" || typeof n == "boolean") break;
				n = L("" + n), e.push(" ", t, "=\"", F(n), "\"");
				break;
			case "defaultValue":
			case "defaultChecked":
			case "innerHTML":
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "ref": break;
			case "autoFocus":
			case "multiple":
			case "muted":
				he(e, t.toLowerCase(), n);
				break;
			case "xlinkHref":
				if (typeof n == "function" || typeof n == "symbol" || typeof n == "boolean") break;
				n = L("" + n), e.push(" ", "xlink:href", "=\"", F(n), "\"");
				break;
			case "contentEditable":
			case "spellCheck":
			case "draggable":
			case "value":
			case "autoReverse":
			case "externalResourcesRequired":
			case "focusable":
			case "preserveAlpha":
				typeof n != "function" && typeof n != "symbol" && e.push(" ", t, "=\"", F(n), "\"");
				break;
			case "inert":
			case "allowFullScreen":
			case "async":
			case "autoPlay":
			case "controls":
			case "default":
			case "defer":
			case "disabled":
			case "disablePictureInPicture":
			case "disableRemotePlayback":
			case "formNoValidate":
			case "hidden":
			case "loop":
			case "noModule":
			case "noValidate":
			case "open":
			case "playsInline":
			case "readOnly":
			case "required":
			case "reversed":
			case "scoped":
			case "seamless":
			case "itemScope":
				n && typeof n != "function" && typeof n != "symbol" && e.push(" ", t, "=\"\"");
				break;
			case "capture":
			case "download":
				!0 === n ? e.push(" ", t, "=\"\"") : !1 !== n && typeof n != "function" && typeof n != "symbol" && e.push(" ", t, "=\"", F(n), "\"");
				break;
			case "cols":
			case "rows":
			case "size":
			case "span":
				typeof n != "function" && typeof n != "symbol" && !isNaN(n) && 1 <= n && e.push(" ", t, "=\"", F(n), "\"");
				break;
			case "rowSpan":
			case "start":
				typeof n == "function" || typeof n == "symbol" || isNaN(n) || e.push(" ", t, "=\"", F(n), "\"");
				break;
			case "xlinkActuate":
				ge(e, "xlink:actuate", n);
				break;
			case "xlinkArcrole":
				ge(e, "xlink:arcrole", n);
				break;
			case "xlinkRole":
				ge(e, "xlink:role", n);
				break;
			case "xlinkShow":
				ge(e, "xlink:show", n);
				break;
			case "xlinkTitle":
				ge(e, "xlink:title", n);
				break;
			case "xlinkType":
				ge(e, "xlink:type", n);
				break;
			case "xmlBase":
				ge(e, "xml:base", n);
				break;
			case "xmlLang":
				ge(e, "xml:lang", n);
				break;
			case "xmlSpace":
				ge(e, "xml:space", n);
				break;
			default: if ((!(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (t = N.get(t) || t, ee(t))) {
				switch (typeof n) {
					case "function":
					case "symbol": return;
					case "boolean":
						var r = t.toLowerCase().slice(0, 5);
						if (r !== "data-" && r !== "aria-") return;
				}
				e.push(" ", t, "=\"", F(n), "\"");
			}
		}
	}
	function Se(e, t, n) {
		if (t != null) {
			if (n != null) throw Error(i(60));
			if (typeof t != "object" || !("__html" in t)) throw Error(i(61));
			t = t.__html, t != null && e.push("" + t);
		}
	}
	function Ce(e) {
		var n = "";
		return t.Children.forEach(e, function(e) {
			e != null && (n += e);
		}), n;
	}
	function we(e, t) {
		if (!(e.instructions & 16)) {
			e.instructions |= 16;
			var n = t.preamble, r = t.bootstrapChunks;
			(n.htmlChunks || n.headChunks) && r.length === 0 ? (r.push(t.startInlineScript), tt(r, e), r.push(">", "addEventListener(\"submit\",function(a){if(!a.defaultPrevented){var c=a.target,d=a.submitter,e=c.action,b=d;if(d){var f=d.getAttribute(\"formAction\");null!=f&&(e=f,b=null)}\"javascript:throw new Error('React form unexpectedly submitted.')\"===e&&(a.preventDefault(),b?(a=document.createElement(\"input\"),a.name=b.name,a.value=b.value,b.parentNode.insertBefore(a,b),b=new FormData(c),a.parentNode.removeChild(a)):b=new FormData(c),a=c.ownerDocument||c,(a.$$reactFormReplay=a.$$reactFormReplay||[]).push(c,d,b))}});", "<\/script>")) : r.unshift(t.startInlineScript, ">", "addEventListener(\"submit\",function(a){if(!a.defaultPrevented){var c=a.target,d=a.submitter,e=c.action,b=d;if(d){var f=d.getAttribute(\"formAction\");null!=f&&(e=f,b=null)}\"javascript:throw new Error('React form unexpectedly submitted.')\"===e&&(a.preventDefault(),b?(a=document.createElement(\"input\"),a.name=b.name,a.value=b.value,b.parentNode.insertBefore(a,b),b=new FormData(c),a.parentNode.removeChild(a)):b=new FormData(c),a=c.ownerDocument||c,(a.$$reactFormReplay=a.$$reactFormReplay||[]).push(c,d,b))}});", "<\/script>");
		}
	}
	function Te(e, t) {
		for (var n in e.push(U("link")), t) if (O.call(t, n)) {
			var r = t[n];
			if (r != null) switch (n) {
				case "children":
				case "dangerouslySetInnerHTML": throw Error(i(399, "link"));
				default: H(e, n, r);
			}
		}
		return e.push("/>"), null;
	}
	var Ee = /(<\/|<)(s)(tyle)/gi;
	function De(e, t, n, r) {
		return "" + t + (n === "s" ? "\\73 " : "\\53 ") + r;
	}
	function Oe(e, t, n) {
		for (var r in e.push(U(n)), t) if (O.call(t, r)) {
			var a = t[r];
			if (a != null) switch (r) {
				case "children":
				case "dangerouslySetInnerHTML": throw Error(i(399, n));
				default: H(e, r, a);
			}
		}
		return e.push("/>"), null;
	}
	function ke(e, t) {
		e.push(U("title"));
		var n = null, r = null, i;
		for (i in t) if (O.call(t, i)) {
			var a = t[i];
			if (a != null) switch (i) {
				case "children":
					n = a;
					break;
				case "dangerouslySetInnerHTML":
					r = a;
					break;
				default: H(e, i, a);
			}
		}
		return e.push(">"), t = Array.isArray(n) ? 2 > n.length ? n[0] : null : n, typeof t != "function" && typeof t != "symbol" && t != null && e.push(F("" + t)), Se(e, r, n), e.push(Ie("title")), null;
	}
	function Ae(e, t) {
		e.push(U("script"));
		var n = null, r = null, i;
		for (i in t) if (O.call(t, i)) {
			var a = t[i];
			if (a != null) switch (i) {
				case "children":
					n = a;
					break;
				case "dangerouslySetInnerHTML":
					r = a;
					break;
				default: H(e, i, a);
			}
		}
		return e.push(">"), Se(e, r, n), typeof n == "string" && e.push(("" + n).replace(se, ce)), e.push(Ie("script")), null;
	}
	function je(e, t, n) {
		e.push(U(n));
		var r = n = null, i;
		for (i in t) if (O.call(t, i)) {
			var a = t[i];
			if (a != null) switch (i) {
				case "children":
					n = a;
					break;
				case "dangerouslySetInnerHTML":
					r = a;
					break;
				default: H(e, i, a);
			}
		}
		return e.push(">"), Se(e, r, n), n;
	}
	function Me(e, t, n) {
		e.push(U(n));
		var r = n = null, i;
		for (i in t) if (O.call(t, i)) {
			var a = t[i];
			if (a != null) switch (i) {
				case "children":
					n = a;
					break;
				case "dangerouslySetInnerHTML":
					r = a;
					break;
				default: H(e, i, a);
			}
		}
		return e.push(">"), Se(e, r, n), typeof n == "string" ? (e.push(F(n)), null) : n;
	}
	var Ne = /^[a-zA-Z][a-zA-Z:_\.\-\d]*$/, Pe = /* @__PURE__ */ new Map();
	function U(e) {
		var t = Pe.get(e);
		if (t === void 0) {
			if (!Ne.test(e)) throw Error(i(65, e));
			t = "<" + e, Pe.set(e, t);
		}
		return t;
	}
	function W(e, t, n, r, a, o, s, c, l) {
		switch (t) {
			case "div":
			case "span":
			case "svg":
			case "path": break;
			case "a":
				e.push(U("a"));
				var u = null, d = null, f;
				for (f in n) if (O.call(n, f)) {
					var p = n[f];
					if (p != null) switch (f) {
						case "children":
							u = p;
							break;
						case "dangerouslySetInnerHTML":
							d = p;
							break;
						case "href":
							p === "" ? ge(e, "href", "") : H(e, f, p);
							break;
						default: H(e, f, p);
					}
				}
				if (e.push(">"), Se(e, d, u), typeof u == "string") {
					e.push(F(u));
					var m = null;
				} else m = u;
				return m;
			case "g":
			case "p":
			case "li": break;
			case "select":
				e.push(U("select"));
				var h = null, g = null, _;
				for (_ in n) if (O.call(n, _)) {
					var v = n[_];
					if (v != null) switch (_) {
						case "children":
							h = v;
							break;
						case "dangerouslySetInnerHTML":
							g = v;
							break;
						case "defaultValue":
						case "value": break;
						default: H(e, _, v);
					}
				}
				return e.push(">"), Se(e, g, h), h;
			case "option":
				var y = c.selectedValue;
				e.push(U("option"));
				var b = null, x = null, S = null, C = null, w;
				for (w in n) if (O.call(n, w)) {
					var E = n[w];
					if (E != null) switch (w) {
						case "children":
							b = E;
							break;
						case "selected":
							S = E;
							break;
						case "dangerouslySetInnerHTML":
							C = E;
							break;
						case "value": x = E;
						default: H(e, w, E);
					}
				}
				if (y != null) {
					var k = x === null ? Ce(b) : "" + x;
					if (T(y)) {
						for (var A = 0; A < y.length; A++) if ("" + y[A] === k) {
							e.push(" selected=\"\"");
							break;
						}
					} else "" + y === k && e.push(" selected=\"\"");
				} else S && e.push(" selected=\"\"");
				return e.push(">"), Se(e, C, b), b;
			case "textarea":
				e.push(U("textarea"));
				var j = null, M = null, N = null, P;
				for (P in n) if (O.call(n, P)) {
					var te = n[P];
					if (te != null) switch (P) {
						case "children":
							N = te;
							break;
						case "value":
							j = te;
							break;
						case "defaultValue":
							M = te;
							break;
						case "dangerouslySetInnerHTML": throw Error(i(91));
						default: H(e, P, te);
					}
				}
				if (j === null && M !== null && (j = M), e.push(">"), N != null) {
					if (j != null) throw Error(i(92));
					if (T(N)) {
						if (1 < N.length) throw Error(i(93));
						j = "" + N[0];
					}
					j = "" + N;
				}
				return typeof j == "string" && j[0] === "\n" && e.push("\n"), j !== null && e.push(F("" + j)), null;
			case "input":
				e.push(U("input"));
				var ne = null, I = null, re = null, ie = null, R = null, z = null, oe = null, se = null, ce = null, le;
				for (le in n) if (O.call(n, le)) {
					var B = n[le];
					if (B != null) switch (le) {
						case "children":
						case "dangerouslySetInnerHTML": throw Error(i(399, "input"));
						case "name":
							ne = B;
							break;
						case "formAction":
							I = B;
							break;
						case "formEncType":
							re = B;
							break;
						case "formMethod":
							ie = B;
							break;
						case "formTarget":
							R = B;
							break;
						case "defaultChecked":
							ce = B;
							break;
						case "defaultValue":
							oe = B;
							break;
						case "checked":
							se = B;
							break;
						case "value":
							z = B;
							break;
						default: H(e, le, B);
					}
				}
				var ue = xe(e, r, a, I, re, ie, R, ne);
				return se === null ? ce !== null && he(e, "checked", ce) : he(e, "checked", se), z === null ? oe !== null && H(e, "value", oe) : H(e, "value", z), e.push("/>"), ue?.forEach(ve, e), null;
			case "button":
				e.push(U("button"));
				var V = null, de = null, fe = null, pe = null, ye = null, Ne = null, Pe = null, W;
				for (W in n) if (O.call(n, W)) {
					var Fe = n[W];
					if (Fe != null) switch (W) {
						case "children":
							V = Fe;
							break;
						case "dangerouslySetInnerHTML":
							de = Fe;
							break;
						case "name":
							fe = Fe;
							break;
						case "formAction":
							pe = Fe;
							break;
						case "formEncType":
							ye = Fe;
							break;
						case "formMethod":
							Ne = Fe;
							break;
						case "formTarget":
							Pe = Fe;
							break;
						default: H(e, W, Fe);
					}
				}
				var Le = xe(e, r, a, pe, ye, Ne, Pe, fe);
				if (e.push(">"), Le?.forEach(ve, e), Se(e, de, V), typeof V == "string") {
					e.push(F(V));
					var Re = null;
				} else Re = V;
				return Re;
			case "form":
				e.push(U("form"));
				var ze = null, Be = null, Ve = null, He = null, Ue = null, We = null, Ge;
				for (Ge in n) if (O.call(n, Ge)) {
					var Ke = n[Ge];
					if (Ke != null) switch (Ge) {
						case "children":
							ze = Ke;
							break;
						case "dangerouslySetInnerHTML":
							Be = Ke;
							break;
						case "action":
							Ve = Ke;
							break;
						case "encType":
							He = Ke;
							break;
						case "method":
							Ue = Ke;
							break;
						case "target":
							We = Ke;
							break;
						default: H(e, Ge, Ke);
					}
				}
				var qe = null, Je = null;
				if (typeof Ve == "function") {
					var G = be(r, Ve);
					G === null ? (e.push(" ", "action", "=\"", _e, "\""), We = Ue = He = Ve = null, we(r, a)) : (Ve = G.action || "", He = G.encType, Ue = G.method, We = G.target, qe = G.data, Je = G.name);
				}
				if (Ve != null && H(e, "action", Ve), He != null && H(e, "encType", He), Ue != null && H(e, "method", Ue), We != null && H(e, "target", We), e.push(">"), Je !== null && (e.push("<input type=\"hidden\""), ge(e, "name", Je), e.push("/>"), qe?.forEach(ve, e)), Se(e, Be, ze), typeof ze == "string") {
					e.push(F(ze));
					var Ye = null;
				} else Ye = ze;
				return Ye;
			case "menuitem":
				for (var Xe in e.push(U("menuitem")), n) if (O.call(n, Xe)) {
					var K = n[Xe];
					if (K != null) switch (Xe) {
						case "children":
						case "dangerouslySetInnerHTML": throw Error(i(400));
						default: H(e, Xe, K);
					}
				}
				return e.push(">"), null;
			case "object":
				e.push(U("object"));
				var Ze = null, Qe = null, $e;
				for ($e in n) if (O.call(n, $e)) {
					var et = n[$e];
					if (et != null) switch ($e) {
						case "children":
							Ze = et;
							break;
						case "dangerouslySetInnerHTML":
							Qe = et;
							break;
						case "data":
							var tt = L("" + et);
							if (tt === "") break;
							e.push(" ", "data", "=\"", F(tt), "\"");
							break;
						default: H(e, $e, et);
					}
				}
				if (e.push(">"), Se(e, Qe, Ze), typeof Ze == "string") {
					e.push(F(Ze));
					var nt = null;
				} else nt = Ze;
				return nt;
			case "title":
				var q = c.tagScope & 1, J = c.tagScope & 4;
				if (c.insertionMode === 4 || q || n.itemProp != null) var rt = ke(e, n);
				else J ? rt = null : (ke(a.hoistableChunks, n), rt = void 0);
				return rt;
			case "link":
				var it = c.tagScope & 1, at = c.tagScope & 4, ot = n.rel, st = n.href, ct = n.precedence;
				if (c.insertionMode === 4 || it || n.itemProp != null || typeof ot != "string" || typeof st != "string" || st === "") {
					Te(e, n);
					var lt = null;
				} else if (n.rel === "stylesheet") {
					if (typeof ct != "string" || n.disabled != null || n.onLoad || n.onError) lt = Te(e, n);
					else {
						var ft = a.styles.get(ct), pt = r.styleResources.hasOwnProperty(st) ? r.styleResources[st] : void 0;
						if (pt !== null) {
							r.styleResources[st] = null, ft || (ft = {
								precedence: F(ct),
								rules: [],
								hrefs: [],
								sheets: /* @__PURE__ */ new Map()
							}, a.styles.set(ct, ft));
							var mt = {
								state: 0,
								props: D({}, n, {
									"data-precedence": n.precedence,
									precedence: null
								})
							};
							if (pt) {
								pt.length === 2 && ut(mt.props, pt);
								var ht = a.preloads.stylesheets.get(st);
								ht && 0 < ht.length ? ht.length = 0 : mt.state = 1;
							}
							ft.sheets.set(st, mt), s && s.stylesheets.add(mt);
						} else if (ft) {
							var gt = ft.sheets.get(st);
							gt && s && s.stylesheets.add(gt);
						}
						l && e.push("<!-- -->"), lt = null;
					}
				} else n.onLoad || n.onError ? lt = Te(e, n) : (l && e.push("<!-- -->"), lt = at ? null : Te(a.hoistableChunks, n));
				return lt;
			case "script":
				var _t = c.tagScope & 1, vt = n.async;
				if (typeof n.src != "string" || !n.src || !vt || typeof vt == "function" || typeof vt == "symbol" || n.onLoad || n.onError || c.insertionMode === 4 || _t || n.itemProp != null) var yt = Ae(e, n);
				else {
					var bt = n.src;
					if (n.type === "module") var xt = r.moduleScriptResources, St = a.preloads.moduleScripts;
					else xt = r.scriptResources, St = a.preloads.scripts;
					var Ct = xt.hasOwnProperty(bt) ? xt[bt] : void 0;
					if (Ct !== null) {
						xt[bt] = null;
						var wt = n;
						if (Ct) {
							Ct.length === 2 && (wt = D({}, n), ut(wt, Ct));
							var Tt = St.get(bt);
							Tt && (Tt.length = 0);
						}
						var Et = [];
						a.scripts.add(Et), Ae(Et, wt);
					}
					l && e.push("<!-- -->"), yt = null;
				}
				return yt;
			case "style":
				var Dt = c.tagScope & 1, Ot = n.precedence, kt = n.href, At = n.nonce;
				if (c.insertionMode === 4 || Dt || n.itemProp != null || typeof Ot != "string" || typeof kt != "string" || kt === "") {
					e.push(U("style"));
					var jt = null, Mt = null, Nt;
					for (Nt in n) if (O.call(n, Nt)) {
						var Pt = n[Nt];
						if (Pt != null) switch (Nt) {
							case "children":
								jt = Pt;
								break;
							case "dangerouslySetInnerHTML":
								Mt = Pt;
								break;
							default: H(e, Nt, Pt);
						}
					}
					e.push(">");
					var Ft = Array.isArray(jt) ? 2 > jt.length ? jt[0] : null : jt;
					typeof Ft != "function" && typeof Ft != "symbol" && Ft != null && e.push(("" + Ft).replace(Ee, De)), Se(e, Mt, jt), e.push(Ie("style"));
					var It = null;
				} else {
					var Lt = a.styles.get(Ot);
					if ((r.styleResources.hasOwnProperty(kt) ? r.styleResources[kt] : void 0) !== null) {
						r.styleResources[kt] = null, Lt || (Lt = {
							precedence: F(Ot),
							rules: [],
							hrefs: [],
							sheets: /* @__PURE__ */ new Map()
						}, a.styles.set(Ot, Lt));
						var Rt = a.nonce.style;
						if (!Rt || Rt === At) {
							Lt.hrefs.push(F(kt));
							var zt = Lt.rules, Y = null, Bt = null, Vt;
							for (Vt in n) if (O.call(n, Vt)) {
								var Ht = n[Vt];
								if (Ht != null) switch (Vt) {
									case "children":
										Y = Ht;
										break;
									case "dangerouslySetInnerHTML": Bt = Ht;
								}
							}
							var Ut = Array.isArray(Y) ? 2 > Y.length ? Y[0] : null : Y;
							typeof Ut != "function" && typeof Ut != "symbol" && Ut != null && zt.push(("" + Ut).replace(Ee, De)), Se(zt, Bt, Y);
						}
					}
					Lt && s && s.styles.add(Lt), l && e.push("<!-- -->"), It = void 0;
				}
				return It;
			case "meta":
				var Wt = c.tagScope & 1, Gt = c.tagScope & 4;
				if (c.insertionMode === 4 || Wt || n.itemProp != null) var Kt = Oe(e, n, "meta");
				else l && e.push("<!-- -->"), Kt = Gt ? null : typeof n.charSet == "string" ? Oe(a.charsetChunks, n, "meta") : n.name === "viewport" ? Oe(a.viewportChunks, n, "meta") : Oe(a.hoistableChunks, n, "meta");
				return Kt;
			case "listing":
			case "pre":
				e.push(U(t));
				var qt = null, Jt = null, Yt;
				for (Yt in n) if (O.call(n, Yt)) {
					var Xt = n[Yt];
					if (Xt != null) switch (Yt) {
						case "children":
							qt = Xt;
							break;
						case "dangerouslySetInnerHTML":
							Jt = Xt;
							break;
						default: H(e, Yt, Xt);
					}
				}
				if (e.push(">"), Jt != null) {
					if (qt != null) throw Error(i(60));
					if (typeof Jt != "object" || !("__html" in Jt)) throw Error(i(61));
					var X = Jt.__html;
					X != null && (typeof X == "string" && 0 < X.length && X[0] === "\n" ? e.push("\n", X) : e.push("" + X));
				}
				return typeof qt == "string" && qt[0] === "\n" && e.push("\n"), qt;
			case "img":
				var Zt = c.tagScope & 3, Qt = n.src, Z = n.srcSet;
				if (!(n.loading === "lazy" || !Qt && !Z || typeof Qt != "string" && Qt != null || typeof Z != "string" && Z != null || n.fetchPriority === "low" || Zt) && (typeof Qt != "string" || Qt[4] !== ":" || Qt[0] !== "d" && Qt[0] !== "D" || Qt[1] !== "a" && Qt[1] !== "A" || Qt[2] !== "t" && Qt[2] !== "T" || Qt[3] !== "a" && Qt[3] !== "A") && (typeof Z != "string" || Z[4] !== ":" || Z[0] !== "d" && Z[0] !== "D" || Z[1] !== "a" && Z[1] !== "A" || Z[2] !== "t" && Z[2] !== "T" || Z[3] !== "a" && Z[3] !== "A")) {
					s !== null && c.tagScope & 64 && (s.suspenseyImages = !0);
					var $t = typeof n.sizes == "string" ? n.sizes : void 0, en = Z ? Z + "\n" + ($t || "") : Qt, tn = a.preloads.images, nn = tn.get(en);
					if (nn) (n.fetchPriority === "high" || 10 > a.highImagePreloads.size) && (tn.delete(en), a.highImagePreloads.add(nn));
					else if (!r.imageResources.hasOwnProperty(en)) {
						r.imageResources[en] = ae;
						var rn = n.crossOrigin, an = typeof rn == "string" ? rn === "use-credentials" ? rn : "" : void 0, on = a.headers, sn;
						on && 0 < on.remainingCapacity && typeof n.srcSet != "string" && (n.fetchPriority === "high" || 500 > on.highImagePreloads.length) && (sn = dt(Qt, "image", {
							imageSrcSet: n.srcSet,
							imageSizes: n.sizes,
							crossOrigin: an,
							integrity: n.integrity,
							nonce: n.nonce,
							type: n.type,
							fetchPriority: n.fetchPriority,
							referrerPolicy: n.refererPolicy
						}), 0 <= (on.remainingCapacity -= sn.length + 2)) ? (a.resets.image[en] = ae, on.highImagePreloads && (on.highImagePreloads += ", "), on.highImagePreloads += sn) : (nn = [], Te(nn, {
							rel: "preload",
							as: "image",
							href: Z ? void 0 : Qt,
							imageSrcSet: Z,
							imageSizes: $t,
							crossOrigin: an,
							integrity: n.integrity,
							type: n.type,
							fetchPriority: n.fetchPriority,
							referrerPolicy: n.referrerPolicy
						}), n.fetchPriority === "high" || 10 > a.highImagePreloads.size ? a.highImagePreloads.add(nn) : (a.bulkPreloads.add(nn), tn.set(en, nn)));
					}
				}
				return Oe(e, n, "img");
			case "base":
			case "area":
			case "br":
			case "col":
			case "embed":
			case "hr":
			case "keygen":
			case "param":
			case "source":
			case "track":
			case "wbr": return Oe(e, n, t);
			case "annotation-xml":
			case "color-profile":
			case "font-face":
			case "font-face-src":
			case "font-face-uri":
			case "font-face-format":
			case "font-face-name":
			case "missing-glyph": break;
			case "head":
				if (2 > c.insertionMode) {
					var cn = o || a.preamble;
					if (cn.headChunks) throw Error(i(545, "`<head>`"));
					o !== null && e.push("<!--head-->"), cn.headChunks = [];
					var ln = je(cn.headChunks, n, "head");
				} else ln = Me(e, n, "head");
				return ln;
			case "body":
				if (2 > c.insertionMode) {
					var un = o || a.preamble;
					if (un.bodyChunks) throw Error(i(545, "`<body>`"));
					o !== null && e.push("<!--body-->"), un.bodyChunks = [];
					var dn = je(un.bodyChunks, n, "body");
				} else dn = Me(e, n, "body");
				return dn;
			case "html":
				if (c.insertionMode === 0) {
					var fn = o || a.preamble;
					if (fn.htmlChunks) throw Error(i(545, "`<html>`"));
					o !== null && e.push("<!--html-->"), fn.htmlChunks = [""];
					var pn = je(fn.htmlChunks, n, "html");
				} else pn = Me(e, n, "html");
				return pn;
			default: if (t.indexOf("-") !== -1) {
				e.push(U(t));
				var mn = null, hn = null, gn;
				for (gn in n) if (O.call(n, gn)) {
					var _n = n[gn];
					if (_n != null) {
						var vn = gn;
						switch (gn) {
							case "children":
								mn = _n;
								break;
							case "dangerouslySetInnerHTML":
								hn = _n;
								break;
							case "style":
								me(e, _n);
								break;
							case "suppressContentEditableWarning":
							case "suppressHydrationWarning":
							case "ref": break;
							case "className": vn = "class";
							default: if (ee(gn) && typeof _n != "function" && typeof _n != "symbol" && !1 !== _n) {
								if (!0 === _n) _n = "";
								else if (typeof _n == "object") continue;
								e.push(" ", vn, "=\"", F(_n), "\"");
							}
						}
					}
				}
				return e.push(">"), Se(e, hn, mn), mn;
			}
		}
		return Me(e, n, t);
	}
	var Fe = /* @__PURE__ */ new Map();
	function Ie(e) {
		var t = Fe.get(e);
		return t === void 0 && (t = "</" + e + ">", Fe.set(e, t)), t;
	}
	function Le(e, t) {
		e = e.preamble, e.htmlChunks === null && t.htmlChunks && (e.htmlChunks = t.htmlChunks), e.headChunks === null && t.headChunks && (e.headChunks = t.headChunks), e.bodyChunks === null && t.bodyChunks && (e.bodyChunks = t.bodyChunks);
	}
	function Re(e, t) {
		t = t.bootstrapChunks;
		for (var n = 0; n < t.length - 1; n++) e.push(t[n]);
		return n < t.length ? (n = t[n], t.length = 0, e.push(n)) : !0;
	}
	function ze(e, t, n) {
		if (e.push("<!--$?--><template id=\""), n === null) throw Error(i(395));
		return e.push(t.boundaryPrefix), t = n.toString(16), e.push(t), e.push("\"></template>");
	}
	function Be(e, t, n, r) {
		switch (n.insertionMode) {
			case 0:
			case 1:
			case 3:
			case 2: return e.push("<div hidden id=\""), e.push(t.segmentPrefix), t = r.toString(16), e.push(t), e.push("\">");
			case 4: return e.push("<svg aria-hidden=\"true\" style=\"display:none\" id=\""), e.push(t.segmentPrefix), t = r.toString(16), e.push(t), e.push("\">");
			case 5: return e.push("<math aria-hidden=\"true\" style=\"display:none\" id=\""), e.push(t.segmentPrefix), t = r.toString(16), e.push(t), e.push("\">");
			case 6: return e.push("<table hidden id=\""), e.push(t.segmentPrefix), t = r.toString(16), e.push(t), e.push("\">");
			case 7: return e.push("<table hidden><tbody id=\""), e.push(t.segmentPrefix), t = r.toString(16), e.push(t), e.push("\">");
			case 8: return e.push("<table hidden><tr id=\""), e.push(t.segmentPrefix), t = r.toString(16), e.push(t), e.push("\">");
			case 9: return e.push("<table hidden><colgroup id=\""), e.push(t.segmentPrefix), t = r.toString(16), e.push(t), e.push("\">");
			default: throw Error(i(397));
		}
	}
	function Ve(e, t) {
		switch (t.insertionMode) {
			case 0:
			case 1:
			case 3:
			case 2: return e.push("</div>");
			case 4: return e.push("</svg>");
			case 5: return e.push("</math>");
			case 6: return e.push("</table>");
			case 7: return e.push("</tbody></table>");
			case 8: return e.push("</tr></table>");
			case 9: return e.push("</colgroup></table>");
			default: throw Error(i(397));
		}
	}
	var He = /[<\u2028\u2029]/g;
	function Ue(e) {
		return JSON.stringify(e).replace(He, function(e) {
			switch (e) {
				case "<": return "\\u003c";
				case "\u2028": return "\\u2028";
				case "\u2029": return "\\u2029";
				default: throw Error("escapeJSStringsForInstructionScripts encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
			}
		});
	}
	var We = /[&><\u2028\u2029]/g;
	function Ge(e) {
		return JSON.stringify(e).replace(We, function(e) {
			switch (e) {
				case "&": return "\\u0026";
				case ">": return "\\u003e";
				case "<": return "\\u003c";
				case "\u2028": return "\\u2028";
				case "\u2029": return "\\u2029";
				default: throw Error("escapeJSObjectForInstructionScripts encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
			}
		});
	}
	var Ke = !1, qe = !0;
	function Je(e) {
		var t = e.rules, n = e.hrefs, r = 0;
		if (n.length) {
			for (this.push(oe.startInlineStyle), this.push(" media=\"not all\" data-precedence=\""), this.push(e.precedence), this.push("\" data-href=\""); r < n.length - 1; r++) this.push(n[r]), this.push(" ");
			for (this.push(n[r]), this.push("\">"), r = 0; r < t.length; r++) this.push(t[r]);
			qe = this.push("</style>"), Ke = !0, t.length = 0, n.length = 0;
		}
	}
	function G(e) {
		return e.state === 2 ? !1 : Ke = !0;
	}
	function Ye(e, t, n) {
		return Ke = !1, qe = !0, oe = n, t.styles.forEach(Je, e), oe = null, t.stylesheets.forEach(G), Ke && (n.stylesToHoist = !0), qe;
	}
	function Xe(e) {
		for (var t = 0; t < e.length; t++) this.push(e[t]);
		e.length = 0;
	}
	var K = [];
	function Ze(e) {
		Te(K, e.props);
		for (var t = 0; t < K.length; t++) this.push(K[t]);
		K.length = 0, e.state = 2;
	}
	function Qe(e) {
		var t = 0 < e.sheets.size;
		e.sheets.forEach(Ze, this), e.sheets.clear();
		var n = e.rules, r = e.hrefs;
		if (!t || r.length) {
			if (this.push(oe.startInlineStyle), this.push(" data-precedence=\""), this.push(e.precedence), e = 0, r.length) {
				for (this.push("\" data-href=\""); e < r.length - 1; e++) this.push(r[e]), this.push(" ");
				this.push(r[e]);
			}
			for (this.push("\">"), e = 0; e < n.length; e++) this.push(n[e]);
			this.push("</style>"), n.length = 0, r.length = 0;
		}
	}
	function $e(e) {
		if (e.state === 0) {
			e.state = 1;
			var t = e.props;
			for (Te(K, {
				rel: "preload",
				as: "style",
				href: e.props.href,
				crossOrigin: t.crossOrigin,
				fetchPriority: t.fetchPriority,
				integrity: t.integrity,
				media: t.media,
				hrefLang: t.hrefLang,
				referrerPolicy: t.referrerPolicy
			}), e = 0; e < K.length; e++) this.push(K[e]);
			K.length = 0;
		}
	}
	function et(e) {
		e.sheets.forEach($e, this), e.sheets.clear();
	}
	function tt(e, t) {
		!(t.instructions & 32) && (t.instructions |= 32, e.push(" id=\"", F("_" + t.idPrefix + "R_"), "\""));
	}
	function nt(e, t) {
		e.push("[");
		var n = "[";
		t.stylesheets.forEach(function(t) {
			if (t.state !== 2) {
				if (t.state === 3) e.push(n), t = Ge("" + t.props.href), e.push(t), e.push("]"), n = ",[";
				else {
					e.push(n);
					var r = t.props["data-precedence"], a = t.props, o = L("" + t.props.href);
					for (var s in o = Ge(o), e.push(o), r = "" + r, e.push(","), r = Ge(r), e.push(r), a) if (O.call(a, s) && (r = a[s], r != null)) switch (s) {
						case "href":
						case "rel":
						case "precedence":
						case "data-precedence": break;
						case "children":
						case "dangerouslySetInnerHTML": throw Error(i(399, "link"));
						default: q(e, s, r);
					}
					e.push("]"), n = ",[", t.state = 3;
				}
			}
		}), e.push("]");
	}
	function q(e, t, n) {
		var r = t.toLowerCase();
		switch (typeof n) {
			case "function":
			case "symbol": return;
		}
		switch (t) {
			case "innerHTML":
			case "dangerouslySetInnerHTML":
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "style":
			case "ref": return;
			case "className":
				r = "class", t = "" + n;
				break;
			case "hidden":
				if (!1 === n) return;
				t = "";
				break;
			case "src":
			case "href":
				n = L(n), t = "" + n;
				break;
			default:
				if (2 < t.length && (t[0] === "o" || t[0] === "O") && (t[1] === "n" || t[1] === "N") || !ee(t)) return;
				t = "" + n;
		}
		e.push(","), r = Ge(r), e.push(r), e.push(","), r = Ge(t), e.push(r);
	}
	function J() {
		return {
			styles: /* @__PURE__ */ new Set(),
			stylesheets: /* @__PURE__ */ new Set(),
			suspenseyImages: !1
		};
	}
	function rt(e) {
		var t = Pn || null;
		if (t) {
			var n = t.resumableState, r = t.renderState;
			if (typeof e == "string" && e) {
				if (!n.dnsResources.hasOwnProperty(e)) {
					n.dnsResources[e] = null, n = r.headers;
					var i, a;
					(a = n && 0 < n.remainingCapacity) && (a = (i = "<" + ("" + e).replace(ft, pt) + ">; rel=dns-prefetch", 0 <= (n.remainingCapacity -= i.length + 2))), a ? (r.resets.dns[e] = null, n.preconnects && (n.preconnects += ", "), n.preconnects += i) : (i = [], Te(i, {
						href: e,
						rel: "dns-prefetch"
					}), r.preconnects.add(i));
				}
				Or(t);
			}
		} else z.D(e);
	}
	function it(e, t) {
		var n = Pn || null;
		if (n) {
			var r = n.resumableState, i = n.renderState;
			if (typeof e == "string" && e) {
				var a = t === "use-credentials" ? "credentials" : typeof t == "string" ? "anonymous" : "default";
				if (!r.connectResources[a].hasOwnProperty(e)) {
					r.connectResources[a][e] = null, r = i.headers;
					var o, s;
					if (s = r && 0 < r.remainingCapacity) {
						if (s = "<" + ("" + e).replace(ft, pt) + ">; rel=preconnect", typeof t == "string") {
							var c = ("" + t).replace(mt, ht);
							s += "; crossorigin=\"" + c + "\"";
						}
						s = (o = s, 0 <= (r.remainingCapacity -= o.length + 2));
					}
					s ? (i.resets.connect[a][e] = null, r.preconnects && (r.preconnects += ", "), r.preconnects += o) : (a = [], Te(a, {
						rel: "preconnect",
						href: e,
						crossOrigin: t
					}), i.preconnects.add(a));
				}
				Or(n);
			}
		} else z.C(e, t);
	}
	function at(e, t, n) {
		var r = Pn || null;
		if (r) {
			var i = r.resumableState, a = r.renderState;
			if (t && e) {
				switch (t) {
					case "image":
						if (n) var o = n.imageSrcSet, s = n.imageSizes, c = n.fetchPriority;
						var l = o ? o + "\n" + (s || "") : e;
						if (i.imageResources.hasOwnProperty(l)) return;
						i.imageResources[l] = ae, i = a.headers;
						var u;
						i && 0 < i.remainingCapacity && typeof o != "string" && c === "high" && (u = dt(e, t, n), 0 <= (i.remainingCapacity -= u.length + 2)) ? (a.resets.image[l] = ae, i.highImagePreloads && (i.highImagePreloads += ", "), i.highImagePreloads += u) : (i = [], Te(i, D({
							rel: "preload",
							href: o ? void 0 : e,
							as: t
						}, n)), c === "high" ? a.highImagePreloads.add(i) : (a.bulkPreloads.add(i), a.preloads.images.set(l, i)));
						break;
					case "style":
						if (i.styleResources.hasOwnProperty(e)) return;
						o = [], Te(o, D({
							rel: "preload",
							href: e,
							as: t
						}, n)), i.styleResources[e] = !n || typeof n.crossOrigin != "string" && typeof n.integrity != "string" ? ae : [n.crossOrigin, n.integrity], a.preloads.stylesheets.set(e, o), a.bulkPreloads.add(o);
						break;
					case "script":
						if (i.scriptResources.hasOwnProperty(e)) return;
						o = [], a.preloads.scripts.set(e, o), a.bulkPreloads.add(o), Te(o, D({
							rel: "preload",
							href: e,
							as: t
						}, n)), i.scriptResources[e] = !n || typeof n.crossOrigin != "string" && typeof n.integrity != "string" ? ae : [n.crossOrigin, n.integrity];
						break;
					default:
						if (i.unknownResources.hasOwnProperty(t)) {
							if (o = i.unknownResources[t], o.hasOwnProperty(e)) return;
						} else o = {}, i.unknownResources[t] = o;
						if (o[e] = ae, (i = a.headers) && 0 < i.remainingCapacity && t === "font" && (l = dt(e, t, n), 0 <= (i.remainingCapacity -= l.length + 2))) a.resets.font[e] = ae, i.fontPreloads && (i.fontPreloads += ", "), i.fontPreloads += l;
						else switch (i = [], e = D({
							rel: "preload",
							href: e,
							as: t
						}, n), Te(i, e), t) {
							case "font":
								a.fontPreloads.add(i);
								break;
							default: a.bulkPreloads.add(i);
						}
				}
				Or(r);
			}
		} else z.L(e, t, n);
	}
	function ot(e, t) {
		var n = Pn || null;
		if (n) {
			var r = n.resumableState, i = n.renderState;
			if (e) {
				var a = t && typeof t.as == "string" ? t.as : "script";
				switch (a) {
					case "script":
						if (r.moduleScriptResources.hasOwnProperty(e)) return;
						a = [], r.moduleScriptResources[e] = !t || typeof t.crossOrigin != "string" && typeof t.integrity != "string" ? ae : [t.crossOrigin, t.integrity], i.preloads.moduleScripts.set(e, a);
						break;
					default:
						if (r.moduleUnknownResources.hasOwnProperty(a)) {
							var o = r.unknownResources[a];
							if (o.hasOwnProperty(e)) return;
						} else o = {}, r.moduleUnknownResources[a] = o;
						a = [], o[e] = ae;
				}
				Te(a, D({
					rel: "modulepreload",
					href: e
				}, t)), i.bulkPreloads.add(a), Or(n);
			}
		} else z.m(e, t);
	}
	function st(e, t, n) {
		var r = Pn || null;
		if (r) {
			var i = r.resumableState, a = r.renderState;
			if (e) {
				t ||= "default";
				var o = a.styles.get(t), s = i.styleResources.hasOwnProperty(e) ? i.styleResources[e] : void 0;
				s !== null && (i.styleResources[e] = null, o || (o = {
					precedence: F(t),
					rules: [],
					hrefs: [],
					sheets: /* @__PURE__ */ new Map()
				}, a.styles.set(t, o)), t = {
					state: 0,
					props: D({
						rel: "stylesheet",
						href: e,
						"data-precedence": t
					}, n)
				}, s && (s.length === 2 && ut(t.props, s), (a = a.preloads.stylesheets.get(e)) && 0 < a.length ? a.length = 0 : t.state = 1), o.sheets.set(e, t), Or(r));
			}
		} else z.S(e, t, n);
	}
	function ct(e, t) {
		var n = Pn || null;
		if (n) {
			var r = n.resumableState, i = n.renderState;
			if (e) {
				var a = r.scriptResources.hasOwnProperty(e) ? r.scriptResources[e] : void 0;
				a !== null && (r.scriptResources[e] = null, t = D({
					src: e,
					async: !0
				}, t), a && (a.length === 2 && ut(t, a), e = i.preloads.scripts.get(e)) && (e.length = 0), e = [], i.scripts.add(e), Ae(e, t), Or(n));
			}
		} else z.X(e, t);
	}
	function lt(e, t) {
		var n = Pn || null;
		if (n) {
			var r = n.resumableState, i = n.renderState;
			if (e) {
				var a = r.moduleScriptResources.hasOwnProperty(e) ? r.moduleScriptResources[e] : void 0;
				a !== null && (r.moduleScriptResources[e] = null, t = D({
					src: e,
					type: "module",
					async: !0
				}, t), a && (a.length === 2 && ut(t, a), e = i.preloads.moduleScripts.get(e)) && (e.length = 0), e = [], i.scripts.add(e), Ae(e, t), Or(n));
			}
		} else z.M(e, t);
	}
	function ut(e, t) {
		e.crossOrigin ??= t[0], e.integrity ??= t[1];
	}
	function dt(e, t, n) {
		for (var r in e = ("" + e).replace(ft, pt), t = ("" + t).replace(mt, ht), t = "<" + e + ">; rel=preload; as=\"" + t + "\"", n) O.call(n, r) && (e = n[r], typeof e == "string" && (t += "; " + r.toLowerCase() + "=\"" + ("" + e).replace(mt, ht) + "\""));
		return t;
	}
	var ft = /[<>\r\n]/g;
	function pt(e) {
		switch (e) {
			case "<": return "%3C";
			case ">": return "%3E";
			case "\n": return "%0A";
			case "\r": return "%0D";
			default: throw Error("escapeLinkHrefForHeaderContextReplacer encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
		}
	}
	var mt = /["';,\r\n]/g;
	function ht(e) {
		switch (e) {
			case "\"": return "%22";
			case "'": return "%27";
			case ";": return "%3B";
			case ",": return "%2C";
			case "\n": return "%0A";
			case "\r": return "%0D";
			default: throw Error("escapeStringForLinkHeaderQuotedParamValueContextReplacer encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
		}
	}
	function gt(e) {
		this.styles.add(e);
	}
	function _t(e) {
		this.stylesheets.add(e);
	}
	function vt(e, t) {
		t.styles.forEach(gt, e), t.stylesheets.forEach(_t, e), t.suspenseyImages && (e.suspenseyImages = !0);
	}
	function yt(e, t) {
		var n = e.idPrefix, r = [], i = e.bootstrapScriptContent, a = e.bootstrapScripts, o = e.bootstrapModules;
		i !== void 0 && (r.push("<script"), tt(r, e), r.push(">", ("" + i).replace(se, ce), "<\/script>")), i = n + "P:";
		var s = n + "S:";
		n += "B:";
		var c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Set(), p = /* @__PURE__ */ new Set(), m = /* @__PURE__ */ new Set(), h = {
			images: /* @__PURE__ */ new Map(),
			stylesheets: /* @__PURE__ */ new Map(),
			scripts: /* @__PURE__ */ new Map(),
			moduleScripts: /* @__PURE__ */ new Map()
		};
		if (a !== void 0) for (var g = 0; g < a.length; g++) {
			var _ = a[g], v, y = void 0, b = void 0, x = {
				rel: "preload",
				as: "script",
				fetchPriority: "low",
				nonce: void 0
			};
			typeof _ == "string" ? x.href = v = _ : (x.href = v = _.src, x.integrity = b = typeof _.integrity == "string" ? _.integrity : void 0, x.crossOrigin = y = typeof _ == "string" || _.crossOrigin == null ? void 0 : _.crossOrigin === "use-credentials" ? "use-credentials" : ""), _ = e;
			var S = v;
			_.scriptResources[S] = null, _.moduleScriptResources[S] = null, _ = [], Te(_, x), f.add(_), r.push("<script src=\"", F(v), "\""), typeof b == "string" && r.push(" integrity=\"", F(b), "\""), typeof y == "string" && r.push(" crossorigin=\"", F(y), "\""), tt(r, e), r.push(" async=\"\"><\/script>");
		}
		if (o !== void 0) for (a = 0; a < o.length; a++) x = o[a], y = v = void 0, b = {
			rel: "modulepreload",
			fetchPriority: "low",
			nonce: void 0
		}, typeof x == "string" ? b.href = g = x : (b.href = g = x.src, b.integrity = y = typeof x.integrity == "string" ? x.integrity : void 0, b.crossOrigin = v = typeof x == "string" || x.crossOrigin == null ? void 0 : x.crossOrigin === "use-credentials" ? "use-credentials" : ""), x = e, _ = g, x.scriptResources[_] = null, x.moduleScriptResources[_] = null, x = [], Te(x, b), f.add(x), r.push("<script type=\"module\" src=\"", F(g), "\""), typeof y == "string" && r.push(" integrity=\"", F(y), "\""), typeof v == "string" && r.push(" crossorigin=\"", F(v), "\""), tt(r, e), r.push(" async=\"\"><\/script>");
		return {
			placeholderPrefix: i,
			segmentPrefix: s,
			boundaryPrefix: n,
			startInlineScript: "<script",
			startInlineStyle: "<style",
			preamble: {
				htmlChunks: null,
				headChunks: null,
				bodyChunks: null
			},
			externalRuntimeScript: null,
			bootstrapChunks: r,
			importMapChunks: [],
			onHeaders: void 0,
			headers: null,
			resets: {
				font: {},
				dns: {},
				connect: {
					default: {},
					anonymous: {},
					credentials: {}
				},
				image: {},
				style: {}
			},
			charsetChunks: [],
			viewportChunks: [],
			hoistableChunks: [],
			preconnects: c,
			fontPreloads: l,
			highImagePreloads: u,
			styles: d,
			bootstrapScripts: f,
			scripts: p,
			bulkPreloads: m,
			preloads: h,
			nonce: {
				script: void 0,
				style: void 0
			},
			stylesToHoist: !1,
			generateStaticMarkup: t
		};
	}
	function bt(e, t, n, r) {
		return n.generateStaticMarkup ? (e.push(F(t)), !1) : (t === "" ? e = r : (r && e.push("<!-- -->"), e.push(F(t)), e = !0), e);
	}
	function xt(e, t, n, r) {
		t.generateStaticMarkup || n && r && e.push("<!-- -->");
	}
	var St = Function.prototype.bind, Ct = Symbol.for("react.client.reference");
	function wt(e) {
		if (e == null) return null;
		if (typeof e == "function") return e.$$typeof === Ct ? null : e.displayName || e.name || null;
		if (typeof e == "string") return e;
		switch (e) {
			case s: return "Fragment";
			case l: return "Profiler";
			case c: return "StrictMode";
			case m: return "Suspense";
			case h: return "SuspenseList";
			case y: return "Activity";
		}
		if (typeof e == "object") switch (e.$$typeof) {
			case o: return "Portal";
			case f: return e.displayName || "Context";
			case u: return (e._context.displayName || "Context") + ".Consumer";
			case p:
				var t = e.render;
				return e = e.displayName, e ||= (e = t.displayName || t.name || "", e === "" ? "ForwardRef" : "ForwardRef(" + e + ")"), e;
			case g: return t = e.displayName || null, t === null ? wt(e.type) || "Memo" : t;
			case _:
				t = e._payload, e = e._init;
				try {
					return wt(e(t));
				} catch {}
		}
		return null;
	}
	var Tt = {}, Et = null;
	function Dt(e, t) {
		if (e !== t) {
			e.context._currentValue2 = e.parentValue, e = e.parent;
			var n = t.parent;
			if (e === null) {
				if (n !== null) throw Error(i(401));
			} else {
				if (n === null) throw Error(i(401));
				Dt(e, n);
			}
			t.context._currentValue2 = t.value;
		}
	}
	function Ot(e) {
		e.context._currentValue2 = e.parentValue, e = e.parent, e !== null && Ot(e);
	}
	function kt(e) {
		var t = e.parent;
		t !== null && kt(t), e.context._currentValue2 = e.value;
	}
	function At(e, t) {
		if (e.context._currentValue2 = e.parentValue, e = e.parent, e === null) throw Error(i(402));
		e.depth === t.depth ? Dt(e, t) : At(e, t);
	}
	function jt(e, t) {
		var n = t.parent;
		if (n === null) throw Error(i(402));
		e.depth === n.depth ? Dt(e, n) : jt(e, n), t.context._currentValue2 = t.value;
	}
	function Mt(e) {
		var t = Et;
		t !== e && (t === null ? kt(e) : e === null ? Ot(t) : t.depth === e.depth ? Dt(t, e) : t.depth > e.depth ? At(t, e) : jt(t, e), Et = e);
	}
	var Nt = {
		enqueueSetState: function(e, t) {
			e = e._reactInternals, e.queue !== null && e.queue.push(t);
		},
		enqueueReplaceState: function(e, t) {
			e = e._reactInternals, e.replace = !0, e.queue = [t];
		},
		enqueueForceUpdate: function() {}
	}, Pt = {
		id: 1,
		overflow: ""
	};
	function Ft(e, t, n) {
		var r = e.id;
		e = e.overflow;
		var i = 32 - It(r) - 1;
		r &= ~(1 << i), n += 1;
		var a = 32 - It(t) + i;
		if (30 < a) {
			var o = i - i % 5;
			return a = (r & (1 << o) - 1).toString(32), r >>= o, i -= o, {
				id: 1 << 32 - It(t) + i | n << i | r,
				overflow: a + e
			};
		}
		return {
			id: 1 << a | n << i | r,
			overflow: e
		};
	}
	var It = Math.clz32 ? Math.clz32 : zt, Lt = Math.log, Rt = Math.LN2;
	function zt(e) {
		return e >>>= 0, e === 0 ? 32 : 31 - (Lt(e) / Rt | 0) | 0;
	}
	function Y() {}
	var Bt = Error(i(460));
	function Vt(e, t, n) {
		switch (n = e[n], n === void 0 ? e.push(t) : n !== t && (t.then(Y, Y), t = n), t.status) {
			case "fulfilled": return t.value;
			case "rejected": throw t.reason;
			default:
				switch (typeof t.status == "string" ? t.then(Y, Y) : (e = t, e.status = "pending", e.then(function(e) {
					if (t.status === "pending") {
						var n = t;
						n.status = "fulfilled", n.value = e;
					}
				}, function(e) {
					if (t.status === "pending") {
						var n = t;
						n.status = "rejected", n.reason = e;
					}
				})), t.status) {
					case "fulfilled": return t.value;
					case "rejected": throw t.reason;
				}
				throw Ht = t, Bt;
		}
	}
	var Ht = null;
	function Ut() {
		if (Ht === null) throw Error(i(459));
		var e = Ht;
		return Ht = null, e;
	}
	function Wt(e, t) {
		return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t;
	}
	var Gt = typeof Object.is == "function" ? Object.is : Wt, Kt = null, qt = null, Jt = null, Yt = null, Xt = null, X = null, Zt = !1, Qt = !1, Z = 0, $t = 0, en = -1, tn = 0, nn = null, rn = null, an = 0;
	function on() {
		if (Kt === null) throw Error(i(321));
		return Kt;
	}
	function sn() {
		if (0 < an) throw Error(i(312));
		return {
			memoizedState: null,
			queue: null,
			next: null
		};
	}
	function cn() {
		return X === null ? Xt === null ? (Zt = !1, Xt = X = sn()) : (Zt = !0, X = Xt) : X.next === null ? (Zt = !1, X = X.next = sn()) : (Zt = !0, X = X.next), X;
	}
	function ln() {
		var e = nn;
		return nn = null, e;
	}
	function un() {
		Yt = Jt = qt = Kt = null, Qt = !1, Xt = null, an = 0, X = rn = null;
	}
	function dn(e, t) {
		return typeof t == "function" ? t(e) : t;
	}
	function fn(e, t, n) {
		if (Kt = on(), X = cn(), Zt) {
			var r = X.queue;
			if (t = r.dispatch, rn !== null && (n = rn.get(r), n !== void 0)) {
				rn.delete(r), r = X.memoizedState;
				do
					r = e(r, n.action), n = n.next;
				while (n !== null);
				return X.memoizedState = r, [r, t];
			}
			return [X.memoizedState, t];
		}
		return e = e === dn ? typeof t == "function" ? t() : t : n === void 0 ? t : n(t), X.memoizedState = e, e = X.queue = {
			last: null,
			dispatch: null
		}, e = e.dispatch = mn.bind(null, Kt, e), [X.memoizedState, e];
	}
	function pn(e, t) {
		if (Kt = on(), X = cn(), t = t === void 0 ? null : t, X !== null) {
			var n = X.memoizedState;
			if (n !== null && t !== null) {
				var r = n[1];
				a: if (r === null) r = !1;
				else {
					for (var i = 0; i < r.length && i < t.length; i++) if (!Gt(t[i], r[i])) {
						r = !1;
						break a;
					}
					r = !0;
				}
				if (r) return n[0];
			}
		}
		return e = e(), X.memoizedState = [e, t], e;
	}
	function mn(e, t, n) {
		if (25 <= an) throw Error(i(301));
		if (e === Kt) {
			if (Qt = !0, e = {
				action: n,
				next: null
			}, rn === null && (rn = /* @__PURE__ */ new Map()), n = rn.get(t), n === void 0) rn.set(t, e);
			else {
				for (t = n; t.next !== null;) t = t.next;
				t.next = e;
			}
		}
	}
	function hn() {
		throw Error(i(440));
	}
	function gn() {
		throw Error(i(394));
	}
	function _n() {
		throw Error(i(479));
	}
	function vn(e, t, n) {
		on();
		var r = $t++, i = Jt;
		if (typeof e.$$FORM_ACTION == "function") {
			var a = null, o = Yt;
			i = i.formState;
			var s = e.$$IS_SIGNATURE_EQUAL;
			if (i !== null && typeof s == "function") {
				var c = i[1];
				s.call(e, i[2], i[3]) && (a = n === void 0 ? "k" + E(JSON.stringify([
					o,
					null,
					r
				]), 0) : "p" + n, c === a && (en = r, t = i[0]));
			}
			var l = e.bind(null, t);
			return e = function(e) {
				l(e);
			}, typeof l.$$FORM_ACTION == "function" && (e.$$FORM_ACTION = function(e) {
				e = l.$$FORM_ACTION(e), n !== void 0 && (n += "", e.action = n);
				var t = e.data;
				return t && (a === null && (a = n === void 0 ? "k" + E(JSON.stringify([
					o,
					null,
					r
				]), 0) : "p" + n), t.append("$ACTION_KEY", a)), e;
			}), [
				t,
				e,
				!1
			];
		}
		var u = e.bind(null, t);
		return [
			t,
			function(e) {
				u(e);
			},
			!1
		];
	}
	function yn(e) {
		var t = tn;
		return tn += 1, nn === null && (nn = []), Vt(nn, e, t);
	}
	function bn() {
		throw Error(i(393));
	}
	var xn = {
		readContext: function(e) {
			return e._currentValue2;
		},
		use: function(e) {
			if (typeof e == "object" && e) {
				if (typeof e.then == "function") return yn(e);
				if (e.$$typeof === f) return e._currentValue2;
			}
			throw Error(i(438, String(e)));
		},
		useContext: function(e) {
			return on(), e._currentValue2;
		},
		useMemo: pn,
		useReducer: fn,
		useRef: function(e) {
			Kt = on(), X = cn();
			var t = X.memoizedState;
			return t === null ? (e = { current: e }, X.memoizedState = e) : t;
		},
		useState: function(e) {
			return fn(dn, e);
		},
		useInsertionEffect: Y,
		useLayoutEffect: Y,
		useCallback: function(e, t) {
			return pn(function() {
				return e;
			}, t);
		},
		useImperativeHandle: Y,
		useEffect: Y,
		useDebugValue: Y,
		useDeferredValue: function(e, t) {
			return on(), t === void 0 ? e : t;
		},
		useTransition: function() {
			return on(), [!1, gn];
		},
		useId: function() {
			var e = qt.treeContext, t = e.overflow;
			e = e.id, e = (e & ~(1 << 32 - It(e) - 1)).toString(32) + t;
			var n = Sn;
			if (n === null) throw Error(i(404));
			return t = Z++, e = "_" + n.idPrefix + "R_" + e, 0 < t && (e += "H" + t.toString(32)), e + "_";
		},
		useSyncExternalStore: function(e, t, n) {
			if (n === void 0) throw Error(i(407));
			return n();
		},
		useOptimistic: function(e) {
			return on(), [e, _n];
		},
		useActionState: vn,
		useFormState: vn,
		useHostTransitionStatus: function() {
			return on(), R;
		},
		useMemoCache: function(e) {
			for (var t = Array(e), n = 0; n < e; n++) t[n] = x;
			return t;
		},
		useCacheRefresh: function() {
			return bn;
		},
		useEffectEvent: function() {
			return hn;
		}
	}, Sn = null, Cn = {
		getCacheForType: function() {
			throw Error(i(248));
		},
		cacheSignal: function() {
			throw Error(i(248));
		}
	}, wn, Tn;
	function En(e) {
		if (wn === void 0) try {
			throw Error();
		} catch (e) {
			var t = e.stack.trim().match(/\n( *(at )?)/);
			wn = t && t[1] || "", Tn = -1 < e.stack.indexOf("\n    at") ? " (<anonymous>)" : -1 < e.stack.indexOf("@") ? "@unknown:0:0" : "";
		}
		return "\n" + wn + e + Tn;
	}
	var Dn = !1;
	function On(e, t) {
		if (!e || Dn) return "";
		Dn = !0;
		var n = Error.prepareStackTrace;
		Error.prepareStackTrace = void 0;
		try {
			var r = { DetermineComponentFrameRoot: function() {
				try {
					if (t) {
						var n = function() {
							throw Error();
						};
						if (Object.defineProperty(n.prototype, "props", { set: function() {
							throw Error();
						} }), typeof Reflect == "object" && Reflect.construct) {
							try {
								Reflect.construct(n, []);
							} catch (e) {
								var r = e;
							}
							Reflect.construct(e, [], n);
						} else {
							try {
								n.call();
							} catch (e) {
								r = e;
							}
							e.call(n.prototype);
						}
					} else {
						try {
							throw Error();
						} catch (e) {
							r = e;
						}
						(n = e()) && typeof n.catch == "function" && n.catch(function() {});
					}
				} catch (e) {
					if (e && r && typeof e.stack == "string") return [e.stack, r.stack];
				}
				return [null, null];
			} };
			r.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
			var i = Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot, "name");
			i && i.configurable && Object.defineProperty(r.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
			var a = r.DetermineComponentFrameRoot(), o = a[0], s = a[1];
			if (o && s) {
				var c = o.split("\n"), l = s.split("\n");
				for (i = r = 0; r < c.length && !c[r].includes("DetermineComponentFrameRoot");) r++;
				for (; i < l.length && !l[i].includes("DetermineComponentFrameRoot");) i++;
				if (r === c.length || i === l.length) for (r = c.length - 1, i = l.length - 1; 1 <= r && 0 <= i && c[r] !== l[i];) i--;
				for (; 1 <= r && 0 <= i; r--, i--) if (c[r] !== l[i]) {
					if (r !== 1 || i !== 1) do
						if (r--, i--, 0 > i || c[r] !== l[i]) {
							var u = "\n" + c[r].replace(" at new ", " at ");
							return e.displayName && u.includes("<anonymous>") && (u = u.replace("<anonymous>", e.displayName)), u;
						}
					while (1 <= r && 0 <= i);
					break;
				}
			}
		} finally {
			Dn = !1, Error.prepareStackTrace = n;
		}
		return (n = e ? e.displayName || e.name : "") ? En(n) : "";
	}
	function kn(e) {
		if (typeof e == "string") return En(e);
		if (typeof e == "function") return e.prototype && e.prototype.isReactComponent ? On(e, !0) : On(e, !1);
		if (typeof e == "object" && e) {
			switch (e.$$typeof) {
				case p: return On(e.render, !1);
				case g: return On(e.type, !1);
				case _:
					var t = e, n = t._payload;
					t = t._init;
					try {
						e = t(n);
					} catch {
						return En("Lazy");
					}
					return kn(e);
			}
			if (typeof e.name == "string") {
				a: {
					n = e.name, t = e.env;
					var r = e.debugLocation;
					if (r != null && (e = Error.prepareStackTrace, Error.prepareStackTrace = void 0, r = r.stack, Error.prepareStackTrace = e, r.startsWith("Error: react-stack-top-frame\n") && (r = r.slice(29)), e = r.indexOf("\n"), e !== -1 && (r = r.slice(e + 1)), e = r.indexOf("react_stack_bottom_frame"), e !== -1 && (e = r.lastIndexOf("\n", e)), e = e === -1 ? "" : r = r.slice(0, e), r = e.lastIndexOf("\n"), e = r === -1 ? e : e.slice(r + 1), e.indexOf(n) !== -1)) {
						n = "\n" + e;
						break a;
					}
					n = En(n + (t ? " [" + t + "]" : ""));
				}
				return n;
			}
		}
		switch (e) {
			case h: return En("SuspenseList");
			case m: return En("Suspense");
		}
		return "";
	}
	function An(e, t) {
		return (500 < t.byteSize || !1) && t.contentPreamble === null;
	}
	function jn(e) {
		if (typeof e == "object" && e && typeof e.environmentName == "string") {
			var t = e.environmentName;
			e = [e].slice(0), typeof e[0] == "string" ? e.splice(0, 1, "[%s] " + e[0], " " + t + " ") : e.splice(0, 0, "[%s]", " " + t + " "), e.unshift(console), t = St.apply(console.error, e), t();
		} else console.error(e);
		return null;
	}
	function Mn(e, t, n, r, i, a, o, s, c, l, u) {
		var d = /* @__PURE__ */ new Set();
		this.destination = null, this.flushScheduled = !1, this.resumableState = e, this.renderState = t, this.rootFormatContext = n, this.progressiveChunkSize = r === void 0 ? 12800 : r, this.status = 10, this.fatalError = null, this.pendingRootTasks = this.allPendingTasks = this.nextSegmentId = 0, this.completedPreambleSegments = this.completedRootSegment = null, this.byteSize = 0, this.abortableTasks = d, this.pingedTasks = [], this.clientRenderedBoundaries = [], this.completedBoundaries = [], this.partialBoundaries = [], this.trackedPostpones = null, this.onError = i === void 0 ? jn : i, this.onPostpone = l === void 0 ? Y : l, this.onAllReady = a === void 0 ? Y : a, this.onShellReady = o === void 0 ? Y : o, this.onShellError = s === void 0 ? Y : s, this.onFatalError = c === void 0 ? Y : c, this.formState = u === void 0 ? null : u;
	}
	function Nn(e, t, n, r, i, a, o, s, c, l, u, d) {
		return t = new Mn(t, n, r, i, a, o, s, c, l, u, d), n = zn(t, 0, null, r, !1, !1), n.parentFlushed = !0, e = Ln(t, null, e, -1, null, n, null, null, t.abortableTasks, null, r, null, Pt, null, null), Bn(e), t.pingedTasks.push(e), t;
	}
	var Pn = null;
	function Fn(e, t) {
		e.pingedTasks.push(t), e.pingedTasks.length === 1 && (e.flushScheduled = e.destination !== null, gr(e));
	}
	function In(e, t, n, r, i) {
		return n = {
			status: 0,
			rootSegmentID: -1,
			parentFlushed: !1,
			pendingTasks: 0,
			row: t,
			completedSegments: [],
			byteSize: 0,
			fallbackAbortableTasks: n,
			errorDigest: null,
			contentState: J(),
			fallbackState: J(),
			contentPreamble: r,
			fallbackPreamble: i,
			trackedContentKeyPath: null,
			trackedFallbackNode: null
		}, t !== null && (t.pendingTasks++, r = t.boundaries, r !== null && (e.allPendingTasks++, n.pendingTasks++, r.push(n)), e = t.inheritedHoistables, e !== null && vt(n.contentState, e)), n;
	}
	function Ln(e, t, n, r, i, a, o, s, c, l, u, d, f, p, m) {
		e.allPendingTasks++, i === null ? e.pendingRootTasks++ : i.pendingTasks++, p !== null && p.pendingTasks++;
		var h = {
			replay: null,
			node: n,
			childIndex: r,
			ping: function() {
				return Fn(e, h);
			},
			blockedBoundary: i,
			blockedSegment: a,
			blockedPreamble: o,
			hoistableState: s,
			abortSet: c,
			keyPath: l,
			formatContext: u,
			context: d,
			treeContext: f,
			row: p,
			componentStack: m,
			thenableState: t
		};
		return c.add(h), h;
	}
	function Rn(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
		e.allPendingTasks++, a === null ? e.pendingRootTasks++ : a.pendingTasks++, f !== null && f.pendingTasks++, n.pendingTasks++;
		var m = {
			replay: n,
			node: r,
			childIndex: i,
			ping: function() {
				return Fn(e, m);
			},
			blockedBoundary: a,
			blockedSegment: null,
			blockedPreamble: null,
			hoistableState: o,
			abortSet: s,
			keyPath: c,
			formatContext: l,
			context: u,
			treeContext: d,
			row: f,
			componentStack: p,
			thenableState: t
		};
		return s.add(m), m;
	}
	function zn(e, t, n, r, i, a) {
		return {
			status: 0,
			parentFlushed: !1,
			id: -1,
			index: t,
			chunks: [],
			children: [],
			preambleChildren: [],
			parentFormatContext: r,
			boundary: n,
			lastPushedText: i,
			textEmbedded: a
		};
	}
	function Bn(e) {
		var t = e.node;
		if (typeof t == "object" && t) switch (t.$$typeof) {
			case a: e.componentStack = {
				parent: e.componentStack,
				type: t.type
			};
		}
	}
	function Vn(e) {
		return e === null ? null : {
			parent: e.parent,
			type: "Suspense Fallback"
		};
	}
	function Hn(e) {
		var t = {};
		return e && Object.defineProperty(t, "componentStack", {
			configurable: !0,
			enumerable: !0,
			get: function() {
				try {
					var n = "", r = e;
					do
						n += kn(r.type), r = r.parent;
					while (r);
					var i = n;
				} catch (e) {
					i = "\nError generating stack: " + e.message + "\n" + e.stack;
				}
				return Object.defineProperty(t, "componentStack", { value: i }), i;
			}
		}), t;
	}
	function Un(e, t, n) {
		if (e = e.onError, t = e(t, n), t == null || typeof t == "string") return t;
	}
	function Wn(e, t) {
		var n = e.onShellError, r = e.onFatalError;
		n(t), r(t), e.destination === null ? (e.status = 13, e.fatalError = t) : (e.status = 14, e.destination.destroy(t));
	}
	function Q(e, t) {
		Gn(e, t.next, t.hoistables);
	}
	function Gn(e, t, n) {
		for (; t !== null;) {
			n !== null && (vt(t.hoistables, n), t.inheritedHoistables = n);
			var r = t.boundaries;
			if (r !== null) {
				t.boundaries = null;
				for (var i = 0; i < r.length; i++) {
					var a = r[i];
					n !== null && vt(a.contentState, n), hr(e, a, null, null);
				}
			}
			if (t.pendingTasks--, 0 < t.pendingTasks) break;
			n = t.hoistables, t = t.next;
		}
	}
	function Kn(e, t) {
		var n = t.boundaries;
		if (n !== null && t.pendingTasks === n.length) {
			for (var r = !0, i = 0; i < n.length; i++) {
				var a = n[i];
				if (a.pendingTasks !== 1 || a.parentFlushed || An(e, a)) {
					r = !1;
					break;
				}
			}
			r && Gn(e, t, t.hoistables);
		}
	}
	function qn(e) {
		var t = {
			pendingTasks: 1,
			boundaries: null,
			hoistables: J(),
			inheritedHoistables: null,
			together: !1,
			next: null
		};
		return e !== null && 0 < e.pendingTasks && (t.pendingTasks++, t.boundaries = [], e.next = t), t;
	}
	function Jn(e, t, n, r, i) {
		var a = t.keyPath, o = t.treeContext, s = t.row;
		t.keyPath = n, n = r.length;
		var c = null;
		if (t.replay !== null) {
			var l = t.replay.slots;
			if (typeof l == "object" && l) for (var u = 0; u < n; u++) {
				var d = i !== "backwards" && i !== "unstable_legacy-backwards" ? u : n - 1 - u, f = r[d];
				t.row = c = qn(c), t.treeContext = Ft(o, n, d);
				var p = l[d];
				typeof p == "number" ? (Qn(e, t, p, f, d), delete l[d]) : sr(e, t, f, d), --c.pendingTasks === 0 && Q(e, c);
			}
			else for (l = 0; l < n; l++) u = i !== "backwards" && i !== "unstable_legacy-backwards" ? l : n - 1 - l, d = r[u], t.row = c = qn(c), t.treeContext = Ft(o, n, u), sr(e, t, d, u), --c.pendingTasks === 0 && Q(e, c);
		} else if (i !== "backwards" && i !== "unstable_legacy-backwards") for (i = 0; i < n; i++) l = r[i], t.row = c = qn(c), t.treeContext = Ft(o, n, i), sr(e, t, l, i), --c.pendingTasks === 0 && Q(e, c);
		else {
			for (i = t.blockedSegment, l = i.children.length, u = i.chunks.length, d = n - 1; 0 <= d; d--) {
				f = r[d], t.row = c = qn(c), t.treeContext = Ft(o, n, d), p = zn(e, u, null, t.formatContext, d !== 0 || i.lastPushedText, !0), i.children.splice(l, 0, p), t.blockedSegment = p;
				try {
					sr(e, t, f, d), xt(p.chunks, e.renderState, p.lastPushedText, p.textEmbedded), p.status = 1, --c.pendingTasks === 0 && Q(e, c);
				} catch (t) {
					throw p.status = e.status === 12 ? 3 : 4, t;
				}
			}
			t.blockedSegment = i, i.lastPushedText = !1;
		}
		s !== null && c !== null && 0 < c.pendingTasks && (s.pendingTasks++, c.next = s), t.treeContext = o, t.row = s, t.keyPath = a;
	}
	function Yn(e, t, n, r, i, a) {
		var o = t.thenableState;
		for (t.thenableState = null, Kt = {}, qt = t, Jt = e, Yt = n, $t = Z = 0, en = -1, tn = 0, nn = o, e = r(i, a); Qt;) Qt = !1, $t = Z = 0, en = -1, tn = 0, an += 1, X = null, e = r(i, a);
		return un(), e;
	}
	function Xn(e, t, n, r, i, a, o) {
		var s = !1;
		if (a !== 0 && e.formState !== null) {
			var c = t.blockedSegment;
			if (c !== null) {
				s = !0, c = c.chunks;
				for (var l = 0; l < a; l++) l === o ? c.push("<!--F!-->") : c.push("<!--F-->");
			}
		}
		a = t.keyPath, t.keyPath = n, i ? (n = t.treeContext, t.treeContext = Ft(n, 1, 0), sr(e, t, r, -1), t.treeContext = n) : s ? sr(e, t, r, -1) : $n(e, t, r, -1), t.keyPath = a;
	}
	function Zn(e, t, n, r, a, o) {
		if (typeof r == "function") {
			if (r.prototype && r.prototype.isReactComponent) {
				var d = a;
				if ("ref" in a) for (var x in d = {}, a) x !== "ref" && (d[x] = a[x]);
				var C = r.defaultProps;
				if (C) for (var E in d === a && (d = D({}, d, a)), C) d[E] === void 0 && (d[E] = C[E]);
				a = d, d = Tt, C = r.contextType, typeof C == "object" && C && (d = C._currentValue2), d = new r(a, d);
				var O = d.state === void 0 ? null : d.state;
				if (d.updater = Nt, d.props = a, d.state = O, C = {
					queue: [],
					replace: !1
				}, d._reactInternals = C, o = r.contextType, d.context = typeof o == "object" && o ? o._currentValue2 : Tt, o = r.getDerivedStateFromProps, typeof o == "function" && (o = o(a, O), O = o == null ? O : D({}, O, o), d.state = O), typeof r.getDerivedStateFromProps != "function" && typeof d.getSnapshotBeforeUpdate != "function" && (typeof d.UNSAFE_componentWillMount == "function" || typeof d.componentWillMount == "function")) {
					if (r = d.state, typeof d.componentWillMount == "function" && d.componentWillMount(), typeof d.UNSAFE_componentWillMount == "function" && d.UNSAFE_componentWillMount(), r !== d.state && Nt.enqueueReplaceState(d, d.state, null), C.queue !== null && 0 < C.queue.length) {
						if (r = C.queue, o = C.replace, C.queue = null, C.replace = !1, o && r.length === 1) d.state = r[0];
						else {
							for (C = o ? r[0] : d.state, O = !0, o = +!!o; o < r.length; o++) E = r[o], E = typeof E == "function" ? E.call(d, C, a, void 0) : E, E != null && (O ? (O = !1, C = D({}, C, E)) : D(C, E));
							d.state = C;
						}
					} else C.queue = null;
				}
				if (r = d.render(), e.status === 12) throw null;
				a = t.keyPath, t.keyPath = n, $n(e, t, r, -1), t.keyPath = a;
			} else {
				if (r = Yn(e, t, n, r, a, void 0), e.status === 12) throw null;
				Xn(e, t, n, r, Z !== 0, $t, en);
			}
		} else if (typeof r == "string") {
			if (d = t.blockedSegment, d === null) d = a.children, C = t.formatContext, O = t.keyPath, t.formatContext = ue(C, r, a), t.keyPath = n, sr(e, t, d, -1), t.formatContext = C, t.keyPath = O;
			else {
				if (O = W(d.chunks, r, a, e.resumableState, e.renderState, t.blockedPreamble, t.hoistableState, t.formatContext, d.lastPushedText), d.lastPushedText = !1, C = t.formatContext, o = t.keyPath, t.keyPath = n, (t.formatContext = ue(C, r, a)).insertionMode === 3) {
					n = zn(e, 0, null, t.formatContext, !1, !1), d.preambleChildren.push(n), t.blockedSegment = n;
					try {
						n.status = 6, sr(e, t, O, -1), xt(n.chunks, e.renderState, n.lastPushedText, n.textEmbedded), n.status = 1;
					} finally {
						t.blockedSegment = d;
					}
				} else sr(e, t, O, -1);
				t.formatContext = C, t.keyPath = o;
				a: {
					switch (t = d.chunks, e = e.resumableState, r) {
						case "title":
						case "style":
						case "script":
						case "area":
						case "base":
						case "br":
						case "col":
						case "embed":
						case "hr":
						case "img":
						case "input":
						case "keygen":
						case "link":
						case "meta":
						case "param":
						case "source":
						case "track":
						case "wbr": break a;
						case "body":
							if (1 >= C.insertionMode) {
								e.hasBody = !0;
								break a;
							}
							break;
						case "html":
							if (C.insertionMode === 0) {
								e.hasHtml = !0;
								break a;
							}
							break;
						case "head": if (1 >= C.insertionMode) break a;
					}
					t.push(Ie(r));
				}
				d.lastPushedText = !1;
			}
		} else {
			switch (r) {
				case b:
				case c:
				case l:
				case s:
					r = t.keyPath, t.keyPath = n, $n(e, t, a.children, -1), t.keyPath = r;
					return;
				case y:
					r = t.blockedSegment, r === null ? a.mode !== "hidden" && (r = t.keyPath, t.keyPath = n, sr(e, t, a.children, -1), t.keyPath = r) : a.mode !== "hidden" && (e.renderState.generateStaticMarkup || r.chunks.push("<!--&-->"), r.lastPushedText = !1, d = t.keyPath, t.keyPath = n, sr(e, t, a.children, -1), t.keyPath = d, e.renderState.generateStaticMarkup || r.chunks.push("<!--/&-->"), r.lastPushedText = !1);
					return;
				case h:
					a: {
						if (r = a.children, a = a.revealOrder, a === "forwards" || a === "backwards" || a === "unstable_legacy-backwards") {
							if (T(r)) {
								Jn(e, t, n, r, a);
								break a;
							}
							if ((d = w(r)) && (d = d.call(r))) {
								if (C = d.next(), !C.done) {
									do
										C = d.next();
									while (!C.done);
									Jn(e, t, n, r, a);
								}
								break a;
							}
						}
						a === "together" ? (a = t.keyPath, d = t.row, C = t.row = qn(null), C.boundaries = [], C.together = !0, t.keyPath = n, $n(e, t, r, -1), --C.pendingTasks === 0 && Q(e, C), t.keyPath = a, t.row = d, d !== null && 0 < C.pendingTasks && (d.pendingTasks++, C.next = d)) : (a = t.keyPath, t.keyPath = n, $n(e, t, r, -1), t.keyPath = a);
					}
					return;
				case S:
				case v: throw Error(i(343));
				case m:
					a: if (t.replay !== null) {
						r = t.keyPath, d = t.formatContext, C = t.row, t.keyPath = n, t.formatContext = fe(e.resumableState, d), t.row = null, n = a.children;
						try {
							sr(e, t, n, -1);
						} finally {
							t.keyPath = r, t.formatContext = d, t.row = C;
						}
					} else {
						r = t.keyPath, o = t.formatContext;
						var k = t.row, A = t.blockedBoundary;
						E = t.blockedPreamble;
						var j = t.hoistableState;
						x = t.blockedSegment;
						var ee = a.fallback;
						a = a.children;
						var M = /* @__PURE__ */ new Set(), N = In(e, t.row, M, null, null);
						e.trackedPostpones !== null && (N.trackedContentKeyPath = n);
						var P = zn(e, x.chunks.length, N, t.formatContext, !1, !1);
						x.children.push(P), x.lastPushedText = !1;
						var F = zn(e, 0, null, t.formatContext, !1, !1);
						if (F.parentFlushed = !0, e.trackedPostpones !== null) {
							d = t.componentStack, C = [
								n[0],
								"Suspense Fallback",
								n[2]
							], O = [
								C[1],
								C[2],
								[],
								null
							], e.trackedPostpones.workingMap.set(C, O), N.trackedFallbackNode = O, t.blockedSegment = P, t.blockedPreamble = N.fallbackPreamble, t.keyPath = C, t.formatContext = de(e.resumableState, o), t.componentStack = Vn(d), P.status = 6;
							try {
								sr(e, t, ee, -1), xt(P.chunks, e.renderState, P.lastPushedText, P.textEmbedded), P.status = 1;
							} catch (t) {
								throw P.status = e.status === 12 ? 3 : 4, t;
							} finally {
								t.blockedSegment = x, t.blockedPreamble = E, t.keyPath = r, t.formatContext = o;
							}
							t = Ln(e, null, a, -1, N, F, N.contentPreamble, N.contentState, t.abortSet, n, fe(e.resumableState, t.formatContext), t.context, t.treeContext, null, d), Bn(t), e.pingedTasks.push(t);
						} else {
							t.blockedBoundary = N, t.blockedPreamble = N.contentPreamble, t.hoistableState = N.contentState, t.blockedSegment = F, t.keyPath = n, t.formatContext = fe(e.resumableState, o), t.row = null, F.status = 6;
							try {
								if (sr(e, t, a, -1), xt(F.chunks, e.renderState, F.lastPushedText, F.textEmbedded), F.status = 1, mr(N, F), N.pendingTasks === 0 && N.status === 0) {
									if (N.status = 1, !An(e, N)) {
										k !== null && --k.pendingTasks === 0 && Q(e, k), e.pendingRootTasks === 0 && t.blockedPreamble && yr(e);
										break a;
									}
								} else k !== null && k.together && Kn(e, k);
							} catch (n) {
								N.status = 4, e.status === 12 ? (F.status = 3, d = e.fatalError) : (F.status = 4, d = n), C = Hn(t.componentStack), O = Un(e, d, C), N.errorDigest = O, ir(e, N);
							} finally {
								t.blockedBoundary = A, t.blockedPreamble = E, t.hoistableState = j, t.blockedSegment = x, t.keyPath = r, t.formatContext = o, t.row = k;
							}
							t = Ln(e, null, ee, -1, A, P, N.fallbackPreamble, N.fallbackState, M, [
								n[0],
								"Suspense Fallback",
								n[2]
							], de(e.resumableState, t.formatContext), t.context, t.treeContext, t.row, Vn(t.componentStack)), Bn(t), e.pingedTasks.push(t);
						}
					}
					return;
			}
			if (typeof r == "object" && r) switch (r.$$typeof) {
				case p:
					if ("ref" in a) for (ee in d = {}, a) ee !== "ref" && (d[ee] = a[ee]);
					else d = a;
					r = Yn(e, t, n, r.render, d, o), Xn(e, t, n, r, Z !== 0, $t, en);
					return;
				case g:
					Zn(e, t, n, r.type, a, o);
					return;
				case f:
					if (C = a.children, d = t.keyPath, a = a.value, O = r._currentValue2, r._currentValue2 = a, o = Et, Et = r = {
						parent: o,
						depth: o === null ? 0 : o.depth + 1,
						context: r,
						parentValue: O,
						value: a
					}, t.context = r, t.keyPath = n, $n(e, t, C, -1), e = Et, e === null) throw Error(i(403));
					e.context._currentValue2 = e.parentValue, e = Et = e.parent, t.context = e, t.keyPath = d;
					return;
				case u:
					a = a.children, r = a(r._context._currentValue2), a = t.keyPath, t.keyPath = n, $n(e, t, r, -1), t.keyPath = a;
					return;
				case _:
					if (d = r._init, r = d(r._payload), e.status === 12) throw null;
					Zn(e, t, n, r, a, o);
					return;
			}
			throw Error(i(130, r == null ? r : typeof r, ""));
		}
	}
	function Qn(e, t, n, r, i) {
		var a = t.replay, o = t.blockedBoundary, s = zn(e, 0, null, t.formatContext, !1, !1);
		s.id = n, s.parentFlushed = !0;
		try {
			t.replay = null, t.blockedSegment = s, sr(e, t, r, i), s.status = 1, o === null ? e.completedRootSegment = s : (mr(o, s), o.parentFlushed && e.partialBoundaries.push(o));
		} finally {
			t.replay = a, t.blockedSegment = null;
		}
	}
	function $n(e, t, n, r) {
		t.replay !== null && typeof t.replay.slots == "number" ? Qn(e, t, t.replay.slots, n, r) : (t.node = n, t.childIndex = r, n = t.componentStack, Bn(t), er(e, t), t.componentStack = n);
	}
	function er(e, t) {
		var n = t.node, r = t.childIndex;
		if (n !== null) {
			if (typeof n == "object") {
				switch (n.$$typeof) {
					case a:
						var s = n.type, c = n.key, l = n.props;
						n = l.ref;
						var u = n === void 0 ? null : n, d = wt(s), p = c ?? (r === -1 ? 0 : r);
						if (c = [
							t.keyPath,
							d,
							p
						], t.replay !== null) a: {
							var h = t.replay;
							for (r = h.nodes, n = 0; n < r.length; n++) {
								var g = r[n];
								if (p === g[1]) {
									if (g.length === 4) {
										if (d !== null && d !== g[0]) throw Error(i(490, g[0], d));
										var v = g[2];
										d = g[3], p = t.node, t.replay = {
											nodes: v,
											slots: d,
											pendingTasks: 1
										};
										try {
											if (Zn(e, t, c, s, l, u), t.replay.pendingTasks === 1 && 0 < t.replay.nodes.length) throw Error(i(488));
											t.replay.pendingTasks--;
										} catch (i) {
											if (typeof i == "object" && i && (i === Bt || typeof i.then == "function")) throw t.node === p ? t.replay = h : r.splice(n, 1), i;
											t.replay.pendingTasks--, l = Hn(t.componentStack), c = e, e = t.blockedBoundary, s = i, l = Un(c, s, l), lr(c, e, v, d, s, l);
										}
										t.replay = h;
									} else {
										if (s !== m) throw Error(i(490, "Suspense", wt(s) || "Unknown"));
										b: {
											h = void 0, s = g[5], u = g[2], d = g[3], p = g[4] === null ? [] : g[4][2], g = g[4] === null ? null : g[4][3];
											var y = t.keyPath, b = t.formatContext, x = t.row, S = t.replay, C = t.blockedBoundary, E = t.hoistableState, D = l.children, O = l.fallback, k = /* @__PURE__ */ new Set();
											l = In(e, t.row, k, null, null), l.parentFlushed = !0, l.rootSegmentID = s, t.blockedBoundary = l, t.hoistableState = l.contentState, t.keyPath = c, t.formatContext = fe(e.resumableState, b), t.row = null, t.replay = {
												nodes: u,
												slots: d,
												pendingTasks: 1
											};
											try {
												if (sr(e, t, D, -1), t.replay.pendingTasks === 1 && 0 < t.replay.nodes.length) throw Error(i(488));
												if (t.replay.pendingTasks--, l.pendingTasks === 0 && l.status === 0) {
													l.status = 1, e.completedBoundaries.push(l);
													break b;
												}
											} catch (n) {
												l.status = 4, v = Hn(t.componentStack), h = Un(e, n, v), l.errorDigest = h, t.replay.pendingTasks--, e.clientRenderedBoundaries.push(l);
											} finally {
												t.blockedBoundary = C, t.hoistableState = E, t.replay = S, t.keyPath = y, t.formatContext = b, t.row = x;
											}
											v = Rn(e, null, {
												nodes: p,
												slots: g,
												pendingTasks: 0
											}, O, -1, C, l.fallbackState, k, [
												c[0],
												"Suspense Fallback",
												c[2]
											], de(e.resumableState, t.formatContext), t.context, t.treeContext, t.row, Vn(t.componentStack)), Bn(v), e.pingedTasks.push(v);
										}
									}
									r.splice(n, 1);
									break a;
								}
							}
						}
						else Zn(e, t, c, s, l, u);
						return;
					case o: throw Error(i(257));
					case _:
						if (v = n._init, n = v(n._payload), e.status === 12) throw null;
						$n(e, t, n, r);
						return;
				}
				if (T(n)) {
					tr(e, t, n, r);
					return;
				}
				if ((v = w(n)) && (v = v.call(n))) {
					if (n = v.next(), !n.done) {
						l = [];
						do
							l.push(n.value), n = v.next();
						while (!n.done);
						tr(e, t, l, r);
					}
					return;
				}
				if (typeof n.then == "function") return t.thenableState = null, $n(e, t, yn(n), r);
				if (n.$$typeof === f) return $n(e, t, n._currentValue2, r);
				throw r = Object.prototype.toString.call(n), Error(i(31, r === "[object Object]" ? "object with keys {" + Object.keys(n).join(", ") + "}" : r));
			}
			typeof n == "string" ? (r = t.blockedSegment, r !== null && (r.lastPushedText = bt(r.chunks, n, e.renderState, r.lastPushedText))) : (typeof n == "number" || typeof n == "bigint") && (r = t.blockedSegment, r !== null && (r.lastPushedText = bt(r.chunks, "" + n, e.renderState, r.lastPushedText)));
		}
	}
	function tr(e, t, n, r) {
		var a = t.keyPath;
		if (r !== -1 && (t.keyPath = [
			t.keyPath,
			"Fragment",
			r
		], t.replay !== null)) {
			for (var o = t.replay, s = o.nodes, c = 0; c < s.length; c++) {
				var l = s[c];
				if (l[1] === r) {
					r = l[2], l = l[3], t.replay = {
						nodes: r,
						slots: l,
						pendingTasks: 1
					};
					try {
						if (tr(e, t, n, -1), t.replay.pendingTasks === 1 && 0 < t.replay.nodes.length) throw Error(i(488));
						t.replay.pendingTasks--;
					} catch (i) {
						if (typeof i == "object" && i && (i === Bt || typeof i.then == "function")) throw i;
						t.replay.pendingTasks--, n = Hn(t.componentStack);
						var u = t.blockedBoundary, d = i;
						n = Un(e, d, n), lr(e, u, r, l, d, n);
					}
					t.replay = o, s.splice(c, 1);
					break;
				}
			}
			t.keyPath = a;
			return;
		}
		if (o = t.treeContext, s = n.length, t.replay !== null && (c = t.replay.slots, typeof c == "object" && c)) {
			for (r = 0; r < s; r++) l = n[r], t.treeContext = Ft(o, s, r), u = c[r], typeof u == "number" ? (Qn(e, t, u, l, r), delete c[r]) : sr(e, t, l, r);
			t.treeContext = o, t.keyPath = a;
			return;
		}
		for (c = 0; c < s; c++) r = n[c], t.treeContext = Ft(o, s, c), sr(e, t, r, c);
		t.treeContext = o, t.keyPath = a;
	}
	function nr(e, t, n) {
		if (n.status = 5, n.rootSegmentID = e.nextSegmentId++, e = n.trackedContentKeyPath, e === null) throw Error(i(486));
		var r = n.trackedFallbackNode, a = [], o = t.workingMap.get(e);
		return o === void 0 ? (n = [
			e[1],
			e[2],
			a,
			null,
			r,
			n.rootSegmentID
		], t.workingMap.set(e, n), jr(n, e[0], t), n) : (o[4] = r, o[5] = n.rootSegmentID, o);
	}
	function rr(e, t, n, r) {
		r.status = 5;
		var a = n.keyPath, o = n.blockedBoundary;
		if (o === null) r.id = e.nextSegmentId++, t.rootSlots = r.id, e.completedRootSegment !== null && (e.completedRootSegment.status = 5);
		else {
			if (o !== null && o.status === 0) {
				var s = nr(e, t, o);
				if (o.trackedContentKeyPath === a && n.childIndex === -1) {
					r.id === -1 && (r.id = r.parentFlushed ? o.rootSegmentID : e.nextSegmentId++), s[3] = r.id;
					return;
				}
			}
			if (r.id === -1 && (r.id = r.parentFlushed && o !== null ? o.rootSegmentID : e.nextSegmentId++), n.childIndex === -1) a === null ? t.rootSlots = r.id : (n = t.workingMap.get(a), n === void 0 ? (n = [
				a[1],
				a[2],
				[],
				r.id
			], jr(n, a[0], t)) : n[3] = r.id);
			else {
				if (a === null) {
					if (e = t.rootSlots, e === null) e = t.rootSlots = {};
					else if (typeof e == "number") throw Error(i(491));
				} else if (o = t.workingMap, s = o.get(a), s === void 0) e = {}, s = [
					a[1],
					a[2],
					[],
					e
				], o.set(a, s), jr(s, a[0], t);
				else if (e = s[3], e === null) e = s[3] = {};
				else if (typeof e == "number") throw Error(i(491));
				e[n.childIndex] = r.id;
			}
		}
	}
	function ir(e, t) {
		e = e.trackedPostpones, e !== null && (t = t.trackedContentKeyPath, t !== null && (t = e.workingMap.get(t), t !== void 0 && (t.length = 4, t[2] = [], t[3] = null)));
	}
	function ar(e, t, n) {
		return Rn(e, n, t.replay, t.node, t.childIndex, t.blockedBoundary, t.hoistableState, t.abortSet, t.keyPath, t.formatContext, t.context, t.treeContext, t.row, t.componentStack);
	}
	function or(e, t, n) {
		var r = t.blockedSegment, i = zn(e, r.chunks.length, null, t.formatContext, r.lastPushedText, !0);
		return r.children.push(i), r.lastPushedText = !1, Ln(e, n, t.node, t.childIndex, t.blockedBoundary, i, t.blockedPreamble, t.hoistableState, t.abortSet, t.keyPath, t.formatContext, t.context, t.treeContext, t.row, t.componentStack);
	}
	function sr(e, t, n, r) {
		var i = t.formatContext, a = t.context, o = t.keyPath, s = t.treeContext, c = t.componentStack, l = t.blockedSegment;
		if (l === null) {
			l = t.replay;
			try {
				return $n(e, t, n, r);
			} catch (u) {
				if (un(), n = u === Bt ? Ut() : u, e.status !== 12 && typeof n == "object" && n) {
					if (typeof n.then == "function") {
						r = u === Bt ? ln() : null, e = ar(e, t, r).ping, n.then(e, e), t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, t.componentStack = c, t.replay = l, Mt(a);
						return;
					}
					if (n.message === "Maximum call stack size exceeded") {
						n = u === Bt ? ln() : null, n = ar(e, t, n), e.pingedTasks.push(n), t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, t.componentStack = c, t.replay = l, Mt(a);
						return;
					}
				}
			}
		} else {
			var u = l.children.length, d = l.chunks.length;
			try {
				return $n(e, t, n, r);
			} catch (r) {
				if (un(), l.children.length = u, l.chunks.length = d, n = r === Bt ? Ut() : r, e.status !== 12 && typeof n == "object" && n) {
					if (typeof n.then == "function") {
						l = n, n = r === Bt ? ln() : null, e = or(e, t, n).ping, l.then(e, e), t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, t.componentStack = c, Mt(a);
						return;
					}
					if (n.message === "Maximum call stack size exceeded") {
						l = r === Bt ? ln() : null, l = or(e, t, l), e.pingedTasks.push(l), t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, t.componentStack = c, Mt(a);
						return;
					}
				}
			}
		}
		throw t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, Mt(a), n;
	}
	function cr(e) {
		var t = e.blockedBoundary, n = e.blockedSegment;
		n !== null && (n.status = 3, hr(this, t, e.row, n));
	}
	function lr(e, t, n, r, a, o) {
		for (var s = 0; s < n.length; s++) {
			var c = n[s];
			if (c.length === 4) lr(e, t, c[2], c[3], a, o);
			else {
				c = c[5];
				var l = e, u = o, d = In(l, null, /* @__PURE__ */ new Set(), null, null);
				d.parentFlushed = !0, d.rootSegmentID = c, d.status = 4, d.errorDigest = u, d.parentFlushed && l.clientRenderedBoundaries.push(d);
			}
		}
		if (n.length = 0, r !== null) {
			if (t === null) throw Error(i(487));
			if (t.status !== 4 && (t.status = 4, t.errorDigest = o, t.parentFlushed && e.clientRenderedBoundaries.push(t)), typeof r == "object") for (var f in r) delete r[f];
		}
	}
	function ur(e, t, n) {
		var r = e.blockedBoundary, i = e.blockedSegment;
		if (i !== null) {
			if (i.status === 6) return;
			i.status = 3;
		}
		var a = Hn(e.componentStack);
		if (r === null) {
			if (t.status !== 13 && t.status !== 14) {
				if (r = e.replay, r === null) {
					t.trackedPostpones !== null && i !== null ? (r = t.trackedPostpones, Un(t, n, a), rr(t, r, e, i), hr(t, null, e.row, i)) : (Un(t, n, a), Wn(t, n));
					return;
				}
				r.pendingTasks--, r.pendingTasks === 0 && 0 < r.nodes.length && (i = Un(t, n, a), lr(t, null, r.nodes, r.slots, n, i)), t.pendingRootTasks--, t.pendingRootTasks === 0 && fr(t);
			}
		} else {
			var o = t.trackedPostpones;
			if (r.status !== 4) {
				if (o !== null && i !== null) return Un(t, n, a), rr(t, o, e, i), r.fallbackAbortableTasks.forEach(function(e) {
					return ur(e, t, n);
				}), r.fallbackAbortableTasks.clear(), hr(t, r, e.row, i);
				r.status = 4, i = Un(t, n, a), r.status = 4, r.errorDigest = i, ir(t, r), r.parentFlushed && t.clientRenderedBoundaries.push(r);
			}
			r.pendingTasks--, i = r.row, i !== null && --i.pendingTasks === 0 && Q(t, i), r.fallbackAbortableTasks.forEach(function(e) {
				return ur(e, t, n);
			}), r.fallbackAbortableTasks.clear();
		}
		e = e.row, e !== null && --e.pendingTasks === 0 && Q(t, e), t.allPendingTasks--, t.allPendingTasks === 0 && pr(t);
	}
	function dr(e, t) {
		try {
			var n = e.renderState, r = n.onHeaders;
			if (r) {
				var i = n.headers;
				if (i) {
					n.headers = null;
					var a = i.preconnects;
					if (i.fontPreloads && (a && (a += ", "), a += i.fontPreloads), i.highImagePreloads && (a && (a += ", "), a += i.highImagePreloads), !t) {
						var o = n.styles.values(), s = o.next();
						b: for (; 0 < i.remainingCapacity && !s.done; s = o.next()) for (var c = s.value.sheets.values(), l = c.next(); 0 < i.remainingCapacity && !l.done; l = c.next()) {
							var u = l.value, d = u.props, f = d.href, p = u.props, m = dt(p.href, "style", {
								crossOrigin: p.crossOrigin,
								integrity: p.integrity,
								nonce: p.nonce,
								type: p.type,
								fetchPriority: p.fetchPriority,
								referrerPolicy: p.referrerPolicy,
								media: p.media
							});
							if (0 <= (i.remainingCapacity -= m.length + 2)) n.resets.style[f] = ae, a && (a += ", "), a += m, n.resets.style[f] = typeof d.crossOrigin == "string" || typeof d.integrity == "string" ? [d.crossOrigin, d.integrity] : ae;
							else break b;
						}
					}
					r(a ? { Link: a } : {});
				}
			}
		} catch (t) {
			Un(e, t, {});
		}
	}
	function fr(e) {
		e.trackedPostpones === null && dr(e, !0), e.trackedPostpones === null && yr(e), e.onShellError = Y, e = e.onShellReady, e();
	}
	function pr(e) {
		dr(e, e.trackedPostpones === null || e.completedRootSegment === null || e.completedRootSegment.status !== 5), yr(e), e = e.onAllReady, e();
	}
	function mr(e, t) {
		if (t.chunks.length === 0 && t.children.length === 1 && t.children[0].boundary === null && t.children[0].id === -1) {
			var n = t.children[0];
			n.id = t.id, n.parentFlushed = !0, n.status !== 1 && n.status !== 3 && n.status !== 4 || mr(e, n);
		} else e.completedSegments.push(t);
	}
	function hr(e, t, n, r) {
		if (n !== null && (--n.pendingTasks === 0 ? Q(e, n) : n.together && Kn(e, n)), e.allPendingTasks--, t === null) {
			if (r !== null && r.parentFlushed) {
				if (e.completedRootSegment !== null) throw Error(i(389));
				e.completedRootSegment = r;
			}
			e.pendingRootTasks--, e.pendingRootTasks === 0 && fr(e);
		} else if (t.pendingTasks--, t.status !== 4) {
			if (t.pendingTasks === 0) {
				if (t.status === 0 && (t.status = 1), r !== null && r.parentFlushed && (r.status === 1 || r.status === 3) && mr(t, r), t.parentFlushed && e.completedBoundaries.push(t), t.status === 1) n = t.row, n !== null && vt(n.hoistables, t.contentState), An(e, t) || (t.fallbackAbortableTasks.forEach(cr, e), t.fallbackAbortableTasks.clear(), n !== null && --n.pendingTasks === 0 && Q(e, n)), e.pendingRootTasks === 0 && e.trackedPostpones === null && t.contentPreamble !== null && yr(e);
				else if (t.status === 5 && (t = t.row, t !== null)) {
					if (e.trackedPostpones !== null) {
						n = e.trackedPostpones;
						var a = t.next;
						if (a !== null && (r = a.boundaries, r !== null)) for (a.boundaries = null, a = 0; a < r.length; a++) {
							var o = r[a];
							nr(e, n, o), hr(e, o, null, null);
						}
					}
					--t.pendingTasks === 0 && Q(e, t);
				}
			} else r === null || !r.parentFlushed || r.status !== 1 && r.status !== 3 || (mr(t, r), t.completedSegments.length === 1 && t.parentFlushed && e.partialBoundaries.push(t)), t = t.row, t !== null && t.together && Kn(e, t);
		}
		e.allPendingTasks === 0 && pr(e);
	}
	function gr(e) {
		if (e.status !== 14 && e.status !== 13) {
			var t = Et, n = re.H;
			re.H = xn;
			var r = re.A;
			re.A = Cn;
			var a = Pn;
			Pn = e;
			var o = Sn;
			Sn = e.resumableState;
			try {
				for (var s = e.pingedTasks, c = 0; c < s.length; c++) {
					var l = s[c], u = e, d = l.blockedSegment;
					if (d === null) {
						var f = u;
						if (l.replay.pendingTasks !== 0) {
							Mt(l.context);
							try {
								if (typeof l.replay.slots == "number" ? Qn(f, l, l.replay.slots, l.node, l.childIndex) : er(f, l), l.replay.pendingTasks === 1 && 0 < l.replay.nodes.length) throw Error(i(488));
								l.replay.pendingTasks--, l.abortSet.delete(l), hr(f, l.blockedBoundary, l.row, null);
							} catch (e) {
								un();
								var p = e === Bt ? Ut() : e;
								if (typeof p == "object" && p && typeof p.then == "function") {
									var m = l.ping;
									p.then(m, m), l.thenableState = e === Bt ? ln() : null;
								} else {
									l.replay.pendingTasks--, l.abortSet.delete(l);
									var h = Hn(l.componentStack);
									u = void 0;
									var g = f, _ = l.blockedBoundary, v = f.status === 12 ? f.fatalError : p, y = l.replay.nodes, b = l.replay.slots;
									u = Un(g, v, h), lr(g, _, y, b, v, u), f.pendingRootTasks--, f.pendingRootTasks === 0 && fr(f), f.allPendingTasks--, f.allPendingTasks === 0 && pr(f);
								}
							}
						}
					} else if (f = void 0, g = d, g.status === 0) {
						g.status = 6, Mt(l.context);
						var x = g.children.length, S = g.chunks.length;
						try {
							er(u, l), xt(g.chunks, u.renderState, g.lastPushedText, g.textEmbedded), l.abortSet.delete(l), g.status = 1, hr(u, l.blockedBoundary, l.row, g);
						} catch (e) {
							un(), g.children.length = x, g.chunks.length = S;
							var C = e === Bt ? Ut() : u.status === 12 ? u.fatalError : e;
							if (u.status === 12 && u.trackedPostpones !== null) {
								var w = u.trackedPostpones, T = Hn(l.componentStack);
								l.abortSet.delete(l), Un(u, C, T), rr(u, w, l, g), hr(u, l.blockedBoundary, l.row, g);
							} else if (typeof C == "object" && C && typeof C.then == "function") {
								g.status = 0, l.thenableState = e === Bt ? ln() : null;
								var E = l.ping;
								C.then(E, E);
							} else {
								var D = Hn(l.componentStack);
								l.abortSet.delete(l), g.status = 4;
								var O = l.blockedBoundary, k = l.row;
								if (k !== null && --k.pendingTasks === 0 && Q(u, k), u.allPendingTasks--, f = Un(u, C, D), O === null) Wn(u, C);
								else if (O.pendingTasks--, O.status !== 4) {
									O.status = 4, O.errorDigest = f, ir(u, O);
									var A = O.row;
									A !== null && --A.pendingTasks === 0 && Q(u, A), O.parentFlushed && u.clientRenderedBoundaries.push(O), u.pendingRootTasks === 0 && u.trackedPostpones === null && O.contentPreamble !== null && yr(u);
								}
								u.allPendingTasks === 0 && pr(u);
							}
						}
					}
				}
				s.splice(0, c), e.destination !== null && Dr(e, e.destination);
			} catch (t) {
				Un(e, t, {}), Wn(e, t);
			} finally {
				Sn = o, re.H = n, re.A = r, n === xn && Mt(t), Pn = a;
			}
		}
	}
	function _r(e, t, n) {
		t.preambleChildren.length && n.push(t.preambleChildren);
		for (var r = !1, i = 0; i < t.children.length; i++) r = vr(e, t.children[i], n) || r;
		return r;
	}
	function vr(e, t, n) {
		var r = t.boundary;
		if (r === null) return _r(e, t, n);
		var a = r.contentPreamble, o = r.fallbackPreamble;
		if (a === null || o === null) return !1;
		switch (r.status) {
			case 1:
				if (Le(e.renderState, a), e.byteSize += r.byteSize, t = r.completedSegments[0], !t) throw Error(i(391));
				return _r(e, t, n);
			case 5: if (e.trackedPostpones !== null) return !0;
			case 4: if (t.status === 1) return Le(e.renderState, o), _r(e, t, n);
			default: return !0;
		}
	}
	function yr(e) {
		if (e.completedRootSegment && e.completedPreambleSegments === null) {
			var t = [], n = e.byteSize, r = vr(e, e.completedRootSegment, t), i = e.renderState.preamble;
			!1 === r || i.headChunks && i.bodyChunks ? e.completedPreambleSegments = t : e.byteSize = n;
		}
	}
	function br(e, t, n, r) {
		switch (n.parentFlushed = !0, n.status) {
			case 0: n.id = e.nextSegmentId++;
			case 5: return r = n.id, n.lastPushedText = !1, n.textEmbedded = !1, e = e.renderState, t.push("<template id=\""), t.push(e.placeholderPrefix), e = r.toString(16), t.push(e), t.push("\"></template>");
			case 1:
				n.status = 2;
				var a = !0, o = n.chunks, s = 0;
				n = n.children;
				for (var c = 0; c < n.length; c++) {
					for (a = n[c]; s < a.index; s++) t.push(o[s]);
					a = Sr(e, t, a, r);
				}
				for (; s < o.length - 1; s++) t.push(o[s]);
				return s < o.length && (a = t.push(o[s])), a;
			case 3: return !0;
			default: throw Error(i(390));
		}
	}
	var xr = 0;
	function Sr(e, t, n, r) {
		var a = n.boundary;
		if (a === null) return br(e, t, n, r);
		if (a.parentFlushed = !0, a.status === 4) {
			var o = a.row;
			return o !== null && --o.pendingTasks === 0 && Q(e, o), e.renderState.generateStaticMarkup || (a = a.errorDigest, t.push("<!--$!-->"), t.push("<template"), a && (t.push(" data-dgst=\""), a = F(a), t.push(a), t.push("\"")), t.push("></template>")), br(e, t, n, r), e = e.renderState.generateStaticMarkup ? !0 : t.push("<!--/$-->"), e;
		}
		if (a.status !== 1) return a.status === 0 && (a.rootSegmentID = e.nextSegmentId++), 0 < a.completedSegments.length && e.partialBoundaries.push(a), ze(t, e.renderState, a.rootSegmentID), r && vt(r, a.fallbackState), br(e, t, n, r), t.push("<!--/$-->");
		if (!Er && An(e, a) && xr + a.byteSize > e.progressiveChunkSize) return a.rootSegmentID = e.nextSegmentId++, e.completedBoundaries.push(a), ze(t, e.renderState, a.rootSegmentID), br(e, t, n, r), t.push("<!--/$-->");
		if (xr += a.byteSize, r && vt(r, a.contentState), n = a.row, n !== null && An(e, a) && --n.pendingTasks === 0 && Q(e, n), e.renderState.generateStaticMarkup || t.push("<!--$-->"), n = a.completedSegments, n.length !== 1) throw Error(i(391));
		return Sr(e, t, n[0], r), e = e.renderState.generateStaticMarkup ? !0 : t.push("<!--/$-->"), e;
	}
	function Cr(e, t, n, r) {
		return Be(t, e.renderState, n.parentFormatContext, n.id), Sr(e, t, n, r), Ve(t, n.parentFormatContext);
	}
	function wr(e, t, n) {
		xr = n.byteSize;
		for (var r = n.completedSegments, i = 0; i < r.length; i++) Tr(e, t, n, r[i]);
		r.length = 0, r = n.row, r !== null && An(e, n) && --r.pendingTasks === 0 && Q(e, r), Ye(t, n.contentState, e.renderState), r = e.resumableState, e = e.renderState, i = n.rootSegmentID, n = n.contentState;
		var a = e.stylesToHoist;
		return e.stylesToHoist = !1, t.push(e.startInlineScript), t.push(">"), a ? (!(r.instructions & 4) && (r.instructions |= 4, t.push("$RX=function(b,c,d,e,f){var a=document.getElementById(b);a&&(b=a.previousSibling,b.data=\"$!\",a=a.dataset,c&&(a.dgst=c),d&&(a.msg=d),e&&(a.stck=e),f&&(a.cstck=f),b._reactRetry&&b._reactRetry())};")), !(r.instructions & 2) && (r.instructions |= 2, t.push("$RB=[];$RV=function(a){$RT=performance.now();for(var b=0;b<a.length;b+=2){var c=a[b],e=a[b+1];null!==e.parentNode&&e.parentNode.removeChild(e);var f=c.parentNode;if(f){var g=c.previousSibling,h=0;do{if(c&&8===c.nodeType){var d=c.data;if(\"/$\"===d||\"/&\"===d)if(0===h)break;else h--;else\"$\"!==d&&\"$?\"!==d&&\"$~\"!==d&&\"$!\"!==d&&\"&\"!==d||h++}d=c.nextSibling;f.removeChild(c);c=d}while(c);for(;e.firstChild;)f.insertBefore(e.firstChild,c);g.data=\"$\";g._reactRetry&&requestAnimationFrame(g._reactRetry)}}a.length=0};\n$RC=function(a,b){if(b=document.getElementById(b))(a=document.getElementById(a))?(a.previousSibling.data=\"$~\",$RB.push(a,b),2===$RB.length&&(\"number\"!==typeof $RT?requestAnimationFrame($RV.bind(null,$RB)):(a=performance.now(),setTimeout($RV.bind(null,$RB),2300>a&&2E3<a?2300-a:$RT+300-a)))):b.parentNode.removeChild(b)};")), r.instructions & 8 ? t.push("$RR(\"") : (r.instructions |= 8, t.push("$RM=new Map;$RR=function(n,w,p){function u(q){this._p=null;q()}for(var r=new Map,t=document,h,b,e=t.querySelectorAll(\"link[data-precedence],style[data-precedence]\"),v=[],k=0;b=e[k++];)\"not all\"===b.getAttribute(\"media\")?v.push(b):(\"LINK\"===b.tagName&&$RM.set(b.getAttribute(\"href\"),b),r.set(b.dataset.precedence,h=b));e=0;b=[];var l,a;for(k=!0;;){if(k){var f=p[e++];if(!f){k=!1;e=0;continue}var c=!1,m=0;var d=f[m++];if(a=$RM.get(d)){var g=a._p;c=!0}else{a=t.createElement(\"link\");a.href=d;a.rel=\n\"stylesheet\";for(a.dataset.precedence=l=f[m++];g=f[m++];)a.setAttribute(g,f[m++]);g=a._p=new Promise(function(q,x){a.onload=u.bind(a,q);a.onerror=u.bind(a,x)});$RM.set(d,a)}d=a.getAttribute(\"media\");!g||d&&!matchMedia(d).matches||b.push(g);if(c)continue}else{a=v[e++];if(!a)break;l=a.getAttribute(\"data-precedence\");a.removeAttribute(\"media\")}c=r.get(l)||h;c===h&&(h=a);r.set(l,a);c?c.parentNode.insertBefore(a,c.nextSibling):(c=t.head,c.insertBefore(a,c.firstChild))}if(p=document.getElementById(n))p.previousSibling.data=\n\"$~\";Promise.all(b).then($RC.bind(null,n,w),$RX.bind(null,n,\"CSS failed to load\"))};$RR(\""))) : (!(r.instructions & 2) && (r.instructions |= 2, t.push("$RB=[];$RV=function(a){$RT=performance.now();for(var b=0;b<a.length;b+=2){var c=a[b],e=a[b+1];null!==e.parentNode&&e.parentNode.removeChild(e);var f=c.parentNode;if(f){var g=c.previousSibling,h=0;do{if(c&&8===c.nodeType){var d=c.data;if(\"/$\"===d||\"/&\"===d)if(0===h)break;else h--;else\"$\"!==d&&\"$?\"!==d&&\"$~\"!==d&&\"$!\"!==d&&\"&\"!==d||h++}d=c.nextSibling;f.removeChild(c);c=d}while(c);for(;e.firstChild;)f.insertBefore(e.firstChild,c);g.data=\"$\";g._reactRetry&&requestAnimationFrame(g._reactRetry)}}a.length=0};\n$RC=function(a,b){if(b=document.getElementById(b))(a=document.getElementById(a))?(a.previousSibling.data=\"$~\",$RB.push(a,b),2===$RB.length&&(\"number\"!==typeof $RT?requestAnimationFrame($RV.bind(null,$RB)):(a=performance.now(),setTimeout($RV.bind(null,$RB),2300>a&&2E3<a?2300-a:$RT+300-a)))):b.parentNode.removeChild(b)};")), t.push("$RC(\"")), r = i.toString(16), t.push(e.boundaryPrefix), t.push(r), t.push("\",\""), t.push(e.segmentPrefix), t.push(r), a ? (t.push("\","), nt(t, n)) : t.push("\""), n = t.push(")<\/script>"), Re(t, e) && n;
	}
	function Tr(e, t, n, r) {
		if (r.status === 2) return !0;
		var a = n.contentState, o = r.id;
		if (o === -1) {
			if ((r.id = n.rootSegmentID) === -1) throw Error(i(392));
			return Cr(e, t, r, a);
		}
		return o === n.rootSegmentID ? Cr(e, t, r, a) : (Cr(e, t, r, a), n = e.resumableState, e = e.renderState, t.push(e.startInlineScript), t.push(">"), n.instructions & 1 ? t.push("$RS(\"") : (n.instructions |= 1, t.push("$RS=function(a,b){a=document.getElementById(a);b=document.getElementById(b);for(a.parentNode.removeChild(a);a.firstChild;)b.parentNode.insertBefore(a.firstChild,b);b.parentNode.removeChild(b)};$RS(\"")), t.push(e.segmentPrefix), o = o.toString(16), t.push(o), t.push("\",\""), t.push(e.placeholderPrefix), t.push(o), t = t.push("\")<\/script>"), t);
	}
	var Er = !1;
	function Dr(e, t) {
		try {
			if (!(0 < e.pendingRootTasks)) {
				var n, r = e.completedRootSegment;
				if (r !== null) {
					if (r.status === 5) return;
					var i = e.completedPreambleSegments;
					if (i === null) return;
					xr = e.byteSize;
					var a = e.resumableState, o = e.renderState, s = o.preamble, c = s.htmlChunks, l = s.headChunks, u;
					if (c) {
						for (u = 0; u < c.length; u++) t.push(c[u]);
						if (l) for (u = 0; u < l.length; u++) t.push(l[u]);
						else {
							var d = U("head");
							t.push(d), t.push(">");
						}
					} else if (l) for (u = 0; u < l.length; u++) t.push(l[u]);
					var f = o.charsetChunks;
					for (u = 0; u < f.length; u++) t.push(f[u]);
					f.length = 0, o.preconnects.forEach(Xe, t), o.preconnects.clear();
					var p = o.viewportChunks;
					for (u = 0; u < p.length; u++) t.push(p[u]);
					p.length = 0, o.fontPreloads.forEach(Xe, t), o.fontPreloads.clear(), o.highImagePreloads.forEach(Xe, t), o.highImagePreloads.clear(), oe = o, o.styles.forEach(Qe, t), oe = null;
					var m = o.importMapChunks;
					for (u = 0; u < m.length; u++) t.push(m[u]);
					m.length = 0, o.bootstrapScripts.forEach(Xe, t), o.scripts.forEach(Xe, t), o.scripts.clear(), o.bulkPreloads.forEach(Xe, t), o.bulkPreloads.clear(), a.instructions |= 32;
					var h = o.hoistableChunks;
					for (u = 0; u < h.length; u++) t.push(h[u]);
					for (a = h.length = 0; a < i.length; a++) {
						var g = i[a];
						for (o = 0; o < g.length; o++) Sr(e, t, g[o], null);
					}
					var _ = e.renderState.preamble, v = _.headChunks;
					if (_.htmlChunks || v) {
						var y = Ie("head");
						t.push(y);
					}
					var b = _.bodyChunks;
					if (b) for (i = 0; i < b.length; i++) t.push(b[i]);
					Sr(e, t, r, null), e.completedRootSegment = null;
					var x = e.renderState;
					if (e.allPendingTasks !== 0 || e.clientRenderedBoundaries.length !== 0 || e.completedBoundaries.length !== 0 || e.trackedPostpones !== null && (e.trackedPostpones.rootNodes.length !== 0 || e.trackedPostpones.rootSlots !== null)) {
						var S = e.resumableState;
						if (!(S.instructions & 64)) {
							if (S.instructions |= 64, t.push(x.startInlineScript), !(S.instructions & 32)) {
								S.instructions |= 32;
								var C = "_" + S.idPrefix + "R_";
								t.push(" id=\"");
								var w = F(C);
								t.push(w), t.push("\"");
							}
							t.push(">"), t.push("requestAnimationFrame(function(){$RT=performance.now()});"), t.push("<\/script>");
						}
					}
					Re(t, x);
				}
				var T = e.renderState;
				r = 0;
				var E = T.viewportChunks;
				for (r = 0; r < E.length; r++) t.push(E[r]);
				E.length = 0, T.preconnects.forEach(Xe, t), T.preconnects.clear(), T.fontPreloads.forEach(Xe, t), T.fontPreloads.clear(), T.highImagePreloads.forEach(Xe, t), T.highImagePreloads.clear(), T.styles.forEach(et, t), T.scripts.forEach(Xe, t), T.scripts.clear(), T.bulkPreloads.forEach(Xe, t), T.bulkPreloads.clear();
				var D = T.hoistableChunks;
				for (r = 0; r < D.length; r++) t.push(D[r]);
				D.length = 0;
				var O = e.clientRenderedBoundaries;
				for (n = 0; n < O.length; n++) {
					var k = O[n];
					T = t;
					var A = e.resumableState, j = e.renderState, ee = k.rootSegmentID, M = k.errorDigest;
					T.push(j.startInlineScript), T.push(">"), A.instructions & 4 ? T.push("$RX(\"") : (A.instructions |= 4, T.push("$RX=function(b,c,d,e,f){var a=document.getElementById(b);a&&(b=a.previousSibling,b.data=\"$!\",a=a.dataset,c&&(a.dgst=c),d&&(a.msg=d),e&&(a.stck=e),f&&(a.cstck=f),b._reactRetry&&b._reactRetry())};;$RX(\"")), T.push(j.boundaryPrefix);
					var N = ee.toString(16);
					if (T.push(N), T.push("\""), M) {
						T.push(",");
						var P = Ue(M || "");
						T.push(P);
					}
					var te = T.push(")<\/script>");
					if (!te) {
						e.destination = null, n++, O.splice(0, n);
						return;
					}
				}
				O.splice(0, n);
				var ne = e.completedBoundaries;
				for (n = 0; n < ne.length; n++) if (!wr(e, t, ne[n])) {
					e.destination = null, n++, ne.splice(0, n);
					return;
				}
				ne.splice(0, n), Er = !0;
				var I = e.partialBoundaries;
				for (n = 0; n < I.length; n++) {
					var L = I[n];
					a: {
						O = e, k = t, xr = L.byteSize;
						var re = L.completedSegments;
						for (te = 0; te < re.length; te++) if (!Tr(O, k, L, re[te])) {
							te++, re.splice(0, te);
							var ie = !1;
							break a;
						}
						re.splice(0, te);
						var R = L.row;
						R !== null && R.together && L.pendingTasks === 1 && (R.pendingTasks === 1 ? Gn(O, R, R.hoistables) : R.pendingTasks--), ie = Ye(k, L.contentState, O.renderState);
					}
					if (!ie) {
						e.destination = null, n++, I.splice(0, n);
						return;
					}
				}
				I.splice(0, n), Er = !1;
				var z = e.completedBoundaries;
				for (n = 0; n < z.length; n++) if (!wr(e, t, z[n])) {
					e.destination = null, n++, z.splice(0, n);
					return;
				}
				z.splice(0, n);
			}
		} finally {
			Er = !1, e.allPendingTasks === 0 && e.clientRenderedBoundaries.length === 0 && e.completedBoundaries.length === 0 && (e.flushScheduled = !1, n = e.resumableState, n.hasBody && (I = Ie("body"), t.push(I)), n.hasHtml && (n = Ie("html"), t.push(n)), e.status = 14, t.push(null), e.destination = null);
		}
	}
	function Or(e) {
		if (!1 === e.flushScheduled && e.pingedTasks.length === 0 && e.destination !== null) {
			e.flushScheduled = !0;
			var t = e.destination;
			t ? Dr(e, t) : e.flushScheduled = !1;
		}
	}
	function kr(e, t) {
		if (e.status === 13) e.status = 14, t.destroy(e.fatalError);
		else if (e.status !== 14 && e.destination === null) {
			e.destination = t;
			try {
				Dr(e, t);
			} catch (t) {
				Un(e, t, {}), Wn(e, t);
			}
		}
	}
	function Ar(e, t) {
		(e.status === 11 || e.status === 10) && (e.status = 12);
		try {
			var n = e.abortableTasks;
			if (0 < n.size) {
				var r = t === void 0 ? Error(i(432)) : typeof t == "object" && t && typeof t.then == "function" ? Error(i(530)) : t;
				e.fatalError = r, n.forEach(function(t) {
					return ur(t, e, r);
				}), n.clear();
			}
			e.destination !== null && Dr(e, e.destination);
		} catch (t) {
			Un(e, t, {}), Wn(e, t);
		}
	}
	function jr(e, t, n) {
		if (t === null) n.rootNodes.push(e);
		else {
			var r = n.workingMap, i = r.get(t);
			i === void 0 && (i = [
				t[1],
				t[2],
				[],
				null
			], r.set(t, i), jr(i, t[0], n)), i[2].push(e);
		}
	}
	function Mr() {}
	function Nr(e, t, n, r) {
		var a = !1, o = null, s = "", c = !1;
		if (t = le(t ? t.identifierPrefix : void 0), e = Nn(e, t, yt(t, n), B(0, null, 0, null), Infinity, Mr, void 0, function() {
			c = !0;
		}, void 0, void 0, void 0), e.flushScheduled = e.destination !== null, gr(e), e.status === 10 && (e.status = 11), e.trackedPostpones === null && dr(e, e.pendingRootTasks === 0), Ar(e, r), kr(e, {
			push: function(e) {
				return e !== null && (s += e), !0;
			},
			destroy: function(e) {
				a = !0, o = e;
			}
		}), a && o !== r) throw o;
		if (!c) throw Error(i(426));
		return s;
	}
	e.renderToStaticMarkup = function(e, t) {
		return Nr(e, t, !0, "The server used \"renderToStaticMarkup\" which does not support Suspense. If you intended to have the server wait for the suspended component please switch to \"renderToReadableStream\" which supports Suspense on the server");
	}, e.renderToString = function(e, t) {
		return Nr(e, t, !1, "The server used \"renderToString\" which does not support Suspense. If you intended for this Suspense boundary to render the fallback content on the server consider throwing an Error somewhere within the Suspense boundary. If you intended to have the server wait for the suspended component please switch to \"renderToReadableStream\" which supports Suspense on the server");
	}, e.version = "19.2.8";
})), g = /* @__PURE__ */ t(((e) => {
	var t = n(), r = d();
	function i(e) {
		var t = "https://react.dev/errors/" + e;
		if (1 < arguments.length) {
			t += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var n = 2; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
		}
		return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
	}
	var a = Symbol.for("react.transitional.element"), o = Symbol.for("react.portal"), s = Symbol.for("react.fragment"), c = Symbol.for("react.strict_mode"), l = Symbol.for("react.profiler"), u = Symbol.for("react.consumer"), f = Symbol.for("react.context"), p = Symbol.for("react.forward_ref"), m = Symbol.for("react.suspense"), h = Symbol.for("react.suspense_list"), g = Symbol.for("react.memo"), _ = Symbol.for("react.lazy"), v = Symbol.for("react.scope"), y = Symbol.for("react.activity"), b = Symbol.for("react.legacy_hidden"), x = Symbol.for("react.memo_cache_sentinel"), S = Symbol.for("react.view_transition"), C = Symbol.iterator;
	function w(e) {
		return typeof e != "object" || !e ? null : (e = C && e[C] || e["@@iterator"], typeof e == "function" ? e : null);
	}
	var T = Array.isArray;
	function E(e, t) {
		var n = e.length & 3, r = e.length - n, i = t;
		for (t = 0; t < r;) {
			var a = e.charCodeAt(t) & 255 | (e.charCodeAt(++t) & 255) << 8 | (e.charCodeAt(++t) & 255) << 16 | (e.charCodeAt(++t) & 255) << 24;
			++t, a = 3432918353 * (a & 65535) + ((3432918353 * (a >>> 16) & 65535) << 16) & 4294967295, a = a << 15 | a >>> 17, a = 461845907 * (a & 65535) + ((461845907 * (a >>> 16) & 65535) << 16) & 4294967295, i ^= a, i = i << 13 | i >>> 19, i = 5 * (i & 65535) + ((5 * (i >>> 16) & 65535) << 16) & 4294967295, i = (i & 65535) + 27492 + (((i >>> 16) + 58964 & 65535) << 16);
		}
		switch (a = 0, n) {
			case 3: a ^= (e.charCodeAt(t + 2) & 255) << 16;
			case 2: a ^= (e.charCodeAt(t + 1) & 255) << 8;
			case 1: a ^= e.charCodeAt(t) & 255, a = 3432918353 * (a & 65535) + ((3432918353 * (a >>> 16) & 65535) << 16) & 4294967295, a = a << 15 | a >>> 17, i ^= 461845907 * (a & 65535) + ((461845907 * (a >>> 16) & 65535) << 16) & 4294967295;
		}
		return i ^= e.length, i ^= i >>> 16, i = 2246822507 * (i & 65535) + ((2246822507 * (i >>> 16) & 65535) << 16) & 4294967295, i ^= i >>> 13, i = 3266489909 * (i & 65535) + ((3266489909 * (i >>> 16) & 65535) << 16) & 4294967295, (i ^ i >>> 16) >>> 0;
	}
	var D = new MessageChannel(), O = [];
	D.port1.onmessage = function() {
		var e = O.shift();
		e && e();
	};
	function k(e) {
		O.push(e), D.port2.postMessage(null);
	}
	function A(e) {
		setTimeout(function() {
			throw e;
		});
	}
	var j = Promise, ee = typeof queueMicrotask == "function" ? queueMicrotask : function(e) {
		j.resolve(null).then(e).catch(A);
	}, M = null, N = 0;
	function P(e, t) {
		if (t.byteLength !== 0) {
			if (2048 < t.byteLength) 0 < N && (e.enqueue(new Uint8Array(M.buffer, 0, N)), M = /* @__PURE__ */ new Uint8Array(2048), N = 0), e.enqueue(t);
			else {
				var n = M.length - N;
				n < t.byteLength && (n === 0 ? e.enqueue(M) : (M.set(t.subarray(0, n), N), e.enqueue(M), t = t.subarray(n)), M = /* @__PURE__ */ new Uint8Array(2048), N = 0), M.set(t, N), N += t.byteLength;
			}
		}
	}
	function F(e, t) {
		return P(e, t), !0;
	}
	function te(e) {
		M && 0 < N && (e.enqueue(new Uint8Array(M.buffer, 0, N)), M = null, N = 0);
	}
	var ne = new TextEncoder();
	function I(e) {
		return ne.encode(e);
	}
	function L(e) {
		return ne.encode(e);
	}
	function re(e) {
		return e.byteLength;
	}
	function ie(e, t) {
		typeof e.error == "function" ? e.error(t) : e.close();
	}
	var R = Object.assign, z = Object.prototype.hasOwnProperty, ae = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), oe = {}, se = {};
	function ce(e) {
		return z.call(se, e) ? !0 : z.call(oe, e) ? !1 : ae.test(e) ? se[e] = !0 : (oe[e] = !0, !1);
	}
	var le = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" ")), B = /* @__PURE__ */ new Map([
		["acceptCharset", "accept-charset"],
		["htmlFor", "for"],
		["httpEquiv", "http-equiv"],
		["crossOrigin", "crossorigin"],
		["accentHeight", "accent-height"],
		["alignmentBaseline", "alignment-baseline"],
		["arabicForm", "arabic-form"],
		["baselineShift", "baseline-shift"],
		["capHeight", "cap-height"],
		["clipPath", "clip-path"],
		["clipRule", "clip-rule"],
		["colorInterpolation", "color-interpolation"],
		["colorInterpolationFilters", "color-interpolation-filters"],
		["colorProfile", "color-profile"],
		["colorRendering", "color-rendering"],
		["dominantBaseline", "dominant-baseline"],
		["enableBackground", "enable-background"],
		["fillOpacity", "fill-opacity"],
		["fillRule", "fill-rule"],
		["floodColor", "flood-color"],
		["floodOpacity", "flood-opacity"],
		["fontFamily", "font-family"],
		["fontSize", "font-size"],
		["fontSizeAdjust", "font-size-adjust"],
		["fontStretch", "font-stretch"],
		["fontStyle", "font-style"],
		["fontVariant", "font-variant"],
		["fontWeight", "font-weight"],
		["glyphName", "glyph-name"],
		["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
		["glyphOrientationVertical", "glyph-orientation-vertical"],
		["horizAdvX", "horiz-adv-x"],
		["horizOriginX", "horiz-origin-x"],
		["imageRendering", "image-rendering"],
		["letterSpacing", "letter-spacing"],
		["lightingColor", "lighting-color"],
		["markerEnd", "marker-end"],
		["markerMid", "marker-mid"],
		["markerStart", "marker-start"],
		["overlinePosition", "overline-position"],
		["overlineThickness", "overline-thickness"],
		["paintOrder", "paint-order"],
		["panose-1", "panose-1"],
		["pointerEvents", "pointer-events"],
		["renderingIntent", "rendering-intent"],
		["shapeRendering", "shape-rendering"],
		["stopColor", "stop-color"],
		["stopOpacity", "stop-opacity"],
		["strikethroughPosition", "strikethrough-position"],
		["strikethroughThickness", "strikethrough-thickness"],
		["strokeDasharray", "stroke-dasharray"],
		["strokeDashoffset", "stroke-dashoffset"],
		["strokeLinecap", "stroke-linecap"],
		["strokeLinejoin", "stroke-linejoin"],
		["strokeMiterlimit", "stroke-miterlimit"],
		["strokeOpacity", "stroke-opacity"],
		["strokeWidth", "stroke-width"],
		["textAnchor", "text-anchor"],
		["textDecoration", "text-decoration"],
		["textRendering", "text-rendering"],
		["transformOrigin", "transform-origin"],
		["underlinePosition", "underline-position"],
		["underlineThickness", "underline-thickness"],
		["unicodeBidi", "unicode-bidi"],
		["unicodeRange", "unicode-range"],
		["unitsPerEm", "units-per-em"],
		["vAlphabetic", "v-alphabetic"],
		["vHanging", "v-hanging"],
		["vIdeographic", "v-ideographic"],
		["vMathematical", "v-mathematical"],
		["vectorEffect", "vector-effect"],
		["vertAdvY", "vert-adv-y"],
		["vertOriginX", "vert-origin-x"],
		["vertOriginY", "vert-origin-y"],
		["wordSpacing", "word-spacing"],
		["writingMode", "writing-mode"],
		["xmlnsXlink", "xmlns:xlink"],
		["xHeight", "x-height"]
	]), ue = /["'&<>]/;
	function V(e) {
		if (typeof e == "boolean" || typeof e == "number" || typeof e == "bigint") return "" + e;
		e = "" + e;
		var t = ue.exec(e);
		if (t) {
			var n = "", r, i = 0;
			for (r = t.index; r < e.length; r++) {
				switch (e.charCodeAt(r)) {
					case 34:
						t = "&quot;";
						break;
					case 38:
						t = "&amp;";
						break;
					case 39:
						t = "&#x27;";
						break;
					case 60:
						t = "&lt;";
						break;
					case 62:
						t = "&gt;";
						break;
					default: continue;
				}
				i !== r && (n += e.slice(i, r)), i = r + 1, n += t;
			}
			e = i === r ? n : n + e.slice(i, r);
		}
		return e;
	}
	var de = /([A-Z])/g, fe = /^ms-/, pe = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
	function me(e) {
		return pe.test("" + e) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : e;
	}
	var he = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, ge = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, _e = {
		pending: !1,
		data: null,
		method: null,
		action: null
	}, ve = ge.d;
	ge.d = {
		f: ve.f,
		r: ve.r,
		D: ur,
		C: dr,
		L: fr,
		m: pr,
		X: hr,
		S: mr,
		M: gr
	};
	var ye = [], be = null;
	L("\"></template>");
	var xe = L("<script"), H = L("<\/script>"), Se = L("<script src=\""), Ce = L("<script type=\"module\" src=\""), we = L(" nonce=\""), Te = L(" integrity=\""), Ee = L(" crossorigin=\""), De = L(" async=\"\"><\/script>"), Oe = L("<style"), ke = /(<\/|<)(s)(cript)/gi;
	function Ae(e, t, n, r) {
		return "" + t + (n === "s" ? "\\u0073" : "\\u0053") + r;
	}
	var je = L("<script type=\"importmap\">"), Me = L("<\/script>");
	function Ne(e, t, n, r, i, a) {
		n = typeof t == "string" ? t : t && t.script;
		var o = n === void 0 ? xe : L("<script nonce=\"" + V(n) + "\""), s = typeof t == "string" ? void 0 : t && t.style, c = s === void 0 ? Oe : L("<style nonce=\"" + V(s) + "\""), l = e.idPrefix, u = [], d = e.bootstrapScriptContent, f = e.bootstrapScripts, p = e.bootstrapModules;
		if (d !== void 0 && (u.push(o), nr(u, e), u.push(J, I(("" + d).replace(ke, Ae)), H)), d = [], r !== void 0 && (d.push(je), d.push(I(("" + JSON.stringify(r)).replace(ke, Ae))), d.push(Me)), r = i ? {
			preconnects: "",
			fontPreloads: "",
			highImagePreloads: "",
			remainingCapacity: 2 + (typeof a == "number" ? a : 2e3)
		} : null, i = {
			placeholderPrefix: L(l + "P:"),
			segmentPrefix: L(l + "S:"),
			boundaryPrefix: L(l + "B:"),
			startInlineScript: o,
			startInlineStyle: c,
			preamble: U(),
			externalRuntimeScript: null,
			bootstrapChunks: u,
			importMapChunks: d,
			onHeaders: i,
			headers: r,
			resets: {
				font: {},
				dns: {},
				connect: {
					default: {},
					anonymous: {},
					credentials: {}
				},
				image: {},
				style: {}
			},
			charsetChunks: [],
			viewportChunks: [],
			hoistableChunks: [],
			preconnects: /* @__PURE__ */ new Set(),
			fontPreloads: /* @__PURE__ */ new Set(),
			highImagePreloads: /* @__PURE__ */ new Set(),
			styles: /* @__PURE__ */ new Map(),
			bootstrapScripts: /* @__PURE__ */ new Set(),
			scripts: /* @__PURE__ */ new Set(),
			bulkPreloads: /* @__PURE__ */ new Set(),
			preloads: {
				images: /* @__PURE__ */ new Map(),
				stylesheets: /* @__PURE__ */ new Map(),
				scripts: /* @__PURE__ */ new Map(),
				moduleScripts: /* @__PURE__ */ new Map()
			},
			nonce: {
				script: n,
				style: s
			},
			hoistableState: null,
			stylesToHoist: !1
		}, f !== void 0) for (r = 0; r < f.length; r++) l = f[r], s = o = void 0, c = {
			rel: "preload",
			as: "script",
			fetchPriority: "low",
			nonce: t
		}, typeof l == "string" ? c.href = a = l : (c.href = a = l.src, c.integrity = s = typeof l.integrity == "string" ? l.integrity : void 0, c.crossOrigin = o = typeof l == "string" || l.crossOrigin == null ? void 0 : l.crossOrigin === "use-credentials" ? "use-credentials" : ""), l = e, d = a, l.scriptResources[d] = null, l.moduleScriptResources[d] = null, l = [], dt(l, c), i.bootstrapScripts.add(l), u.push(Se, I(V(a)), G), n && u.push(we, I(V(n)), G), typeof s == "string" && u.push(Te, I(V(s)), G), typeof o == "string" && u.push(Ee, I(V(o)), G), nr(u, e), u.push(De);
		if (p !== void 0) for (t = 0; t < p.length; t++) s = p[t], a = r = void 0, o = {
			rel: "modulepreload",
			fetchPriority: "low",
			nonce: n
		}, typeof s == "string" ? o.href = f = s : (o.href = f = s.src, o.integrity = a = typeof s.integrity == "string" ? s.integrity : void 0, o.crossOrigin = r = typeof s == "string" || s.crossOrigin == null ? void 0 : s.crossOrigin === "use-credentials" ? "use-credentials" : ""), s = e, c = f, s.scriptResources[c] = null, s.moduleScriptResources[c] = null, s = [], dt(s, o), i.bootstrapScripts.add(s), u.push(Ce, I(V(f)), G), n && u.push(we, I(V(n)), G), typeof a == "string" && u.push(Te, I(V(a)), G), typeof r == "string" && u.push(Ee, I(V(r)), G), nr(u, e), u.push(De);
		return i;
	}
	function Pe(e, t, n, r, i) {
		return {
			idPrefix: e === void 0 ? "" : e,
			nextFormID: 0,
			streamingFormat: 0,
			bootstrapScriptContent: n,
			bootstrapScripts: r,
			bootstrapModules: i,
			instructions: 0,
			hasBody: !1,
			hasHtml: !1,
			unknownResources: {},
			dnsResources: {},
			connectResources: {
				default: {},
				anonymous: {},
				credentials: {}
			},
			imageResources: {},
			styleResources: {},
			scriptResources: {},
			moduleUnknownResources: {},
			moduleScriptResources: {}
		};
	}
	function U() {
		return {
			htmlChunks: null,
			headChunks: null,
			bodyChunks: null
		};
	}
	function W(e, t, n, r) {
		return {
			insertionMode: e,
			selectedValue: t,
			tagScope: n,
			viewTransition: r
		};
	}
	function Fe(e) {
		return W(e === "http://www.w3.org/2000/svg" ? 4 : e === "http://www.w3.org/1998/Math/MathML" ? 5 : 0, null, 0, null);
	}
	function Ie(e, t, n) {
		var r = e.tagScope & -25;
		switch (t) {
			case "noscript": return W(2, null, r | 1, null);
			case "select": return W(2, n.value == null ? n.defaultValue : n.value, r, null);
			case "svg": return W(4, null, r, null);
			case "picture": return W(2, null, r | 2, null);
			case "math": return W(5, null, r, null);
			case "foreignObject": return W(2, null, r, null);
			case "table": return W(6, null, r, null);
			case "thead":
			case "tbody":
			case "tfoot": return W(7, null, r, null);
			case "colgroup": return W(9, null, r, null);
			case "tr": return W(8, null, r, null);
			case "head":
				if (2 > e.insertionMode) return W(3, null, r, null);
				break;
			case "html": if (e.insertionMode === 0) return W(1, null, r, null);
		}
		return 6 <= e.insertionMode || 2 > e.insertionMode ? W(2, null, r, null) : e.tagScope === r ? e : W(e.insertionMode, e.selectedValue, r, null);
	}
	function Le(e) {
		return e === null ? null : {
			update: e.update,
			enter: "none",
			exit: "none",
			share: e.update,
			name: e.autoName,
			autoName: e.autoName,
			nameIdx: 0
		};
	}
	function Re(e, t) {
		return t.tagScope & 32 && (e.instructions |= 128), W(t.insertionMode, t.selectedValue, t.tagScope | 12, Le(t.viewTransition));
	}
	function ze(e, t) {
		e = Le(t.viewTransition);
		var n = t.tagScope | 16;
		return e !== null && e.share !== "none" && (n |= 64), W(t.insertionMode, t.selectedValue, n, e);
	}
	var Be = L("<!-- -->");
	function Ve(e, t, n, r) {
		return t === "" ? r : (r && e.push(Be), e.push(I(V(t))), !0);
	}
	var He = /* @__PURE__ */ new Map(), Ue = L(" style=\""), We = L(":"), Ge = L(";");
	function Ke(e, t) {
		if (typeof t != "object") throw Error(i(62));
		var n = !0, r;
		for (r in t) if (z.call(t, r)) {
			var a = t[r];
			if (a != null && typeof a != "boolean" && a !== "") {
				if (r.indexOf("--") === 0) {
					var o = I(V(r));
					a = I(V(("" + a).trim()));
				} else o = He.get(r), o === void 0 && (o = L(V(r.replace(de, "-$1").toLowerCase().replace(fe, "-ms-"))), He.set(r, o)), a = typeof a == "number" ? a === 0 || le.has(r) ? I("" + a) : I(a + "px") : I(V(("" + a).trim()));
				n ? (n = !1, e.push(Ue, o, We, a)) : e.push(Ge, o, We, a);
			}
		}
		n || e.push(G);
	}
	var qe = L(" "), Je = L("=\""), G = L("\""), Ye = L("=\"\"");
	function Xe(e, t, n) {
		n && typeof n != "function" && typeof n != "symbol" && e.push(qe, I(t), Ye);
	}
	function K(e, t, n) {
		typeof n != "function" && typeof n != "symbol" && typeof n != "boolean" && e.push(qe, I(t), Je, I(V(n)), G);
	}
	var Ze = L(V("javascript:throw new Error('React form unexpectedly submitted.')")), Qe = L("<input type=\"hidden\"");
	function $e(e, t) {
		this.push(Qe), et(e), K(this, "name", t), K(this, "value", e), this.push(rt);
	}
	function et(e) {
		if (typeof e != "string") throw Error(i(480));
	}
	function tt(e, t) {
		if (typeof t.$$FORM_ACTION == "function") {
			var n = e.nextFormID++;
			e = e.idPrefix + n;
			try {
				var r = t.$$FORM_ACTION(e);
				return r && r.data?.forEach(et), r;
			} catch (e) {
				if (typeof e == "object" && e && typeof e.then == "function") throw e;
			}
		}
		return null;
	}
	function nt(e, t, n, r, i, a, o, s) {
		var c = null;
		if (typeof r == "function") {
			var l = tt(t, r);
			l === null ? (e.push(qe, I("formAction"), Je, Ze, G), o = a = i = r = s = null, ct(t, n)) : (s = l.name, r = l.action || "", i = l.encType, a = l.method, o = l.target, c = l.data);
		}
		return s != null && q(e, "name", s), r != null && q(e, "formAction", r), i != null && q(e, "formEncType", i), a != null && q(e, "formMethod", a), o != null && q(e, "formTarget", o), c;
	}
	function q(e, t, n) {
		switch (t) {
			case "className":
				K(e, "class", n);
				break;
			case "tabIndex":
				K(e, "tabindex", n);
				break;
			case "dir":
			case "role":
			case "viewBox":
			case "width":
			case "height":
				K(e, t, n);
				break;
			case "style":
				Ke(e, n);
				break;
			case "src":
			case "href": if (n === "") break;
			case "action":
			case "formAction":
				if (n == null || typeof n == "function" || typeof n == "symbol" || typeof n == "boolean") break;
				n = me("" + n), e.push(qe, I(t), Je, I(V(n)), G);
				break;
			case "defaultValue":
			case "defaultChecked":
			case "innerHTML":
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "ref": break;
			case "autoFocus":
			case "multiple":
			case "muted":
				Xe(e, t.toLowerCase(), n);
				break;
			case "xlinkHref":
				if (typeof n == "function" || typeof n == "symbol" || typeof n == "boolean") break;
				n = me("" + n), e.push(qe, I("xlink:href"), Je, I(V(n)), G);
				break;
			case "contentEditable":
			case "spellCheck":
			case "draggable":
			case "value":
			case "autoReverse":
			case "externalResourcesRequired":
			case "focusable":
			case "preserveAlpha":
				typeof n != "function" && typeof n != "symbol" && e.push(qe, I(t), Je, I(V(n)), G);
				break;
			case "inert":
			case "allowFullScreen":
			case "async":
			case "autoPlay":
			case "controls":
			case "default":
			case "defer":
			case "disabled":
			case "disablePictureInPicture":
			case "disableRemotePlayback":
			case "formNoValidate":
			case "hidden":
			case "loop":
			case "noModule":
			case "noValidate":
			case "open":
			case "playsInline":
			case "readOnly":
			case "required":
			case "reversed":
			case "scoped":
			case "seamless":
			case "itemScope":
				n && typeof n != "function" && typeof n != "symbol" && e.push(qe, I(t), Ye);
				break;
			case "capture":
			case "download":
				!0 === n ? e.push(qe, I(t), Ye) : !1 !== n && typeof n != "function" && typeof n != "symbol" && e.push(qe, I(t), Je, I(V(n)), G);
				break;
			case "cols":
			case "rows":
			case "size":
			case "span":
				typeof n != "function" && typeof n != "symbol" && !isNaN(n) && 1 <= n && e.push(qe, I(t), Je, I(V(n)), G);
				break;
			case "rowSpan":
			case "start":
				typeof n == "function" || typeof n == "symbol" || isNaN(n) || e.push(qe, I(t), Je, I(V(n)), G);
				break;
			case "xlinkActuate":
				K(e, "xlink:actuate", n);
				break;
			case "xlinkArcrole":
				K(e, "xlink:arcrole", n);
				break;
			case "xlinkRole":
				K(e, "xlink:role", n);
				break;
			case "xlinkShow":
				K(e, "xlink:show", n);
				break;
			case "xlinkTitle":
				K(e, "xlink:title", n);
				break;
			case "xlinkType":
				K(e, "xlink:type", n);
				break;
			case "xmlBase":
				K(e, "xml:base", n);
				break;
			case "xmlLang":
				K(e, "xml:lang", n);
				break;
			case "xmlSpace":
				K(e, "xml:space", n);
				break;
			default: if ((!(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (t = B.get(t) || t, ce(t))) {
				switch (typeof n) {
					case "function":
					case "symbol": return;
					case "boolean":
						var r = t.toLowerCase().slice(0, 5);
						if (r !== "data-" && r !== "aria-") return;
				}
				e.push(qe, I(t), Je, I(V(n)), G);
			}
		}
	}
	var J = L(">"), rt = L("/>");
	function it(e, t, n) {
		if (t != null) {
			if (n != null) throw Error(i(60));
			if (typeof t != "object" || !("__html" in t)) throw Error(i(61));
			t = t.__html, t != null && e.push(I("" + t));
		}
	}
	function at(e) {
		var n = "";
		return t.Children.forEach(e, function(e) {
			e != null && (n += e);
		}), n;
	}
	var ot = L(" selected=\"\""), st = L("addEventListener(\"submit\",function(a){if(!a.defaultPrevented){var c=a.target,d=a.submitter,e=c.action,b=d;if(d){var f=d.getAttribute(\"formAction\");null!=f&&(e=f,b=null)}\"javascript:throw new Error('React form unexpectedly submitted.')\"===e&&(a.preventDefault(),b?(a=document.createElement(\"input\"),a.name=b.name,a.value=b.value,b.parentNode.insertBefore(a,b),b=new FormData(c),a.parentNode.removeChild(a)):b=new FormData(c),a=c.ownerDocument||c,(a.$$reactFormReplay=a.$$reactFormReplay||[]).push(c,d,b))}});");
	function ct(e, t) {
		if (!(e.instructions & 16)) {
			e.instructions |= 16;
			var n = t.preamble, r = t.bootstrapChunks;
			(n.htmlChunks || n.headChunks) && r.length === 0 ? (r.push(t.startInlineScript), nr(r, e), r.push(J, st, H)) : r.unshift(t.startInlineScript, J, st, H);
		}
	}
	var lt = L("<!--F!-->"), ut = L("<!--F-->");
	function dt(e, t) {
		for (var n in e.push(Tt("link")), t) if (z.call(t, n)) {
			var r = t[n];
			if (r != null) switch (n) {
				case "children":
				case "dangerouslySetInnerHTML": throw Error(i(399, "link"));
				default: q(e, n, r);
			}
		}
		return e.push(rt), null;
	}
	var ft = /(<\/|<)(s)(tyle)/gi;
	function pt(e, t, n, r) {
		return "" + t + (n === "s" ? "\\73 " : "\\53 ") + r;
	}
	function mt(e, t, n) {
		for (var r in e.push(Tt(n)), t) if (z.call(t, r)) {
			var a = t[r];
			if (a != null) switch (r) {
				case "children":
				case "dangerouslySetInnerHTML": throw Error(i(399, n));
				default: q(e, r, a);
			}
		}
		return e.push(rt), null;
	}
	function ht(e, t) {
		e.push(Tt("title"));
		var n = null, r = null, i;
		for (i in t) if (z.call(t, i)) {
			var a = t[i];
			if (a != null) switch (i) {
				case "children":
					n = a;
					break;
				case "dangerouslySetInnerHTML":
					r = a;
					break;
				default: q(e, i, a);
			}
		}
		return e.push(J), t = Array.isArray(n) ? 2 > n.length ? n[0] : null : n, typeof t != "function" && typeof t != "symbol" && t != null && e.push(I(V("" + t))), it(e, r, n), e.push(kt("title")), null;
	}
	var gt = L("<!--head-->"), _t = L("<!--body-->"), vt = L("<!--html-->");
	function yt(e, t) {
		e.push(Tt("script"));
		var n = null, r = null, i;
		for (i in t) if (z.call(t, i)) {
			var a = t[i];
			if (a != null) switch (i) {
				case "children":
					n = a;
					break;
				case "dangerouslySetInnerHTML":
					r = a;
					break;
				default: q(e, i, a);
			}
		}
		return e.push(J), it(e, r, n), typeof n == "string" && e.push(I(("" + n).replace(ke, Ae))), e.push(kt("script")), null;
	}
	function bt(e, t, n) {
		e.push(Tt(n));
		var r = n = null, i;
		for (i in t) if (z.call(t, i)) {
			var a = t[i];
			if (a != null) switch (i) {
				case "children":
					n = a;
					break;
				case "dangerouslySetInnerHTML":
					r = a;
					break;
				default: q(e, i, a);
			}
		}
		return e.push(J), it(e, r, n), n;
	}
	function xt(e, t, n) {
		e.push(Tt(n));
		var r = n = null, i;
		for (i in t) if (z.call(t, i)) {
			var a = t[i];
			if (a != null) switch (i) {
				case "children":
					n = a;
					break;
				case "dangerouslySetInnerHTML":
					r = a;
					break;
				default: q(e, i, a);
			}
		}
		return e.push(J), it(e, r, n), typeof n == "string" ? (e.push(I(V(n))), null) : n;
	}
	var St = L("\n"), Ct = /^[a-zA-Z][a-zA-Z:_\.\-\d]*$/, wt = /* @__PURE__ */ new Map();
	function Tt(e) {
		var t = wt.get(e);
		if (t === void 0) {
			if (!Ct.test(e)) throw Error(i(65, e));
			t = L("<" + e), wt.set(e, t);
		}
		return t;
	}
	var Et = L("<!DOCTYPE html>");
	function Dt(e, t, n, r, a, o, s, c, l) {
		switch (t) {
			case "div":
			case "span":
			case "svg":
			case "path": break;
			case "a":
				e.push(Tt("a"));
				var u = null, d = null, f;
				for (f in n) if (z.call(n, f)) {
					var p = n[f];
					if (p != null) switch (f) {
						case "children":
							u = p;
							break;
						case "dangerouslySetInnerHTML":
							d = p;
							break;
						case "href":
							p === "" ? K(e, "href", "") : q(e, f, p);
							break;
						default: q(e, f, p);
					}
				}
				if (e.push(J), it(e, d, u), typeof u == "string") {
					e.push(I(V(u)));
					var m = null;
				} else m = u;
				return m;
			case "g":
			case "p":
			case "li": break;
			case "select":
				e.push(Tt("select"));
				var h = null, g = null, _;
				for (_ in n) if (z.call(n, _)) {
					var v = n[_];
					if (v != null) switch (_) {
						case "children":
							h = v;
							break;
						case "dangerouslySetInnerHTML":
							g = v;
							break;
						case "defaultValue":
						case "value": break;
						default: q(e, _, v);
					}
				}
				return e.push(J), it(e, g, h), h;
			case "option":
				var y = c.selectedValue;
				e.push(Tt("option"));
				var b = null, x = null, S = null, C = null, w;
				for (w in n) if (z.call(n, w)) {
					var E = n[w];
					if (E != null) switch (w) {
						case "children":
							b = E;
							break;
						case "selected":
							S = E;
							break;
						case "dangerouslySetInnerHTML":
							C = E;
							break;
						case "value": x = E;
						default: q(e, w, E);
					}
				}
				if (y != null) {
					var D = x === null ? at(b) : "" + x;
					if (T(y)) {
						for (var O = 0; O < y.length; O++) if ("" + y[O] === D) {
							e.push(ot);
							break;
						}
					} else "" + y === D && e.push(ot);
				} else S && e.push(ot);
				return e.push(J), it(e, C, b), b;
			case "textarea":
				e.push(Tt("textarea"));
				var k = null, A = null, j = null, ee;
				for (ee in n) if (z.call(n, ee)) {
					var M = n[ee];
					if (M != null) switch (ee) {
						case "children":
							j = M;
							break;
						case "value":
							k = M;
							break;
						case "defaultValue":
							A = M;
							break;
						case "dangerouslySetInnerHTML": throw Error(i(91));
						default: q(e, ee, M);
					}
				}
				if (k === null && A !== null && (k = A), e.push(J), j != null) {
					if (k != null) throw Error(i(92));
					if (T(j)) {
						if (1 < j.length) throw Error(i(93));
						k = "" + j[0];
					}
					k = "" + j;
				}
				return typeof k == "string" && k[0] === "\n" && e.push(St), k !== null && e.push(I(V("" + k))), null;
			case "input":
				e.push(Tt("input"));
				var N = null, P = null, F = null, te = null, ne = null, L = null, re = null, ie = null, ae = null, oe;
				for (oe in n) if (z.call(n, oe)) {
					var se = n[oe];
					if (se != null) switch (oe) {
						case "children":
						case "dangerouslySetInnerHTML": throw Error(i(399, "input"));
						case "name":
							N = se;
							break;
						case "formAction":
							P = se;
							break;
						case "formEncType":
							F = se;
							break;
						case "formMethod":
							te = se;
							break;
						case "formTarget":
							ne = se;
							break;
						case "defaultChecked":
							ae = se;
							break;
						case "defaultValue":
							re = se;
							break;
						case "checked":
							ie = se;
							break;
						case "value":
							L = se;
							break;
						default: q(e, oe, se);
					}
				}
				var le = nt(e, r, a, P, F, te, ne, N);
				return ie === null ? ae !== null && Xe(e, "checked", ae) : Xe(e, "checked", ie), L === null ? re !== null && q(e, "value", re) : q(e, "value", L), e.push(rt), le?.forEach($e, e), null;
			case "button":
				e.push(Tt("button"));
				var B = null, ue = null, de = null, fe = null, pe = null, he = null, ge = null, _e;
				for (_e in n) if (z.call(n, _e)) {
					var ve = n[_e];
					if (ve != null) switch (_e) {
						case "children":
							B = ve;
							break;
						case "dangerouslySetInnerHTML":
							ue = ve;
							break;
						case "name":
							de = ve;
							break;
						case "formAction":
							fe = ve;
							break;
						case "formEncType":
							pe = ve;
							break;
						case "formMethod":
							he = ve;
							break;
						case "formTarget":
							ge = ve;
							break;
						default: q(e, _e, ve);
					}
				}
				var be = nt(e, r, a, fe, pe, he, ge, de);
				if (e.push(J), be?.forEach($e, e), it(e, ue, B), typeof B == "string") {
					e.push(I(V(B)));
					var xe = null;
				} else xe = B;
				return xe;
			case "form":
				e.push(Tt("form"));
				var H = null, Se = null, Ce = null, we = null, Te = null, Ee = null, De;
				for (De in n) if (z.call(n, De)) {
					var Oe = n[De];
					if (Oe != null) switch (De) {
						case "children":
							H = Oe;
							break;
						case "dangerouslySetInnerHTML":
							Se = Oe;
							break;
						case "action":
							Ce = Oe;
							break;
						case "encType":
							we = Oe;
							break;
						case "method":
							Te = Oe;
							break;
						case "target":
							Ee = Oe;
							break;
						default: q(e, De, Oe);
					}
				}
				var ke = null, Ae = null;
				if (typeof Ce == "function") {
					var je = tt(r, Ce);
					je === null ? (e.push(qe, I("action"), Je, Ze, G), Ee = Te = we = Ce = null, ct(r, a)) : (Ce = je.action || "", we = je.encType, Te = je.method, Ee = je.target, ke = je.data, Ae = je.name);
				}
				if (Ce != null && q(e, "action", Ce), we != null && q(e, "encType", we), Te != null && q(e, "method", Te), Ee != null && q(e, "target", Ee), e.push(J), Ae !== null && (e.push(Qe), K(e, "name", Ae), e.push(rt), ke?.forEach($e, e)), it(e, Se, H), typeof H == "string") {
					e.push(I(V(H)));
					var Me = null;
				} else Me = H;
				return Me;
			case "menuitem":
				for (var Ne in e.push(Tt("menuitem")), n) if (z.call(n, Ne)) {
					var Pe = n[Ne];
					if (Pe != null) switch (Ne) {
						case "children":
						case "dangerouslySetInnerHTML": throw Error(i(400));
						default: q(e, Ne, Pe);
					}
				}
				return e.push(J), null;
			case "object":
				e.push(Tt("object"));
				var U = null, W = null, Fe;
				for (Fe in n) if (z.call(n, Fe)) {
					var Ie = n[Fe];
					if (Ie != null) switch (Fe) {
						case "children":
							U = Ie;
							break;
						case "dangerouslySetInnerHTML":
							W = Ie;
							break;
						case "data":
							var Le = me("" + Ie);
							if (Le === "") break;
							e.push(qe, I("data"), Je, I(V(Le)), G);
							break;
						default: q(e, Fe, Ie);
					}
				}
				if (e.push(J), it(e, W, U), typeof U == "string") {
					e.push(I(V(U)));
					var Re = null;
				} else Re = U;
				return Re;
			case "title":
				var ze = c.tagScope & 1, Ve = c.tagScope & 4;
				if (c.insertionMode === 4 || ze || n.itemProp != null) var He = ht(e, n);
				else Ve ? He = null : (ht(a.hoistableChunks, n), He = void 0);
				return He;
			case "link":
				var Ue = c.tagScope & 1, We = c.tagScope & 4, Ge = n.rel, Ye = n.href, et = n.precedence;
				if (c.insertionMode === 4 || Ue || n.itemProp != null || typeof Ge != "string" || typeof Ye != "string" || Ye === "") {
					dt(e, n);
					var st = null;
				} else if (n.rel === "stylesheet") {
					if (typeof et != "string" || n.disabled != null || n.onLoad || n.onError) st = dt(e, n);
					else {
						var lt = a.styles.get(et), ut = r.styleResources.hasOwnProperty(Ye) ? r.styleResources[Ye] : void 0;
						if (ut !== null) {
							r.styleResources[Ye] = null, lt || (lt = {
								precedence: I(V(et)),
								rules: [],
								hrefs: [],
								sheets: /* @__PURE__ */ new Map()
							}, a.styles.set(et, lt));
							var Ct = {
								state: 0,
								props: R({}, n, {
									"data-precedence": n.precedence,
									precedence: null
								})
							};
							if (ut) {
								ut.length === 2 && _r(Ct.props, ut);
								var wt = a.preloads.stylesheets.get(Ye);
								wt && 0 < wt.length ? wt.length = 0 : Ct.state = 1;
							}
							lt.sheets.set(Ye, Ct), s && s.stylesheets.add(Ct);
						} else if (lt) {
							var Dt = lt.sheets.get(Ye);
							Dt && s && s.stylesheets.add(Dt);
						}
						l && e.push(Be), st = null;
					}
				} else n.onLoad || n.onError ? st = dt(e, n) : (l && e.push(Be), st = We ? null : dt(a.hoistableChunks, n));
				return st;
			case "script":
				var Ot = c.tagScope & 1, At = n.async;
				if (typeof n.src != "string" || !n.src || !At || typeof At == "function" || typeof At == "symbol" || n.onLoad || n.onError || c.insertionMode === 4 || Ot || n.itemProp != null) var jt = yt(e, n);
				else {
					var Mt = n.src;
					if (n.type === "module") var Nt = r.moduleScriptResources, Pt = a.preloads.moduleScripts;
					else Nt = r.scriptResources, Pt = a.preloads.scripts;
					var Ft = Nt.hasOwnProperty(Mt) ? Nt[Mt] : void 0;
					if (Ft !== null) {
						Nt[Mt] = null;
						var It = n;
						if (Ft) {
							Ft.length === 2 && (It = R({}, n), _r(It, Ft));
							var Lt = Pt.get(Mt);
							Lt && (Lt.length = 0);
						}
						var Rt = [];
						a.scripts.add(Rt), yt(Rt, It);
					}
					l && e.push(Be), jt = null;
				}
				return jt;
			case "style":
				var zt = c.tagScope & 1, Y = n.precedence, Bt = n.href, Vt = n.nonce;
				if (c.insertionMode === 4 || zt || n.itemProp != null || typeof Y != "string" || typeof Bt != "string" || Bt === "") {
					e.push(Tt("style"));
					var Ht = null, Ut = null, Wt;
					for (Wt in n) if (z.call(n, Wt)) {
						var Gt = n[Wt];
						if (Gt != null) switch (Wt) {
							case "children":
								Ht = Gt;
								break;
							case "dangerouslySetInnerHTML":
								Ut = Gt;
								break;
							default: q(e, Wt, Gt);
						}
					}
					e.push(J);
					var Kt = Array.isArray(Ht) ? 2 > Ht.length ? Ht[0] : null : Ht;
					typeof Kt != "function" && typeof Kt != "symbol" && Kt != null && e.push(I(("" + Kt).replace(ft, pt))), it(e, Ut, Ht), e.push(kt("style"));
					var qt = null;
				} else {
					var Jt = a.styles.get(Y);
					if ((r.styleResources.hasOwnProperty(Bt) ? r.styleResources[Bt] : void 0) !== null) {
						r.styleResources[Bt] = null, Jt || (Jt = {
							precedence: I(V(Y)),
							rules: [],
							hrefs: [],
							sheets: /* @__PURE__ */ new Map()
						}, a.styles.set(Y, Jt));
						var Yt = a.nonce.style;
						if (!Yt || Yt === Vt) {
							Jt.hrefs.push(I(V(Bt)));
							var Xt = Jt.rules, X = null, Zt = null, Qt;
							for (Qt in n) if (z.call(n, Qt)) {
								var Z = n[Qt];
								if (Z != null) switch (Qt) {
									case "children":
										X = Z;
										break;
									case "dangerouslySetInnerHTML": Zt = Z;
								}
							}
							var $t = Array.isArray(X) ? 2 > X.length ? X[0] : null : X;
							typeof $t != "function" && typeof $t != "symbol" && $t != null && Xt.push(I(("" + $t).replace(ft, pt))), it(Xt, Zt, X);
						}
					}
					Jt && s && s.styles.add(Jt), l && e.push(Be), qt = void 0;
				}
				return qt;
			case "meta":
				var en = c.tagScope & 1, tn = c.tagScope & 4;
				if (c.insertionMode === 4 || en || n.itemProp != null) var nn = mt(e, n, "meta");
				else l && e.push(Be), nn = tn ? null : typeof n.charSet == "string" ? mt(a.charsetChunks, n, "meta") : n.name === "viewport" ? mt(a.viewportChunks, n, "meta") : mt(a.hoistableChunks, n, "meta");
				return nn;
			case "listing":
			case "pre":
				e.push(Tt(t));
				var rn = null, an = null, on;
				for (on in n) if (z.call(n, on)) {
					var sn = n[on];
					if (sn != null) switch (on) {
						case "children":
							rn = sn;
							break;
						case "dangerouslySetInnerHTML":
							an = sn;
							break;
						default: q(e, on, sn);
					}
				}
				if (e.push(J), an != null) {
					if (rn != null) throw Error(i(60));
					if (typeof an != "object" || !("__html" in an)) throw Error(i(61));
					var cn = an.__html;
					cn != null && (typeof cn == "string" && 0 < cn.length && cn[0] === "\n" ? e.push(St, I(cn)) : e.push(I("" + cn)));
				}
				return typeof rn == "string" && rn[0] === "\n" && e.push(St), rn;
			case "img":
				var ln = c.tagScope & 3, un = n.src, dn = n.srcSet;
				if (!(n.loading === "lazy" || !un && !dn || typeof un != "string" && un != null || typeof dn != "string" && dn != null || n.fetchPriority === "low" || ln) && (typeof un != "string" || un[4] !== ":" || un[0] !== "d" && un[0] !== "D" || un[1] !== "a" && un[1] !== "A" || un[2] !== "t" && un[2] !== "T" || un[3] !== "a" && un[3] !== "A") && (typeof dn != "string" || dn[4] !== ":" || dn[0] !== "d" && dn[0] !== "D" || dn[1] !== "a" && dn[1] !== "A" || dn[2] !== "t" && dn[2] !== "T" || dn[3] !== "a" && dn[3] !== "A")) {
					s !== null && c.tagScope & 64 && (s.suspenseyImages = !0);
					var fn = typeof n.sizes == "string" ? n.sizes : void 0, pn = dn ? dn + "\n" + (fn || "") : un, mn = a.preloads.images, hn = mn.get(pn);
					if (hn) (n.fetchPriority === "high" || 10 > a.highImagePreloads.size) && (mn.delete(pn), a.highImagePreloads.add(hn));
					else if (!r.imageResources.hasOwnProperty(pn)) {
						r.imageResources[pn] = ye;
						var gn = n.crossOrigin, _n = typeof gn == "string" ? gn === "use-credentials" ? gn : "" : void 0, vn = a.headers, yn;
						vn && 0 < vn.remainingCapacity && typeof n.srcSet != "string" && (n.fetchPriority === "high" || 500 > vn.highImagePreloads.length) && (yn = vr(un, "image", {
							imageSrcSet: n.srcSet,
							imageSizes: n.sizes,
							crossOrigin: _n,
							integrity: n.integrity,
							nonce: n.nonce,
							type: n.type,
							fetchPriority: n.fetchPriority,
							referrerPolicy: n.refererPolicy
						}), 0 <= (vn.remainingCapacity -= yn.length + 2)) ? (a.resets.image[pn] = ye, vn.highImagePreloads && (vn.highImagePreloads += ", "), vn.highImagePreloads += yn) : (hn = [], dt(hn, {
							rel: "preload",
							as: "image",
							href: dn ? void 0 : un,
							imageSrcSet: dn,
							imageSizes: fn,
							crossOrigin: _n,
							integrity: n.integrity,
							type: n.type,
							fetchPriority: n.fetchPriority,
							referrerPolicy: n.referrerPolicy
						}), n.fetchPriority === "high" || 10 > a.highImagePreloads.size ? a.highImagePreloads.add(hn) : (a.bulkPreloads.add(hn), mn.set(pn, hn)));
					}
				}
				return mt(e, n, "img");
			case "base":
			case "area":
			case "br":
			case "col":
			case "embed":
			case "hr":
			case "keygen":
			case "param":
			case "source":
			case "track":
			case "wbr": return mt(e, n, t);
			case "annotation-xml":
			case "color-profile":
			case "font-face":
			case "font-face-src":
			case "font-face-uri":
			case "font-face-format":
			case "font-face-name":
			case "missing-glyph": break;
			case "head":
				if (2 > c.insertionMode) {
					var bn = o || a.preamble;
					if (bn.headChunks) throw Error(i(545, "`<head>`"));
					o !== null && e.push(gt), bn.headChunks = [];
					var xn = bt(bn.headChunks, n, "head");
				} else xn = xt(e, n, "head");
				return xn;
			case "body":
				if (2 > c.insertionMode) {
					var Sn = o || a.preamble;
					if (Sn.bodyChunks) throw Error(i(545, "`<body>`"));
					o !== null && e.push(_t), Sn.bodyChunks = [];
					var Cn = bt(Sn.bodyChunks, n, "body");
				} else Cn = xt(e, n, "body");
				return Cn;
			case "html":
				if (c.insertionMode === 0) {
					var wn = o || a.preamble;
					if (wn.htmlChunks) throw Error(i(545, "`<html>`"));
					o !== null && e.push(vt), wn.htmlChunks = [Et];
					var Tn = bt(wn.htmlChunks, n, "html");
				} else Tn = xt(e, n, "html");
				return Tn;
			default: if (t.indexOf("-") !== -1) {
				e.push(Tt(t));
				var En = null, Dn = null, On;
				for (On in n) if (z.call(n, On)) {
					var kn = n[On];
					if (kn != null) {
						var An = On;
						switch (On) {
							case "children":
								En = kn;
								break;
							case "dangerouslySetInnerHTML":
								Dn = kn;
								break;
							case "style":
								Ke(e, kn);
								break;
							case "suppressContentEditableWarning":
							case "suppressHydrationWarning":
							case "ref": break;
							case "className": An = "class";
							default: if (ce(On) && typeof kn != "function" && typeof kn != "symbol" && !1 !== kn) {
								if (!0 === kn) kn = "";
								else if (typeof kn == "object") continue;
								e.push(qe, I(An), Je, I(V(kn)), G);
							}
						}
					}
				}
				return e.push(J), it(e, Dn, En), En;
			}
		}
		return xt(e, n, t);
	}
	var Ot = /* @__PURE__ */ new Map();
	function kt(e) {
		var t = Ot.get(e);
		return t === void 0 && (t = L("</" + e + ">"), Ot.set(e, t)), t;
	}
	function At(e, t) {
		e = e.preamble, e.htmlChunks === null && t.htmlChunks && (e.htmlChunks = t.htmlChunks), e.headChunks === null && t.headChunks && (e.headChunks = t.headChunks), e.bodyChunks === null && t.bodyChunks && (e.bodyChunks = t.bodyChunks);
	}
	function jt(e, t) {
		t = t.bootstrapChunks;
		for (var n = 0; n < t.length - 1; n++) P(e, t[n]);
		return n < t.length ? (n = t[n], t.length = 0, F(e, n)) : !0;
	}
	var Mt = L("requestAnimationFrame(function(){$RT=performance.now()});"), Nt = L("<template id=\""), Pt = L("\"></template>"), Ft = L("<!--&-->"), It = L("<!--/&-->"), Lt = L("<!--$-->"), Rt = L("<!--$?--><template id=\""), zt = L("\"></template>"), Y = L("<!--$!-->"), Bt = L("<!--/$-->"), Vt = L("<template"), Ht = L("\""), Ut = L(" data-dgst=\"");
	L(" data-msg=\""), L(" data-stck=\""), L(" data-cstck=\"");
	var Wt = L("></template>");
	function Gt(e, t, n) {
		if (P(e, Rt), n === null) throw Error(i(395));
		return P(e, t.boundaryPrefix), P(e, I(n.toString(16))), F(e, zt);
	}
	var Kt = L("<div hidden id=\""), qt = L("\">"), Jt = L("</div>"), Yt = L("<svg aria-hidden=\"true\" style=\"display:none\" id=\""), Xt = L("\">"), X = L("</svg>"), Zt = L("<math aria-hidden=\"true\" style=\"display:none\" id=\""), Qt = L("\">"), Z = L("</math>"), $t = L("<table hidden id=\""), en = L("\">"), tn = L("</table>"), nn = L("<table hidden><tbody id=\""), rn = L("\">"), an = L("</tbody></table>"), on = L("<table hidden><tr id=\""), sn = L("\">"), cn = L("</tr></table>"), ln = L("<table hidden><colgroup id=\""), un = L("\">"), dn = L("</colgroup></table>");
	function fn(e, t, n, r) {
		switch (n.insertionMode) {
			case 0:
			case 1:
			case 3:
			case 2: return P(e, Kt), P(e, t.segmentPrefix), P(e, I(r.toString(16))), F(e, qt);
			case 4: return P(e, Yt), P(e, t.segmentPrefix), P(e, I(r.toString(16))), F(e, Xt);
			case 5: return P(e, Zt), P(e, t.segmentPrefix), P(e, I(r.toString(16))), F(e, Qt);
			case 6: return P(e, $t), P(e, t.segmentPrefix), P(e, I(r.toString(16))), F(e, en);
			case 7: return P(e, nn), P(e, t.segmentPrefix), P(e, I(r.toString(16))), F(e, rn);
			case 8: return P(e, on), P(e, t.segmentPrefix), P(e, I(r.toString(16))), F(e, sn);
			case 9: return P(e, ln), P(e, t.segmentPrefix), P(e, I(r.toString(16))), F(e, un);
			default: throw Error(i(397));
		}
	}
	function pn(e, t) {
		switch (t.insertionMode) {
			case 0:
			case 1:
			case 3:
			case 2: return F(e, Jt);
			case 4: return F(e, X);
			case 5: return F(e, Z);
			case 6: return F(e, tn);
			case 7: return F(e, an);
			case 8: return F(e, cn);
			case 9: return F(e, dn);
			default: throw Error(i(397));
		}
	}
	var mn = L("$RS=function(a,b){a=document.getElementById(a);b=document.getElementById(b);for(a.parentNode.removeChild(a);a.firstChild;)b.parentNode.insertBefore(a.firstChild,b);b.parentNode.removeChild(b)};$RS(\""), hn = L("$RS(\""), gn = L("\",\""), _n = L("\")<\/script>");
	L("<template data-rsi=\"\" data-sid=\""), L("\" data-pid=\"");
	var vn = L("$RB=[];$RV=function(a){$RT=performance.now();for(var b=0;b<a.length;b+=2){var c=a[b],e=a[b+1];null!==e.parentNode&&e.parentNode.removeChild(e);var f=c.parentNode;if(f){var g=c.previousSibling,h=0;do{if(c&&8===c.nodeType){var d=c.data;if(\"/$\"===d||\"/&\"===d)if(0===h)break;else h--;else\"$\"!==d&&\"$?\"!==d&&\"$~\"!==d&&\"$!\"!==d&&\"&\"!==d||h++}d=c.nextSibling;f.removeChild(c);c=d}while(c);for(;e.firstChild;)f.insertBefore(e.firstChild,c);g.data=\"$\";g._reactRetry&&requestAnimationFrame(g._reactRetry)}}a.length=0};\n$RC=function(a,b){if(b=document.getElementById(b))(a=document.getElementById(a))?(a.previousSibling.data=\"$~\",$RB.push(a,b),2===$RB.length&&(\"number\"!==typeof $RT?requestAnimationFrame($RV.bind(null,$RB)):(a=performance.now(),setTimeout($RV.bind(null,$RB),2300>a&&2E3<a?2300-a:$RT+300-a)))):b.parentNode.removeChild(b)};");
	I("$RV=function(A,g){function k(a,b){var e=a.getAttribute(b);e&&(b=a.style,l.push(a,b.viewTransitionName,b.viewTransitionClass),\"auto\"!==e&&(b.viewTransitionClass=e),(a=a.getAttribute(\"vt-name\"))||(a=\"_T_\"+K++ +\"_\"),b.viewTransitionName=a,B=!0)}var B=!1,K=0,l=[];try{var f=document.__reactViewTransition;if(f){f.finished.finally($RV.bind(null,g));return}var m=new Map;for(f=1;f<g.length;f+=2)for(var h=g[f].querySelectorAll(\"[vt-share]\"),d=0;d<h.length;d++){var c=h[d];m.set(c.getAttribute(\"vt-name\"),c)}var u=[];for(h=0;h<g.length;h+=2){var C=g[h],x=C.parentNode;if(x){var v=x.getBoundingClientRect();if(v.left||v.top||v.width||v.height){c=C;for(f=0;c;){if(8===c.nodeType){var r=c.data;if(\"/$\"===r)if(0===f)break;else f--;else\"$\"!==r&&\"$?\"!==r&&\"$~\"!==r&&\"$!\"!==r||f++}else if(1===c.nodeType){d=c;var D=d.getAttribute(\"vt-name\"),y=m.get(D);k(d,y?\"vt-share\":\"vt-exit\");y&&(k(y,\"vt-share\"),m.set(D,null));var E=d.querySelectorAll(\"[vt-share]\");for(d=0;d<E.length;d++){var F=E[d],G=F.getAttribute(\"vt-name\"),\nH=m.get(G);H&&(k(F,\"vt-share\"),k(H,\"vt-share\"),m.set(G,null))}}c=c.nextSibling}for(var I=g[h+1],t=I.firstElementChild;t;)null!==m.get(t.getAttribute(\"vt-name\"))&&k(t,\"vt-enter\"),t=t.nextElementSibling;c=x;do for(var n=c.firstElementChild;n;){var J=n.getAttribute(\"vt-update\");J&&\"none\"!==J&&!l.includes(n)&&k(n,\"vt-update\");n=n.nextElementSibling}while((c=c.parentNode)&&1===c.nodeType&&\"none\"!==c.getAttribute(\"vt-update\"));u.push.apply(u,I.querySelectorAll('img[src]:not([loading=\"lazy\"])'))}}}if(B){var z=\ndocument.__reactViewTransition=document.startViewTransition({update:function(){A(g);for(var a=[document.documentElement.clientHeight,document.fonts.ready],b={},e=0;e<u.length;b={g:b.g},e++)if(b.g=u[e],!b.g.complete){var p=b.g.getBoundingClientRect();0<p.bottom&&0<p.right&&p.top<window.innerHeight&&p.left<window.innerWidth&&(p=new Promise(function(w){return function(q){w.g.addEventListener(\"load\",q);w.g.addEventListener(\"error\",q)}}(b)),a.push(p))}return Promise.race([Promise.all(a),new Promise(function(w){var q=\nperformance.now();setTimeout(w,2300>q&&2E3<q?2300-q:500)})])},types:[]});z.ready.finally(function(){for(var a=l.length-3;0<=a;a-=3){var b=l[a],e=b.style;e.viewTransitionName=l[a+1];e.viewTransitionClass=l[a+1];\"\"===b.getAttribute(\"style\")&&b.removeAttribute(\"style\")}});z.finished.finally(function(){document.__reactViewTransition===z&&(document.__reactViewTransition=null)});$RB=[];return}}catch(a){}A(g)}.bind(null,$RV);");
	var yn = L("$RC(\""), bn = L("$RM=new Map;$RR=function(n,w,p){function u(q){this._p=null;q()}for(var r=new Map,t=document,h,b,e=t.querySelectorAll(\"link[data-precedence],style[data-precedence]\"),v=[],k=0;b=e[k++];)\"not all\"===b.getAttribute(\"media\")?v.push(b):(\"LINK\"===b.tagName&&$RM.set(b.getAttribute(\"href\"),b),r.set(b.dataset.precedence,h=b));e=0;b=[];var l,a;for(k=!0;;){if(k){var f=p[e++];if(!f){k=!1;e=0;continue}var c=!1,m=0;var d=f[m++];if(a=$RM.get(d)){var g=a._p;c=!0}else{a=t.createElement(\"link\");a.href=d;a.rel=\n\"stylesheet\";for(a.dataset.precedence=l=f[m++];g=f[m++];)a.setAttribute(g,f[m++]);g=a._p=new Promise(function(q,x){a.onload=u.bind(a,q);a.onerror=u.bind(a,x)});$RM.set(d,a)}d=a.getAttribute(\"media\");!g||d&&!matchMedia(d).matches||b.push(g);if(c)continue}else{a=v[e++];if(!a)break;l=a.getAttribute(\"data-precedence\");a.removeAttribute(\"media\")}c=r.get(l)||h;c===h&&(h=a);r.set(l,a);c?c.parentNode.insertBefore(a,c.nextSibling):(c=t.head,c.insertBefore(a,c.firstChild))}if(p=document.getElementById(n))p.previousSibling.data=\n\"$~\";Promise.all(b).then($RC.bind(null,n,w),$RX.bind(null,n,\"CSS failed to load\"))};$RR(\""), xn = L("$RR(\""), Sn = L("\",\""), Cn = L("\","), wn = L("\""), Tn = L(")<\/script>");
	L("<template data-rci=\"\" data-bid=\""), L("<template data-rri=\"\" data-bid=\""), L("\" data-sid=\""), L("\" data-sty=\"");
	var En = L("$RX=function(b,c,d,e,f){var a=document.getElementById(b);a&&(b=a.previousSibling,b.data=\"$!\",a=a.dataset,c&&(a.dgst=c),d&&(a.msg=d),e&&(a.stck=e),f&&(a.cstck=f),b._reactRetry&&b._reactRetry())};"), Dn = L("$RX=function(b,c,d,e,f){var a=document.getElementById(b);a&&(b=a.previousSibling,b.data=\"$!\",a=a.dataset,c&&(a.dgst=c),d&&(a.msg=d),e&&(a.stck=e),f&&(a.cstck=f),b._reactRetry&&b._reactRetry())};;$RX(\""), On = L("$RX(\""), kn = L("\""), An = L(","), jn = L(")<\/script>");
	L("<template data-rxi=\"\" data-bid=\""), L("\" data-dgst=\""), L("\" data-msg=\""), L("\" data-stck=\""), L("\" data-cstck=\"");
	var Mn = /[<\u2028\u2029]/g;
	function Nn(e) {
		return JSON.stringify(e).replace(Mn, function(e) {
			switch (e) {
				case "<": return "\\u003c";
				case "\u2028": return "\\u2028";
				case "\u2029": return "\\u2029";
				default: throw Error("escapeJSStringsForInstructionScripts encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
			}
		});
	}
	var Pn = /[&><\u2028\u2029]/g;
	function Fn(e) {
		return JSON.stringify(e).replace(Pn, function(e) {
			switch (e) {
				case "&": return "\\u0026";
				case ">": return "\\u003e";
				case "<": return "\\u003c";
				case "\u2028": return "\\u2028";
				case "\u2029": return "\\u2029";
				default: throw Error("escapeJSObjectForInstructionScripts encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
			}
		});
	}
	var In = L(" media=\"not all\" data-precedence=\""), Ln = L("\" data-href=\""), Rn = L("\">"), zn = L("</style>"), Bn = !1, Vn = !0;
	function Hn(e) {
		var t = e.rules, n = e.hrefs, r = 0;
		if (n.length) {
			for (P(this, be.startInlineStyle), P(this, In), P(this, e.precedence), P(this, Ln); r < n.length - 1; r++) P(this, n[r]), P(this, Yn);
			for (P(this, n[r]), P(this, Rn), r = 0; r < t.length; r++) P(this, t[r]);
			Vn = F(this, zn), Bn = !0, t.length = 0, n.length = 0;
		}
	}
	function Un(e) {
		return e.state === 2 ? !1 : Bn = !0;
	}
	function Wn(e, t, n) {
		return Bn = !1, Vn = !0, be = n, t.styles.forEach(Hn, e), be = null, t.stylesheets.forEach(Un), Bn && (n.stylesToHoist = !0), Vn;
	}
	function Q(e) {
		for (var t = 0; t < e.length; t++) P(this, e[t]);
		e.length = 0;
	}
	var Gn = [];
	function Kn(e) {
		dt(Gn, e.props);
		for (var t = 0; t < Gn.length; t++) P(this, Gn[t]);
		Gn.length = 0, e.state = 2;
	}
	var qn = L(" data-precedence=\""), Jn = L("\" data-href=\""), Yn = L(" "), Xn = L("\">"), Zn = L("</style>");
	function Qn(e) {
		var t = 0 < e.sheets.size;
		e.sheets.forEach(Kn, this), e.sheets.clear();
		var n = e.rules, r = e.hrefs;
		if (!t || r.length) {
			if (P(this, be.startInlineStyle), P(this, qn), P(this, e.precedence), e = 0, r.length) {
				for (P(this, Jn); e < r.length - 1; e++) P(this, r[e]), P(this, Yn);
				P(this, r[e]);
			}
			for (P(this, Xn), e = 0; e < n.length; e++) P(this, n[e]);
			P(this, Zn), n.length = 0, r.length = 0;
		}
	}
	function $n(e) {
		if (e.state === 0) {
			e.state = 1;
			var t = e.props;
			for (dt(Gn, {
				rel: "preload",
				as: "style",
				href: e.props.href,
				crossOrigin: t.crossOrigin,
				fetchPriority: t.fetchPriority,
				integrity: t.integrity,
				media: t.media,
				hrefLang: t.hrefLang,
				referrerPolicy: t.referrerPolicy
			}), e = 0; e < Gn.length; e++) P(this, Gn[e]);
			Gn.length = 0;
		}
	}
	function er(e) {
		e.sheets.forEach($n, this), e.sheets.clear();
	}
	L("<link rel=\"expect\" href=\"#"), L("\" blocking=\"render\"/>");
	var tr = L(" id=\"");
	function nr(e, t) {
		!(t.instructions & 32) && (t.instructions |= 32, e.push(tr, I(V("_" + t.idPrefix + "R_")), G));
	}
	var rr = L("["), ir = L(",["), ar = L(","), or = L("]");
	function sr(e, t) {
		P(e, rr);
		var n = rr;
		t.stylesheets.forEach(function(t) {
			if (t.state !== 2) {
				if (t.state === 3) P(e, n), P(e, I(Fn("" + t.props.href))), P(e, or), n = ir;
				else {
					P(e, n);
					var r = t.props["data-precedence"], a = t.props;
					for (var o in P(e, I(Fn(me("" + t.props.href)))), r = "" + r, P(e, ar), P(e, I(Fn(r))), a) if (z.call(a, o) && (r = a[o], r != null)) switch (o) {
						case "href":
						case "rel":
						case "precedence":
						case "data-precedence": break;
						case "children":
						case "dangerouslySetInnerHTML": throw Error(i(399, "link"));
						default: cr(e, o, r);
					}
					P(e, or), n = ir, t.state = 3;
				}
			}
		}), P(e, or);
	}
	function cr(e, t, n) {
		var r = t.toLowerCase();
		switch (typeof n) {
			case "function":
			case "symbol": return;
		}
		switch (t) {
			case "innerHTML":
			case "dangerouslySetInnerHTML":
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "style":
			case "ref": return;
			case "className":
				r = "class", t = "" + n;
				break;
			case "hidden":
				if (!1 === n) return;
				t = "";
				break;
			case "src":
			case "href":
				n = me(n), t = "" + n;
				break;
			default:
				if (2 < t.length && (t[0] === "o" || t[0] === "O") && (t[1] === "n" || t[1] === "N") || !ce(t)) return;
				t = "" + n;
		}
		P(e, ar), P(e, I(Fn(r))), P(e, ar), P(e, I(Fn(t)));
	}
	function lr() {
		return {
			styles: /* @__PURE__ */ new Set(),
			stylesheets: /* @__PURE__ */ new Set(),
			suspenseyImages: !1
		};
	}
	function ur(e) {
		var t = Ui || null;
		if (t) {
			var n = t.resumableState, r = t.renderState;
			if (typeof e == "string" && e) {
				if (!n.dnsResources.hasOwnProperty(e)) {
					n.dnsResources[e] = null, n = r.headers;
					var i, a;
					(a = n && 0 < n.remainingCapacity) && (a = (i = "<" + ("" + e).replace(yr, br) + ">; rel=dns-prefetch", 0 <= (n.remainingCapacity -= i.length + 2))), a ? (r.resets.dns[e] = null, n.preconnects && (n.preconnects += ", "), n.preconnects += i) : (i = [], dt(i, {
						href: e,
						rel: "dns-prefetch"
					}), r.preconnects.add(i));
				}
				Ba(t);
			}
		} else ve.D(e);
	}
	function dr(e, t) {
		var n = Ui || null;
		if (n) {
			var r = n.resumableState, i = n.renderState;
			if (typeof e == "string" && e) {
				var a = t === "use-credentials" ? "credentials" : typeof t == "string" ? "anonymous" : "default";
				if (!r.connectResources[a].hasOwnProperty(e)) {
					r.connectResources[a][e] = null, r = i.headers;
					var o, s;
					if (s = r && 0 < r.remainingCapacity) {
						if (s = "<" + ("" + e).replace(yr, br) + ">; rel=preconnect", typeof t == "string") {
							var c = ("" + t).replace(xr, Sr);
							s += "; crossorigin=\"" + c + "\"";
						}
						s = (o = s, 0 <= (r.remainingCapacity -= o.length + 2));
					}
					s ? (i.resets.connect[a][e] = null, r.preconnects && (r.preconnects += ", "), r.preconnects += o) : (a = [], dt(a, {
						rel: "preconnect",
						href: e,
						crossOrigin: t
					}), i.preconnects.add(a));
				}
				Ba(n);
			}
		} else ve.C(e, t);
	}
	function fr(e, t, n) {
		var r = Ui || null;
		if (r) {
			var i = r.resumableState, a = r.renderState;
			if (t && e) {
				switch (t) {
					case "image":
						if (n) var o = n.imageSrcSet, s = n.imageSizes, c = n.fetchPriority;
						var l = o ? o + "\n" + (s || "") : e;
						if (i.imageResources.hasOwnProperty(l)) return;
						i.imageResources[l] = ye, i = a.headers;
						var u;
						i && 0 < i.remainingCapacity && typeof o != "string" && c === "high" && (u = vr(e, t, n), 0 <= (i.remainingCapacity -= u.length + 2)) ? (a.resets.image[l] = ye, i.highImagePreloads && (i.highImagePreloads += ", "), i.highImagePreloads += u) : (i = [], dt(i, R({
							rel: "preload",
							href: o ? void 0 : e,
							as: t
						}, n)), c === "high" ? a.highImagePreloads.add(i) : (a.bulkPreloads.add(i), a.preloads.images.set(l, i)));
						break;
					case "style":
						if (i.styleResources.hasOwnProperty(e)) return;
						o = [], dt(o, R({
							rel: "preload",
							href: e,
							as: t
						}, n)), i.styleResources[e] = !n || typeof n.crossOrigin != "string" && typeof n.integrity != "string" ? ye : [n.crossOrigin, n.integrity], a.preloads.stylesheets.set(e, o), a.bulkPreloads.add(o);
						break;
					case "script":
						if (i.scriptResources.hasOwnProperty(e)) return;
						o = [], a.preloads.scripts.set(e, o), a.bulkPreloads.add(o), dt(o, R({
							rel: "preload",
							href: e,
							as: t
						}, n)), i.scriptResources[e] = !n || typeof n.crossOrigin != "string" && typeof n.integrity != "string" ? ye : [n.crossOrigin, n.integrity];
						break;
					default:
						if (i.unknownResources.hasOwnProperty(t)) {
							if (o = i.unknownResources[t], o.hasOwnProperty(e)) return;
						} else o = {}, i.unknownResources[t] = o;
						if (o[e] = ye, (i = a.headers) && 0 < i.remainingCapacity && t === "font" && (l = vr(e, t, n), 0 <= (i.remainingCapacity -= l.length + 2))) a.resets.font[e] = ye, i.fontPreloads && (i.fontPreloads += ", "), i.fontPreloads += l;
						else switch (i = [], e = R({
							rel: "preload",
							href: e,
							as: t
						}, n), dt(i, e), t) {
							case "font":
								a.fontPreloads.add(i);
								break;
							default: a.bulkPreloads.add(i);
						}
				}
				Ba(r);
			}
		} else ve.L(e, t, n);
	}
	function pr(e, t) {
		var n = Ui || null;
		if (n) {
			var r = n.resumableState, i = n.renderState;
			if (e) {
				var a = t && typeof t.as == "string" ? t.as : "script";
				switch (a) {
					case "script":
						if (r.moduleScriptResources.hasOwnProperty(e)) return;
						a = [], r.moduleScriptResources[e] = !t || typeof t.crossOrigin != "string" && typeof t.integrity != "string" ? ye : [t.crossOrigin, t.integrity], i.preloads.moduleScripts.set(e, a);
						break;
					default:
						if (r.moduleUnknownResources.hasOwnProperty(a)) {
							var o = r.unknownResources[a];
							if (o.hasOwnProperty(e)) return;
						} else o = {}, r.moduleUnknownResources[a] = o;
						a = [], o[e] = ye;
				}
				dt(a, R({
					rel: "modulepreload",
					href: e
				}, t)), i.bulkPreloads.add(a), Ba(n);
			}
		} else ve.m(e, t);
	}
	function mr(e, t, n) {
		var r = Ui || null;
		if (r) {
			var i = r.resumableState, a = r.renderState;
			if (e) {
				t ||= "default";
				var o = a.styles.get(t), s = i.styleResources.hasOwnProperty(e) ? i.styleResources[e] : void 0;
				s !== null && (i.styleResources[e] = null, o || (o = {
					precedence: I(V(t)),
					rules: [],
					hrefs: [],
					sheets: /* @__PURE__ */ new Map()
				}, a.styles.set(t, o)), t = {
					state: 0,
					props: R({
						rel: "stylesheet",
						href: e,
						"data-precedence": t
					}, n)
				}, s && (s.length === 2 && _r(t.props, s), (a = a.preloads.stylesheets.get(e)) && 0 < a.length ? a.length = 0 : t.state = 1), o.sheets.set(e, t), Ba(r));
			}
		} else ve.S(e, t, n);
	}
	function hr(e, t) {
		var n = Ui || null;
		if (n) {
			var r = n.resumableState, i = n.renderState;
			if (e) {
				var a = r.scriptResources.hasOwnProperty(e) ? r.scriptResources[e] : void 0;
				a !== null && (r.scriptResources[e] = null, t = R({
					src: e,
					async: !0
				}, t), a && (a.length === 2 && _r(t, a), e = i.preloads.scripts.get(e)) && (e.length = 0), e = [], i.scripts.add(e), yt(e, t), Ba(n));
			}
		} else ve.X(e, t);
	}
	function gr(e, t) {
		var n = Ui || null;
		if (n) {
			var r = n.resumableState, i = n.renderState;
			if (e) {
				var a = r.moduleScriptResources.hasOwnProperty(e) ? r.moduleScriptResources[e] : void 0;
				a !== null && (r.moduleScriptResources[e] = null, t = R({
					src: e,
					type: "module",
					async: !0
				}, t), a && (a.length === 2 && _r(t, a), e = i.preloads.moduleScripts.get(e)) && (e.length = 0), e = [], i.scripts.add(e), yt(e, t), Ba(n));
			}
		} else ve.M(e, t);
	}
	function _r(e, t) {
		e.crossOrigin ??= t[0], e.integrity ??= t[1];
	}
	function vr(e, t, n) {
		for (var r in e = ("" + e).replace(yr, br), t = ("" + t).replace(xr, Sr), t = "<" + e + ">; rel=preload; as=\"" + t + "\"", n) z.call(n, r) && (e = n[r], typeof e == "string" && (t += "; " + r.toLowerCase() + "=\"" + ("" + e).replace(xr, Sr) + "\""));
		return t;
	}
	var yr = /[<>\r\n]/g;
	function br(e) {
		switch (e) {
			case "<": return "%3C";
			case ">": return "%3E";
			case "\n": return "%0A";
			case "\r": return "%0D";
			default: throw Error("escapeLinkHrefForHeaderContextReplacer encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
		}
	}
	var xr = /["';,\r\n]/g;
	function Sr(e) {
		switch (e) {
			case "\"": return "%22";
			case "'": return "%27";
			case ";": return "%3B";
			case ",": return "%2C";
			case "\n": return "%0A";
			case "\r": return "%0D";
			default: throw Error("escapeStringForLinkHeaderQuotedParamValueContextReplacer encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
		}
	}
	function Cr(e) {
		this.styles.add(e);
	}
	function wr(e) {
		this.stylesheets.add(e);
	}
	function Tr(e, t) {
		t.styles.forEach(Cr, e), t.stylesheets.forEach(wr, e), t.suspenseyImages && (e.suspenseyImages = !0);
	}
	function Er(e) {
		return 0 < e.stylesheets.size || e.suspenseyImages;
	}
	var Dr = Function.prototype.bind, Or = Symbol.for("react.client.reference");
	function kr(e) {
		if (e == null) return null;
		if (typeof e == "function") return e.$$typeof === Or ? null : e.displayName || e.name || null;
		if (typeof e == "string") return e;
		switch (e) {
			case s: return "Fragment";
			case l: return "Profiler";
			case c: return "StrictMode";
			case m: return "Suspense";
			case h: return "SuspenseList";
			case y: return "Activity";
		}
		if (typeof e == "object") switch (e.$$typeof) {
			case o: return "Portal";
			case f: return e.displayName || "Context";
			case u: return (e._context.displayName || "Context") + ".Consumer";
			case p:
				var t = e.render;
				return e = e.displayName, e ||= (e = t.displayName || t.name || "", e === "" ? "ForwardRef" : "ForwardRef(" + e + ")"), e;
			case g: return t = e.displayName || null, t === null ? kr(e.type) || "Memo" : t;
			case _:
				t = e._payload, e = e._init;
				try {
					return kr(e(t));
				} catch {}
		}
		return null;
	}
	var Ar = {}, jr = null;
	function Mr(e, t) {
		if (e !== t) {
			e.context._currentValue = e.parentValue, e = e.parent;
			var n = t.parent;
			if (e === null) {
				if (n !== null) throw Error(i(401));
			} else {
				if (n === null) throw Error(i(401));
				Mr(e, n);
			}
			t.context._currentValue = t.value;
		}
	}
	function Nr(e) {
		e.context._currentValue = e.parentValue, e = e.parent, e !== null && Nr(e);
	}
	function Pr(e) {
		var t = e.parent;
		t !== null && Pr(t), e.context._currentValue = e.value;
	}
	function Fr(e, t) {
		if (e.context._currentValue = e.parentValue, e = e.parent, e === null) throw Error(i(402));
		e.depth === t.depth ? Mr(e, t) : Fr(e, t);
	}
	function Ir(e, t) {
		var n = t.parent;
		if (n === null) throw Error(i(402));
		e.depth === n.depth ? Mr(e, n) : Ir(e, n), t.context._currentValue = t.value;
	}
	function Lr(e) {
		var t = jr;
		t !== e && (t === null ? Pr(e) : e === null ? Nr(t) : t.depth === e.depth ? Mr(t, e) : t.depth > e.depth ? Fr(t, e) : Ir(t, e), jr = e);
	}
	var Rr = {
		enqueueSetState: function(e, t) {
			e = e._reactInternals, e.queue !== null && e.queue.push(t);
		},
		enqueueReplaceState: function(e, t) {
			e = e._reactInternals, e.replace = !0, e.queue = [t];
		},
		enqueueForceUpdate: function() {}
	}, zr = {
		id: 1,
		overflow: ""
	};
	function Br(e, t, n) {
		var r = e.id;
		e = e.overflow;
		var i = 32 - Vr(r) - 1;
		r &= ~(1 << i), n += 1;
		var a = 32 - Vr(t) + i;
		if (30 < a) {
			var o = i - i % 5;
			return a = (r & (1 << o) - 1).toString(32), r >>= o, i -= o, {
				id: 1 << 32 - Vr(t) + i | n << i | r,
				overflow: a + e
			};
		}
		return {
			id: 1 << a | n << i | r,
			overflow: e
		};
	}
	var Vr = Math.clz32 ? Math.clz32 : Wr, Hr = Math.log, Ur = Math.LN2;
	function Wr(e) {
		return e >>>= 0, e === 0 ? 32 : 31 - (Hr(e) / Ur | 0) | 0;
	}
	function Gr() {}
	var Kr = Error(i(460));
	function qr(e, t, n) {
		switch (n = e[n], n === void 0 ? e.push(t) : n !== t && (t.then(Gr, Gr), t = n), t.status) {
			case "fulfilled": return t.value;
			case "rejected": throw t.reason;
			default:
				switch (typeof t.status == "string" ? t.then(Gr, Gr) : (e = t, e.status = "pending", e.then(function(e) {
					if (t.status === "pending") {
						var n = t;
						n.status = "fulfilled", n.value = e;
					}
				}, function(e) {
					if (t.status === "pending") {
						var n = t;
						n.status = "rejected", n.reason = e;
					}
				})), t.status) {
					case "fulfilled": return t.value;
					case "rejected": throw t.reason;
				}
				throw Jr = t, Kr;
		}
	}
	var Jr = null;
	function Yr() {
		if (Jr === null) throw Error(i(459));
		var e = Jr;
		return Jr = null, e;
	}
	function Xr(e, t) {
		return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t;
	}
	var Zr = typeof Object.is == "function" ? Object.is : Xr, Qr = null, $r = null, ei = null, ti = null, ni = null, $ = null, ri = !1, ii = !1, ai = 0, oi = 0, si = -1, ci = 0, li = null, ui = null, di = 0;
	function fi() {
		if (Qr === null) throw Error(i(321));
		return Qr;
	}
	function pi() {
		if (0 < di) throw Error(i(312));
		return {
			memoizedState: null,
			queue: null,
			next: null
		};
	}
	function mi() {
		return $ === null ? ni === null ? (ri = !1, ni = $ = pi()) : (ri = !0, $ = ni) : $.next === null ? (ri = !1, $ = $.next = pi()) : (ri = !0, $ = $.next), $;
	}
	function hi() {
		var e = li;
		return li = null, e;
	}
	function gi() {
		ti = ei = $r = Qr = null, ii = !1, ni = null, di = 0, $ = ui = null;
	}
	function _i(e, t) {
		return typeof t == "function" ? t(e) : t;
	}
	function vi(e, t, n) {
		if (Qr = fi(), $ = mi(), ri) {
			var r = $.queue;
			if (t = r.dispatch, ui !== null && (n = ui.get(r), n !== void 0)) {
				ui.delete(r), r = $.memoizedState;
				do
					r = e(r, n.action), n = n.next;
				while (n !== null);
				return $.memoizedState = r, [r, t];
			}
			return [$.memoizedState, t];
		}
		return e = e === _i ? typeof t == "function" ? t() : t : n === void 0 ? t : n(t), $.memoizedState = e, e = $.queue = {
			last: null,
			dispatch: null
		}, e = e.dispatch = bi.bind(null, Qr, e), [$.memoizedState, e];
	}
	function yi(e, t) {
		if (Qr = fi(), $ = mi(), t = t === void 0 ? null : t, $ !== null) {
			var n = $.memoizedState;
			if (n !== null && t !== null) {
				var r = n[1];
				a: if (r === null) r = !1;
				else {
					for (var i = 0; i < r.length && i < t.length; i++) if (!Zr(t[i], r[i])) {
						r = !1;
						break a;
					}
					r = !0;
				}
				if (r) return n[0];
			}
		}
		return e = e(), $.memoizedState = [e, t], e;
	}
	function bi(e, t, n) {
		if (25 <= di) throw Error(i(301));
		if (e === Qr) {
			if (ii = !0, e = {
				action: n,
				next: null
			}, ui === null && (ui = /* @__PURE__ */ new Map()), n = ui.get(t), n === void 0) ui.set(t, e);
			else {
				for (t = n; t.next !== null;) t = t.next;
				t.next = e;
			}
		}
	}
	function xi() {
		throw Error(i(440));
	}
	function Si() {
		throw Error(i(394));
	}
	function Ci() {
		throw Error(i(479));
	}
	function wi(e, t, n) {
		fi();
		var r = oi++, i = ei;
		if (typeof e.$$FORM_ACTION == "function") {
			var a = null, o = ti;
			i = i.formState;
			var s = e.$$IS_SIGNATURE_EQUAL;
			if (i !== null && typeof s == "function") {
				var c = i[1];
				s.call(e, i[2], i[3]) && (a = n === void 0 ? "k" + E(JSON.stringify([
					o,
					null,
					r
				]), 0) : "p" + n, c === a && (si = r, t = i[0]));
			}
			var l = e.bind(null, t);
			return e = function(e) {
				l(e);
			}, typeof l.$$FORM_ACTION == "function" && (e.$$FORM_ACTION = function(e) {
				e = l.$$FORM_ACTION(e), n !== void 0 && (n += "", e.action = n);
				var t = e.data;
				return t && (a === null && (a = n === void 0 ? "k" + E(JSON.stringify([
					o,
					null,
					r
				]), 0) : "p" + n), t.append("$ACTION_KEY", a)), e;
			}), [
				t,
				e,
				!1
			];
		}
		var u = e.bind(null, t);
		return [
			t,
			function(e) {
				u(e);
			},
			!1
		];
	}
	function Ti(e) {
		var t = ci;
		return ci += 1, li === null && (li = []), qr(li, e, t);
	}
	function Ei() {
		throw Error(i(393));
	}
	var Di = {
		readContext: function(e) {
			return e._currentValue;
		},
		use: function(e) {
			if (typeof e == "object" && e) {
				if (typeof e.then == "function") return Ti(e);
				if (e.$$typeof === f) return e._currentValue;
			}
			throw Error(i(438, String(e)));
		},
		useContext: function(e) {
			return fi(), e._currentValue;
		},
		useMemo: yi,
		useReducer: vi,
		useRef: function(e) {
			Qr = fi(), $ = mi();
			var t = $.memoizedState;
			return t === null ? (e = { current: e }, $.memoizedState = e) : t;
		},
		useState: function(e) {
			return vi(_i, e);
		},
		useInsertionEffect: Gr,
		useLayoutEffect: Gr,
		useCallback: function(e, t) {
			return yi(function() {
				return e;
			}, t);
		},
		useImperativeHandle: Gr,
		useEffect: Gr,
		useDebugValue: Gr,
		useDeferredValue: function(e, t) {
			return fi(), t === void 0 ? e : t;
		},
		useTransition: function() {
			return fi(), [!1, Si];
		},
		useId: function() {
			var e = $r.treeContext, t = e.overflow;
			e = e.id, e = (e & ~(1 << 32 - Vr(e) - 1)).toString(32) + t;
			var n = Oi;
			if (n === null) throw Error(i(404));
			return t = ai++, e = "_" + n.idPrefix + "R_" + e, 0 < t && (e += "H" + t.toString(32)), e + "_";
		},
		useSyncExternalStore: function(e, t, n) {
			if (n === void 0) throw Error(i(407));
			return n();
		},
		useOptimistic: function(e) {
			return fi(), [e, Ci];
		},
		useActionState: wi,
		useFormState: wi,
		useHostTransitionStatus: function() {
			return fi(), _e;
		},
		useMemoCache: function(e) {
			for (var t = Array(e), n = 0; n < e; n++) t[n] = x;
			return t;
		},
		useCacheRefresh: function() {
			return Ei;
		},
		useEffectEvent: function() {
			return xi;
		}
	}, Oi = null, ki = {
		getCacheForType: function() {
			throw Error(i(248));
		},
		cacheSignal: function() {
			throw Error(i(248));
		}
	}, Ai, ji;
	function Mi(e) {
		if (Ai === void 0) try {
			throw Error();
		} catch (e) {
			var t = e.stack.trim().match(/\n( *(at )?)/);
			Ai = t && t[1] || "", ji = -1 < e.stack.indexOf("\n    at") ? " (<anonymous>)" : -1 < e.stack.indexOf("@") ? "@unknown:0:0" : "";
		}
		return "\n" + Ai + e + ji;
	}
	var Ni = !1;
	function Pi(e, t) {
		if (!e || Ni) return "";
		Ni = !0;
		var n = Error.prepareStackTrace;
		Error.prepareStackTrace = void 0;
		try {
			var r = { DetermineComponentFrameRoot: function() {
				try {
					if (t) {
						var n = function() {
							throw Error();
						};
						if (Object.defineProperty(n.prototype, "props", { set: function() {
							throw Error();
						} }), typeof Reflect == "object" && Reflect.construct) {
							try {
								Reflect.construct(n, []);
							} catch (e) {
								var r = e;
							}
							Reflect.construct(e, [], n);
						} else {
							try {
								n.call();
							} catch (e) {
								r = e;
							}
							e.call(n.prototype);
						}
					} else {
						try {
							throw Error();
						} catch (e) {
							r = e;
						}
						(n = e()) && typeof n.catch == "function" && n.catch(function() {});
					}
				} catch (e) {
					if (e && r && typeof e.stack == "string") return [e.stack, r.stack];
				}
				return [null, null];
			} };
			r.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
			var i = Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot, "name");
			i && i.configurable && Object.defineProperty(r.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
			var a = r.DetermineComponentFrameRoot(), o = a[0], s = a[1];
			if (o && s) {
				var c = o.split("\n"), l = s.split("\n");
				for (i = r = 0; r < c.length && !c[r].includes("DetermineComponentFrameRoot");) r++;
				for (; i < l.length && !l[i].includes("DetermineComponentFrameRoot");) i++;
				if (r === c.length || i === l.length) for (r = c.length - 1, i = l.length - 1; 1 <= r && 0 <= i && c[r] !== l[i];) i--;
				for (; 1 <= r && 0 <= i; r--, i--) if (c[r] !== l[i]) {
					if (r !== 1 || i !== 1) do
						if (r--, i--, 0 > i || c[r] !== l[i]) {
							var u = "\n" + c[r].replace(" at new ", " at ");
							return e.displayName && u.includes("<anonymous>") && (u = u.replace("<anonymous>", e.displayName)), u;
						}
					while (1 <= r && 0 <= i);
					break;
				}
			}
		} finally {
			Ni = !1, Error.prepareStackTrace = n;
		}
		return (n = e ? e.displayName || e.name : "") ? Mi(n) : "";
	}
	function Fi(e) {
		if (typeof e == "string") return Mi(e);
		if (typeof e == "function") return e.prototype && e.prototype.isReactComponent ? Pi(e, !0) : Pi(e, !1);
		if (typeof e == "object" && e) {
			switch (e.$$typeof) {
				case p: return Pi(e.render, !1);
				case g: return Pi(e.type, !1);
				case _:
					var t = e, n = t._payload;
					t = t._init;
					try {
						e = t(n);
					} catch {
						return Mi("Lazy");
					}
					return Fi(e);
			}
			if (typeof e.name == "string") {
				a: {
					n = e.name, t = e.env;
					var r = e.debugLocation;
					if (r != null && (e = Error.prepareStackTrace, Error.prepareStackTrace = void 0, r = r.stack, Error.prepareStackTrace = e, r.startsWith("Error: react-stack-top-frame\n") && (r = r.slice(29)), e = r.indexOf("\n"), e !== -1 && (r = r.slice(e + 1)), e = r.indexOf("react_stack_bottom_frame"), e !== -1 && (e = r.lastIndexOf("\n", e)), e = e === -1 ? "" : r = r.slice(0, e), r = e.lastIndexOf("\n"), e = r === -1 ? e : e.slice(r + 1), e.indexOf(n) !== -1)) {
						n = "\n" + e;
						break a;
					}
					n = Mi(n + (t ? " [" + t + "]" : ""));
				}
				return n;
			}
		}
		switch (e) {
			case h: return Mi("SuspenseList");
			case m: return Mi("Suspense");
		}
		return "";
	}
	function Ii(e, t) {
		return (500 < t.byteSize || Er(t.contentState)) && t.contentPreamble === null;
	}
	function Li(e) {
		if (typeof e == "object" && e && typeof e.environmentName == "string") {
			var t = e.environmentName;
			e = [e].slice(0), typeof e[0] == "string" ? e.splice(0, 1, "%c%s%c " + e[0], "background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px", " " + t + " ", "") : e.splice(0, 0, "%c%s%c", "background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px", " " + t + " ", ""), e.unshift(console), t = Dr.apply(console.error, e), t();
		} else console.error(e);
		return null;
	}
	function Ri(e, t, n, r, i, a, o, s, c, l, u) {
		var d = /* @__PURE__ */ new Set();
		this.destination = null, this.flushScheduled = !1, this.resumableState = e, this.renderState = t, this.rootFormatContext = n, this.progressiveChunkSize = r === void 0 ? 12800 : r, this.status = 10, this.fatalError = null, this.pendingRootTasks = this.allPendingTasks = this.nextSegmentId = 0, this.completedPreambleSegments = this.completedRootSegment = null, this.byteSize = 0, this.abortableTasks = d, this.pingedTasks = [], this.clientRenderedBoundaries = [], this.completedBoundaries = [], this.partialBoundaries = [], this.trackedPostpones = null, this.onError = i === void 0 ? Li : i, this.onPostpone = l === void 0 ? Gr : l, this.onAllReady = a === void 0 ? Gr : a, this.onShellReady = o === void 0 ? Gr : o, this.onShellError = s === void 0 ? Gr : s, this.onFatalError = c === void 0 ? Gr : c, this.formState = u === void 0 ? null : u;
	}
	function zi(e, t, n, r, i, a, o, s, c, l, u, d) {
		return t = new Ri(t, n, r, i, a, o, s, c, l, u, d), n = Ji(t, 0, null, r, !1, !1), n.parentFlushed = !0, e = Ki(t, null, e, -1, null, n, null, null, t.abortableTasks, null, r, null, zr, null, null), Yi(e), t.pingedTasks.push(e), t;
	}
	function Bi(e, t, n, r, i, a, o, s, c, l, u) {
		return e = zi(e, t, n, r, i, a, o, s, c, l, u, void 0), e.trackedPostpones = {
			workingMap: /* @__PURE__ */ new Map(),
			rootNodes: [],
			rootSlots: null
		}, e;
	}
	function Vi(e, t, n, r, i, a, o, s, c) {
		return n = new Ri(t.resumableState, n, t.rootFormatContext, t.progressiveChunkSize, r, i, a, o, s, c, null), n.nextSegmentId = t.nextSegmentId, typeof t.replaySlots == "number" ? (r = Ji(n, 0, null, t.rootFormatContext, !1, !1), r.parentFlushed = !0, e = Ki(n, null, e, -1, null, r, null, null, n.abortableTasks, null, t.rootFormatContext, null, zr, null, null), Yi(e), n.pingedTasks.push(e), n) : (e = qi(n, null, {
			nodes: t.replayNodes,
			slots: t.replaySlots,
			pendingTasks: 0
		}, e, -1, null, null, n.abortableTasks, null, t.rootFormatContext, null, zr, null, null), Yi(e), n.pingedTasks.push(e), n);
	}
	function Hi(e, t, n, r, i, a, o, s, c) {
		return e = Vi(e, t, n, r, i, a, o, s, c), e.trackedPostpones = {
			workingMap: /* @__PURE__ */ new Map(),
			rootNodes: [],
			rootSlots: null
		}, e;
	}
	var Ui = null;
	function Wi(e, t) {
		e.pingedTasks.push(t), e.pingedTasks.length === 1 && (e.flushScheduled = e.destination !== null, e.trackedPostpones !== null || e.status === 10 ? ee(function() {
			return Da(e);
		}) : k(function() {
			return Da(e);
		}));
	}
	function Gi(e, t, n, r, i) {
		return n = {
			status: 0,
			rootSegmentID: -1,
			parentFlushed: !1,
			pendingTasks: 0,
			row: t,
			completedSegments: [],
			byteSize: 0,
			fallbackAbortableTasks: n,
			errorDigest: null,
			contentState: lr(),
			fallbackState: lr(),
			contentPreamble: r,
			fallbackPreamble: i,
			trackedContentKeyPath: null,
			trackedFallbackNode: null
		}, t !== null && (t.pendingTasks++, r = t.boundaries, r !== null && (e.allPendingTasks++, n.pendingTasks++, r.push(n)), e = t.inheritedHoistables, e !== null && Tr(n.contentState, e)), n;
	}
	function Ki(e, t, n, r, i, a, o, s, c, l, u, d, f, p, m) {
		e.allPendingTasks++, i === null ? e.pendingRootTasks++ : i.pendingTasks++, p !== null && p.pendingTasks++;
		var h = {
			replay: null,
			node: n,
			childIndex: r,
			ping: function() {
				return Wi(e, h);
			},
			blockedBoundary: i,
			blockedSegment: a,
			blockedPreamble: o,
			hoistableState: s,
			abortSet: c,
			keyPath: l,
			formatContext: u,
			context: d,
			treeContext: f,
			row: p,
			componentStack: m,
			thenableState: t
		};
		return c.add(h), h;
	}
	function qi(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
		e.allPendingTasks++, a === null ? e.pendingRootTasks++ : a.pendingTasks++, f !== null && f.pendingTasks++, n.pendingTasks++;
		var m = {
			replay: n,
			node: r,
			childIndex: i,
			ping: function() {
				return Wi(e, m);
			},
			blockedBoundary: a,
			blockedSegment: null,
			blockedPreamble: null,
			hoistableState: o,
			abortSet: s,
			keyPath: c,
			formatContext: l,
			context: u,
			treeContext: d,
			row: f,
			componentStack: p,
			thenableState: t
		};
		return s.add(m), m;
	}
	function Ji(e, t, n, r, i, a) {
		return {
			status: 0,
			parentFlushed: !1,
			id: -1,
			index: t,
			chunks: [],
			children: [],
			preambleChildren: [],
			parentFormatContext: r,
			boundary: n,
			lastPushedText: i,
			textEmbedded: a
		};
	}
	function Yi(e) {
		var t = e.node;
		if (typeof t == "object" && t) switch (t.$$typeof) {
			case a: e.componentStack = {
				parent: e.componentStack,
				type: t.type
			};
		}
	}
	function Xi(e) {
		return e === null ? null : {
			parent: e.parent,
			type: "Suspense Fallback"
		};
	}
	function Zi(e) {
		var t = {};
		return e && Object.defineProperty(t, "componentStack", {
			configurable: !0,
			enumerable: !0,
			get: function() {
				try {
					var n = "", r = e;
					do
						n += Fi(r.type), r = r.parent;
					while (r);
					var i = n;
				} catch (e) {
					i = "\nError generating stack: " + e.message + "\n" + e.stack;
				}
				return Object.defineProperty(t, "componentStack", { value: i }), i;
			}
		}), t;
	}
	function Qi(e, t, n) {
		if (e = e.onError, t = e(t, n), t == null || typeof t == "string") return t;
	}
	function $i(e, t) {
		var n = e.onShellError, r = e.onFatalError;
		n(t), r(t), e.destination === null ? (e.status = 13, e.fatalError = t) : (e.status = 14, ie(e.destination, t));
	}
	function ea(e, t) {
		ta(e, t.next, t.hoistables);
	}
	function ta(e, t, n) {
		for (; t !== null;) {
			n !== null && (Tr(t.hoistables, n), t.inheritedHoistables = n);
			var r = t.boundaries;
			if (r !== null) {
				t.boundaries = null;
				for (var i = 0; i < r.length; i++) {
					var a = r[i];
					n !== null && Tr(a.contentState, n), Ea(e, a, null, null);
				}
			}
			if (t.pendingTasks--, 0 < t.pendingTasks) break;
			n = t.hoistables, t = t.next;
		}
	}
	function na(e, t) {
		var n = t.boundaries;
		if (n !== null && t.pendingTasks === n.length) {
			for (var r = !0, i = 0; i < n.length; i++) {
				var a = n[i];
				if (a.pendingTasks !== 1 || a.parentFlushed || Ii(e, a)) {
					r = !1;
					break;
				}
			}
			r && ta(e, t, t.hoistables);
		}
	}
	function ra(e) {
		var t = {
			pendingTasks: 1,
			boundaries: null,
			hoistables: lr(),
			inheritedHoistables: null,
			together: !1,
			next: null
		};
		return e !== null && 0 < e.pendingTasks && (t.pendingTasks++, t.boundaries = [], e.next = t), t;
	}
	function ia(e, t, n, r, i) {
		var a = t.keyPath, o = t.treeContext, s = t.row;
		t.keyPath = n, n = r.length;
		var c = null;
		if (t.replay !== null) {
			var l = t.replay.slots;
			if (typeof l == "object" && l) for (var u = 0; u < n; u++) {
				var d = i !== "backwards" && i !== "unstable_legacy-backwards" ? u : n - 1 - u, f = r[d];
				t.row = c = ra(c), t.treeContext = Br(o, n, d);
				var p = l[d];
				typeof p == "number" ? (ca(e, t, p, f, d), delete l[d]) : _a(e, t, f, d), --c.pendingTasks === 0 && ea(e, c);
			}
			else for (l = 0; l < n; l++) u = i !== "backwards" && i !== "unstable_legacy-backwards" ? l : n - 1 - l, d = r[u], t.row = c = ra(c), t.treeContext = Br(o, n, u), _a(e, t, d, u), --c.pendingTasks === 0 && ea(e, c);
		} else if (i !== "backwards" && i !== "unstable_legacy-backwards") for (i = 0; i < n; i++) l = r[i], t.row = c = ra(c), t.treeContext = Br(o, n, i), _a(e, t, l, i), --c.pendingTasks === 0 && ea(e, c);
		else {
			for (i = t.blockedSegment, l = i.children.length, u = i.chunks.length, d = n - 1; 0 <= d; d--) {
				f = r[d], t.row = c = ra(c), t.treeContext = Br(o, n, d), p = Ji(e, u, null, t.formatContext, d !== 0 || i.lastPushedText, !0), i.children.splice(l, 0, p), t.blockedSegment = p;
				try {
					_a(e, t, f, d), p.lastPushedText && p.textEmbedded && p.chunks.push(Be), p.status = 1, Ta(e, t.blockedBoundary, p), --c.pendingTasks === 0 && ea(e, c);
				} catch (t) {
					throw p.status = e.status === 12 ? 3 : 4, t;
				}
			}
			t.blockedSegment = i, i.lastPushedText = !1;
		}
		s !== null && c !== null && 0 < c.pendingTasks && (s.pendingTasks++, c.next = s), t.treeContext = o, t.row = s, t.keyPath = a;
	}
	function aa(e, t, n, r, i, a) {
		var o = t.thenableState;
		for (t.thenableState = null, Qr = {}, $r = t, ei = e, ti = n, oi = ai = 0, si = -1, ci = 0, li = o, e = r(i, a); ii;) ii = !1, oi = ai = 0, si = -1, ci = 0, di += 1, $ = null, e = r(i, a);
		return gi(), e;
	}
	function oa(e, t, n, r, i, a, o) {
		var s = !1;
		if (a !== 0 && e.formState !== null) {
			var c = t.blockedSegment;
			if (c !== null) {
				s = !0, c = c.chunks;
				for (var l = 0; l < a; l++) l === o ? c.push(lt) : c.push(ut);
			}
		}
		a = t.keyPath, t.keyPath = n, i ? (n = t.treeContext, t.treeContext = Br(n, 1, 0), _a(e, t, r, -1), t.treeContext = n) : s ? _a(e, t, r, -1) : la(e, t, r, -1), t.keyPath = a;
	}
	function sa(e, t, n, r, a, o) {
		if (typeof r == "function") {
			if (r.prototype && r.prototype.isReactComponent) {
				var d = a;
				if ("ref" in a) for (var x in d = {}, a) x !== "ref" && (d[x] = a[x]);
				var C = r.defaultProps;
				if (C) for (var E in d === a && (d = R({}, d, a)), C) d[E] === void 0 && (d[E] = C[E]);
				a = d, d = Ar, C = r.contextType, typeof C == "object" && C && (d = C._currentValue), d = new r(a, d);
				var D = d.state === void 0 ? null : d.state;
				if (d.updater = Rr, d.props = a, d.state = D, C = {
					queue: [],
					replace: !1
				}, d._reactInternals = C, o = r.contextType, d.context = typeof o == "object" && o ? o._currentValue : Ar, o = r.getDerivedStateFromProps, typeof o == "function" && (o = o(a, D), D = o == null ? D : R({}, D, o), d.state = D), typeof r.getDerivedStateFromProps != "function" && typeof d.getSnapshotBeforeUpdate != "function" && (typeof d.UNSAFE_componentWillMount == "function" || typeof d.componentWillMount == "function")) {
					if (r = d.state, typeof d.componentWillMount == "function" && d.componentWillMount(), typeof d.UNSAFE_componentWillMount == "function" && d.UNSAFE_componentWillMount(), r !== d.state && Rr.enqueueReplaceState(d, d.state, null), C.queue !== null && 0 < C.queue.length) {
						if (r = C.queue, o = C.replace, C.queue = null, C.replace = !1, o && r.length === 1) d.state = r[0];
						else {
							for (C = o ? r[0] : d.state, D = !0, o = +!!o; o < r.length; o++) E = r[o], E = typeof E == "function" ? E.call(d, C, a, void 0) : E, E != null && (D ? (D = !1, C = R({}, C, E)) : R(C, E));
							d.state = C;
						}
					} else C.queue = null;
				}
				if (r = d.render(), e.status === 12) throw null;
				a = t.keyPath, t.keyPath = n, la(e, t, r, -1), t.keyPath = a;
			} else {
				if (r = aa(e, t, n, r, a, void 0), e.status === 12) throw null;
				oa(e, t, n, r, ai !== 0, oi, si);
			}
		} else if (typeof r == "string") {
			if (d = t.blockedSegment, d === null) d = a.children, C = t.formatContext, D = t.keyPath, t.formatContext = Ie(C, r, a), t.keyPath = n, _a(e, t, d, -1), t.formatContext = C, t.keyPath = D;
			else {
				if (D = Dt(d.chunks, r, a, e.resumableState, e.renderState, t.blockedPreamble, t.hoistableState, t.formatContext, d.lastPushedText), d.lastPushedText = !1, C = t.formatContext, o = t.keyPath, t.keyPath = n, (t.formatContext = Ie(C, r, a)).insertionMode === 3) {
					n = Ji(e, 0, null, t.formatContext, !1, !1), d.preambleChildren.push(n), t.blockedSegment = n;
					try {
						n.status = 6, _a(e, t, D, -1), n.lastPushedText && n.textEmbedded && n.chunks.push(Be), n.status = 1, Ta(e, t.blockedBoundary, n);
					} finally {
						t.blockedSegment = d;
					}
				} else _a(e, t, D, -1);
				t.formatContext = C, t.keyPath = o;
				a: {
					switch (t = d.chunks, e = e.resumableState, r) {
						case "title":
						case "style":
						case "script":
						case "area":
						case "base":
						case "br":
						case "col":
						case "embed":
						case "hr":
						case "img":
						case "input":
						case "keygen":
						case "link":
						case "meta":
						case "param":
						case "source":
						case "track":
						case "wbr": break a;
						case "body":
							if (1 >= C.insertionMode) {
								e.hasBody = !0;
								break a;
							}
							break;
						case "html":
							if (C.insertionMode === 0) {
								e.hasHtml = !0;
								break a;
							}
							break;
						case "head": if (1 >= C.insertionMode) break a;
					}
					t.push(kt(r));
				}
				d.lastPushedText = !1;
			}
		} else {
			switch (r) {
				case b:
				case c:
				case l:
				case s:
					r = t.keyPath, t.keyPath = n, la(e, t, a.children, -1), t.keyPath = r;
					return;
				case y:
					r = t.blockedSegment, r === null ? a.mode !== "hidden" && (r = t.keyPath, t.keyPath = n, _a(e, t, a.children, -1), t.keyPath = r) : a.mode !== "hidden" && (r.chunks.push(Ft), r.lastPushedText = !1, d = t.keyPath, t.keyPath = n, _a(e, t, a.children, -1), t.keyPath = d, r.chunks.push(It), r.lastPushedText = !1);
					return;
				case h:
					a: {
						if (r = a.children, a = a.revealOrder, a === "forwards" || a === "backwards" || a === "unstable_legacy-backwards") {
							if (T(r)) {
								ia(e, t, n, r, a);
								break a;
							}
							if ((d = w(r)) && (d = d.call(r))) {
								if (C = d.next(), !C.done) {
									do
										C = d.next();
									while (!C.done);
									ia(e, t, n, r, a);
								}
								break a;
							}
						}
						a === "together" ? (a = t.keyPath, d = t.row, C = t.row = ra(null), C.boundaries = [], C.together = !0, t.keyPath = n, la(e, t, r, -1), --C.pendingTasks === 0 && ea(e, C), t.keyPath = a, t.row = d, d !== null && 0 < C.pendingTasks && (d.pendingTasks++, C.next = d)) : (a = t.keyPath, t.keyPath = n, la(e, t, r, -1), t.keyPath = a);
					}
					return;
				case S:
				case v: throw Error(i(343));
				case m:
					a: if (t.replay !== null) {
						r = t.keyPath, d = t.formatContext, C = t.row, t.keyPath = n, t.formatContext = ze(e.resumableState, d), t.row = null, n = a.children;
						try {
							_a(e, t, n, -1);
						} finally {
							t.keyPath = r, t.formatContext = d, t.row = C;
						}
					} else {
						r = t.keyPath, o = t.formatContext;
						var O = t.row;
						E = t.blockedBoundary, x = t.blockedPreamble;
						var k = t.hoistableState, A = t.blockedSegment, j = a.fallback;
						a = a.children;
						var ee = /* @__PURE__ */ new Set(), M = 2 > t.formatContext.insertionMode ? Gi(e, t.row, ee, U(), U()) : Gi(e, t.row, ee, null, null);
						e.trackedPostpones !== null && (M.trackedContentKeyPath = n);
						var N = Ji(e, A.chunks.length, M, t.formatContext, !1, !1);
						A.children.push(N), A.lastPushedText = !1;
						var P = Ji(e, 0, null, t.formatContext, !1, !1);
						if (P.parentFlushed = !0, e.trackedPostpones !== null) {
							d = t.componentStack, C = [
								n[0],
								"Suspense Fallback",
								n[2]
							], D = [
								C[1],
								C[2],
								[],
								null
							], e.trackedPostpones.workingMap.set(C, D), M.trackedFallbackNode = D, t.blockedSegment = N, t.blockedPreamble = M.fallbackPreamble, t.keyPath = C, t.formatContext = Re(e.resumableState, o), t.componentStack = Xi(d), N.status = 6;
							try {
								_a(e, t, j, -1), N.lastPushedText && N.textEmbedded && N.chunks.push(Be), N.status = 1, Ta(e, E, N);
							} catch (t) {
								throw N.status = e.status === 12 ? 3 : 4, t;
							} finally {
								t.blockedSegment = A, t.blockedPreamble = x, t.keyPath = r, t.formatContext = o;
							}
							t = Ki(e, null, a, -1, M, P, M.contentPreamble, M.contentState, t.abortSet, n, ze(e.resumableState, t.formatContext), t.context, t.treeContext, null, d), Yi(t), e.pingedTasks.push(t);
						} else {
							t.blockedBoundary = M, t.blockedPreamble = M.contentPreamble, t.hoistableState = M.contentState, t.blockedSegment = P, t.keyPath = n, t.formatContext = ze(e.resumableState, o), t.row = null, P.status = 6;
							try {
								if (_a(e, t, a, -1), P.lastPushedText && P.textEmbedded && P.chunks.push(Be), P.status = 1, Ta(e, M, P), wa(M, P), M.pendingTasks === 0 && M.status === 0) {
									if (M.status = 1, !Ii(e, M)) {
										O !== null && --O.pendingTasks === 0 && ea(e, O), e.pendingRootTasks === 0 && t.blockedPreamble && Aa(e);
										break a;
									}
								} else O !== null && O.together && na(e, O);
							} catch (n) {
								M.status = 4, e.status === 12 ? (P.status = 3, d = e.fatalError) : (P.status = 4, d = n), C = Zi(t.componentStack), D = Qi(e, d, C), M.errorDigest = D, ma(e, M);
							} finally {
								t.blockedBoundary = E, t.blockedPreamble = x, t.hoistableState = k, t.blockedSegment = A, t.keyPath = r, t.formatContext = o, t.row = O;
							}
							t = Ki(e, null, j, -1, E, N, M.fallbackPreamble, M.fallbackState, ee, [
								n[0],
								"Suspense Fallback",
								n[2]
							], Re(e.resumableState, t.formatContext), t.context, t.treeContext, t.row, Xi(t.componentStack)), Yi(t), e.pingedTasks.push(t);
						}
					}
					return;
			}
			if (typeof r == "object" && r) switch (r.$$typeof) {
				case p:
					if ("ref" in a) for (A in d = {}, a) A !== "ref" && (d[A] = a[A]);
					else d = a;
					r = aa(e, t, n, r.render, d, o), oa(e, t, n, r, ai !== 0, oi, si);
					return;
				case g:
					sa(e, t, n, r.type, a, o);
					return;
				case f:
					if (C = a.children, d = t.keyPath, a = a.value, D = r._currentValue, r._currentValue = a, o = jr, jr = r = {
						parent: o,
						depth: o === null ? 0 : o.depth + 1,
						context: r,
						parentValue: D,
						value: a
					}, t.context = r, t.keyPath = n, la(e, t, C, -1), e = jr, e === null) throw Error(i(403));
					e.context._currentValue = e.parentValue, e = jr = e.parent, t.context = e, t.keyPath = d;
					return;
				case u:
					a = a.children, r = a(r._context._currentValue), a = t.keyPath, t.keyPath = n, la(e, t, r, -1), t.keyPath = a;
					return;
				case _:
					if (d = r._init, r = d(r._payload), e.status === 12) throw null;
					sa(e, t, n, r, a, o);
					return;
			}
			throw Error(i(130, r == null ? r : typeof r, ""));
		}
	}
	function ca(e, t, n, r, i) {
		var a = t.replay, o = t.blockedBoundary, s = Ji(e, 0, null, t.formatContext, !1, !1);
		s.id = n, s.parentFlushed = !0;
		try {
			t.replay = null, t.blockedSegment = s, _a(e, t, r, i), s.status = 1, Ta(e, o, s), o === null ? e.completedRootSegment = s : (wa(o, s), o.parentFlushed && e.partialBoundaries.push(o));
		} finally {
			t.replay = a, t.blockedSegment = null;
		}
	}
	function la(e, t, n, r) {
		t.replay !== null && typeof t.replay.slots == "number" ? ca(e, t, t.replay.slots, n, r) : (t.node = n, t.childIndex = r, n = t.componentStack, Yi(t), ua(e, t), t.componentStack = n);
	}
	function ua(e, t) {
		var n = t.node, r = t.childIndex;
		if (n !== null) {
			if (typeof n == "object") {
				switch (n.$$typeof) {
					case a:
						var s = n.type, c = n.key, l = n.props;
						n = l.ref;
						var u = n === void 0 ? null : n, d = kr(s), p = c ?? (r === -1 ? 0 : r);
						if (c = [
							t.keyPath,
							d,
							p
						], t.replay !== null) a: {
							var h = t.replay;
							for (r = h.nodes, n = 0; n < r.length; n++) {
								var g = r[n];
								if (p === g[1]) {
									if (g.length === 4) {
										if (d !== null && d !== g[0]) throw Error(i(490, g[0], d));
										var v = g[2];
										d = g[3], p = t.node, t.replay = {
											nodes: v,
											slots: d,
											pendingTasks: 1
										};
										try {
											if (sa(e, t, c, s, l, u), t.replay.pendingTasks === 1 && 0 < t.replay.nodes.length) throw Error(i(488));
											t.replay.pendingTasks--;
										} catch (i) {
											if (typeof i == "object" && i && (i === Kr || typeof i.then == "function")) throw t.node === p ? t.replay = h : r.splice(n, 1), i;
											t.replay.pendingTasks--, l = Zi(t.componentStack), c = e, e = t.blockedBoundary, s = i, l = Qi(c, s, l), ya(c, e, v, d, s, l);
										}
										t.replay = h;
									} else {
										if (s !== m) throw Error(i(490, "Suspense", kr(s) || "Unknown"));
										b: {
											h = void 0, s = g[5], u = g[2], d = g[3], p = g[4] === null ? [] : g[4][2], g = g[4] === null ? null : g[4][3];
											var y = t.keyPath, b = t.formatContext, x = t.row, S = t.replay, C = t.blockedBoundary, E = t.hoistableState, D = l.children, O = l.fallback, k = /* @__PURE__ */ new Set();
											l = 2 > t.formatContext.insertionMode ? Gi(e, t.row, k, U(), U()) : Gi(e, t.row, k, null, null), l.parentFlushed = !0, l.rootSegmentID = s, t.blockedBoundary = l, t.hoistableState = l.contentState, t.keyPath = c, t.formatContext = ze(e.resumableState, b), t.row = null, t.replay = {
												nodes: u,
												slots: d,
												pendingTasks: 1
											};
											try {
												if (_a(e, t, D, -1), t.replay.pendingTasks === 1 && 0 < t.replay.nodes.length) throw Error(i(488));
												if (t.replay.pendingTasks--, l.pendingTasks === 0 && l.status === 0) {
													l.status = 1, e.completedBoundaries.push(l);
													break b;
												}
											} catch (n) {
												l.status = 4, v = Zi(t.componentStack), h = Qi(e, n, v), l.errorDigest = h, t.replay.pendingTasks--, e.clientRenderedBoundaries.push(l);
											} finally {
												t.blockedBoundary = C, t.hoistableState = E, t.replay = S, t.keyPath = y, t.formatContext = b, t.row = x;
											}
											v = qi(e, null, {
												nodes: p,
												slots: g,
												pendingTasks: 0
											}, O, -1, C, l.fallbackState, k, [
												c[0],
												"Suspense Fallback",
												c[2]
											], Re(e.resumableState, t.formatContext), t.context, t.treeContext, t.row, Xi(t.componentStack)), Yi(v), e.pingedTasks.push(v);
										}
									}
									r.splice(n, 1);
									break a;
								}
							}
						}
						else sa(e, t, c, s, l, u);
						return;
					case o: throw Error(i(257));
					case _:
						if (v = n._init, n = v(n._payload), e.status === 12) throw null;
						la(e, t, n, r);
						return;
				}
				if (T(n)) {
					da(e, t, n, r);
					return;
				}
				if ((v = w(n)) && (v = v.call(n))) {
					if (n = v.next(), !n.done) {
						l = [];
						do
							l.push(n.value), n = v.next();
						while (!n.done);
						da(e, t, l, r);
					}
					return;
				}
				if (typeof n.then == "function") return t.thenableState = null, la(e, t, Ti(n), r);
				if (n.$$typeof === f) return la(e, t, n._currentValue, r);
				throw r = Object.prototype.toString.call(n), Error(i(31, r === "[object Object]" ? "object with keys {" + Object.keys(n).join(", ") + "}" : r));
			}
			typeof n == "string" ? (r = t.blockedSegment, r !== null && (r.lastPushedText = Ve(r.chunks, n, e.renderState, r.lastPushedText))) : (typeof n == "number" || typeof n == "bigint") && (r = t.blockedSegment, r !== null && (r.lastPushedText = Ve(r.chunks, "" + n, e.renderState, r.lastPushedText)));
		}
	}
	function da(e, t, n, r) {
		var a = t.keyPath;
		if (r !== -1 && (t.keyPath = [
			t.keyPath,
			"Fragment",
			r
		], t.replay !== null)) {
			for (var o = t.replay, s = o.nodes, c = 0; c < s.length; c++) {
				var l = s[c];
				if (l[1] === r) {
					r = l[2], l = l[3], t.replay = {
						nodes: r,
						slots: l,
						pendingTasks: 1
					};
					try {
						if (da(e, t, n, -1), t.replay.pendingTasks === 1 && 0 < t.replay.nodes.length) throw Error(i(488));
						t.replay.pendingTasks--;
					} catch (i) {
						if (typeof i == "object" && i && (i === Kr || typeof i.then == "function")) throw i;
						t.replay.pendingTasks--, n = Zi(t.componentStack);
						var u = t.blockedBoundary, d = i;
						n = Qi(e, d, n), ya(e, u, r, l, d, n);
					}
					t.replay = o, s.splice(c, 1);
					break;
				}
			}
			t.keyPath = a;
			return;
		}
		if (o = t.treeContext, s = n.length, t.replay !== null && (c = t.replay.slots, typeof c == "object" && c)) {
			for (r = 0; r < s; r++) l = n[r], t.treeContext = Br(o, s, r), u = c[r], typeof u == "number" ? (ca(e, t, u, l, r), delete c[r]) : _a(e, t, l, r);
			t.treeContext = o, t.keyPath = a;
			return;
		}
		for (c = 0; c < s; c++) r = n[c], t.treeContext = Br(o, s, c), _a(e, t, r, c);
		t.treeContext = o, t.keyPath = a;
	}
	function fa(e, t, n) {
		if (n.status = 5, n.rootSegmentID = e.nextSegmentId++, e = n.trackedContentKeyPath, e === null) throw Error(i(486));
		var r = n.trackedFallbackNode, a = [], o = t.workingMap.get(e);
		return o === void 0 ? (n = [
			e[1],
			e[2],
			a,
			null,
			r,
			n.rootSegmentID
		], t.workingMap.set(e, n), Ua(n, e[0], t), n) : (o[4] = r, o[5] = n.rootSegmentID, o);
	}
	function pa(e, t, n, r) {
		r.status = 5;
		var a = n.keyPath, o = n.blockedBoundary;
		if (o === null) r.id = e.nextSegmentId++, t.rootSlots = r.id, e.completedRootSegment !== null && (e.completedRootSegment.status = 5);
		else {
			if (o !== null && o.status === 0) {
				var s = fa(e, t, o);
				if (o.trackedContentKeyPath === a && n.childIndex === -1) {
					r.id === -1 && (r.id = r.parentFlushed ? o.rootSegmentID : e.nextSegmentId++), s[3] = r.id;
					return;
				}
			}
			if (r.id === -1 && (r.id = r.parentFlushed && o !== null ? o.rootSegmentID : e.nextSegmentId++), n.childIndex === -1) a === null ? t.rootSlots = r.id : (n = t.workingMap.get(a), n === void 0 ? (n = [
				a[1],
				a[2],
				[],
				r.id
			], Ua(n, a[0], t)) : n[3] = r.id);
			else {
				if (a === null) {
					if (e = t.rootSlots, e === null) e = t.rootSlots = {};
					else if (typeof e == "number") throw Error(i(491));
				} else if (o = t.workingMap, s = o.get(a), s === void 0) e = {}, s = [
					a[1],
					a[2],
					[],
					e
				], o.set(a, s), Ua(s, a[0], t);
				else if (e = s[3], e === null) e = s[3] = {};
				else if (typeof e == "number") throw Error(i(491));
				e[n.childIndex] = r.id;
			}
		}
	}
	function ma(e, t) {
		e = e.trackedPostpones, e !== null && (t = t.trackedContentKeyPath, t !== null && (t = e.workingMap.get(t), t !== void 0 && (t.length = 4, t[2] = [], t[3] = null)));
	}
	function ha(e, t, n) {
		return qi(e, n, t.replay, t.node, t.childIndex, t.blockedBoundary, t.hoistableState, t.abortSet, t.keyPath, t.formatContext, t.context, t.treeContext, t.row, t.componentStack);
	}
	function ga(e, t, n) {
		var r = t.blockedSegment, i = Ji(e, r.chunks.length, null, t.formatContext, r.lastPushedText, !0);
		return r.children.push(i), r.lastPushedText = !1, Ki(e, n, t.node, t.childIndex, t.blockedBoundary, i, t.blockedPreamble, t.hoistableState, t.abortSet, t.keyPath, t.formatContext, t.context, t.treeContext, t.row, t.componentStack);
	}
	function _a(e, t, n, r) {
		var i = t.formatContext, a = t.context, o = t.keyPath, s = t.treeContext, c = t.componentStack, l = t.blockedSegment;
		if (l === null) {
			l = t.replay;
			try {
				return la(e, t, n, r);
			} catch (u) {
				if (gi(), n = u === Kr ? Yr() : u, e.status !== 12 && typeof n == "object" && n) {
					if (typeof n.then == "function") {
						r = u === Kr ? hi() : null, e = ha(e, t, r).ping, n.then(e, e), t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, t.componentStack = c, t.replay = l, Lr(a);
						return;
					}
					if (n.message === "Maximum call stack size exceeded") {
						n = u === Kr ? hi() : null, n = ha(e, t, n), e.pingedTasks.push(n), t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, t.componentStack = c, t.replay = l, Lr(a);
						return;
					}
				}
			}
		} else {
			var u = l.children.length, d = l.chunks.length;
			try {
				return la(e, t, n, r);
			} catch (r) {
				if (gi(), l.children.length = u, l.chunks.length = d, n = r === Kr ? Yr() : r, e.status !== 12 && typeof n == "object" && n) {
					if (typeof n.then == "function") {
						l = n, n = r === Kr ? hi() : null, e = ga(e, t, n).ping, l.then(e, e), t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, t.componentStack = c, Lr(a);
						return;
					}
					if (n.message === "Maximum call stack size exceeded") {
						l = r === Kr ? hi() : null, l = ga(e, t, l), e.pingedTasks.push(l), t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, t.componentStack = c, Lr(a);
						return;
					}
				}
			}
		}
		throw t.formatContext = i, t.context = a, t.keyPath = o, t.treeContext = s, Lr(a), n;
	}
	function va(e) {
		var t = e.blockedBoundary, n = e.blockedSegment;
		n !== null && (n.status = 3, Ea(this, t, e.row, n));
	}
	function ya(e, t, n, r, a, o) {
		for (var s = 0; s < n.length; s++) {
			var c = n[s];
			if (c.length === 4) ya(e, t, c[2], c[3], a, o);
			else {
				c = c[5];
				var l = e, u = o, d = Gi(l, null, /* @__PURE__ */ new Set(), null, null);
				d.parentFlushed = !0, d.rootSegmentID = c, d.status = 4, d.errorDigest = u, d.parentFlushed && l.clientRenderedBoundaries.push(d);
			}
		}
		if (n.length = 0, r !== null) {
			if (t === null) throw Error(i(487));
			if (t.status !== 4 && (t.status = 4, t.errorDigest = o, t.parentFlushed && e.clientRenderedBoundaries.push(t)), typeof r == "object") for (var f in r) delete r[f];
		}
	}
	function ba(e, t, n) {
		var r = e.blockedBoundary, i = e.blockedSegment;
		if (i !== null) {
			if (i.status === 6) return;
			i.status = 3;
		}
		var a = Zi(e.componentStack);
		if (r === null) {
			if (t.status !== 13 && t.status !== 14) {
				if (r = e.replay, r === null) {
					t.trackedPostpones !== null && i !== null ? (r = t.trackedPostpones, Qi(t, n, a), pa(t, r, e, i), Ea(t, null, e.row, i)) : (Qi(t, n, a), $i(t, n));
					return;
				}
				r.pendingTasks--, r.pendingTasks === 0 && 0 < r.nodes.length && (i = Qi(t, n, a), ya(t, null, r.nodes, r.slots, n, i)), t.pendingRootTasks--, t.pendingRootTasks === 0 && Sa(t);
			}
		} else {
			var o = t.trackedPostpones;
			if (r.status !== 4) {
				if (o !== null && i !== null) return Qi(t, n, a), pa(t, o, e, i), r.fallbackAbortableTasks.forEach(function(e) {
					return ba(e, t, n);
				}), r.fallbackAbortableTasks.clear(), Ea(t, r, e.row, i);
				r.status = 4, i = Qi(t, n, a), r.status = 4, r.errorDigest = i, ma(t, r), r.parentFlushed && t.clientRenderedBoundaries.push(r);
			}
			r.pendingTasks--, i = r.row, i !== null && --i.pendingTasks === 0 && ea(t, i), r.fallbackAbortableTasks.forEach(function(e) {
				return ba(e, t, n);
			}), r.fallbackAbortableTasks.clear();
		}
		e = e.row, e !== null && --e.pendingTasks === 0 && ea(t, e), t.allPendingTasks--, t.allPendingTasks === 0 && Ca(t);
	}
	function xa(e, t) {
		try {
			var n = e.renderState, r = n.onHeaders;
			if (r) {
				var i = n.headers;
				if (i) {
					n.headers = null;
					var a = i.preconnects;
					if (i.fontPreloads && (a && (a += ", "), a += i.fontPreloads), i.highImagePreloads && (a && (a += ", "), a += i.highImagePreloads), !t) {
						var o = n.styles.values(), s = o.next();
						b: for (; 0 < i.remainingCapacity && !s.done; s = o.next()) for (var c = s.value.sheets.values(), l = c.next(); 0 < i.remainingCapacity && !l.done; l = c.next()) {
							var u = l.value, d = u.props, f = d.href, p = u.props, m = vr(p.href, "style", {
								crossOrigin: p.crossOrigin,
								integrity: p.integrity,
								nonce: p.nonce,
								type: p.type,
								fetchPriority: p.fetchPriority,
								referrerPolicy: p.referrerPolicy,
								media: p.media
							});
							if (0 <= (i.remainingCapacity -= m.length + 2)) n.resets.style[f] = ye, a && (a += ", "), a += m, n.resets.style[f] = typeof d.crossOrigin == "string" || typeof d.integrity == "string" ? [d.crossOrigin, d.integrity] : ye;
							else break b;
						}
					}
					r(a ? { Link: a } : {});
				}
			}
		} catch (t) {
			Qi(e, t, {});
		}
	}
	function Sa(e) {
		e.trackedPostpones === null && xa(e, !0), e.trackedPostpones === null && Aa(e), e.onShellError = Gr, e = e.onShellReady, e();
	}
	function Ca(e) {
		xa(e, e.trackedPostpones === null || e.completedRootSegment === null || e.completedRootSegment.status !== 5), Aa(e), e = e.onAllReady, e();
	}
	function wa(e, t) {
		if (t.chunks.length === 0 && t.children.length === 1 && t.children[0].boundary === null && t.children[0].id === -1) {
			var n = t.children[0];
			n.id = t.id, n.parentFlushed = !0, n.status !== 1 && n.status !== 3 && n.status !== 4 || wa(e, n);
		} else e.completedSegments.push(t);
	}
	function Ta(e, t, n) {
		if (re !== null) {
			n = n.chunks;
			for (var r = 0, i = 0; i < n.length; i++) r += n[i].byteLength;
			t === null ? e.byteSize += r : t.byteSize += r;
		}
	}
	function Ea(e, t, n, r) {
		if (n !== null && (--n.pendingTasks === 0 ? ea(e, n) : n.together && na(e, n)), e.allPendingTasks--, t === null) {
			if (r !== null && r.parentFlushed) {
				if (e.completedRootSegment !== null) throw Error(i(389));
				e.completedRootSegment = r;
			}
			e.pendingRootTasks--, e.pendingRootTasks === 0 && Sa(e);
		} else if (t.pendingTasks--, t.status !== 4) {
			if (t.pendingTasks === 0) {
				if (t.status === 0 && (t.status = 1), r !== null && r.parentFlushed && (r.status === 1 || r.status === 3) && wa(t, r), t.parentFlushed && e.completedBoundaries.push(t), t.status === 1) n = t.row, n !== null && Tr(n.hoistables, t.contentState), Ii(e, t) || (t.fallbackAbortableTasks.forEach(va, e), t.fallbackAbortableTasks.clear(), n !== null && --n.pendingTasks === 0 && ea(e, n)), e.pendingRootTasks === 0 && e.trackedPostpones === null && t.contentPreamble !== null && Aa(e);
				else if (t.status === 5 && (t = t.row, t !== null)) {
					if (e.trackedPostpones !== null) {
						n = e.trackedPostpones;
						var a = t.next;
						if (a !== null && (r = a.boundaries, r !== null)) for (a.boundaries = null, a = 0; a < r.length; a++) {
							var o = r[a];
							fa(e, n, o), Ea(e, o, null, null);
						}
					}
					--t.pendingTasks === 0 && ea(e, t);
				}
			} else r === null || !r.parentFlushed || r.status !== 1 && r.status !== 3 || (wa(t, r), t.completedSegments.length === 1 && t.parentFlushed && e.partialBoundaries.push(t)), t = t.row, t !== null && t.together && na(e, t);
		}
		e.allPendingTasks === 0 && Ca(e);
	}
	function Da(e) {
		if (e.status !== 14 && e.status !== 13) {
			var t = jr, n = he.H;
			he.H = Di;
			var r = he.A;
			he.A = ki;
			var a = Ui;
			Ui = e;
			var o = Oi;
			Oi = e.resumableState;
			try {
				for (var s = e.pingedTasks, c = 0; c < s.length; c++) {
					var l = s[c], u = e, d = l.blockedSegment;
					if (d === null) {
						var f = u;
						if (l.replay.pendingTasks !== 0) {
							Lr(l.context);
							try {
								if (typeof l.replay.slots == "number" ? ca(f, l, l.replay.slots, l.node, l.childIndex) : ua(f, l), l.replay.pendingTasks === 1 && 0 < l.replay.nodes.length) throw Error(i(488));
								l.replay.pendingTasks--, l.abortSet.delete(l), Ea(f, l.blockedBoundary, l.row, null);
							} catch (e) {
								gi();
								var p = e === Kr ? Yr() : e;
								if (typeof p == "object" && p && typeof p.then == "function") {
									var m = l.ping;
									p.then(m, m), l.thenableState = e === Kr ? hi() : null;
								} else {
									l.replay.pendingTasks--, l.abortSet.delete(l);
									var h = Zi(l.componentStack);
									u = void 0;
									var g = f, _ = l.blockedBoundary, v = f.status === 12 ? f.fatalError : p, y = l.replay.nodes, b = l.replay.slots;
									u = Qi(g, v, h), ya(g, _, y, b, v, u), f.pendingRootTasks--, f.pendingRootTasks === 0 && Sa(f), f.allPendingTasks--, f.allPendingTasks === 0 && Ca(f);
								}
							}
						}
					} else if (f = void 0, g = d, g.status === 0) {
						g.status = 6, Lr(l.context);
						var x = g.children.length, S = g.chunks.length;
						try {
							ua(u, l), g.lastPushedText && g.textEmbedded && g.chunks.push(Be), l.abortSet.delete(l), g.status = 1, Ta(u, l.blockedBoundary, g), Ea(u, l.blockedBoundary, l.row, g);
						} catch (e) {
							gi(), g.children.length = x, g.chunks.length = S;
							var C = e === Kr ? Yr() : u.status === 12 ? u.fatalError : e;
							if (u.status === 12 && u.trackedPostpones !== null) {
								var w = u.trackedPostpones, T = Zi(l.componentStack);
								l.abortSet.delete(l), Qi(u, C, T), pa(u, w, l, g), Ea(u, l.blockedBoundary, l.row, g);
							} else if (typeof C == "object" && C && typeof C.then == "function") {
								g.status = 0, l.thenableState = e === Kr ? hi() : null;
								var E = l.ping;
								C.then(E, E);
							} else {
								var D = Zi(l.componentStack);
								l.abortSet.delete(l), g.status = 4;
								var O = l.blockedBoundary, k = l.row;
								if (k !== null && --k.pendingTasks === 0 && ea(u, k), u.allPendingTasks--, f = Qi(u, C, D), O === null) $i(u, C);
								else if (O.pendingTasks--, O.status !== 4) {
									O.status = 4, O.errorDigest = f, ma(u, O);
									var A = O.row;
									A !== null && --A.pendingTasks === 0 && ea(u, A), O.parentFlushed && u.clientRenderedBoundaries.push(O), u.pendingRootTasks === 0 && u.trackedPostpones === null && O.contentPreamble !== null && Aa(u);
								}
								u.allPendingTasks === 0 && Ca(u);
							}
						}
					}
				}
				s.splice(0, c), e.destination !== null && Ra(e, e.destination);
			} catch (t) {
				Qi(e, t, {}), $i(e, t);
			} finally {
				Oi = o, he.H = n, he.A = r, n === Di && Lr(t), Ui = a;
			}
		}
	}
	function Oa(e, t, n) {
		t.preambleChildren.length && n.push(t.preambleChildren);
		for (var r = !1, i = 0; i < t.children.length; i++) r = ka(e, t.children[i], n) || r;
		return r;
	}
	function ka(e, t, n) {
		var r = t.boundary;
		if (r === null) return Oa(e, t, n);
		var a = r.contentPreamble, o = r.fallbackPreamble;
		if (a === null || o === null) return !1;
		switch (r.status) {
			case 1:
				if (At(e.renderState, a), e.byteSize += r.byteSize, t = r.completedSegments[0], !t) throw Error(i(391));
				return Oa(e, t, n);
			case 5: if (e.trackedPostpones !== null) return !0;
			case 4: if (t.status === 1) return At(e.renderState, o), Oa(e, t, n);
			default: return !0;
		}
	}
	function Aa(e) {
		if (e.completedRootSegment && e.completedPreambleSegments === null) {
			var t = [], n = e.byteSize, r = ka(e, e.completedRootSegment, t), i = e.renderState.preamble;
			!1 === r || i.headChunks && i.bodyChunks ? e.completedPreambleSegments = t : e.byteSize = n;
		}
	}
	function ja(e, t, n, r) {
		switch (n.parentFlushed = !0, n.status) {
			case 0: n.id = e.nextSegmentId++;
			case 5: return r = n.id, n.lastPushedText = !1, n.textEmbedded = !1, e = e.renderState, P(t, Nt), P(t, e.placeholderPrefix), e = I(r.toString(16)), P(t, e), F(t, Pt);
			case 1:
				n.status = 2;
				var a = !0, o = n.chunks, s = 0;
				n = n.children;
				for (var c = 0; c < n.length; c++) {
					for (a = n[c]; s < a.index; s++) P(t, o[s]);
					a = Na(e, t, a, r);
				}
				for (; s < o.length - 1; s++) P(t, o[s]);
				return s < o.length && (a = F(t, o[s])), a;
			case 3: return !0;
			default: throw Error(i(390));
		}
	}
	var Ma = 0;
	function Na(e, t, n, r) {
		var a = n.boundary;
		if (a === null) return ja(e, t, n, r);
		if (a.parentFlushed = !0, a.status === 4) {
			var o = a.row;
			o !== null && --o.pendingTasks === 0 && ea(e, o), a = a.errorDigest, F(t, Y), P(t, Vt), a && (P(t, Ut), P(t, I(V(a))), P(t, Ht)), F(t, Wt), ja(e, t, n, r);
		} else if (a.status !== 1) a.status === 0 && (a.rootSegmentID = e.nextSegmentId++), 0 < a.completedSegments.length && e.partialBoundaries.push(a), Gt(t, e.renderState, a.rootSegmentID), r && Tr(r, a.fallbackState), ja(e, t, n, r);
		else if (!La && Ii(e, a) && (Ma + a.byteSize > e.progressiveChunkSize || Er(a.contentState))) a.rootSegmentID = e.nextSegmentId++, e.completedBoundaries.push(a), Gt(t, e.renderState, a.rootSegmentID), ja(e, t, n, r);
		else {
			if (Ma += a.byteSize, r && Tr(r, a.contentState), n = a.row, n !== null && Ii(e, a) && --n.pendingTasks === 0 && ea(e, n), F(t, Lt), n = a.completedSegments, n.length !== 1) throw Error(i(391));
			Na(e, t, n[0], r);
		}
		return F(t, Bt);
	}
	function Pa(e, t, n, r) {
		return fn(t, e.renderState, n.parentFormatContext, n.id), Na(e, t, n, r), pn(t, n.parentFormatContext);
	}
	function Fa(e, t, n) {
		Ma = n.byteSize;
		for (var r = n.completedSegments, i = 0; i < r.length; i++) Ia(e, t, n, r[i]);
		r.length = 0, r = n.row, r !== null && Ii(e, n) && --r.pendingTasks === 0 && ea(e, r), Wn(t, n.contentState, e.renderState), r = e.resumableState, e = e.renderState, i = n.rootSegmentID, n = n.contentState;
		var a = e.stylesToHoist;
		return e.stylesToHoist = !1, P(t, e.startInlineScript), P(t, J), a ? (!(r.instructions & 4) && (r.instructions |= 4, P(t, En)), !(r.instructions & 2) && (r.instructions |= 2, P(t, vn)), r.instructions & 8 ? P(t, xn) : (r.instructions |= 8, P(t, bn))) : (!(r.instructions & 2) && (r.instructions |= 2, P(t, vn)), P(t, yn)), r = I(i.toString(16)), P(t, e.boundaryPrefix), P(t, r), P(t, Sn), P(t, e.segmentPrefix), P(t, r), a ? (P(t, Cn), sr(t, n)) : P(t, wn), n = F(t, Tn), jt(t, e) && n;
	}
	function Ia(e, t, n, r) {
		if (r.status === 2) return !0;
		var a = n.contentState, o = r.id;
		if (o === -1) {
			if ((r.id = n.rootSegmentID) === -1) throw Error(i(392));
			return Pa(e, t, r, a);
		}
		return o === n.rootSegmentID ? Pa(e, t, r, a) : (Pa(e, t, r, a), n = e.resumableState, e = e.renderState, P(t, e.startInlineScript), P(t, J), n.instructions & 1 ? P(t, hn) : (n.instructions |= 1, P(t, mn)), P(t, e.segmentPrefix), o = I(o.toString(16)), P(t, o), P(t, gn), P(t, e.placeholderPrefix), P(t, o), t = F(t, _n), t);
	}
	var La = !1;
	function Ra(e, t) {
		M = /* @__PURE__ */ new Uint8Array(2048), N = 0;
		try {
			if (!(0 < e.pendingRootTasks)) {
				var n, r = e.completedRootSegment;
				if (r !== null) {
					if (r.status === 5) return;
					var i = e.completedPreambleSegments;
					if (i === null) return;
					Ma = e.byteSize;
					var a = e.resumableState, o = e.renderState, s = o.preamble, c = s.htmlChunks, l = s.headChunks, u;
					if (c) {
						for (u = 0; u < c.length; u++) P(t, c[u]);
						if (l) for (u = 0; u < l.length; u++) P(t, l[u]);
						else P(t, Tt("head")), P(t, J);
					} else if (l) for (u = 0; u < l.length; u++) P(t, l[u]);
					var d = o.charsetChunks;
					for (u = 0; u < d.length; u++) P(t, d[u]);
					d.length = 0, o.preconnects.forEach(Q, t), o.preconnects.clear();
					var f = o.viewportChunks;
					for (u = 0; u < f.length; u++) P(t, f[u]);
					f.length = 0, o.fontPreloads.forEach(Q, t), o.fontPreloads.clear(), o.highImagePreloads.forEach(Q, t), o.highImagePreloads.clear(), be = o, o.styles.forEach(Qn, t), be = null;
					var p = o.importMapChunks;
					for (u = 0; u < p.length; u++) P(t, p[u]);
					p.length = 0, o.bootstrapScripts.forEach(Q, t), o.scripts.forEach(Q, t), o.scripts.clear(), o.bulkPreloads.forEach(Q, t), o.bulkPreloads.clear(), c || l || (a.instructions |= 32);
					var m = o.hoistableChunks;
					for (u = 0; u < m.length; u++) P(t, m[u]);
					for (a = m.length = 0; a < i.length; a++) {
						var h = i[a];
						for (o = 0; o < h.length; o++) Na(e, t, h[o], null);
					}
					var g = e.renderState.preamble, _ = g.headChunks;
					(g.htmlChunks || _) && P(t, kt("head"));
					var v = g.bodyChunks;
					if (v) for (i = 0; i < v.length; i++) P(t, v[i]);
					Na(e, t, r, null), e.completedRootSegment = null;
					var y = e.renderState;
					if (e.allPendingTasks !== 0 || e.clientRenderedBoundaries.length !== 0 || e.completedBoundaries.length !== 0 || e.trackedPostpones !== null && (e.trackedPostpones.rootNodes.length !== 0 || e.trackedPostpones.rootSlots !== null)) {
						var b = e.resumableState;
						if (!(b.instructions & 64)) {
							if (b.instructions |= 64, P(t, y.startInlineScript), !(b.instructions & 32)) {
								b.instructions |= 32;
								var x = "_" + b.idPrefix + "R_";
								P(t, tr), P(t, I(V(x))), P(t, G);
							}
							P(t, J), P(t, Mt), F(t, H);
						}
					}
					jt(t, y);
				}
				var S = e.renderState;
				r = 0;
				var C = S.viewportChunks;
				for (r = 0; r < C.length; r++) P(t, C[r]);
				C.length = 0, S.preconnects.forEach(Q, t), S.preconnects.clear(), S.fontPreloads.forEach(Q, t), S.fontPreloads.clear(), S.highImagePreloads.forEach(Q, t), S.highImagePreloads.clear(), S.styles.forEach(er, t), S.scripts.forEach(Q, t), S.scripts.clear(), S.bulkPreloads.forEach(Q, t), S.bulkPreloads.clear();
				var w = S.hoistableChunks;
				for (r = 0; r < w.length; r++) P(t, w[r]);
				w.length = 0;
				var T = e.clientRenderedBoundaries;
				for (n = 0; n < T.length; n++) {
					var E = T[n];
					S = t;
					var D = e.resumableState, O = e.renderState, k = E.rootSegmentID, A = E.errorDigest;
					P(S, O.startInlineScript), P(S, J), D.instructions & 4 ? P(S, On) : (D.instructions |= 4, P(S, Dn)), P(S, O.boundaryPrefix), P(S, I(k.toString(16))), P(S, kn), A && (P(S, An), P(S, I(Nn(A || ""))));
					var j = F(S, jn);
					if (!j) {
						e.destination = null, n++, T.splice(0, n);
						return;
					}
				}
				T.splice(0, n);
				var ee = e.completedBoundaries;
				for (n = 0; n < ee.length; n++) if (!Fa(e, t, ee[n])) {
					e.destination = null, n++, ee.splice(0, n);
					return;
				}
				ee.splice(0, n), te(t), M = /* @__PURE__ */ new Uint8Array(2048), N = 0, La = !0;
				var ne = e.partialBoundaries;
				for (n = 0; n < ne.length; n++) {
					var L = ne[n];
					a: {
						T = e, E = t, Ma = L.byteSize;
						var re = L.completedSegments;
						for (j = 0; j < re.length; j++) if (!Ia(T, E, L, re[j])) {
							j++, re.splice(0, j);
							var ie = !1;
							break a;
						}
						re.splice(0, j);
						var R = L.row;
						R !== null && R.together && L.pendingTasks === 1 && (R.pendingTasks === 1 ? ta(T, R, R.hoistables) : R.pendingTasks--), ie = Wn(E, L.contentState, T.renderState);
					}
					if (!ie) {
						e.destination = null, n++, ne.splice(0, n);
						return;
					}
				}
				ne.splice(0, n), La = !1;
				var z = e.completedBoundaries;
				for (n = 0; n < z.length; n++) if (!Fa(e, t, z[n])) {
					e.destination = null, n++, z.splice(0, n);
					return;
				}
				z.splice(0, n);
			}
		} finally {
			La = !1, e.allPendingTasks === 0 && e.clientRenderedBoundaries.length === 0 && e.completedBoundaries.length === 0 ? (e.flushScheduled = !1, n = e.resumableState, n.hasBody && P(t, kt("body")), n.hasHtml && P(t, kt("html")), te(t), e.status = 14, t.close(), e.destination = null) : te(t);
		}
	}
	function za(e) {
		e.flushScheduled = e.destination !== null, ee(function() {
			return Da(e);
		}), k(function() {
			e.status === 10 && (e.status = 11), e.trackedPostpones === null && xa(e, e.pendingRootTasks === 0);
		});
	}
	function Ba(e) {
		!1 === e.flushScheduled && e.pingedTasks.length === 0 && e.destination !== null && (e.flushScheduled = !0, k(function() {
			var t = e.destination;
			t ? Ra(e, t) : e.flushScheduled = !1;
		}));
	}
	function Va(e, t) {
		if (e.status === 13) e.status = 14, ie(t, e.fatalError);
		else if (e.status !== 14 && e.destination === null) {
			e.destination = t;
			try {
				Ra(e, t);
			} catch (t) {
				Qi(e, t, {}), $i(e, t);
			}
		}
	}
	function Ha(e, t) {
		(e.status === 11 || e.status === 10) && (e.status = 12);
		try {
			var n = e.abortableTasks;
			if (0 < n.size) {
				var r = t === void 0 ? Error(i(432)) : typeof t == "object" && t && typeof t.then == "function" ? Error(i(530)) : t;
				e.fatalError = r, n.forEach(function(t) {
					return ba(t, e, r);
				}), n.clear();
			}
			e.destination !== null && Ra(e, e.destination);
		} catch (t) {
			Qi(e, t, {}), $i(e, t);
		}
	}
	function Ua(e, t, n) {
		if (t === null) n.rootNodes.push(e);
		else {
			var r = n.workingMap, i = r.get(t);
			i === void 0 && (i = [
				t[1],
				t[2],
				[],
				null
			], r.set(t, i), Ua(i, t[0], n)), i[2].push(e);
		}
	}
	function Wa(e) {
		var t = e.trackedPostpones;
		if (t === null || t.rootNodes.length === 0 && t.rootSlots === null) return e.trackedPostpones = null;
		if (e.completedRootSegment === null || e.completedRootSegment.status !== 5 && e.completedPreambleSegments !== null) {
			var n = e.nextSegmentId, r = t.rootSlots, i = e.resumableState;
			i.bootstrapScriptContent = void 0, i.bootstrapScripts = void 0, i.bootstrapModules = void 0;
		} else {
			n = 0, r = -1, i = e.resumableState;
			var a = e.renderState;
			i.nextFormID = 0, i.hasBody = !1, i.hasHtml = !1, i.unknownResources = { font: a.resets.font }, i.dnsResources = a.resets.dns, i.connectResources = a.resets.connect, i.imageResources = a.resets.image, i.styleResources = a.resets.style, i.scriptResources = {}, i.moduleUnknownResources = {}, i.moduleScriptResources = {}, i.instructions = 0;
		}
		return {
			nextSegmentId: n,
			rootFormatContext: e.rootFormatContext,
			progressiveChunkSize: e.progressiveChunkSize,
			resumableState: e.resumableState,
			replayNodes: t.rootNodes,
			replaySlots: r
		};
	}
	function Ga() {
		var e = t.version;
		if (e !== "19.2.8") throw Error(i(527, e, "19.2.8"));
	}
	Ga(), Ga(), e.prerender = function(e, t) {
		return new Promise(function(n, r) {
			var i = t ? t.onHeaders : void 0, a;
			i && (a = function(e) {
				i(new Headers(e));
			});
			var o = Pe(t ? t.identifierPrefix : void 0, t ? t.unstable_externalRuntimeSrc : void 0, t ? t.bootstrapScriptContent : void 0, t ? t.bootstrapScripts : void 0, t ? t.bootstrapModules : void 0), s = Bi(e, o, Ne(o, void 0, t ? t.unstable_externalRuntimeSrc : void 0, t ? t.importMap : void 0, a, t ? t.maxHeadersLength : void 0), Fe(t ? t.namespaceURI : void 0), t ? t.progressiveChunkSize : void 0, t ? t.onError : void 0, function() {
				var e = new ReadableStream({
					type: "bytes",
					pull: function(e) {
						Va(s, e);
					},
					cancel: function(e) {
						s.destination = null, Ha(s, e);
					}
				}, { highWaterMark: 0 });
				e = {
					postponed: Wa(s),
					prelude: e
				}, n(e);
			}, void 0, void 0, r, t ? t.onPostpone : void 0);
			if (t && t.signal) {
				var c = t.signal;
				if (c.aborted) Ha(s, c.reason);
				else {
					var l = function() {
						Ha(s, c.reason), c.removeEventListener("abort", l);
					};
					c.addEventListener("abort", l);
				}
			}
			za(s);
		});
	}, e.renderToReadableStream = function(e, t) {
		return new Promise(function(n, r) {
			var i, a, o = new Promise(function(e, t) {
				a = e, i = t;
			}), s = t ? t.onHeaders : void 0, c;
			s && (c = function(e) {
				s(new Headers(e));
			});
			var l = Pe(t ? t.identifierPrefix : void 0, t ? t.unstable_externalRuntimeSrc : void 0, t ? t.bootstrapScriptContent : void 0, t ? t.bootstrapScripts : void 0, t ? t.bootstrapModules : void 0), u = zi(e, l, Ne(l, t ? t.nonce : void 0, t ? t.unstable_externalRuntimeSrc : void 0, t ? t.importMap : void 0, c, t ? t.maxHeadersLength : void 0), Fe(t ? t.namespaceURI : void 0), t ? t.progressiveChunkSize : void 0, t ? t.onError : void 0, a, function() {
				var e = new ReadableStream({
					type: "bytes",
					pull: function(e) {
						Va(u, e);
					},
					cancel: function(e) {
						u.destination = null, Ha(u, e);
					}
				}, { highWaterMark: 0 });
				e.allReady = o, n(e);
			}, function(e) {
				o.catch(function() {}), r(e);
			}, i, t ? t.onPostpone : void 0, t ? t.formState : void 0);
			if (t && t.signal) {
				var d = t.signal;
				if (d.aborted) Ha(u, d.reason);
				else {
					var f = function() {
						Ha(u, d.reason), d.removeEventListener("abort", f);
					};
					d.addEventListener("abort", f);
				}
			}
			za(u);
		});
	}, e.resume = function(e, t, n) {
		return new Promise(function(r, i) {
			var a, o, s = new Promise(function(e, t) {
				o = e, a = t;
			}), c = Vi(e, t, Ne(t.resumableState, n ? n.nonce : void 0, void 0, void 0, void 0, void 0), n ? n.onError : void 0, o, function() {
				var e = new ReadableStream({
					type: "bytes",
					pull: function(e) {
						Va(c, e);
					},
					cancel: function(e) {
						c.destination = null, Ha(c, e);
					}
				}, { highWaterMark: 0 });
				e.allReady = s, r(e);
			}, function(e) {
				s.catch(function() {}), i(e);
			}, a, n ? n.onPostpone : void 0);
			if (n && n.signal) {
				var l = n.signal;
				if (l.aborted) Ha(c, l.reason);
				else {
					var u = function() {
						Ha(c, l.reason), l.removeEventListener("abort", u);
					};
					l.addEventListener("abort", u);
				}
			}
			za(c);
		});
	}, e.resumeAndPrerender = function(e, t, n) {
		return new Promise(function(r, i) {
			var a = Hi(e, t, Ne(t.resumableState, void 0, void 0, void 0, void 0, void 0), n ? n.onError : void 0, function() {
				var e = new ReadableStream({
					type: "bytes",
					pull: function(e) {
						Va(a, e);
					},
					cancel: function(e) {
						a.destination = null, Ha(a, e);
					}
				}, { highWaterMark: 0 });
				e = {
					postponed: Wa(a),
					prelude: e
				}, r(e);
			}, void 0, void 0, i, n ? n.onPostpone : void 0);
			if (n && n.signal) {
				var o = n.signal;
				if (o.aborted) Ha(a, o.reason);
				else {
					var s = function() {
						Ha(a, o.reason), o.removeEventListener("abort", s);
					};
					o.addEventListener("abort", s);
				}
			}
			za(a);
		});
	}, e.version = "19.2.8";
})), _ = /* @__PURE__ */ t(((e) => {
	var t = h(), n = g();
	e.version = t.version, e.renderToString = t.renderToString, e.renderToStaticMarkup = t.renderToStaticMarkup, e.renderToReadableStream = n.renderToReadableStream, e.resume = n.resume;
})), v = /* @__PURE__ */ e(u(), 1), y = _(), b = "$engine";
function x(e) {
	return typeof e == "object" && !!e && "code" in e && typeof e.code == "string";
}
function S(e) {
	let { def: t, players: n, onChange: r } = e, i = e.seed ?? crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0], a = t.schemas.config, o = a?.safeParse(e.config), s = a ? o?.success ? o.data : a.parse(void 0) : void 0, c = t.setup(s, n, i), l = c.state;
	t.meta.id, c.fx;
	let u = c.fx?.length ? [c.fx] : [], d = 0, f = [{
		type: "$setup",
		config: s,
		players: n,
		seed: i,
		...t.saveCompatibility ? { saveVersion: t.saveCompatibility.version } : {}
	}], p = (e, n, i) => {
		let a = t.reduce(l, e, { by: n });
		return x(a) ? a : (l = a.state, t.meta.id, a.fx, a.fx?.length && u.push(a.fx), d += 1, f.push(i ? {
			by: n,
			action: e,
			auto: !0
		} : {
			by: n,
			action: e
		}), r(), null);
	};
	return {
		handleAction(e, r, i) {
			if (!n.includes(e)) return null;
			let a = t.schemas.action.safeParse(r);
			return a.success ? p(a.data, e, i?.auto) : null;
		},
		dispatchTick(e) {
			let n = t.schemas.action.safeParse({
				type: "tick",
				now: e
			});
			n.success && p(n.data, b);
		},
		takeFx() {
			let e = u;
			return u = [], e;
		},
		viewFor(e) {
			if (n.includes(e)) return t.viewFor(l, e);
		},
		viewForBot(e) {
			if (n.includes(e)) return t.viewForBot?.(l, e) ?? t.viewFor(l, e);
		},
		debugDump: () => ({
			version: d,
			log: f,
			state: l
		}),
		peekState: () => l,
		status: () => t.status(l),
		autopilotShares() {
			let e = /* @__PURE__ */ new Map(), t = /* @__PURE__ */ new Map();
			for (let n = 1; n < f.length; n += 1) {
				let r = f[n];
				typeof r.by == "string" && r.by !== "$engine" && (e.set(r.by, (e.get(r.by) ?? 0) + 1), r.auto === !0 && t.set(r.by, (t.get(r.by) ?? 0) + 1));
			}
			let n = {};
			for (let [r, i] of t) {
				let t = e.get(r);
				t && (n[r] = i / t);
			}
			return n;
		}
	};
}
function C(e) {
	let { def: t, log: n, onChange: r } = e, i = n[0];
	if (!i || i.type !== "$setup" || !Array.isArray(i.players) || !i.players.length || !i.players.every((e) => typeof e == "string") || new Set(i.players).size !== i.players.length || typeof i.seed != "number" || !Number.isFinite(i.seed) || t.schemas.config && !t.schemas.config.safeParse(i.config).success) return null;
	let a = S({
		def: t,
		players: i.players,
		seed: i.seed,
		config: i.config,
		onChange: r
	});
	a.takeFx();
	for (let e = 1; e < n.length; e += 1) {
		let r = n[e];
		if (typeof r?.by != "string" || !t.schemas.action.safeParse(r.action).success) return null;
		let i = a.debugDump().version;
		if (r.by === "$engine") {
			let e = r.action?.now;
			if (typeof e != "number" || !Number.isFinite(e)) return null;
			a.dispatchTick(e);
		} else if (a.handleAction(r.by, r.action, { auto: r.auto === !0 }) !== null) return null;
		if (a.debugDump().version !== i + 1) return null;
		a.takeFx();
	}
	return a;
}
//#endregion
//#region src/shared/fx/stage.tsx
var w = /* @__PURE__ */ e(o(), 1), T = 8, E = 24, D = (0, m.createContext)({
	fx: [],
	resetKey: null
});
function O({ renderers: e, fx: t, resetKey: n, myRid: r, members: i, children: a }) {
	return /* @__PURE__ */ (0, w.jsx)(D.Provider, {
		value: {
			fx: t,
			resetKey: n
		},
		children: /* @__PURE__ */ (0, w.jsxs)(s, { children: [a, e && /* @__PURE__ */ (0, w.jsx)(k, {
			renderers: e,
			fx: t,
			resetKey: n,
			myRid: r,
			members: i
		})] })
	});
}
function k({ renderers: e, fx: t, resetKey: n, myRid: r, members: i }) {
	let a = c(), o = l(), s = (0, m.useRef)([]), u = (0, m.useRef)(0), d = (0, m.useRef)(0), f = (0, m.useRef)(n), p = (0, m.useRef)([]), h = (0, m.useRef)(0), g = (0, m.useRef)(0), [_, v] = (0, m.useState)(null);
	return (0, m.useLayoutEffect)(() => {
		let c = () => {
			for (let e of p.current) a.setBusy(e, !1);
			p.current = [];
		}, l = () => {
			let t = s.current;
			for (; t.length;) {
				let n = [t.shift()];
				for (; t[0]?.with;) n.push(t.shift());
				let o = d.current > 0;
				d.current = Math.max(0, d.current - n.length);
				let s = {
					anchor: (e) => a.measure(e),
					member: (e) => i?.find((t) => t.rid === e),
					myRid: r,
					queued: t.length + +!!o
				}, c = n.map((t) => e[t.kind]?.(t, s) ?? null).filter((e) => e !== null);
				if (!c.length) continue;
				let l = [...new Set(c.flatMap((e) => e.hide ?? []))], u = new Set(p.current);
				for (let e of u) l.includes(e) || a.setBusy(e, !1);
				for (let e of l) u.has(e) || a.setBusy(e, !0);
				return p.current = l, g.current += 1, v({
					key: g.current,
					scenes: c
				}), h.current = window.setTimeout(m, Math.max(...c.map((e) => e.ms))), !0;
			}
			return !1;
		}, m = () => {
			window.clearTimeout(h.current), h.current = 0, l() || (c(), v(null));
		};
		if (f.current !== n) {
			f.current = n, u.current = 0, s.current = [], d.current = 0, _ && m();
			return;
		}
		let y = t.slice(u.current);
		if (u.current = t.length, y.length && (_ && (d.current += y.length), s.current.push(...y), s.current.length > T && (s.current = s.current.filter((e) => !e.ephemeral)), s.current.length > E && (s.current = s.current.slice(-24)), d.current = Math.min(d.current, s.current.length)), _ && _.scenes.some((e) => e.hide?.some((e) => a.measure(e) === null)) && m(), _) {
			if (!h.current) {
				let e = [...new Set(_.scenes.flatMap((e) => e.hide ?? []))];
				for (let t of e) a.setBusy(t, !0);
				p.current = e, h.current = window.setTimeout(m, Math.max(..._.scenes.map((e) => e.ms)));
			}
			return;
		}
		if (o) {
			s.current = [], d.current = 0;
			return;
		}
		l();
	}, [
		a,
		t,
		n,
		_,
		o,
		e,
		r,
		i
	]), (0, m.useEffect)(() => () => {
		window.clearTimeout(h.current), h.current = 0;
		for (let e of p.current) a.setBusy(e, !1);
		p.current = [];
	}, [a]), /* @__PURE__ */ (0, w.jsx)("div", {
		className: "pointer-events-none absolute inset-0 z-10 overflow-hidden",
		"aria-hidden": !0,
		children: _?.scenes.map((e, t) => /* @__PURE__ */ (0, w.jsx)(m.Fragment, { children: e.node }, `${_.key}:${t}`))
	});
}
//#endregion
//#region packages/sdk/src/platform-locales.ts
var A = {
	zh: {
		developer: {
			title: "制作你的游戏",
			subtitle: "从示例开始，用 AI 或代码实现你的桌游，再邀请朋友一起玩。",
			back: "返回首页",
			kit: "下载完整开发包",
			sdk: "单独下载 SDK",
			includes: "一次下载即可获得 SDK、两个可玩示例，以及从制作到发布的中英文教程。",
			requirement: "需要 Node.js 22.18 或更高版本。首次安装依赖需要联网。",
			version: "SDK 版本 {{version}} · 开发包 {{size}}",
			loading: "正在加载下载信息…",
			unavailable: "暂时无法加载下载信息，请稍后重试。",
			retry: "重新加载",
			startTitle: "先试玩，再开始修改",
			startText: "解压开发包，在包含 package.json 的文件夹打开终端，依次运行以下命令。",
			startHint: "预览地址会显示在终端中，按 Ctrl+C 退出。修改后需重新构建；验收固定成品包和恢复日志的方法见制作指南。",
			quickstart: "快速开始",
			quickstartDesc: "准备环境、运行示例，再为你的游戏设置名称和 ID。",
			manual: "编写游戏代码",
			manualDesc: "实现规则和界面，添加素材、机器人和存档。",
			ai: "使用 AI 制作",
			aiDesc: "描述你的游戏想法，让 AI 按随包指南协助完成代码与试玩。",
			publish: "发布你的游戏",
			publishDesc: "上传游戏文件，添加到 BGParty，并解决常见发布问题。",
			api: "查看 SDK 接口索引",
			exampleTitle: "选择适合你的示例",
			basic: "数到十",
			basicDesc: "从简单规则入手，学习回合操作、双语界面、机器人和结果展示。",
			advanced: "密牌比大小",
			advancedDesc: "学习如何保密手牌、使用图片、设置开局选项，并编写规则和结果页面。",
			exampleHint: "切换示例会替换示例的名称、规则和设置，请在开始修改前选好。用下面的命令设置游戏 ID，并同步更新代码中的引用。",
			promptTitle: "向 AI 描述你的游戏",
			copy: "复制需求模板",
			copied: "已复制",
			copyFailed: "未能复制，请选中文本后手动复制。",
			prompt: "请先阅读工程的 AGENTS.md、README.md 和 docs/。\n游戏名称与英文 ID（可协助确定）：\n玩家人数，是否共用一台设备：\n准备流程、每回合的操作与流程：\n所有人可见的信息、仅玩家自己可见的信息：\n如何结束游戏、判定胜负、处理平局和特殊情况：\n需要的开局设置、机器人或进度保存：\n规则附件、已有素材与期望的美术风格：\n希望重点试玩的情况：\n尚未确定的内容请先与我讨论。确认规则和方案后，先做出可玩的版本，再运行 check/build 并实际试玩；最后说明修改文件、检查结果和尚未验证的情况。",
			sdkHint: "更新已有项目的 SDK 时使用。首次制作游戏，请下载上方的完整开发包。",
			verify: "发布前先完整试玩一局，检查每位玩家看到的信息、中英文和手机／桌面显示；再到 BGParty 中检查联机、离线、更新和继续游戏。",
			homeHint: "下载模板，跟随教程完成你的桌游"
		},
		packs: {
			title: "游戏来源与下载",
			sources: "游戏来源",
			sourceUrl: "来源目录地址",
			add: "添加来源",
			refresh: "检查更新",
			removeSource: "取消订阅",
			installed: "已下载的游戏",
			download: "下载游戏",
			remove: "移除下载",
			empty: "尚未下载游戏。首次游玩会自动下载。",
			savedData: "已保存的游戏数据",
			clearData: "清除游戏数据",
			confirmClearData: "确认永久清除",
			clearDataLabel: "清除{{game}}的游戏数据",
			dataHint: "移除下载会保留成长进度与游戏设置。清除游戏数据无法恢复；浏览器清理网站数据也会删除这些记录。",
			noSavedData: "尚无已保存的游戏数据。",
			dataCleared: "游戏数据已清除。",
			dataPinned: "这款游戏正在使用中，请关闭相关游戏页面后再清除数据。",
			addHint: "添加提供游戏目录的 HTTPS 地址。来源需要允许本站读取目录和游戏文件。",
			unsubscribeHint: "取消订阅会停止检查来源更新，已下载的游戏仍保留。",
			resumeIncompatible: "新版无法继续这份存档，需要重新开局。",
			resumeCheckFailed: "暂时无法继续这份存档。可以重试或重新开局。",
			resumeCancel: "暂不进入",
			resumeRetry: "重试续玩",
			resumeNewVersion: "重新开局",
			busy: "正在处理…",
			failed: "操作未完成。请检查地址、网络及可用存储空间。",
			pinned: "这款游戏正在使用中，请结束对局并关闭相关页面后再移除下载。",
			official: "官方来源",
			offlineHint: "已下载的游戏可离线游玩；浏览器清理网站数据后需要重新下载。",
			incompatible: "这份存档无法继续，请重新开局。",
			tools: "游戏工具",
			updateRequired: "这款游戏需要更新本站后才能运行。请更新本站后重试。",
			unavailable: "该来源已不再提供这款游戏，无法新建联机对局。已下载版本仍可本地游玩。",
			checkingUpdates: "正在检查游戏更新",
			checkingFiles: "正在检查游戏文件",
			downloadingFiles: "正在下载游戏文件",
			savingFiles: "正在保存游戏文件",
			preparingMatch: "正在准备对局",
			restoringMatch: "正在恢复对局",
			openingGame: "正在打开游戏画面",
			loadingOptions: "正在加载游戏设置",
			downloadAmount: "{{done}} / {{total}}",
			downloadedAmount: "已下载 {{size}}",
			predownloading: "预下载中",
			updating: "更新中",
			preparingFiles: "正在准备游戏文件",
			cachedOffline: "已缓存，可离线游玩",
			offlineAvailable: "可离线游玩",
			notCachedOffline: "未缓存，请联网后下载",
			notCachedFailed: "未缓存，开局时可重试下载",
			loadFailed: "游戏未能加载。请检查网络、游戏来源和可用存储空间，然后重试。",
			missingSource: "此房间使用了你尚未添加或暂时无法读取的游戏来源。",
			addAndJoin: "添加来源并加载游戏",
			retry: "重新加载",
			unsupported: "当前浏览器无法下载并保存游戏。请使用支持离线存储的浏览器，通过 HTTPS 打开本站。",
			catalogFailed: "游戏目录暂时无法读取。请检查网络和浏览器存储权限后重试。"
		},
		avatarNames: /* @__PURE__ */ "闪闪.木兰.白须.罗宾.红胡.喵巫.皮皮.老船.德古.丸子.阿绿.爱迪.念念.夜影.哈罗.老王.比特.大厨.诺娃.阿隆.追风.婆婆.丹青.尔摩.阿狐.滚滚.呱呱.斑斑.绒绒.爪爪.角角.嗡嗡".split("."),
		platform: {
			onlineRoom: "在线房间",
			room: "房间",
			members: "房间成员 {{n}}",
			invite: "邀请朋友",
			scanHint: "扫描二维码加入房间",
			collapseInvite: "收起邀请二维码",
			expandInvite: "展开邀请二维码",
			viewAll: "查看全部",
			previous: "向左浏览",
			next: "向右浏览",
			back: "返回",
			newBadge: "NEW",
			selectedGame: "本局游戏",
			noSelection: "请选择游戏",
			players: "{{n}} 人",
			seated: "{{n}} 人已就座 · 适合 {{range}} 人",
			start: "开始游戏",
			recentEmpty: "玩过的游戏会显示在这里",
			scanTitle: "扫码加入",
			scanInstruction: "对准房主的二维码",
			useScan: "改用扫码",
			connected: "已加入房间",
			connecting: "正在接入房间"
		},
		common: {
			appName: "桌游趴",
			appNameSub: "BGPARTY",
			langSwitch: "切换语言",
			close: "关闭",
			qr: {
				starting: "正在打开相机…",
				denied: "相机权限被拒,允许后重试",
				noCamera: "找不到可用的相机",
				unsupported: "当前环境不支持相机",
				close: "关闭",
				manual: "扫不了?手动输入"
			},
			draw: {
				undo: "撤销",
				clear: "清空",
				colorAria: "画笔颜色 {{n}}",
				widthAria: "笔宽 {{n}}"
			},
			log: {
				title: "记录",
				empty: "还没有记录"
			},
			onlineRules: "在线说明书",
			onlineRulesIn: "在线说明书（{{lang}}）",
			rulesLangZh: "中文",
			rulesLangEn: "英文",
			rulesLangDe: "德语",
			rulesLangFr: "法语",
			rulesLangEs: "西班牙语",
			rulesLangIt: "意大利语",
			rulesLangRu: "俄语",
			rulesLangJa: "日语"
		},
		profile: {
			title: "我的名片",
			pickAvatar: "挑个头像",
			avatarOption: "头像 {{n}}",
			nameLabel: "名字",
			unnamed: "还没起名",
			save: "保存"
		},
		session: {
			menu: {
				open: "游戏菜单",
				close: "关闭游戏菜单"
			},
			steps: {
				load: "正在准备联机组件…",
				relay: "正在连接服务器…",
				peer: "找到房间了,正在敲门…",
				join: "正在接入房间…",
				stuckHost: "有点慢:主机可能在锁屏,或网络不佳",
				stuckRelay: "连不上配对服务器?检查网络,或稍等自动恢复",
				relayFallback: "直连不通,已切换低速通道(延迟较高)",
				switchRelay: "不在一个局域网?切换低速通道"
			},
			reconnecting: "连接中断,重连中…",
			qr: {
				hostIdle: "小伙伴先扫下方入场码,再扫 TA 出示的配对码",
				hostAnswer: "让 TA 扫这个码接通 · 点二维码可切回入场码",
				playerOffer: "请主机扫这个配对码",
				connecting: "已收到主机回应,正在接通…",
				preparing: "正在生成配对码…",
				tooBig: "配对码太大了,请关闭多余的网络连接后重试",
				copy: "复制配对码",
				copied: "已复制",
				paste: "扫不了?粘贴配对码",
				pasteTitle: "粘贴配对码",
				pastePlaceholder: "粘贴对方出示的配对码文本",
				pasteConfirm: "确认",
				useQr: "改用扫码配对(无网环境)",
				useRelay: "改用服务器连接"
			},
			gameLoading: "正在加载游戏…",
			gameStartFailed: "游戏启动失败，请刷新页面后重试。",
			result: {
				title: "本局结束",
				playAgain: "再来一局",
				backToLobby: "返回大厅",
				waitHost: "等主机决定下一步…",
				exportLog: "导出对局记录"
			},
			records: {
				title: "对局记录",
				submit: "提交对局记录",
				export: "导出完整记录",
				automatic: "终局自动提交",
				automaticHint: "适用于此浏览器中的所有游戏",
				consentTitle: "允许自动上传对局记录吗？",
				consentDescription: "这可以帮助我们分析对局、改进机器人。记录包含玩家昵称和游戏内操作，不包含房间口令或其他敏感信息。你可以随时在设置中关闭。",
				consentDecline: "不同意，不再询问",
				consentAccept: "同意并开启",
				purpose: "提交完整对局记录，用于复盘分析。",
				queued: "等待联网提交",
				sending: "正在提交…",
				sent: "对局记录已提交",
				retry: "重试提交记录",
				storageFailed: "无法暂存，请导出记录",
				unavailable: "无法提交，请导出记录",
				tooLarge: "记录过大，请导出保存"
			},
			back: {
				title: "退出房间?",
				playerDesc: "退出即离开座位,用同一张二维码或链接随时回来",
				dissolveTitle: "解散房间?",
				dissolveDesc: "全桌断线,座位和这张二维码都不再有效",
				dissolveConfirm: "确认解散",
				endGameTitle: "结束本局?",
				endGameDesc: "全桌一起回大厅,本局进度不保留",
				confirm: "确认退出",
				cancel: "再想想"
			},
			hint: {
				button: "帮我想一步",
				title: "bot 建议",
				confirm: "就这么走",
				cancel: "再想想",
				noAction: "现在没有需要你决策的地方",
				updated: "局面有变化,建议已更新",
				usedCount: "本局求助 bot {{n}} 次"
			},
			autopilot: {
				on: "开启托管",
				off: "取消托管",
				active: "托管中",
				sheetTitle: "托管(bot 代打)",
				sheetHint: "开启后该座位由 bot 代打,随时可取消",
				share: "托管 {{n}}%"
			}
		},
		settings: {
			title: "设置",
			general: "通用",
			language: "界面语言",
			chinese: "简体中文",
			english: "English",
			back: "返回设置",
			gamesAndAi: "游戏与 AI",
			enabled: "已开启",
			disabled: "已关闭",
			notConfigured: "未配置",
			sourceCount: "{{n}} 个游戏来源",
			sourceOrderHint: "同一游戏默认使用排在后面的来源，也可在开局时选择。",
			moveSourceUp: "上移来源：{{source}}",
			moveSourceDown: "下移来源：{{source}}",
			customSource: "自定义游戏源",
			invalidSourceUrl: "请输入有效的 HTTPS 游戏目录地址，地址不能包含账号、密码或片段标识。",
			sourceAdded: "游戏来源已添加。",
			sourceRefreshed: "游戏目录已更新。",
			sourceUnsubscribed: "已取消订阅，已下载的游戏仍保留。",
			sourcesEmpty: "尚无可用的游戏来源。",
			downloads: "下载管理",
			downloadsHint: "下载游戏，管理离线内容",
			downloaded: "已下载",
			notDownloaded: "未下载",
			downloading: "下载中",
			savingDownload: "正在保存",
			preparingDownload: "正在准备",
			downloadWaiting: "等待下载",
			downloadFailed: "下载失败，请重试",
			downloadGameLabel: "下载 {{game}}",
			downloadAll: "全部下载",
			downloadAllHint: "下载所有游戏来源中尚未下载的游戏。",
			stopDownloads: "停止后续下载",
			downloadSummary: "{{n}} / {{total}} 款 · 已下载 {{downloaded}} 款",
			downloadRemaining: "剩余 {{n}} 款",
			downloadOffline: "当前已离线，联网后可下载游戏。",
			noGames: "暂无游戏，请先添加或刷新游戏来源。",
			confirmRemoveDownload: "确认移除下载",
			removeGameLabel: "移除 {{game}} 的下载",
			searchSources: "搜索来源名称或地址",
			searchDownloads: "搜索游戏名称或来源",
			listCount: "{{n}} / {{total}} 项",
			noMatches: "没有匹配的结果。",
			recordSubmission: "自动提交对局记录",
			recordSubmissionHint: "开启后，此浏览器会在对局结束时自动提交完整对局记录，用于复盘分析。",
			aiSetupHint: "使用 AI 玩家前，请先在首页右上角的设置中配置 AI 端点。",
			about: "关于与更新",
			installFailed: "暂时无法安装，请通过浏览器菜单添加到主屏幕。",
			sound: "音效",
			soundHint: "轮到你行动和结算时的提示音",
			turnSound: "提示音",
			turnSoundSoft: "柔和",
			turnSoundWood: "木鱼",
			turnSoundPop: "气泡",
			turnSoundChime: "铃铛"
		},
		pwa: {
			updateAvailable: "新版本已准备好",
			updateNow: "更新",
			later: "稍后",
			updateReadyTitle: "新版本已准备好",
			updateReadyBody: "重启后自动生效",
			checkUpdate: "检查更新",
			checking: "正在检查更新…",
			upToDate: "已是最新",
			downloading: "发现新版本,正在后台下载…",
			checkFailed: "检查失败,请检查网络",
			installTitle: "安装到桌面",
			installBody: "下次进入更快,还可以离线玩",
			installAction: "安装",
			installIosTitle: "安装到主屏幕",
			installIosStep1: "点击浏览器底部的「分享」按钮",
			installIosStep2: "在菜单中选择「添加到主屏幕」",
			installIosStep3: "点击右上角「添加」完成安装"
		},
		home: {
			title: "今晚玩点啥",
			buildTime: "更新于",
			labLink: "试验场",
			sheetCalibLink: "版图校准",
			createRoom: "新建房间",
			startTag: "开局 / START",
			createHint: "做东开桌，邀请朋友扫码入座",
			joinRoom: "加入房间",
			joinHint: "扫朋友的房间码",
			otherModes: "换一种玩法",
			offlineRoom: "离线模式",
			offlineHint: "一个人也能开局",
			hotseat: "本地热座",
			hotseatHint: "轮流传递设备",
			comingSoon: "敬请期待",
			newsTitle: "公告",
			newsItems: { uiRefresh: {
				title: "界面换新啦",
				body: "全新的首页、大堂和对局体验。"
			} }
		},
		ai: {
			title: "AI 端点配置",
			hint: "协议固定 OpenAI 兼容(/chat/completions);Key 只存本机,浏览器直连端点,不经任何中转。",
			empty: "还没有端点,先加一个",
			add: "新增端点",
			edit: "编辑",
			delete: "删除",
			confirmDelete: "确认删除",
			nameLabel: "端点名称",
			baseUrlLabel: "服务地址",
			apiKeyLabel: "API Key",
			modelLabel: "模型名称",
			save: "保存",
			back: "返回列表",
			test: "测试连接",
			testing: "测试中…",
			testOk: "连上了",
			testFail: "连不上,检查地址和 Key",
			usage: "调用 {{n}} 次 · 入 {{pin}} / 出 {{pout}}",
			usageLabel: "查看用量",
			usageByGame: "{{game}}:{{n}} 次 · 入 {{pin}} / 出 {{pout}}",
			usageByGameAvg: "{{game}}:{{n}} 次 · 入 {{pin}} / 出 {{pout}} · 局均每座 {{avg}}",
			namePlaceholder: "名字(如:公司中转)",
			baseUrlPlaceholder: "地址,如 https://api.openai.com/v1",
			apiKeyPlaceholder: "API Key",
			modelPlaceholder: "模型,如 gpt-4o-mini"
		},
		lobby: {
			colors: {
				blueberry: "蓝莓",
				tangerine: "橘子",
				grape: "葡萄",
				honey: "蜂蜜",
				seasalt: "海盐",
				peach: "蜜桃",
				avocado: "牛油果",
				cocoa: "可可",
				mint: "薄荷",
				sesame: "芝麻"
			},
			you: "你",
			offline: "离线",
			bot: "机器人",
			botAi: "AI",
			thinking: "思考中",
			done: "已行动",
			rules: "玩法说明",
			memberCount: "{{n}} 人已入座",
			namePlaceholder: "输入名字",
			waiting: "已入座,等主机开局",
			nextGame: "本局进行中,下一局轮到你",
			host: {
				badge: "你是本局主机,别锁屏",
				nameTitle: "先报个名,再开房",
				open: "开房",
				opening: "正在开房…",
				openFailed: "开房失败:需要 https 或 localhost",
				openStale: "页面版本过旧:刷新后再开房",
				refresh: "刷新页面",
				offlineBadge: "离线模式",
				offlineInvite: "单机离线房:加机器人直接开局,扫码加入不可用",
				hotseatBadge: "本地热座",
				hotseatInvite: "热座房:加本地玩家或机器人开局,设备在大家手里传着玩",
				addLocal: "加个本地玩家",
				removeLocal: "移除本地玩家",
				renameLocalTitle: "改个名字",
				passTo: "交给 {{name}}",
				passHint: "点任意处继续",
				passForce: "强制交接",
				iAm: "我是 {{name}}",
				qrLabel: "入场二维码",
				scanHint: "同 WiFi 的小伙伴扫码进房",
				qrCollapsed: "二维码已收起,点按展开",
				copyLink: "复制入场链接",
				copied: "已复制",
				pickGame: "选个游戏",
				searchGames: "查找游戏",
				searchClear: "清空搜索",
				filters: {
					trigger: "筛选",
					triggerLabel: "筛选游戏，已选 {{n}} 项",
					title: "筛选游戏",
					selected: "已选筛选条件",
					remove: "移除“{{name}}”筛选",
					clear: "清空筛选",
					gameplay: "玩法",
					interaction: "互动",
					matchAny: "每组满足任一项",
					all: "全部玩法（{{n}}）",
					less: "收起玩法",
					viewResults: "查看 {{n}} 款游戏",
					resultCount: "{{n}} / {{total}} 款游戏",
					mechanics: {
						handManagement: "手牌管理",
						diceRolling: "掷骰",
						drafting: "轮抽",
						tilePlacement: "板块放置",
						setCollection: "成套收集",
						engineBuilding: "引擎构筑",
						deduction: "推理",
						rollAndWrite: "骰写／翻写",
						deckBagBuilding: "牌库构筑／袋构筑",
						routeBuilding: "路线建设",
						areaControl: "区域控制",
						pushYourLuck: "赌运",
						trickTaking: "吃墩",
						wordAssociation: "词语联想",
						betting: "下注",
						gridMovement: "网格移动",
						actionPoints: "行动点",
						race: "竞速",
						workerPlacement: "工人放置",
						auction: "拍卖",
						stockHolding: "股票投资",
						drawing: "绘画",
						actionProgramming: "行动编程"
					},
					interactions: {
						cooperative: "合作",
						communicationLimits: "沟通受限",
						teamBased: "团队对抗",
						hiddenRoles: "隐藏身份"
					}
				},
				sort: "排序",
				sortDefault: "默认(收藏置顶)",
				sortNew: "最新上架",
				sortRecent: "最近游玩",
				sortPlays: "游戏次数",
				noGameMatch: "没有匹配的游戏",
				layoutCompact: "切换为紧凑列表",
				layoutCover: "切换为大封面",
				favorite: "收藏,选游戏时置顶",
				unfavorite: "取消收藏",
				options: "选项",
				saveOptions: "保存",
				noGames: "游戏上架中",
				start: "开局",
				startCount: "开局 ({{n}}/{{min}}–{{max}})",
				needGame: "先选个游戏",
				needPlayers: "这游戏要 {{min}}–{{max}} 人,现在 {{n}} 人",
				noEngine: "游戏还没接入,稍等版本更新",
				addBot: "加个机器人",
				addAiBot: "加个 AI",
				botUnsupported: "这游戏不支持机器人,先移除再开局",
				aiBotUnsupported: "这游戏不支持 AI 机器人,先移除再开局",
				aiDegraded: "「{{name}}」暂时连不上,这一招由本地机器人代打",
				removeBot: "移除机器人",
				endGame: "结束回大厅",
				resumeTitle: "继续上次对局?",
				resumeDesc: "有一局 {{n}} 人局没打完,上次玩到 {{time}}",
				resumeContinue: "继续上局",
				resumeNew: "重新开局",
				resumeBadge: "续玩",
				gameSource: "游戏来源",
				defaultSource: "默认",
				dissolve: "解散房间",
				dissolveConfirm: "再点一次确认解散",
				closed: "房间已解散",
				reopen: "再开一间"
			},
			join: {
				invalid: "二维码无效",
				manualTitle: "手动加入",
				room: "房间号",
				key: "口令",
				roomPlaceholder: "12 位房间号",
				keyPlaceholder: "16 位口令",
				go: "进房",
				versionMismatch: "页面版本不一致,刷新后重新扫码",
				seating: "正在入座…",
				failed: "连接失败",
				faultInsecure: "非安全上下文:需要 https 或 localhost",
				faultNetwork: "网络问题:连不上配对服务",
				faultHostOffline: "主机不在线",
				faultHostFault: "连上了但主机没回音",
				retryHint: "{{n}} 秒后自动重试",
				retryNow: "立即重试",
				rejected: "进房被拒绝",
				naming: "怎么称呼你?",
				sit: "入座",
				leave: "离开房间",
				leaveConfirm: "再点一次确认离开",
				left: "已离开房间",
				rejoin: "重新加入"
			}
		},
		games: {},
		lab: {
			title: "试验场",
			playTester: "测试玩家",
			playUnknownGame: "未找到这个游戏",
			variantsTitle: "朝向变体",
			variantsHint: "旋转成横屏或把视口拖矮,观察对应方块变色",
			boxWide: "wide:横屏",
			boxShort: "short:矮屏",
			tokensTitle: "主题 token(已冻结)",
			touchTitle: "触控目标",
			touchPrimary: "主操作 48px",
			touchNormal: "普通 44px",
			safeTitle: "安全区",
			safeHint: "贴边元素(如底部操作栏)加 safe-* 补刘海留白,桌面值恒为 0",
			safeValues: "实测 上{{t}} 下{{b}} 左{{l}} 右{{r}}",
			iconsTitle: "图标(lucide · 2.5 描边)",
			confirmTitle: "两步确认",
			confirmIdle: "解散房间",
			confirmArmed: "再点一次确认",
			confirmDone: "已执行 {{n}} 次",
			paletteTitle: "派对色板(1.3)",
			paletteHint: "玩家标识色,入座按房分配;顺序即分配顺序,冷暖交错防撞色",
			faviconTitle: "应用图标方向",
			faviconHint: "按 64/32/16px 实物尺寸对比;16px 是浏览器标签页真实大小,那里糊掉的方向直接淘汰",
			avatarCardTitle: "大头像+名字(容器方案库)",
			avatarCardHint: "四种容器形态;C 已拍板用于房间名单,其余备用;玩家色作头像底色",
			avatarA: "竖版贴纸卡",
			avatarB: "横版横幅卡",
			avatarC: "奖牌式(名字压边)",
			avatarD: "无卡裸排",
			demoNameShort: "阿梨",
			demoNameLong: "超级无敌小葡萄",
			strip: {
				title: "对局玩家条(PlayerStrip)",
				hint: "三种布局按状态量取用;样例覆盖长名/机器人/离线/自己/思考中/已行动/多状态,计分 chip 与 nimmt 同款",
				variantPlate: "plate:横排名牌,状态多自动折行",
				variantMedal: "medal:竖排奖牌,状态少",
				variantMini: "mini:无状态极简"
			},
			fx: {
				title: "FX 演出原语(docs/FX.md)",
				hint: "锚点 + 手工触发批次;飞行带落点抑制(目标先隐后现),数值滚动走 diff",
				fly: "飞一张 A→B",
				chain: "链式 A→B→C + 浮字",
				bump: "分数 +3"
			},
			dice: {
				title: "3D 骰子(CSS transform)",
				hint: "共享掷骰模块:翻滚后必然定格在目标点数;下区走完整 fx 管线(banner → 飞向落点)",
				roll1: "掷 1 颗",
				roll2: "掷 2 颗",
				roll3: "掷 3 颗",
				fxTitle: "掷骰 fx 演出",
				rollBanner: "横幅掷 2 颗",
				rollInplace: "就地掷 3 颗",
				rollMiss: "横幅(无落点锚点)"
			},
			transport: {
				title: "传输探针(阶段 4)",
				hostStart: "开房当主机",
				hostRunning: "主机运行中",
				playerTitle: "玩家侧:扫码或输入凭据连接",
				room: "房间号",
				key: "口令",
				link: "入场链接",
				qrLabel: "入场二维码",
				scanBtn: "扫码连接",
				roomPlaceholder: "12 位房间号",
				keyPlaceholder: "16 位口令",
				connect: "连接",
				ping: "发 ping",
				echo: "主机回显",
				viewLabel: "当前视图",
				online: "在线 {{n}} 人",
				close: "关闭会话",
				statusConnecting: "连接中…",
				statusReady: "已连接",
				statusRejected: "被拒绝({{r}})",
				statusFailed: "连接失败",
				faultInsecure: "非安全上下文:需要 https 或 localhost",
				faultNetwork: "网络问题:连不上配对服务",
				faultHostOffline: "主机不在线",
				faultHostFault: "连上了但主机没回音",
				retryHint: "{{n}} 秒后自动重试",
				retryNow: "立即重试"
			},
			engine: {
				title: "Engine 自检(阶段 6)",
				hint: "本地假游戏(计数器)跑 GameSession 核心链路,不过网络",
				run: "运行自检",
				errLimit: "计数已达上限",
				checkValid: "合法动作推进 state",
				checkBadShape: "坏形状静默丢",
				checkOutsider: "非本局 rid 静默丢",
				checkGameError: "GameError 原样返回",
				checkTick: "dispatchTick 进 log",
				checkPrivate: "私有视图按人裁剪",
				checkReplay: "replay 重建与实况一致",
				checkPrng: "PRNG 确定性",
				checkFx: "fx 累积成组、takeFx drain 清空"
			},
			baseline: {
				title: "主题基线提案(1.2)",
				secSem: "语义色:solid / soft 双档",
				secType: "文字阶梯 4+1 档",
				secFont: "展示字体 Baloo 2(拉丁/数字)",
				fontZhNote: "中文走系统字(本句即效果)",
				gameName: "行动代号",
				gameDesc: "两队对抗,暗号联络己方特工",
				gamePlayers: "{{min}}–{{max}} 人 · 15 分钟",
				roomCode: "4K2Q"
			},
			sheetCalib: {
				title: "版图校准",
				hint: "点选 / Shift 加选;拖拽移动,选中项右/下/右下角手柄改大小;方向键 1px(Shift=10px);Alt+方向 调宽高;[ ] 调 pitch",
				groups: "标注组",
				links: "联动组(等距分布)",
				selAll: "全选",
				gap: "边缘间距(px)",
				spread: "分布",
				save: "保存到源文件",
				saved: "已保存 ✓",
				saveFailed: "保存失败",
				reset: "放弃修改",
				dirty: "{{n}} 组未保存",
				multiSet: "已选 {{n}} 项,统一设置",
				noCalib: "该游戏的 sheet-layout.ts 未导出 CALIB_LAYOUT",
				mark: "画记",
				markDefault: "默认",
				markX: "X 叉",
				markSlash: "斜线",
				markCircle: "圆圈"
			}
		}
	},
	en: {
		developer: {
			title: "Create your game",
			subtitle: "Start with an example, build your board game with AI or code, and invite friends to play.",
			back: "Back to home",
			kit: "Download complete kit",
			sdk: "Download SDK only",
			includes: "Get the SDK, two playable examples, and Chinese and English guides from creation to publishing in one download.",
			requirement: "Requires Node.js 22.18 or later. Initial dependency installation needs internet access.",
			version: "SDK {{version}} · Kit {{size}}",
			loading: "Loading download information…",
			unavailable: "Download information is unavailable. Please try again later.",
			retry: "Retry",
			startTitle: "Play first, then make changes",
			startText: "Extract the kit, open a terminal in the folder containing package.json, and run these commands in order.",
			startHint: "The terminal prints the local preview URL. Ctrl+C stops it. Rebuild after editing; see the guide for fixed-package acceptance and log restoration.",
			quickstart: "Quick start",
			quickstartDesc: "Set up, run an example, then choose a name and ID for your game.",
			manual: "Code your game",
			manualDesc: "Build rules and screens, then add artwork, bots and saves.",
			ai: "Create with AI",
			aiDesc: "Describe your idea and use the included guides to have AI help code and playtest it.",
			publish: "Publish your game",
			publishDesc: "Upload your game files, add them to BGParty, and resolve common publishing issues.",
			api: "Browse SDK API index",
			exampleTitle: "Choose an example to build on",
			basic: "Count to Ten",
			basicDesc: "Start with simple rules and learn turns, bilingual screens, bots and results.",
			advanced: "Secret Cards",
			advancedDesc: "Learn to keep cards private, use artwork, add setup options, and create rules and results screens.",
			exampleHint: "Choose before editing: switching replaces the example’s name, rules and settings. Use the command below to set your game ID and update code references together.",
			promptTitle: "Describe your game to AI",
			copy: "Copy project brief",
			copied: "Copied",
			copyFailed: "Could not copy. Select the text and copy it manually.",
			prompt: "Read AGENTS.md, README.md and docs/ first.\nGame name and ID (help me choose if needed):\nPlayer counts and whether players share a device:\nSetup, player actions and turn flow:\nInformation everyone can see and information only its player can see:\nEnd conditions, winners, ties and special cases:\nSetup options, bots or progress saving needed:\nRules, supplied assets and desired art style:\nSituations to focus on when playtesting:\nDiscuss anything undecided with me first. Agree on rules and approach, build a playable version, then run check/build and actually play. Report changed files, checks and untested cases.",
			sdkHint: "For updating the SDK in an existing project. For your first game, download the complete kit above.",
			verify: "Before publishing, finish a match and check what each player sees, both languages and phone/desktop layouts. Then check networking, offline play, updates and resuming a game in BGParty.",
			homeHint: "Download a template and follow the guides to build your board game"
		},
		packs: {
			title: "Game sources and downloads",
			sources: "Game sources",
			sourceUrl: "Source catalog address",
			add: "Add source",
			refresh: "Check for updates",
			removeSource: "Unsubscribe",
			installed: "Downloaded games",
			download: "Download game",
			remove: "Remove download",
			empty: "No games downloaded yet. Playing a game downloads it automatically.",
			savedData: "Saved game data",
			clearData: "Clear game data",
			confirmClearData: "Confirm permanent removal",
			clearDataLabel: "Clear saved data for {{game}}",
			dataHint: "Removing a download keeps progress and game settings. Clearing game data cannot be undone. Clearing site data in your browser also removes these records.",
			noSavedData: "No saved game data yet.",
			dataCleared: "Game data cleared.",
			dataPinned: "This game is in use. Close its game pages before clearing data.",
			addHint: "Add an HTTPS game catalog address. The source must allow this site to read its catalog and game files.",
			unsubscribeHint: "Unsubscribing stops source update checks and keeps downloaded games.",
			resumeIncompatible: "The new version cannot continue this save. Start a new game.",
			resumeCheckFailed: "This save could not be continued. Try again or start a new game.",
			resumeCancel: "Not now",
			resumeRetry: "Try continuing again",
			resumeNewVersion: "Start a new game",
			busy: "Working…",
			failed: "The operation could not finish. Check the address, connection and available storage.",
			pinned: "This game is in use. End the match and close its pages before removing the download.",
			official: "Official source",
			offlineHint: "Downloaded games can be played offline. If your browser clears site data, they will need downloading again.",
			incompatible: "This save cannot be continued. Start a new game.",
			tools: "Game tools",
			updateRequired: "This game requires an updated site. Update this site and try again.",
			unavailable: "This source no longer provides the game, so a new online match cannot start. The downloaded version can still be played locally.",
			checkingUpdates: "Checking for game updates",
			checkingFiles: "Checking game files",
			downloadingFiles: "Downloading game files",
			savingFiles: "Saving game files",
			preparingMatch: "Preparing the match",
			restoringMatch: "Restoring the match",
			openingGame: "Opening the game",
			loadingOptions: "Loading game settings",
			downloadAmount: "{{done}} / {{total}}",
			downloadedAmount: "{{size}} downloaded",
			predownloading: "Downloading ahead",
			updating: "Updating",
			preparingFiles: "Preparing game files",
			cachedOffline: "Cached · available offline",
			offlineAvailable: "Available offline",
			notCachedOffline: "Not cached. Connect to download.",
			notCachedFailed: "Not cached. Start to retry the download.",
			loadFailed: "The game could not load. Check your connection, game source and available storage, then try again.",
			missingSource: "This room uses a game source you have not added or cannot currently read.",
			addAndJoin: "Add source and load game",
			retry: "Try again",
			unsupported: "This browser cannot download and save games. Open this site over HTTPS in a browser that supports offline storage.",
			catalogFailed: "The game catalog could not be loaded. Check your connection and browser storage permissions, then try again."
		},
		avatarNames: /* @__PURE__ */ "Twinkle.Gala.Sage.Robin.Bjorn.Hexie.Pip.Patch.Drac.Buns.Gronk.Gizmo.Mercy.Shade.Halo.Rex.Coda.Chef.Nova.Skye.Blaze.Nana.Hue.Sleuth.Foxy.Puff.Froggy.Stripe.Bunny.Inky.Uni.Buzz".split("."),
		platform: {
			onlineRoom: "Online room",
			room: "Room",
			members: "Players {{n}}",
			invite: "Invite friends",
			scanHint: "Scan to join the room",
			collapseInvite: "Hide invitation code",
			expandInvite: "Show invitation code",
			viewAll: "View all",
			previous: "Browse left",
			next: "Browse right",
			back: "Back",
			newBadge: "NEW",
			selectedGame: "This game",
			noSelection: "Choose a game",
			players: "{{n}} players",
			seated: "{{n}} seated · {{range}} players",
			start: "Start game",
			recentEmpty: "Games you play will appear here",
			scanTitle: "Scan to join",
			scanInstruction: "Scan the host’s room code",
			useScan: "Scan instead",
			connected: "Joined the room",
			connecting: "Joining the room"
		},
		common: {
			appName: "BGParty",
			appNameSub: "桌游趴",
			langSwitch: "Switch language",
			close: "Close",
			qr: {
				starting: "Opening camera…",
				denied: "Camera access denied — allow it and retry",
				noCamera: "No camera found",
				unsupported: "Camera is not supported here",
				close: "Close",
				manual: "Can't scan? Enter manually"
			},
			draw: {
				undo: "Undo",
				clear: "Clear",
				colorAria: "Brush color {{n}}",
				widthAria: "Brush size {{n}}"
			},
			log: {
				title: "Log",
				empty: "Nothing yet"
			},
			onlineRules: "Online rulebook",
			onlineRulesIn: "Online rulebook ({{lang}})",
			rulesLangZh: "Chinese",
			rulesLangEn: "English",
			rulesLangDe: "German",
			rulesLangFr: "French",
			rulesLangEs: "Spanish",
			rulesLangIt: "Italian",
			rulesLangRu: "Russian",
			rulesLangJa: "Japanese"
		},
		profile: {
			title: "My profile",
			pickAvatar: "Pick an avatar",
			avatarOption: "Avatar {{n}}",
			nameLabel: "Name",
			unnamed: "No name yet",
			save: "Save"
		},
		session: {
			menu: {
				open: "Game menu",
				close: "Close game menu"
			},
			steps: {
				load: "Preparing connectivity…",
				relay: "Connecting to server…",
				peer: "Room found, knocking…",
				join: "Joining the room…",
				stuckHost: "Taking long: host may be locked or on a bad network",
				stuckRelay: "Can't reach pairing relays — check network or wait",
				relayFallback: "Direct link failed — switched to relay (higher latency)",
				switchRelay: "Not on the same LAN? Switch to relay"
			},
			reconnecting: "Connection lost, reconnecting…",
			qr: {
				hostIdle: "Friends scan the entry code below first, then scan their pairing code",
				hostAnswer: "Let them scan this code to connect · tap the code to show the entry code again",
				playerOffer: "Ask the host to scan this pairing code",
				connecting: "Answer received, connecting…",
				preparing: "Preparing pairing code…",
				tooBig: "Pairing code is too large — turn off extra network connections and retry",
				copy: "Copy pairing code",
				copied: "Copied",
				paste: "Can't scan? Paste the code",
				pasteTitle: "Paste pairing code",
				pastePlaceholder: "Paste the code shown on the other device",
				pasteConfirm: "Confirm",
				useQr: "Use QR pairing (no internet)",
				useRelay: "Use server connection instead"
			},
			gameLoading: "Loading game…",
			gameStartFailed: "Could not start the game. Refresh the page and try again.",
			result: {
				title: "Game over",
				playAgain: "Play again",
				backToLobby: "Back to lobby",
				waitHost: "Waiting for the host…",
				exportLog: "Export game log"
			},
			records: {
				title: "Game log",
				submit: "Submit game log",
				export: "Export full log",
				automatic: "Submit on game end",
				automaticHint: "Applies to all games in this browser",
				consentTitle: "Allow automatic game log uploads?",
				consentDescription: "This helps us analyze games and improve our bots. Logs include player nicknames and in-game actions, but no room passwords or other sensitive information. You can turn this off in settings at any time.",
				consentDecline: "Decline and don’t ask again",
				consentAccept: "Agree and enable",
				purpose: "Submit the full game log for replay analysis.",
				queued: "Waiting for connection",
				sending: "Submitting…",
				sent: "Game log submitted",
				retry: "Retry submission",
				storageFailed: "Cannot save; export log",
				unavailable: "Cannot submit; export log",
				tooLarge: "Log too large; export it"
			},
			back: {
				title: "Leave the room?",
				playerDesc: "You'll leave your seat. Rejoin anytime with the same QR code or link.",
				dissolveTitle: "Dissolve the room?",
				dissolveDesc: "Everyone disconnects; seats and this QR code expire.",
				dissolveConfirm: "Dissolve",
				endGameTitle: "End this game?",
				endGameDesc: "Everyone returns to the lobby; this game is discarded.",
				confirm: "Leave room",
				cancel: "Stay"
			},
			hint: {
				button: "Suggest a move",
				title: "Bot suggests",
				confirm: "Play it",
				cancel: "Not yet",
				noAction: "Nothing for you to decide right now",
				updated: "The board changed — suggestion updated",
				usedCount: "Asked the bot for help {{n}} times this game"
			},
			autopilot: {
				on: "Enable autopilot",
				off: "Disable autopilot",
				active: "Autopilot",
				sheetTitle: "Autopilot (bot plays)",
				sheetHint: "While on, a bot plays this seat — cancel anytime",
				share: "bot {{n}}%"
			}
		},
		settings: {
			title: "Settings",
			general: "General",
			language: "Language",
			chinese: "简体中文",
			english: "English",
			back: "All settings",
			gamesAndAi: "Games & AI",
			enabled: "On",
			disabled: "Off",
			notConfigured: "Not configured",
			sourceCount: "Sources: {{n}}",
			sourceOrderHint: "For the same game, sources lower in the list are preferred. You can also choose when starting a game.",
			moveSourceUp: "Move source up: {{source}}",
			moveSourceDown: "Move source down: {{source}}",
			customSource: "Custom game source",
			invalidSourceUrl: "Enter a valid HTTPS game catalog URL without credentials or a fragment.",
			sourceAdded: "Game source added.",
			sourceRefreshed: "Game catalog updated.",
			sourceUnsubscribed: "Unsubscribed. Downloaded games are kept.",
			sourcesEmpty: "No game sources available yet.",
			downloads: "Downloads",
			downloadsHint: "Download games and manage offline content",
			downloaded: "Downloaded",
			notDownloaded: "Not downloaded",
			downloading: "Downloading",
			savingDownload: "Saving",
			preparingDownload: "Preparing",
			downloadWaiting: "Waiting to download",
			downloadFailed: "Download failed. Try again.",
			downloadGameLabel: "Download {{game}}",
			downloadAll: "Download all",
			downloadAllHint: "Download every game not yet downloaded from your game sources.",
			stopDownloads: "Stop remaining",
			downloadSummary: "{{n}} / {{total}} games · {{downloaded}} downloaded",
			downloadRemaining: "{{n}} remaining",
			downloadOffline: "You are offline. Connect to download games.",
			noGames: "No games available. Add or refresh a game source first.",
			confirmRemoveDownload: "Confirm removal",
			removeGameLabel: "Remove download: {{game}}",
			searchSources: "Search source names or URLs",
			searchDownloads: "Search games or sources",
			listCount: "{{n}} / {{total}} items",
			noMatches: "No matching results.",
			recordSubmission: "Automatic game log submission",
			recordSubmissionHint: "When enabled, this browser submits the full game log after each match for replay analysis.",
			aiSetupHint: "To use AI players, configure an AI endpoint in Settings at the top right of the home page.",
			about: "About & updates",
			installFailed: "Installation is unavailable. Try adding this site from your browser menu.",
			sound: "Sound effects",
			soundHint: "Plays on your turn and during settlement",
			turnSound: "Turn sound",
			turnSoundSoft: "Soft",
			turnSoundWood: "Woodblock",
			turnSoundPop: "Pop",
			turnSoundChime: "Chime"
		},
		pwa: {
			updateAvailable: "New version is ready",
			updateNow: "Update",
			later: "Later",
			updateReadyTitle: "New version is ready",
			updateReadyBody: "Takes effect on next restart",
			checkUpdate: "Check for updates",
			checking: "Checking for updates…",
			upToDate: "Up to date",
			downloading: "New version found, downloading…",
			checkFailed: "Check failed, check your network",
			installTitle: "Add to home screen",
			installBody: "Opens faster next time and works offline",
			installAction: "Install",
			installIosTitle: "Add to Home Screen",
			installIosStep1: "Tap the Share button in the browser toolbar",
			installIosStep2: "Choose \"Add to Home Screen\"",
			installIosStep3: "Tap \"Add\" in the top right to finish"
		},
		home: {
			title: "What are we playing tonight",
			buildTime: "Updated",
			labLink: "Lab",
			sheetCalibLink: "Sheet calibration",
			createRoom: "New room",
			startTag: "START",
			createHint: "Host a table and invite friends",
			joinRoom: "Join room",
			joinHint: "Scan a friend's room code",
			otherModes: "More ways to play",
			offlineRoom: "Offline",
			offlineHint: "Play with bots",
			hotseat: "Pass & Play",
			hotseatHint: "Take turns",
			comingSoon: "Coming soon",
			newsTitle: "News",
			newsItems: { uiRefresh: {
				title: "Fresh new look",
				body: "Brand-new home, lobby and in-game experience."
			} }
		},
		ai: {
			title: "AI endpoints",
			hint: "Fixed OpenAI-compatible protocol (/chat/completions). Keys stay on this device; the browser calls the endpoint directly.",
			empty: "No endpoints yet — add one",
			add: "Add endpoint",
			edit: "Edit",
			delete: "Delete",
			confirmDelete: "Confirm",
			nameLabel: "Endpoint name",
			baseUrlLabel: "Base URL",
			apiKeyLabel: "API key",
			modelLabel: "Model name",
			save: "Save",
			back: "Back to list",
			test: "Test connection",
			testing: "Testing…",
			testOk: "Connected",
			testFail: "Unreachable — check the URL and key",
			usage: "{{n}} calls · in {{pin}} / out {{pout}}",
			usageLabel: "Show usage",
			usageByGame: "{{game}}: {{n}} calls · in {{pin}} / out {{pout}}",
			usageByGameAvg: "{{game}}: {{n}} calls · in {{pin}} / out {{pout}} · avg {{avg}}/seat·game",
			namePlaceholder: "Name (e.g. Work relay)",
			baseUrlPlaceholder: "Base URL, e.g. https://api.openai.com/v1",
			apiKeyPlaceholder: "API key",
			modelPlaceholder: "Model, e.g. gpt-4o-mini"
		},
		lobby: {
			colors: {
				blueberry: "Blueberry",
				tangerine: "Tangerine",
				grape: "Grape",
				honey: "Honey",
				seasalt: "Sea Salt",
				peach: "Peach",
				avocado: "Avocado",
				cocoa: "Cocoa",
				mint: "Mint",
				sesame: "Sesame"
			},
			you: "you",
			offline: "offline",
			bot: "Bot",
			botAi: "AI",
			thinking: "Thinking",
			done: "Done",
			rules: "How to play",
			memberCount: "{{n}} seated",
			namePlaceholder: "Your name",
			waiting: "Seated — waiting for the host to start",
			nextGame: "Game in progress — you join the next round",
			host: {
				badge: "You're the host — keep the screen on",
				nameTitle: "Tell us your name first",
				open: "Open room",
				opening: "Opening room…",
				openFailed: "Failed to open: https or localhost required",
				openStale: "Page version is outdated — refresh to host",
				refresh: "Refresh",
				offlineBadge: "Offline mode",
				offlineInvite: "Offline room: add bots and start; joining by scan is unavailable",
				hotseatBadge: "Hot-seat",
				hotseatInvite: "Hot-seat room: add local players or bots and pass the device around",
				addLocal: "Add a local player",
				removeLocal: "Remove local player",
				renameLocalTitle: "Rename",
				passTo: "Pass to {{name}}",
				passHint: "Tap anywhere to continue",
				passForce: "Pass anyway",
				iAm: "I'm {{name}}",
				qrLabel: "Join QR code",
				scanHint: "Friends on the same WiFi scan to join",
				qrCollapsed: "QR hidden — tap to show",
				copyLink: "Copy join link",
				copied: "Copied",
				pickGame: "Pick a game",
				searchGames: "Search games",
				searchClear: "Clear search",
				filters: {
					trigger: "Filter",
					triggerLabel: "Filter games, {{n}} selected",
					title: "Filter games",
					selected: "Selected filters",
					remove: "Remove {{name}} filter",
					clear: "Clear filters",
					gameplay: "Gameplay",
					interaction: "Interaction",
					matchAny: "Match any in each group",
					all: "All gameplay ({{n}})",
					less: "Show less",
					viewResults: "View {{n}} games",
					resultCount: "{{n}} / {{total}} games",
					mechanics: {
						handManagement: "Hand management",
						diceRolling: "Dice rolling",
						drafting: "Drafting",
						tilePlacement: "Tile placement",
						setCollection: "Set collection",
						engineBuilding: "Engine building",
						deduction: "Deduction",
						rollAndWrite: "Roll / flip and write",
						deckBagBuilding: "Deck / bag building",
						routeBuilding: "Route building",
						areaControl: "Area control",
						pushYourLuck: "Push your luck",
						trickTaking: "Trick-taking",
						wordAssociation: "Word association",
						betting: "Betting",
						gridMovement: "Grid movement",
						actionPoints: "Action points",
						race: "Race",
						workerPlacement: "Worker placement",
						auction: "Auction",
						stockHolding: "Stock holding",
						drawing: "Drawing",
						actionProgramming: "Action programming"
					},
					interactions: {
						cooperative: "Cooperative",
						communicationLimits: "Limited communication",
						teamBased: "Team-based",
						hiddenRoles: "Hidden roles"
					}
				},
				sort: "Sort",
				sortDefault: "Default (favorites first)",
				sortNew: "Newest",
				sortRecent: "Recently played",
				sortPlays: "Most played",
				noGameMatch: "No games match",
				layoutCompact: "Switch to compact list",
				layoutCover: "Switch to big covers",
				favorite: "Favorite, pinned to top",
				unfavorite: "Unfavorite",
				options: "Options",
				saveOptions: "Save",
				noGames: "Games are on the way",
				start: "Start",
				startCount: "Start ({{n}}/{{min}}–{{max}})",
				needGame: "Pick a game first",
				needPlayers: "Needs {{min}}–{{max}} players, now {{n}}",
				noEngine: "Game not wired in yet",
				addBot: "Add a bot",
				addAiBot: "Add an AI bot",
				botUnsupported: "This game has no bot support — remove bots first",
				aiBotUnsupported: "This game has no AI bot support — remove AI bots first",
				aiDegraded: "\"{{name}}\" is unreachable — the local bot plays this move",
				removeBot: "Remove bot",
				endGame: "End & back to lobby",
				resumeTitle: "Resume last game?",
				resumeDesc: "Unfinished {{n}}-player game, saved at {{time}}",
				resumeContinue: "Resume",
				resumeNew: "Start a new game",
				resumeBadge: "Saved",
				gameSource: "Game source",
				defaultSource: "Default",
				dissolve: "Dissolve room",
				dissolveConfirm: "Tap again to confirm",
				closed: "Room dissolved",
				reopen: "Host a new room"
			},
			join: {
				invalid: "Invalid QR code",
				manualTitle: "Join manually",
				room: "Room",
				key: "Key",
				roomPlaceholder: "12-char room id",
				keyPlaceholder: "16-char key",
				go: "Join",
				versionMismatch: "Version mismatch — refresh and rescan",
				seating: "Taking your seat…",
				failed: "Connection failed",
				faultInsecure: "Not a secure context: https or localhost required",
				faultNetwork: "Network issue: cannot reach pairing relays",
				faultHostOffline: "Host is offline",
				faultHostFault: "Connected but the host is not responding",
				retryHint: "Auto-retry in {{n}}s",
				retryNow: "Retry now",
				rejected: "Entry rejected by the host",
				naming: "What should we call you?",
				sit: "Take a seat",
				leave: "Leave room",
				leaveConfirm: "Tap again to leave",
				left: "You left the room",
				rejoin: "Rejoin"
			}
		},
		games: {},
		lab: {
			title: "Lab",
			playTester: "Test player",
			playUnknownGame: "Game not found",
			variantsTitle: "Orientation variants",
			variantsHint: "Rotate to landscape or shrink viewport height to see boxes change color",
			boxWide: "wide: landscape",
			boxShort: "short: ≤480px",
			tokensTitle: "Theme tokens (frozen)",
			touchTitle: "Touch targets",
			touchPrimary: "Primary 48px",
			touchNormal: "Normal 44px",
			safeTitle: "Safe area",
			safeHint: "Edge-flush elements (e.g. bottom bar) use safe-* for notch padding; always 0 on desktop",
			safeValues: "Measured T{{t}} B{{b}} L{{l}} R{{r}}",
			iconsTitle: "Icons (lucide · 2.5 stroke)",
			confirmTitle: "Two-step confirm",
			confirmIdle: "Dismiss room",
			confirmArmed: "Tap again to confirm",
			confirmDone: "Executed {{n}} times",
			paletteTitle: "Party palette (1.3)",
			paletteHint: "Player colors, assigned per room at seating; order = assignment order, warm/cool interleaved",
			faviconTitle: "App icon directions",
			faviconHint: "Compared at real sizes 64/32/16px — 16px is the actual browser tab size; anything blurry there is out",
			avatarCardTitle: "Big avatar + name (container library)",
			avatarCardHint: "Four container variants; C ships in room roster, the rest stay on the shelf; player color as avatar backdrop",
			avatarA: "Vertical sticker card",
			avatarB: "Horizontal banner card",
			avatarC: "Medal (name overlaps)",
			avatarD: "Bare inline",
			demoNameShort: "Ali",
			demoNameLong: "Super Duper Grape",
			strip: {
				title: "In-game player strip (PlayerStrip)",
				hint: "Pick a layout by status volume; samples cover long names/bots/offline/self/thinking/done/many statuses, score chip same as nimmt",
				variantPlate: "plate: horizontal nameplate, statuses wrap",
				variantMedal: "medal: vertical medal, few statuses",
				variantMini: "mini: minimal, no status"
			},
			fx: {
				title: "FX primitives (docs/FX.md)",
				hint: "Anchors + manual batches; flights hide the destination until arrival, numbers roll via diff",
				fly: "Fly A→B",
				chain: "Chain A→B→C + floater",
				bump: "Score +3"
			},
			dice: {
				title: "3D dice (CSS transform)",
				hint: "Shared dice module: always lands on the target value; the lower area runs the full fx pipeline (banner → fly to anchor)",
				roll1: "Roll 1",
				roll2: "Roll 2",
				roll3: "Roll 3",
				fxTitle: "Dice roll fx",
				rollBanner: "Banner, 2 dice",
				rollInplace: "In-place, 3 dice",
				rollMiss: "Banner (no anchor)"
			},
			transport: {
				title: "Transport probe (phase 4)",
				hostStart: "Host a room",
				hostRunning: "Host running",
				playerTitle: "Player: scan QR or enter credentials",
				room: "Room",
				key: "Key",
				link: "Join link",
				qrLabel: "Join QR code",
				scanBtn: "Scan to connect",
				roomPlaceholder: "12-char room id",
				keyPlaceholder: "16-char key",
				connect: "Connect",
				ping: "Send ping",
				echo: "Host echo",
				viewLabel: "Current view",
				online: "{{n}} online",
				close: "Close session",
				statusConnecting: "Connecting…",
				statusReady: "Connected",
				statusRejected: "Rejected ({{r}})",
				statusFailed: "Connection failed",
				faultInsecure: "Not a secure context: https or localhost required",
				faultNetwork: "Network issue: cannot reach pairing relays",
				faultHostOffline: "Host is offline",
				faultHostFault: "Connected but the host is not responding",
				retryHint: "Auto-retry in {{n}}s",
				retryNow: "Retry now"
			},
			engine: {
				title: "Engine self-test (stage 6)",
				hint: "Runs the GameSession core path against a local fake game (counter), no network",
				run: "Run self-test",
				errLimit: "Counter limit reached",
				checkValid: "Legal action advances state",
				checkBadShape: "Malformed action silently dropped",
				checkOutsider: "Non-player rid silently dropped",
				checkGameError: "GameError returned as-is",
				checkTick: "dispatchTick lands in log",
				checkPrivate: "Private view trimmed per player",
				checkReplay: "Replay rebuild matches live state",
				checkPrng: "PRNG determinism",
				checkFx: "fx accumulates in groups, takeFx drains"
			},
			baseline: {
				title: "Theme baseline proposal (1.2)",
				secSem: "Semantic colors: solid / soft",
				secType: "Type ladder, 4+1 steps",
				secFont: "Display font Baloo 2 (latin/digits)",
				fontZhNote: "CJK falls back to system font (this line in CJK would show it)",
				gameName: "Codenames",
				gameDesc: "Two rival teams, contact agents with codewords",
				gamePlayers: "{{min}}–{{max}} players · 15 min",
				roomCode: "4K2Q"
			},
			sheetCalib: {
				title: "Sheet calibration",
				hint: "Click / Shift-click to select; drag to move, drag selection handles (right/bottom/corner) to resize; arrows 1px (Shift=10px); Alt+arrows resize; [ ] pitch",
				groups: "Groups",
				links: "Linked series (even spread)",
				selAll: "All",
				gap: "Edge gap (px)",
				spread: "Spread",
				save: "Save to source",
				saved: "Saved ✓",
				saveFailed: "Save failed",
				reset: "Discard changes",
				dirty: "{{n}} groups unsaved",
				multiSet: "{{n}} selected — set all",
				noCalib: "This game's sheet-layout.ts does not export CALIB_LAYOUT",
				mark: "Mark",
				markDefault: "Default",
				markX: "Cross (X)",
				markSlash: "Slash",
				markCircle: "Circle"
			}
		}
	}
};
//#endregion
//#region packages/sdk/src/runtime.tsx
function j(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw Error("Invalid runtime arguments");
	return e;
}
function ee(e, t) {
	if (!e?.definition || typeof e.View != "function") throw Error("Invalid game module");
	p(t.host);
	let n = e.definition, o = n.meta.id, s = {
		zh: {
			...A.zh,
			games: { [o]: e.locales.zh }
		},
		en: {
			...A.en,
			games: { [o]: e.locales.en }
		}
	};
	a(s), r.setState({ locale: t.locale });
	let c = (0, v.createRoot)(t.root), l = null, u = [], d = [], h = Promise.resolve(void 0), g = new ResizeObserver(() => t.emit("resize", Math.ceil(t.root.scrollHeight))), _ = () => {
		if (!l) throw Error("Game has not started");
		return {
			...l.debugDump(),
			status: l.status(),
			views: Object.fromEntries(u.map((e) => [e, l.viewFor(e)])),
			botViews: Object.fromEntries(u.map((e) => [e, l.viewForBot(e)])),
			fx: l.takeFx(),
			autopilot: l.autopilotShares(),
			nextTick: n.nextTickIn?.(l.peekState(), Date.now()) ?? null
		};
	}, b = async (i, a) => {
		let s = a === void 0 ? {} : j(a);
		if (i === "describe") return {
			meta: JSON.parse(JSON.stringify(n.meta)),
			bot: !!e.bot,
			describe: !!e.describe,
			options: !!e.Options,
			guide: !!e.Guide,
			locales: e.locales,
			llm: e.llm ? { actionJsonSchema: e.llm.actionJsonSchema } : void 0,
			menu: !!e.MenuItems,
			ruleIcons: Object.fromEntries(Object.entries(e.ruleIcons ?? {}).map(([e, t]) => [e, (0, y.renderToStaticMarkup)((0, m.createElement)(t, { size: 24 }))])),
			range: n.meta.playerRange?.(s.config) ?? {
				min: n.meta.minPlayers,
				max: n.meta.maxPlayers
			}
		};
		if (i.startsWith("llm.")) {
			if (!e.llm || typeof s.rid != "string") throw Error("AI support is unavailable");
			let t = {
				rid: s.rid,
				difficulty: "normal",
				memory: s.memory
			}, n = s.view;
			if (i === "llm.needsAction") return e.llm.needsAction?.(n, t) ?? !0;
			if (i === "llm.describeView") return e.llm.describeView(n, t);
			if (i === "llm.parseAction") return e.llm.parseAction(s.raw, n, t);
		}
		if (i === "start") {
			if (!Array.isArray(s.players) || !s.players.every((e) => typeof e == "string") || s.players.length > 128) throw Error("Invalid players");
			u = s.players;
			let e = n.meta.playerRange?.(s.config) ?? {
				min: n.meta.minPlayers,
				max: n.meta.maxPlayers
			};
			if (u.length < e.min || u.length > e.max) throw Error("Invalid player count");
			return l = S({
				def: n,
				players: u,
				config: s.config,
				seed: typeof s.seed == "number" ? s.seed : void 0,
				onChange() {}
			}), _();
		}
		if (i === "resume") {
			if (!Array.isArray(s.log) || typeof s.sameGame != "boolean") throw Error("Invalid saved game");
			let e = structuredClone(s.log), t = j(e[0]), r = n.saveCompatibility;
			if (r && (typeof r.version != "string" || !r.version.length)) throw Error("Invalid save compatibility contract");
			if (!s.sameGame) {
				let n = typeof t.saveVersion == "string" ? t.saveVersion : void 0;
				if (!r) return { compatible: !1 };
				if (n !== r.version && (!n || !r.compatibleWith?.includes(n))) {
					if (!r.migrate) return { compatible: !1 };
					let t = await r.migrate({
						version: n,
						log: e
					});
					if (t === null) return { compatible: !1 };
					if (!Array.isArray(t)) throw Error("Invalid saved game migration");
					e = t;
				}
			}
			let i = C({
				def: n,
				log: e,
				onChange() {}
			});
			if (!i) throw Error("Saved game verification failed");
			l = i, u = j(e[0]).players;
			for (let e of u) {
				let t = i.viewFor(e);
				if (!n.schemas.publicView.safeParse(t.public).success || t.private !== void 0 && !n.schemas.privateView.safeParse(t.private).success) throw Error("Restored game view is invalid");
			}
			return {
				compatible: !0,
				log: _().log
			};
		}
		if (i === "restore") {
			if (!Array.isArray(s.log)) throw Error("Invalid saved game");
			let e = j(s.log[0]);
			if (!Array.isArray(e.players) || !e.players.every((e) => typeof e == "string")) throw Error("Invalid saved players");
			let t = C({
				def: n,
				log: s.log,
				onChange() {}
			});
			if (!t) throw Error("Saved game is incompatible");
			return l = t, u = e.players, _();
		}
		if (i === "action") {
			if (!l || typeof s.rid != "string") throw Error("Game has not started");
			return {
				error: l.handleAction(s.rid, s.action, { auto: s.auto === !0 }),
				snapshot: _()
			};
		}
		if (i === "tick") {
			if (!l || typeof s.now != "number" || !Number.isFinite(s.now)) throw Error("Invalid tick");
			return l.dispatchTick(s.now), _();
		}
		if (i === "snapshot") return _();
		if (i === "nextTick") return l ? n.nextTickIn?.(l.peekState(), Number(s.now)) ?? null : null;
		if (i === "validate") {
			if (![
				"publicView",
				"privateView",
				"action",
				"config"
			].includes(String(s.part))) throw Error("Invalid schema");
			let e = n.schemas[s.part]?.safeParse(s.data);
			return e?.success ? {
				success: !0,
				data: e.data
			} : { success: !1 };
		}
		if (i === "locale") {
			if (s.locale !== "zh" && s.locale !== "en") throw Error("Invalid locale");
			return r.setState({ locale: s.locale }), null;
		}
		if (i === "render") {
			g.unobserve(t.root), t.root.style.height = "100%", document.body.style.overflow = "hidden";
			let r = j(s.props), i = n.schemas.publicView.safeParse(r.public), a = r.private === void 0 ? void 0 : n.schemas.privateView.safeParse(r.private);
			if (!i.success || a && !a.success || !Array.isArray(r.members) || typeof r.myRid != "string") throw Error("Invalid game view");
			Array.isArray(s.fx) && (d = s.fx);
			let l = {
				...r,
				public: i.data,
				private: a?.success ? a.data : void 0,
				send: (e) => t.emit("action", e)
			}, u = s.result ? e.OverView ?? f : e.View, p = (0, m.createElement)(u, {
				...l,
				result: s.result,
				accent: n.meta.accent,
				renderRowExtra: e.RowView ? (t) => (0, m.createElement)(e.RowView, {
					public: i.data,
					rid: t,
					myRid: l.myRid
				}) : void 0,
				onPlayAgain: s.host ? () => t.emit("play-again", {}) : void 0,
				onPlayAgainWithConfig: s.host ? (e) => t.emit("play-again", { patch: e }) : void 0,
				onBackToLobby: s.host ? () => t.emit("back", {}) : void 0
			});
			return c.render((0, m.createElement)(O, {
				renderers: e.fx,
				fx: d,
				myRid: l.myRid,
				members: l.members,
				resetKey: s.epoch ?? o,
				children: p
			})), null;
		}
		if (i === "configure") return t.root.style.height = "auto", document.body.style.overflow = "visible", g.observe(t.root), s.mode === "menu" && e.MenuItems ? (t.root.style.height = "100%", c.render((0, m.createElement)(e.MenuItems, { close() {} }))) : s.mode === "guide" && e.Guide ? c.render((0, m.createElement)(e.Guide)) : e.Options && c.render((0, m.createElement)(e.Options, {
			value: s.value,
			offline: s.offline,
			onChange: (e) => t.emit("config", e)
		})), null;
		if (i === "dispose") return g.disconnect(), c.unmount(), p(void 0), l = null, null;
		throw Error("Unsupported runtime method");
	};
	return (t, n) => {
		if (t === "bot") {
			if (!e.bot) return Promise.resolve({ move: null });
			let t = j(n), a = String(t.rid), o = t.view ?? l?.viewForBot(a);
			return Promise.resolve(e.bot(o, {
				rid: a,
				difficulty: t.difficulty === "weak" ? "weak" : "normal",
				memory: t.memory
			})).then((t) => ({
				move: t,
				description: t && e.describe ? e.describe(t.action, o, (e, t) => i(r.getState().locale, e, t)) : void 0
			}));
		}
		let a = h.then(() => b(t, n));
		return h = a.catch(() => void 0), a;
	};
}
//#endregion
export { ee as connectRuntime };
