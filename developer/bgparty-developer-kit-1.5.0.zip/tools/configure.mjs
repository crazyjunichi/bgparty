import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { randomUUID } from 'node:crypto'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('..', import.meta.url))
const configFile = resolve(root, 'game.json')
const config = JSON.parse(readFileSync(configFile, 'utf8'))
const [command, value] = process.argv.slice(2)
const writeJson = (file, data) => writeFileSync(file, JSON.stringify(data, null, 2) + '\n')
try {
  if (command === 'rename') {
    if (!/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/.test(value ?? '') || value.length > 80) throw new Error('Use a game ID such as my-game (lowercase letters, numbers and hyphens).')
    const previous = config.metadata.id
    const visit = (directory) => {
      for (const entry of readdirSync(directory, { withFileTypes: true })) {
        const file = resolve(directory, entry.name)
        if (entry.isDirectory()) visit(file)
        else if (/\.tsx?$/.test(file)) {
          const before = readFileSync(file, 'utf8')
          const after = before.replaceAll(`games.${previous}.`, `games.${value}.`).replace(`interface GameMessages { ${previous}:`, `interface GameMessages { '${value}':`)
            .replace(`interface GameMessages { '${previous}':`, `interface GameMessages { '${value}':`)
          if (after !== before) writeFileSync(file, after)
        }
      }
    }
    visit(resolve(root, 'src')); visit(resolve(root, 'examples'))
    config.metadata.id = value
    config.metadata.uuid ??= randomUUID()
    config.releaseRevision ??= 1
    const packageFile = resolve(root, 'package.json')
    writeJson(packageFile, { ...JSON.parse(readFileSync(packageFile, 'utf8')), name: 'bgparty-game-' + value })
  } else if (command === 'example') {
    if (!['basic', 'private-cards'].includes(value)) throw new Error('Usage: npm run example -- basic|private-cards')
    const advanced = value === 'private-cards'
    config.entry = advanced ? 'examples/private-cards.tsx' : 'src/index.tsx'
    config.metadata.hotseat = advanced ? 'cover' : 'open'
    config.metadata.capabilities = { bot: true, ai: false, options: advanced, guide: advanced }
    config.metadata.labels = advanced ? {
      zh: { name: '密牌比大小', desc: '轮流亮出密牌，数值最高的玩家获胜。', rules: '每人获得一张密牌。轮流亮牌，所有人亮牌后，数值最高的玩家获胜，相同数值并列获胜。' },
      en: { name: 'Secret Cards', desc: 'Reveal your secret card. The highest value wins.', rules: 'Each player gets a secret card. Reveal in turn; the highest value wins, including ties.' },
    } : {
      zh: { name: '数到十', desc: '轮流加一或加二，先到十的人获胜。', rules: '玩家轮流选择加一或加二。使总数达到十的玩家获胜。' },
      en: { name: 'Count to Ten', desc: 'Add one or two. Reach ten to win.', rules: 'Take turns adding one or two. The player who reaches ten wins.' },
    }
  } else throw new Error('Usage: npm run rename -- my-game | npm run example -- basic|private-cards')
  writeJson(configFile, config)
  console.log('Updated game.json; run npm run check and npm run dev. Example selection replaces the sample name/rules/options; keep your changes in source control.')
} catch (error) { console.error(error.message); process.exitCode = 1 }
