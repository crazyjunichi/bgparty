# Make a game with AI

For image-heavy games, agree whether to opt in with `sdkApi: 4` and `assetLoading: "deferred-images"`. Ask the AI to follow the [development guide](development.en.md), migrate all raster references to async asset lookup, and verify waiting/errors/retry, path changes and unmounts. Adding only the flag while retaining synchronous image reads is incomplete. Existing synchronous games and starter examples do not require migration.

For fixed-package acceptance follow the [development guide](development.en.md#fixed-packages-and-log-restoration) and use SDK `bgparty-game accept`. It does not rebuild or follow mutable build outputs. Each run owns its address, storage identity, connected-browser tab and evidence. Restore legal logs through normal page controls and actually exercise the affected behavior. Coordinate only shared browser controls with short leases; do not serialize entire development tasks. Follow the project's listener authorization policy.

Give the complete project folder to a coding assistant that can read/edit local files. Ask it to read AGENTS.md and docs/ first. A chat-only AI can help design or write code, but you must perform installation, builds and browser actions. The main BGParty repository is unnecessary.

## Describe the game

Copy and fill this brief, attaching rules and assets you are allowed to use. Mark unclear rules as unresolved instead of asking the AI to silently invent them.

```text
Read AGENTS.md, README.md and the docs/ development guides first.
Game name and stable ID:
Player counts and hotseat requirements:
Available player actions:
Public information and each player's private information:
Setup, turn flow, end conditions and winner determination:
Special cases, ties and illegal actions:
Options, rule bots and persistent progress:
Original rules or attachments:
Visual direction and supplied assets:
Acceptance scenarios:
Explain your understanding and questions before implementation.
```

## Work in stages

Agree on rules and the state/action/view model, including information privacy. Choose an example, rename together, and implement playable pure rules.

Run check and build, align metadata and exported capabilities, then preview after obtaining any required port permission. Actually complete a match. For failures, provide terminal output, reproduction steps and expected behavior.

Improve layouts, assets, rules and both languages. Check mobile/desktop. Prefer SVG and public SDK components. Check contracts before advanced features; do not allow direct game networking or access to host secrets.

Follow [Publishing](publishing.en.md) and verify actual installation, networking, offline use and updates in BGParty. Ask the assistant to distinguish verified cases from untested ones. Generated code or successful compilation is not full game acceptance.

## Iteration prompt

```text
Read the existing project and guides. Change only what this task needs.
Goal:
Rules, visual direction and save behavior to preserve:
Reproduction steps, actual behavior and expected result:
Explain affected files and save compatibility before changing code.
Run check/build and report changed files, actual verification and untested cases.
```

Review AI-generated rules and art yourself. Keep published IDs stable. Visual-only updates normally retain the save version; rule changes require a compatibility decision backed by old-version evidence.
