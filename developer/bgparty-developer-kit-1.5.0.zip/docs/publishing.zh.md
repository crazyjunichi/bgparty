# 发布你的游戏

把完成的游戏上传后，你和朋友就可以在 BGParty 中下载并游玩。下面说明需要上传哪些文件、如何添加游戏，以及遇到问题时怎么检查。

## 上传游戏文件

```sh
npm run check
npm run build
```

使用 Git 托管的游戏站可直接固定并发布候选：

```sh
npx bgparty-game prepare --site https://example.com/games.json --repo git@github.com:owner/game-site.git --branch gh-pages
npx bgparty-game verify --candidate <候选UUID>
npx bgparty-game publish --candidate <候选UUID>
```

`prepare` 固定目标和包字节，并根据该站当前目录分配递增的发布版本；`publish` 只复用候选，不重新构建。远端分支或游戏版本发生并发变化时须重新准备或核对，不强制覆盖。也可以使用其他工具发布符合相同目录和包格式的 HTTPS 静态站。

把整个 .bgparty/release/ 目录的内容上传到你自己的静态托管空间。根目录的 games.json、games/ 中的游戏 ZIP、全部素材／数据卷和封面都必须上传。不要上传源码、node_modules 或 bgparty-sdk.tgz；游戏源不需要发布运行时 SDK。

托管必须支持公开 HTTPS、浏览器跨域读取（CORS），而且目录和文件不能要求登录、Cookie 或重定向。对象存储/CDN 可为这些公开文件设置 Access-Control-Allow-Origin: *；访问清单、ZIP 和封面时都要检查响应。文件分享页、临时下载链接通常不能直接作为游戏源。

在 BGParty 的“设置 → 游戏来源与下载”添加完整目录地址，例如 https://example.com/my-games/games.json。确认游戏出现在列表中，实际下载并开局，再邀请另一台设备验联机。完成下载后检查离线运行。能够在地址栏下载文件，不代表跨域读取已经配置正确。

`game.json` 中的 `metadata.uuid` 是游戏的长期身份：首次命名时生成一次，之后保持不变；`metadata.id` 仍是游戏自己的短名称。迁移站点时沿用同一 UUID。目录中的 `releaseRevision` 是正整数，新包发布时递增；同一候选重试不增加。手工发布时自行维护这个版本并保留完整目录，先上传 ZIP／资源，再更新 `games.json`。保留旧包供仍使用旧版本的玩家获取，绝不修改已发布路径中的字节。

## 常见问题

- 找不到 bgparty-sdk.tgz：重新获取完整开发包并保留根目录文件，不用 sdk.zip 替代；已有项目升级时同步替换 SDK 包并重新安装依赖。
- 安装失败或 Node 版本不支持：检查 node --version、npm 网络／代理和完整错误；Windows 可改用 npm.cmd。
- 页面出现 games.xxx 字样：使用 rename 命令统一改名，核对 GameMessages、翻译键与 locales 注册的 ID。
- 修改源码后没有变化：dev 不监听文件，重新 build 并刷新，或退出后再 dev。
- 本机预览不能在手机访问：预览只监听 127.0.0.1；真机联机用 HTTPS 的 BGParty 与已发布游戏源。
- 图片空白：核对 public/ 文件、相对 public/ 的别名、大小写和 gameAssetUrl；资源函数不加 resources/ 前缀，不要使用 /public/ 或远程素材 URL。
- 选项／规则／机器人入口缺失：核对 game.json 的 capabilities 与实际导出，重新构建。
- 外部源加载失败：同时检查目录及 ZIP 的 HTTPS、CORS、无重定向、完整上传，以及清单大小／摘要一致。
- SDK/API 不兼容：查看 game.json 的 sdkApi 与平台版本，更新平台或 SDK；不要只修改数字以绕过限制。
- 存档无法恢复：核对 saveCompatibility 与旧版日志，明确不兼容时重新开局，不改写玩家原档强行放行。

## 发布前记录

游戏菜单可以查看并复制本局实际运行的游戏包和公共运行库版本。新构建的版本包含 UTC 构建时间，界面按设备本地时区显示；历史包没有时间时仅显示摘要。排查“更新后仍未修复”时，请核对完整 SHA-256 和构建时间，并确认玩家已经更新下载、重新开局。重复上传同一成品包保留原版本和时间，不要为修改时间手工改写已发布的包。

记录游戏 ID、SDK 版本、存档版本、本次改动、已验证的人数／选项／语言／浏览器、联机与离线结果、未验项。声称兼容旧档前，用旧发布版的代表性记录验证进度、资源和结果；当前版本自测不能代替跨版本验证。
