# SDK API / 公共接口

The installed package's declarations are the source for exact signatures. 使用安装包中的类型声明查看完整参数与返回类型；编辑器可直接跳转定义。下方完整模块／出口表由当前 SDK 契约生成，随下载包更新，不根据本仓游戏的引用猜测公共能力。

## 常用入口 / Common entry points

- @bgparty/sdk/core：defineGame、GameDefinition、种子随机数、规则与 bot 类型。Pure rules, schemas and bots.
- @bgparty/sdk/ui：GameScreen、PlayerStrip、PhaseBanner、DeltaNumber、Texture、界面参数类型。Layout and common view props.
- @bgparty/sdk/i18n、messages：useT、useGameT、语言与 GameMessages 扩展。Localization and message augmentation.
- @bgparty/sdk/assets：gameAssetUrl、sharedAssetUrl；API 4 新增 loadGameAssetUrl(path): Promise<string>。Resolve installed assets to sandbox URLs; opt-in deferred images require asynchronous lookup. See the development guide for loading/error handling.
- @bgparty/sdk/storage：readGameStorage、writeGameStorage，要求 sdkApi: 2。Committed local progress with revision conflict handling.
- @bgparty/sdk/bottom-sheet：BottomSheet，横屏默认从右侧展开；`side="left"` 从左侧展开，要求 sdkApi: 3。竖屏仍从底部展开。Landscape side panels default to right; `side="left"` selects the left edge (sdkApi: 3). Portrait sheets still open from the bottom.
- @bgparty/sdk/icons、player-colors、avatars：平台公开图标、座位色和头像。Public presentation helpers.
- @bgparty/sdk/fx/*、drawing/*、three/*：按需接入演出、绘画与 3D 支持。Optional effects, drawing and resilient 3D.

核心流程示例见 [中文开发教程](development.zh.md) / [English development guide](development.en.md)。准确的输入、输出和可选回调以对应 .d.ts 为准；不直接导入 types/ 下的内部路径。

Game modules run in the host sandbox. 不要在 Node 里执行 SDK 的 empty.mjs。UI/API 1 游戏可继续使用兼容 SDK；采用新存储接口时在 game.json 顶层声明 sdkApi: 2。SDK npm 包版本、最低 API 与游戏存档版本分别维护。


## Complete module exports / 完整公共出口

### @bgparty/sdk/assets

`gameAssetUrl`, `loadGameAssetUrl`, `sharedAssetUrl`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/packages/sdk/src/assets.d.ts

### @bgparty/sdk/avatars

`AVATARS`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/avatars.d.ts

### @bgparty/sdk/bot-personality

`botPersonality`, `BotPersonality`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/bot-personality.d.ts

### @bgparty/sdk/bottom-sheet

`BottomSheet`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/bottom-sheet.d.ts

### @bgparty/sdk/confirm-button

`ConfirmButton`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/confirm-button.d.ts

### @bgparty/sdk/core

`BotCtx`, `BotDescribe`, `BotMove`, `BotThink`, `defineGame`, `FxEntry`, `GameDefinition`, `GameError`, `GameMeta`, `GameStatus`, `PlayerView`, `randomIntAt`, `ReduceCtx`, `SaveCompatibility`, `StateWithFx`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/packages/sdk/src/core.d.ts

### @bgparty/sdk/storage

`GameStorageSnapshot`, `GameStorageWriteResult`, `readGameStorage`, `writeGameStorage`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/packages/sdk/src/storage.d.ts

### @bgparty/sdk/drawing/canvas

`DrawingPad`, `SquareBox`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/drawing/canvas.d.ts

### @bgparty/sdk/drawing/strokes

`CANVAS_SIZE`, `PALETTE`, `Stroke`, `STROKE_WIDTHS`, `strokeSchema`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/drawing/strokes.d.ts

### @bgparty/sdk/drawing/view

`DrawingView`, `StrokePath`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/drawing/view.d.ts

### @bgparty/sdk/engine/prng

`randomAt`, `randomIntAt`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/engine/prng.d.ts

### @bgparty/sdk/fx/anchors

`AnchorBox`, `FxAnchorsProvider`, `useFxAnchor`, `useFxAnchors`, `useFxAnchorsMaybe`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/fx/anchors.d.ts

### @bgparty/sdk/fx/delta-number

`DeltaNumber`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/fx/delta-number.d.ts

### @bgparty/sdk/fx/dice-cube

`D6_SLOT`, `DICE_FACE_CLASS`, `DiceCube`, `diceFaceContent`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/fx/dice-cube.d.ts

### @bgparty/sdk/fx/dice-roll

`createDiceRollRenderer`, `DICE_ROLL_MS`, `DiceParse`, `DiceSpec`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/fx/dice-roll.d.ts

### @bgparty/sdk/fx/dice-roll-ms

`DICE_ROLL_MS`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/fx/dice-roll-ms.d.ts

### @bgparty/sdk/fx/primitives

`Flash`, `Floater`, `FlySprite`, `PulseBox`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/fx/primitives.d.ts

### @bgparty/sdk/fx/use-reduced-motion

`usePrefersReducedMotion`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/fx/use-reduced-motion.d.ts

### @bgparty/sdk/game-menu

`GameMenu`, `GameMenuAction`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/game-menu.d.ts

### @bgparty/sdk/i18n

`avatarNameAt`, `I18nKey`, `I18nVars`, `Locale`, `registerGameMessages`, `registerMessages`, `translate`, `useGameT`, `useI18nSettings`, `useT`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/packages/sdk/src/i18n.d.ts

### @bgparty/sdk/icons

`IconAdd`, `IconBack`, `IconBell`, `IconBot`, `IconCheck`, `IconClose`, `IconConnected`, `IconCopy`, `IconDisconnected`, `IconDown`, `IconDownload`, `IconEdit`, `IconEffect`, `IconExpand`, `IconExternal`, `IconEye`, `IconFlood`, `IconHint`, `IconHistory`, `IconHotseat`, `IconInfo`, `IconInstall`, `IconLang`, `IconLayoutCompact`, `IconLayoutCover`, `IconListen`, `IconLog`, `IconMenu`, `IconMirror`, `IconMore`, `IconMove`, `IconOptions`, `IconPile`, `IconPlay`, `IconPlayers`, `IconProgress`, `IconProps`, `IconQr`, `IconRecenter`, `IconRotate`, `IconScan`, `IconSearch`, `IconSettings`, `IconShare`, `IconShoot`, `IconShuffle`, `IconSort`, `IconStar`, `IconTrap`, `IconTrash`, `IconUpdate`, `IconWarning`, `IconZoomIn`, `IconZoomOut`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/icons.d.ts

### @bgparty/sdk/lobby

`botAvatarOf`, `BotKind`, `botRidOf`, `gameResultSchema`, `GameResultView`, `isAiBotRid`, `isBotRid`, `isLocalRid`, `lobbyMemberSchema`, `LobbyMemberView`, `LobbyUp`, `lobbyUpSchema`, `localAvatarOf`, `localRidOf`, `RoomView`, `roomViewSchema`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/lobby/protocol.d.ts

### @bgparty/sdk/messages

`GameMessages`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/packages/sdk/src/messages.d.ts

### @bgparty/sdk/player-colors

`PLAYER_COLORS`, `PlayerColor`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/player-colors.d.ts

### @bgparty/sdk/polyomino

`cellsOf`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/polyomino.d.ts

### @bgparty/sdk/runtime

`connectRuntime`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/packages/sdk/src/runtime.d.ts

### @bgparty/sdk/sfx

`playBell`, `playGameOver`, `playSettle`, `playTurn`, `previewTurn`, `TurnSoundId`, `useSfxSettings`, `useSoundEdge`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/sfx.d.ts

### @bgparty/sdk/sheet-geometry

`CircleSpec`, `gridCell`, `gridCells`, `GridSpec`, `LayoutDump`, `MarkStyle`, `SheetRect`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/sheet-geometry.d.ts

### @bgparty/sdk/sheet-mark

`SheetMark`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/sheet-mark.d.ts

### @bgparty/sdk/sheet-view

`EligibleCell`, `SheetFocus`, `SheetFxProbe`, `SheetText`, `SheetView`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/sheet-view.d.ts

### @bgparty/sdk/team-medal

`TeamMedal`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/team-medal.d.ts

### @bgparty/sdk/texture

`Texture`, `TextureKind`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/texture.d.ts

### @bgparty/sdk/three/resilient-canvas

`ResilientCanvas`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/three/resilient-canvas.d.ts

### @bgparty/sdk/ui

`DeltaNumber`, `GameMenuItemsProps`, `GameOptionsProps`, `GameOverViewProps`, `GameScreen`, `GameViewProps`, `PhaseBanner`, `PhaseTone`, `PlayerStrip`, `Texture`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/packages/sdk/src/ui.d.ts

### @bgparty/sdk/ui/confetti

`Confetti`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/games/ui/confetti.d.ts

### @bgparty/sdk/ui/game-options

`OptionCheckbox`, `OptionRadio`, `OptionSection`, `OptionSwitch`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/games/ui/game-options.d.ts

### @bgparty/sdk/ui/game-over-screen

`GameOverChime`, `GameOverScreen`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/games/ui/game-over-screen.d.ts

### @bgparty/sdk/ui/game-screen

`GameScreen`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/games/ui/game-screen.d.ts

### @bgparty/sdk/ui/hint-ring

`HintRing`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/games/ui/hint-ring.d.ts

### @bgparty/sdk/ui/log-sheet

`LogSheet`, `LogTicker`, `rich`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/games/ui/log-sheet.d.ts

### @bgparty/sdk/ui/phase-banner

`PhaseBanner`, `PhaseTone`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/games/ui/phase-banner.d.ts

### @bgparty/sdk/ui/player-strip

`PlayerStrip`, `PlayerStripVariant`, `SeatBadgedAvatar`, `seatName`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/games/ui/player-strip.d.ts

### @bgparty/sdk/use-wake-lock

`useWakeLock`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/use-wake-lock.d.ts

### @bgparty/sdk/word-list

`default`

Declaration / 类型声明：node_modules/@bgparty/sdk/types/src/shared/word-list.d.ts
