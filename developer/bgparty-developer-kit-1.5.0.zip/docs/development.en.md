# Code your game

Complete [Quick start](quickstart.en.md), then build your game's rules, screens and features. Use src/index.tsx for the basics and examples/private-cards.tsx for private cards, setup options and custom results screens.

## Rules

Import defineGame, GameDefinition and randomIntAt from @bgparty/sdk/core, and z from zod. GameDefinition generics are State, Action, Public, Private, Config.

- Define zod action/publicView/privateView schemas. An optional config schema must parse undefined into complete defaults.
- setup(config, players, seed) returns { state }. Player IDs identify seats. randomIntAt(seed, cursor, n) produces an integer in [0,n); keep seed/cursor in state for subsequent draws and increment the cursor after each use.
- reduce(state, action, { by }) returns { state } or { code, params? }. Validate actor, phase and resources, including actions sent outside the UI. Never mutate prior state, read the clock or use Math.random.
- viewFor(state, rid) returns { public, private? }. Do not expose deck order, opponents' hands or roles in public.
- status(state) returns { phase }; finish with both winner and complete ranking (best first), optionally scores.
- Timed games use nextTickIn and tick actions carrying now. Optional fx are output effects, separate from replay actions.

## Entry and metadata

Default-export { definition, View, locales: { zh, en } }. Optional exports are bot, describe, Options, Guide, OverView, RowView, MenuItems, ruleIcons, fx and llm. Keep game.json capabilities.bot/ai/options/guide aligned with actual exports so the platform exposes them.

game.json contains entry and metadata: stable id, bilingual labels, min/maxPlayers, accent, iconPath, tier, hotseat, mechanics, interactionTags, search and releasedAt. Describe quality honestly. hotseat is open, cover for private information, or off. Dynamic player limits can use definition.meta.playerRange(config).

## UI and localization

View receives public, private, members, myRid and send(action). Display member names from members. Import GameViewProps, GameOptionsProps and GameOverViewProps from @bgparty/sdk/ui; narrow unknown values with your schemas.

Use GameScreen with a stable action height, banner and overlays. Minimum touch target: 44px, primary controls: 48px. Check portrait phones, short screens and desktops. Import local CSS with unique game-prefixed class names. Use static Tailwind classes and import bgparty:game-utilities; no separate Vite/Tailwind configuration is needed.

src/messages.ts constrains English to the Chinese key structure and augments GameMessages through @bgparty/sdk/messages. useT uses full keys. The rename command changes prefixes together. useGameT<typeof zh>(gameId), from @bgparty/sdk/i18n, is also available for local keys. Translate UI, errors, accessibility labels and rules.

## Assets and imports

```tsx
import { gameAssetUrl } from '@bgparty/sdk/assets'
const token = gameAssetUrl('token.svg')
// <img src={token} alt="" />
```

gameAssetUrl uses aliases relative to public/: public/token.svg maps to token.svg, without a resources/ prefix. metadata.iconPath instead uses the cover's package path, resources/cover.svg for public/cover.svg. The tool generates hashed cover URLs and games.json. Import JSON normally; large JSON/assets are split into resource ZIPs automatically. Do not hand-edit generated catalogs or hashes.

For image-heavy games, opt in with top-level `"sdkApi": 4, "assetLoading": "deferred-images"` in game.json. Installation still downloads and verifies everything. Startup preloads code, styles, JSON, SVG and SDK-owned shared assets; game-owned PNG/JPEG/WebP/GIF/AVIF images are read and verified from the fixed local packages when needed. Import `loadGameAssetUrl` from `@bgparty/sdk/assets`, await it, then assign img/src, SVG image/href or dynamic CSS backgrounds. Do not pass unloaded images to synchronous gameAssetUrl or static CSS url(). Ignore stale Promise results after path changes/unmounts; show localized loading, errors and retry, and wait for decoding before image-dependent input. The runtime owns URL cleanup; do not revoke URLs yourself. Games without this option keep the original synchronous path.

Import host packages such as React, react-dom, zod and three by their standard names; import shared modules through @bgparty/sdk/*. empty.mjs is a host placeholder, not an executable Node game runtime. Games cannot access networks, native IndexedDB, parent credentials or AI keys. Bundle resources locally. AI bots provide view descriptions/action parsing, while the platform handles credentials and requests.

## Optional features

Options({ value, onChange, offline }) uses configSchema.parse(value) and emits complete config; setup receives validated config. Guide renders rules. bot(view, ctx) returns { action, memory? } or null, optionally asynchronously. Use only the cropped view; reduce still validates every bot action.

OverView receives result, public, private, members, myRid and optional onPlayAgain/onBackToLobby. Hide unavailable actions. The platform supplies default results when OverView is absent. See [API index](API.md) and linked declarations for menu, rule icon, FX and LLM contracts. Implement optional features only when required.

## Persistent progress

Use @bgparty/sdk/storage with game.json top-level sdkApi: 2. Values are strings; your game owns its data schema and version.

```ts
import { readGameStorage, writeGameStorage } from '@bgparty/sdk/storage'
async function saveSetting(value: string) {
  for (let attempt = 0; attempt < 3; attempt++) {
    const latest = await readGameStorage()
    const result = await writeGameStorage({ revision: latest.revision, values: { ...latest.values, setting: value } })
    if (result.status === 'saved') return
  }
  throw new Error('Save failed')
}
```

This replaces one setting only. Catch failures in the UI and offer a localized retry. For rewards, commit match/player deduplication and progress together; recompute from the latest snapshot on conflict rather than retrying stale rewards. Storage is limited to 512 KiB on the current browser, without device synchronization. Uninstall keeps data; explicit data clearing removes it.

## Saves and verification

Start with saveCompatibility: { version: '1' }. This version is independent of ZIP/SDK versions. Review rule, config, action, random sequence and gameplay-data changes for compatibility. For conversion, increment the save version and implement migrate({ version, log }), returning a new log or null. compatibleWith means direct acceptance without conversion. Successful replay alone does not prove equivalent rules.

Verify legal/illegal actions, each seat's privacy, player-count limits, options, results, bots, both languages and mobile/desktop layouts. Use BGParty for actual networking, installation/update, offline play, save resume and persistence. Record tested and untested cases; compilation and preview alone do not certify them.


## Fixed packages and log restoration

Keep using check/build after source edits. For immutable acceptance run `npx bgparty-game accept --game-zip <game ZIP> --sdk-zip <runtime SDK ZIP> --game-root <game catalog directory> --sdk-root <SDK registry directory>`. Locate the game via .bgparty/release/games.json and the SDK via the installed SDK runtime/sdk.json; each root is its catalog/registry directory. It validates and freezes every local dependency and the preview client before binding a random 127.0.0.1 port, without building source or opening a browser. Each run has its own identity, origin and storage; this does not test persistence across launches.

Use your own tab in the built-in or connected browser. In “Acceptance and logs”, paste a legal action array and click “Restore log”, or pass `--log <JSON>` and click “Load prepared log”. You can export the current log. Actually exercise affected interactions and motion after restoration; never inject arbitrary display state. Use `accept-status --run <UUID>` to inspect, and Ctrl+C or `accept-stop --run <UUID>` to exit. Records and evidence live under .bgparty/local/acceptance/<UUID>/. Runs may coexist; shared window/viewport controls require short accept-lock/accept-unlock leases described in the SDK README. Follow your project's listener authorization policy.

Package acceptance defaults to `--motion normal`. Check the on-page environment probe and run-bound evidence before observing actual game actions. Use `--motion system` for a baseline; ordinary preview follows system preferences. Environment readiness does not prove game animation quality.
