# 编写游戏代码

先完成[快速开始](quickstart.zh.md)，再为你的游戏实现规则、界面和所需功能。src/index.tsx 演示基础玩法，examples/private-cards.tsx 演示手牌保密、开局选项和自定义结果页面，可按需参考。

## 规则契约

从 @bgparty/sdk/core 导入 defineGame、GameDefinition 和 randomIntAt，从 zod 导入 z。GameDefinition 的泛型依次是 State、Action、Public、Private、Config。

- schemas.action、publicView、privateView 使用 zod；有选项时添加 config，并让 config.parse(undefined) 得到完整默认值。
- setup(config, players, seed) 返回 { state }，players 是座位 ID。随机用 randomIntAt(seed, cursor, n)，返回 0 到 n-1。后续抽牌把 seed 和 cursor 存入 state，每次消耗后递增 cursor。
- reduce(state, action, { by }) 返回 { state } 或 { code, params? }。检查行动人、阶段、资源与动作条件；禁用按钮不能替代规则校验。不要修改原 state，不读取时钟或 Math.random。
- viewFor(state, rid) 返回 { public, private? }。public 给所有人，private 只给该座位。牌库顺序、其他人的手牌与身份不应进入 public。
- status(state) 返回 { phase }；终局同时给 winner 和完整 ranking，可附 scores。ranking 从最好到最差，不能依赖平台猜测分数方向。
- 限时游戏通过 nextTickIn 与 { type: 'tick', now } 动作接收时间。规则输出可含 fx；详见对应公开类型。

## 入口与元数据

默认导出对象至少包含 { definition, View, locales: { zh, en } }。可选导出 bot、describe、Options、Guide、OverView、RowView、MenuItems、ruleIcons、fx、llm。game.json 的 capabilities 声明 bot、ai、options、guide，须与实际导出一致；仅导出组件而不改标志，平台可能不提供相应入口。

game.json 顶层 entry 指定入口；metadata 指定稳定 ID、双语 labels、人数、accent、iconPath、tier、hotseat、mechanics、interactionTags、search、releasedAt。示例默认 alpha；开发完成程度由作者如实标注。hotseat 为 open（无秘密）、cover（换座遮挡）或 off（不适合热座）。动态人数范围可在 definition.meta.playerRange(config) 中声明。

## 界面与双语

View 接收 public、private、members、myRid、send(action)。成员名称来自 members；使用 send 提交动作。GameViewProps、GameOptionsProps、GameOverViewProps 从 @bgparty/sdk/ui 导入。unknown 类型的视图可以用本游戏 schema.parse 收窄，不盲目断言。

使用 GameScreen 的 banner、固定高度 actions 和 overlay。触控目标至少 44px，主要操作至少 48px；照顾手机竖屏、低高度与大屏，避免页面横向溢出。源码类名是静态 Tailwind 类；自写 CSS 使用游戏唯一前缀，通过入口 import 本地 CSS。引入 bgparty:game-utilities 获取当前游戏使用的 Tailwind 工具类，不另外配置 Vite/Tailwind。

src/messages.ts 的英文对象受中文结构约束，通过 @bgparty/sdk/messages 扩展 GameMessages，useT 使用完整翻译键。rename 命令处理键前缀。也可使用 @bgparty/sdk/i18n 的 useGameT<typeof zh>(gameId) 获取局部键函数。保持按钮、错误、无障碍说明与规则双语完整。

## 素材与模块

```tsx
import { gameAssetUrl } from '@bgparty/sdk/assets'
const token = gameAssetUrl('token.svg')
// <img src={token} alt="" />
```

gameAssetUrl 使用相对 public/ 的资源别名：public/token.svg 对应 token.svg，不加 resources/ 前缀。metadata.iconPath 则使用封面的包内路径，例如 resources/cover.svg，两者用途不同。工具自动生成发布封面和目录，不手改 games.json。JSON 可正常 import；较大的 JSON 和素材会自动分卷。构建工具管理引用路径和 SHA-256，不手工拼包。

图片很多时，可在 `game.json` 顶层选择 `"sdkApi": 4, "assetLoading": "deferred-images"`。平台仍先完整安装；进入游戏时预载代码、样式、JSON、SVG 及 SDK 自带资源，游戏自己的 PNG/JPEG/WebP/GIF/AVIF 按显示需要从本地固定包读取并校验。所有这类图片改用 `await loadGameAssetUrl('photo.webp')`（从 `@bgparty/sdk/assets` 导入），拿到 URL 后再设置 img/src、SVG image/href 或动态 CSS 背景。不要把未加载的图片交给同步 gameAssetUrl 或静态 CSS url()。在 React effect 中忽略已卸载或路径已切换的 Promise 结果，并显示双语加载、失败与重试状态；依赖图片的点击操作等待图片解码完成。URL 由沙箱统一释放，不自行 revoke。未声明该选项的游戏保持原同步流程。

React、react-dom、zod、three 等宿主公开依赖按标准包名导入，公共组件按 @bgparty/sdk/* 导入。SDK 的 empty.mjs 是宿主占位，不可直接在 Node 中执行游戏模块。游戏不能直接联网或打开原生 IndexedDB，也不能读取平台凭据。资源放包内，AI bot 只定义视图描述与动作解析，不获取密钥或自行请求模型。

## 选项、机器人与终局

Options({ value, onChange, offline }) 读取 configSchema.parse(value)，onChange 返回完整配置；setup 接收已验证的配置。Guide 返回规则内容。bot(view, ctx) 只看裁剪后的视图，在可行动时返回 { action, memory? }，否则 null，可异步。不要在 bot 中读其他人的秘密；让所有动作再次经过 reduce。

OverView 使用 result、public、private、members、myRid 与可选的 onPlayAgain、onBackToLobby。回调缺失时不要显示可用按钮。没有 OverView 则使用平台通用结算。MenuItems 的 close、规则图标、FX 和 LLM 契约在 [API 索引](API.md)的声明中查阅；不需要的能力无需实现。

## 成长与设置

持久化新数据使用 @bgparty/sdk/storage，game.json 顶层声明 sdkApi: 2。数据是字符串键值，结构和数据版本由游戏维护。

```ts
import { readGameStorage, writeGameStorage } from '@bgparty/sdk/storage'
async function saveSetting(value: string) {
  for (let attempt = 0; attempt < 3; attempt++) {
    const latest = await readGameStorage()
    const result = await writeGameStorage({ revision: latest.revision, values: { ...latest.values, setting: value } })
    if (result.status === 'saved') return
  }
  throw new Error('Save failed')
}
```

此片段只示范覆盖一个设置；调用端必须捕获失败并显示双语重试入口。奖励必须按对局及玩家去重，和成长数据同次提交；conflict 后基于新快照重新计算，不能只重复写旧奖励。最多 512 KiB，数据仅在本机浏览器，不跨设备同步；移除下载保留数据，独立清除会删除数据。

## 存档与验收

首版声明 saveCompatibility: { version: '1' }。存档版本不随 ZIP 或 SDK 版本递增。规则、配置、动作、随机序列或玩法数据变化要审查旧记录；需要转换时升级版本并提供 migrate({ version, log })，返回新日志或 null。compatibleWith 仅用于无需转换即可接受的旧版本。不得把无证据的“能重放”当成语义兼容。

发布前实际覆盖合法／非法动作、各座位私有信息、最少／最多人数、开局选项、终局、机器人、中英文和手机／桌面。完整平台另验联机、安装更新、离线、续玩和存储。开发预览和类型检查不能代替这些验收；记录已验与未验范围。


## 固定成品包与日志恢复

源码修改后继续 check/build；需要固定一轮输入验收时，运行 `npx bgparty-game accept --game-zip <游戏ZIP> --sdk-zip <SDK运行ZIP> --game-root <游戏清单目录> --sdk-root <SDK清单目录>`。它校验并读入全部本地包、依赖卷和客户端后才分配 127.0.0.1 端口，不构建源码，不启动浏览器。SDK ZIP 在安装包的 runtime/sdk.json 中定位；游戏 ZIP 在 .bgparty/release/games.json 中定位，root 分别指向对应清单目录。每轮独立运行 ID、地址与存储，不能将其当作跨启动持久化验收。

在已有或内置浏览器打开自己的临时标签页，通过“验收记录与日志”粘贴合法动作数组并点击“恢复日志”，或 `--log <JSON>` 后点击“载入准备日志”；可导出当前日志。恢复后实际检查受影响操作和动态，不能注入任意状态。用 `accept-status --run <UUID>` 查询，Ctrl+C 或 `accept-stop --run <UUID>` 退出。记录与证据放 `.bgparty/local/acceptance/<UUID>/`。多个运行可以并存；共享浏览器窗口/视口前按 SDK README 的 accept-lock/accept-unlock 短时互斥，其他项目的端口授权仍须遵守。

成品包独立验收默认强制正常动效（`--motion normal`），先确认页面环境探针和本轮证据通过，再观察实际动作演出。`--motion system` 用于对照系统偏好；普通 preview 不覆盖系统设置。环境探针不代替游戏动效验收。
