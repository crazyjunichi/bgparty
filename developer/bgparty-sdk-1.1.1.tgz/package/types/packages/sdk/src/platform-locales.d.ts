export declare const platformLocales: Record<'zh' | 'en', Record<string, unknown>>;
