declare global {
    var __bgpartyAssetUrl: ((path: string) => string) | undefined;
}
/** Uses the published asset alias (independent projects: path relative to public/), not its ZIP file path. */
export declare function gameAssetUrl(path: string): string;
export declare const sharedAssetUrl: typeof gameAssetUrl;
