export interface GameStorageSnapshot {
    revision: number;
    values: Record<string, string>;
}
export interface GameStorageWriteResult {
    status: 'saved' | 'conflict';
    snapshot: GameStorageSnapshot;
}
/** Read the latest committed data for this game and source. */
export declare function readGameStorage(): Promise<GameStorageSnapshot>;
/** A saved result is returned only after the platform database transaction commits. */
export declare function writeGameStorage(snapshot: GameStorageSnapshot): Promise<GameStorageWriteResult>;
