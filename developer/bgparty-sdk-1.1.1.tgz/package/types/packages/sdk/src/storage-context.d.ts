declare let host: ((method: string, args: unknown) => Promise<unknown>) | undefined;
export declare function connectGameStorage(call: typeof host): void;
export declare function requestGameStorage(method: string, args: unknown): Promise<unknown>;
export {};
