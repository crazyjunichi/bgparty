import type { I18nVars } from '../../../src/shared/i18n';
type Keys<T> = {
    [K in keyof T & string]: T[K] extends string ? K : T[K] extends readonly unknown[] ? never : `${K}.${Keys<T[K]>}`;
}[keyof T & string];
export * from '../../../src/shared/i18n';
export type { Locale, I18nVars } from '../../../src/shared/i18n';
export declare function useGameT<T extends object>(gameId: string): (key: Keys<T>, vars?: I18nVars) => string;
