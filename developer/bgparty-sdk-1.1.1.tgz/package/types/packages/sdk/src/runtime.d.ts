import { type ComponentType } from 'react';
import '../../../src/index.css';
import { type AnyDef } from '../../../src/engine/game-session';
import { type FxRenderers } from '../../../src/shared/fx/stage';
import type { AnyLlmBotSpec } from '../../../src/engine/llm-bot';
interface ViewProps {
    public: unknown;
    private?: unknown;
    members: {
        rid: string;
        name: string;
        avatar: number;
        colorIndex: number;
    }[];
    myRid: string;
    send(action: unknown): void;
}
interface Plugin {
    definition: AnyDef;
    View: ComponentType<ViewProps>;
    OverView?: ComponentType<Record<string, unknown>>;
    RowView?: ComponentType<Record<string, unknown>>;
    MenuItems?: ComponentType<Record<string, unknown>>;
    Options?: ComponentType<Record<string, unknown>>;
    Guide?: ComponentType;
    fx?: FxRenderers;
    bot?: (view: unknown, context: {
        rid: string;
        difficulty: 'weak' | 'normal';
        memory: unknown;
        signal?: AbortSignal;
    }) => unknown;
    describe?: (...args: unknown[]) => string;
    llm?: AnyLlmBotSpec;
    ruleIcons?: Record<string, ComponentType<{
        size?: number;
    }>>;
    locales: Record<'zh' | 'en', Record<string, unknown>>;
}
interface Context {
    root: HTMLElement;
    locale: 'zh' | 'en';
    host(method: string, args: unknown): Promise<unknown>;
    emit(name: string, data: unknown): void;
    assetUrl(path: string): string;
}
export declare function connectRuntime(plugin: Plugin, context: Context): (method: string, args: unknown) => Promise<unknown>;
export {};
