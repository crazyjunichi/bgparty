export { randomIntAt } from '../../../src/engine/prng';
export type { GameDefinition, GameMeta, GameError, GameStatus, PlayerView, ReduceCtx, StateWithFx, FxEntry, BotThink, BotCtx, BotMove, BotDescribe, SaveCompatibility } from '../../../src/shared/protocol';
export declare function defineGame<T>(game: T): T;
