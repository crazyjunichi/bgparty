/** 画记样式标记:#/lab/sheet-calib 可逐条配置,游戏 view 自行决定是否消费及如何渲染(颜色等表现不进这里) */
export type MarkStyle = 'x' | 'slash' | 'circle';
/** 世界坐标系里的一个矩形格 */
export interface SheetRect {
    x: number;
    y: number;
    w: number;
    h: number;
    mark?: MarkStyle;
}
/** 等距网格:首格左上 (x,y),格 w×h,相邻格左缘间距 pitch,共 count 格。不规则版面不要用,直接写 SheetRect 列表 */
export interface GridSpec {
    x: number;
    y: number;
    w: number;
    h: number;
    pitch: number;
    count: number;
    mark?: MarkStyle;
}
/** 网格第 i 格的矩形 */
export declare function gridCell(g: GridSpec, i: number): SheetRect;
/** 网格展开为格列表(标注校验/逐个叠层用) */
export declare function gridCells(g: GridSpec): SheetRect[];
/** 圆形热点(锁圈等) */
export interface CircleSpec {
    cx: number;
    cy: number;
    r: number;
    mark?: MarkStyle;
}
/** 标注校验导出形状:sheet-layout.ts 按约定导出 dumpLayout() 返回它,scripts/sheet-dump-layout.mts 消费 */
export interface LayoutDump {
    w: number;
    h: number;
    /** 命名格组(如 'row:red' / 'penalties'),校验图按组着色并标注序号 */
    groups: Record<string, SheetRect[]>;
    /** 圆形热点(锁圈等),校验图画圆 */
    circles?: Record<string, CircleSpec[]>;
}
