export declare function useBuildTimeLabel(): string;
