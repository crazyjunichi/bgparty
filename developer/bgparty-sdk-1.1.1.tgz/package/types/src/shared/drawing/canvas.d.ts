import { type ReactNode } from 'react';
import { type Stroke } from './strokes';
/** 正方形容器:画幅必须是正方形,否则 viewBox 映射拉伸、笔迹落点偏移。
 *  横屏/矮屏下宽不是约束,用 ResizeObserver 取 min(宽,高) 钉成正方形 */
export declare function SquareBox({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function DrawingPad({ value, onChange }: {
    value: Stroke[];
    onChange(strokes: Stroke[]): void;
}): import("react").JSX.Element;
