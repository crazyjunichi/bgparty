import { z } from 'zod';
export declare const CANVAS_SIZE = 1000;
export declare const PALETTE: readonly ["#1c1917", "#dc2626", "#ea580c", "#eab308", "#16a34a", "#0284c7", "#7c3aed", "#db2777"];
export declare const STROKE_WIDTHS: readonly [8, 16, 32];
export declare const strokeSchema: z.ZodObject<{
    c: z.ZodInt;
    w: z.ZodInt;
    pts: z.ZodArray<z.ZodInt>;
}, z.core.$strip>;
export type Stroke = z.infer<typeof strokeSchema>;
