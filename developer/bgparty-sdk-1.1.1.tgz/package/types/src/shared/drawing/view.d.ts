import { type Stroke } from './strokes';
export declare function DrawingView({ strokes, className }: {
    strokes: Stroke[];
    className?: string;
}): import("react").JSX.Element;
export declare function StrokePath({ stroke }: {
    stroke: Stroke;
}): import("react").JSX.Element;
