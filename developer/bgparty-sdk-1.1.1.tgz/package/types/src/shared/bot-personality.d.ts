export interface BotPersonality {
    /** 风险偏好:高=敢赌 */
    risk: number;
    /** 收益渴望:高=愿为大额收益冒险 */
    greed: number;
    /** 攻击性:高=乐意损人(暂无游戏消费) */
    aggression: number;
    /** 从众:高=决策看重他人动向 */
    herd: number;
    /** 心机:高=爱诈唬/放假信号(暂无游戏消费) */
    cunning: number;
    /** 耐心:低=急着落袋 */
    patience: number;
    /** 好胜:高=落后激进、领先保守 */
    compete: number;
    /** 情绪化:决策噪声 */
    noise: number;
}
/** 取某个 bot 座位(头像索引)的性格;null/越界按均衡处理 */
export declare function botPersonality(avatar: number | null): BotPersonality;
