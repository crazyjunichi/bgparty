/** 定长 base36 串:房间号 / 口令 / rid 等会话 id */
export declare function randomBase36(len: number): string;
export declare function isBase36(s: string, len: number): boolean;
