import { type ReactNode } from 'react';
import { type CanvasProps } from '@react-three/fiber';
type ResilientCanvasProps = CanvasProps & {
    recoveryFallback?: ReactNode;
    onRecoveryChange?: (recovering: boolean) => void;
};
export declare function ResilientCanvas({ recoveryFallback, onRecoveryChange, onCreated, ...props }: ResilientCanvasProps): string | number | bigint | boolean | Iterable<ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | import("react").JSX.Element | null;
export {};
