import words from './data/word-list.json';
export default words;
