import type { AnyBotThink } from '../engine/bot-driver';
import type { BotDescribe } from './protocol';
export type AnyBotDescribe = BotDescribe<any, any, any>;
export interface BotResolvers {
    hasRuleBot(id: string): boolean;
    hasBotDescribe(id: string): boolean;
    loadBotThink(id: string): Promise<AnyBotThink | undefined>;
    loadBotDescribe(id: string): Promise<AnyBotDescribe | undefined>;
}
/** 由 games/registry 模块顶层调用;注册前(不应发生)全部空操作 */
export declare function registerBotResolvers(resolvers: BotResolvers): void;
export declare function hasRuleBot(id: string): boolean;
export declare function hasBotDescribe(id: string): boolean;
export declare function loadBotThink(id: string): Promise<AnyBotThink | undefined>;
export declare function loadBotDescribe(id: string): Promise<AnyBotDescribe | undefined>;
