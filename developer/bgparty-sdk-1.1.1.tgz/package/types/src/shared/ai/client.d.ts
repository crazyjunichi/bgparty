import type { AiProfile } from './store';
export interface ChatMessage {
    role: 'system' | 'user' | 'assistant';
    content: string;
}
/**
 * OpenAI 兼容 chat/completions 最小客户端:只走这一种协议(2026-09-15 拍板),
 * 官方/中转(one-api 类)/本地推理(vllm、Ollama 的 OpenAI 兼容层)都长这样。
 * 只取 content 文本,不流式——bot 一招一答,流式没有意义。
 */
export declare function chatCompletion(profile: AiProfile, messages: ChatMessage[], opts?: {
    signal?: AbortSignal;
    timeoutMs?: number;
    jsonMode?: boolean;
    gameId?: string;
}): Promise<string>;
/** 配置 sheet 的「测试连接」:一条最小对话能回 content 即通 */
export declare function testProfile(profile: AiProfile): Promise<void>;
