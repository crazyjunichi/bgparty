export interface AiProfile {
    id: string;
    name: string;
    /** 如 https://api.openai.com/v1;调用时拼 /chat/completions */
    baseUrl: string;
    apiKey: string;
    model: string;
}
export interface AiUsage {
    calls: number;
    promptTokens: number;
    completionTokens: number;
}
export interface ProfileUsage {
    total: AiUsage;
    /** 按游戏归因:gameId → 用量;'' 桶 = 非对局调用(测试连接等)。重试/失败调用照计——确实烧了 token */
    byGame: Record<string, AiUsage>;
    /** gameId → 累计 AI 座位局数(每开一局按 AI 座位数加;恢复重建不计)。「单局单 bot 均值」= byGame 用量 ÷ seatGames */
    seatGames: Record<string, number>;
}
interface AiSettings {
    profiles: AiProfile[];
    activeId: string | null;
    /** 按 profile 累计的 token 用量;只记量不折算金额,端点价格各异且常变 */
    usage: Record<string, ProfileUsage>;
    upsert(profile: AiProfile): void;
    remove(id: string): void;
    setActive(id: string): void;
    /** gameId = null 记进 '' 桶(非对局调用) */
    recordUsage(id: string, gameId: string | null, promptTokens: number, completionTokens: number): void;
    /** 新开一局时按 AI 座位数登记(分母);恢复重建不算新局 */
    recordSeatGames(id: string, gameId: string, seats: number): void;
}
export declare const useAiSettings: import("zustand").UseBoundStore<Omit<import("zustand").StoreApi<AiSettings>, "setState" | "persist"> & {
    setState(partial: AiSettings | Partial<AiSettings> | ((state: AiSettings) => AiSettings | Partial<AiSettings>), replace?: false | undefined): unknown;
    setState(state: AiSettings | ((state: AiSettings) => AiSettings), replace: true): unknown;
    persist: {
        setOptions: (options: Partial<import("zustand/middleware").PersistOptions<AiSettings, unknown, unknown>>) => void;
        clearStorage: () => void;
        rehydrate: () => Promise<void> | void;
        hasHydrated: () => boolean;
        onHydrate: (fn: (state: AiSettings) => void) => () => void;
        onFinishHydration: (fn: (state: AiSettings) => void) => () => void;
        getOptions: () => Partial<import("zustand/middleware").PersistOptions<AiSettings, unknown, unknown>>;
    };
}>;
/** 当前生效的 profile;未配置 = null(LLM bot 据此直接回落规则 bot) */
export declare function activeProfile(): AiProfile | null;
export {};
