import type { Messages } from './locales/zh';
import type { GameMessages } from '../../../packages/sdk/src/messages';
export type Locale = 'zh' | 'en';
export declare function registerMessages(data: Record<Locale, Messages>): void;
export declare function registerGameMessages(id: string, locales: Record<Locale, Record<string, unknown>>): void;
type FlatKeys<T> = {
    [K in keyof T & string]: T[K] extends string ? K : T[K] extends readonly unknown[] ? never : `${K}.${FlatKeys<T[K]>}`;
}[keyof T & string];
type RegisteredMessages = Omit<Messages, 'games'> & {
    games: GameMessages;
};
export type I18nKey = FlatKeys<RegisteredMessages>;
export type I18nVars = Record<string, string | number>;
export declare function translate(locale: Locale, key: I18nKey, vars?: I18nVars): string;
interface I18nSettings {
    locale: Locale;
    setLocale: (locale: Locale) => void;
}
export declare const useI18nSettings: import("zustand").UseBoundStore<Omit<import("zustand").StoreApi<I18nSettings>, "setState" | "persist"> & {
    setState(partial: I18nSettings | Partial<I18nSettings> | ((state: I18nSettings) => I18nSettings | Partial<I18nSettings>), replace?: false | undefined): unknown;
    setState(state: I18nSettings | ((state: I18nSettings) => I18nSettings), replace: true): unknown;
    persist: {
        setOptions: (options: Partial<import("zustand/middleware").PersistOptions<I18nSettings, {
            locale: Locale;
        }, unknown>>) => void;
        clearStorage: () => void;
        rehydrate: () => Promise<void> | void;
        hasHydrated: () => boolean;
        onHydrate: (fn: (state: I18nSettings) => void) => () => void;
        onFinishHydration: (fn: (state: I18nSettings) => void) => () => void;
        getOptions: () => Partial<import("zustand/middleware").PersistOptions<I18nSettings, {
            locale: Locale;
        }, unknown>>;
    };
}>;
export declare function useT(): (key: I18nKey, vars?: I18nVars) => string;
export declare function avatarNameAt(locale: Locale, index: number): string;
export {};
