export declare const AVATARS: string[];
