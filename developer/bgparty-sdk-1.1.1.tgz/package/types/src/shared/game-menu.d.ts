import { type ReactNode } from 'react';
/** 对局中的平台操作浮层。按钮和菜单不占游戏视口的布局高度。 */
export declare function GameMenu({ children, notice, quickAction, attention, headerAction, }: {
    children: (close: () => void) => ReactNode;
    notice?: ReactNode;
    quickAction?: ReactNode;
    attention?: string;
    headerAction?: ReactNode;
}): import("react").JSX.Element;
export declare function GameMenuAction({ icon, label, onClick, danger, pressed, }: {
    icon: ReactNode;
    label: string;
    onClick: () => void;
    danger?: boolean;
    pressed?: boolean;
}): import("react").JSX.Element;
