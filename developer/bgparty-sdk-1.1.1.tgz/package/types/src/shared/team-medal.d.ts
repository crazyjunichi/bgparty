import type { LobbyMemberView } from '../lobby/protocol';
/** 分组奖牌:小头像+名字;editable 时可拖(touch-none 防拖动变滚动);crowned = 队长类标记(👑 角标,不只靠排序)。
 * 自 codenames/medal.tsx 上提(decrypto 分组复用,第二次出现按惯例入 shared) */
export declare function TeamMedal({ member, rid, editable, dragging, floating, crowned, onStartDrag, }: {
    member: LobbyMemberView | undefined;
    rid: string;
    editable?: boolean;
    dragging?: boolean;
    floating?: boolean;
    crowned?: boolean;
    onStartDrag?: (rid: string, e: React.PointerEvent) => void;
}): import("react").JSX.Element;
