import type { I18nKey } from './i18n';
export interface PlayerColor {
    id: string;
    hex: string;
    nameKey: I18nKey;
}
export declare const PLAYER_COLORS: PlayerColor[];
