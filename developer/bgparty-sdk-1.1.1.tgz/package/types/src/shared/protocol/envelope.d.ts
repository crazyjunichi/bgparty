import { z } from 'zod';
export declare const PROTOCOL_VERSION = 1;
export type JsonValue = string | number | boolean | null | JsonValue[] | {
    [key: string]: JsonValue;
};
export declare const jsonValueSchema: z.ZodType<JsonValue>;
export declare const envelopeKindSchema: z.ZodEnum<{
    lobby: "lobby";
    game: "game";
}>;
export type EnvelopeKind = z.infer<typeof envelopeKindSchema>;
export declare const fxEntrySchema: z.ZodObject<{
    kind: z.ZodString;
    rid: z.ZodOptional<z.ZodString>;
    data: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
    for: z.ZodOptional<z.ZodArray<z.ZodString>>;
    secret: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
    with: z.ZodOptional<z.ZodBoolean>;
    ephemeral: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export type FxEntry = z.infer<typeof fxEntrySchema>;
export declare const upMsgSchema: z.ZodObject<{
    v: z.ZodInt;
    kind: z.ZodEnum<{
        lobby: "lobby";
        game: "game";
    }>;
    rid: z.ZodString;
    seq: z.ZodInt;
    hello: z.ZodBoolean;
    data: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    relay: z.ZodOptional<z.ZodBoolean>;
    hb: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export type UpMsg = z.infer<typeof upMsgSchema>;
export declare const downMsgSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    v: z.ZodInt;
    ok: z.ZodLiteral<true>;
    view: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    fx: z.ZodOptional<z.ZodArray<z.ZodObject<{
        kind: z.ZodString;
        rid: z.ZodOptional<z.ZodString>;
        data: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        for: z.ZodOptional<z.ZodArray<z.ZodString>>;
        secret: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        with: z.ZodOptional<z.ZodBoolean>;
        ephemeral: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>>>;
}, z.core.$strip>, z.ZodObject<{
    v: z.ZodInt;
    ok: z.ZodLiteral<false>;
    reason: z.ZodOptional<z.ZodString>;
    params: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>>;
}, z.core.$strip>], "ok">;
export type DownMsg = z.infer<typeof downMsgSchema>;
