import type { ZodType } from 'zod';
import type { I18nKey, I18nVars } from '../i18n';
import type { FxEntry } from './envelope';
export type PlayerId = string;
export type GameMechanic = 'hand-management' | 'dice-rolling' | 'drafting' | 'tile-placement' | 'set-collection' | 'engine-building' | 'deduction' | 'roll-and-write' | 'deck-bag-building' | 'route-building' | 'area-control' | 'push-your-luck' | 'trick-taking' | 'word-association' | 'betting' | 'grid-movement' | 'action-points' | 'race' | 'worker-placement' | 'auction' | 'stock-holding' | 'drawing' | 'action-programming';
export type GameInteractionTag = 'cooperative' | 'communication-limits' | 'team-based' | 'hidden-roles';
export type RulesLang = 'zh' | 'en' | 'de' | 'fr' | 'es' | 'it' | 'ru' | 'ja';
export interface GameMeta {
    /** Minimum compatible SDK API revision; omitted for the original public API. */
    sdkApi?: number;
    id: string;
    mechanics: GameMechanic[];
    interactionTags: GameInteractionTag[];
    nameKey: I18nKey;
    descKey: I18nKey;
    rulesKey: I18nKey;
    icon: string;
    iconImg?: string;
    rulesUrl?: Partial<Record<RulesLang, string>>;
    minPlayers: number;
    maxPlayers: number;
    bestPlayers?: number[];
    playerRange?: (config: unknown) => {
        min: number;
        max: number;
    };
    accent: string;
    releasedAt: string;
    tier: 'released' | 'beta' | 'alpha' | 'dev';
    search: {
        py: string;
        init: string;
    };
    hotseat: 'open' | 'cover' | 'off';
    /** 机器人算出动作后的节奏停顿；缺省沿用调度器默认值。 */
    botDelayMs?: number;
    precacheAssets?: string[];
}
export interface GameSchemas<A, PUB, PRIV, C = unknown> {
    action: ZodType<A>;
    publicView: ZodType<PUB>;
    privateView: ZodType<PRIV>;
    /** 开局选项的形状:有则 createGameSession 先卡再喂 setup(失败落默认值);
     * 约定必须能 parse(undefined) 出全默认——大堂未配置/恢复旧档都靠它兜底 */
    config?: ZodType<C>;
}
export interface GameError {
    code: I18nKey;
    params?: I18nVars;
}
export interface StateWithFx<S> {
    state: S;
    fx?: FxEntry[];
}
export interface ReduceCtx {
    by: PlayerId;
}
export interface PlayerView<PUB, PRIV> {
    public: PUB;
    private?: PRIV;
}
export interface GameStatus {
    phase: string;
    winner?: PlayerId[];
    /** 终局全体排名,优→劣;与 winner 同时提供才触发通用结算段 */
    ranking?: PlayerId[];
    scores?: Record<PlayerId, number>;
}
export interface GameResult {
    winner: PlayerId[];
    ranking: PlayerId[];
    scores?: Record<PlayerId, number>;
    /** 托管占比(2026-09-18):rid → 该玩家动作中 bot 代打的比例(0-1),只含 >0 的座位;由 action log 的 auto 标记推导 */
    autopilot?: Record<PlayerId, number>;
}
export interface SaveCompatibility {
    version: string;
    compatibleWith?: readonly string[];
    /** Convert a copy of the original log; null explicitly declines this saved game. */
    migrate?(saved: {
        version?: string;
        log: unknown[];
    }): unknown[] | null | Promise<unknown[] | null>;
}
export interface GameDefinition<S, A, PUB, PRIV = PUB, C = unknown> {
    meta: GameMeta;
    saveCompatibility?: SaveCompatibility;
    schemas: GameSchemas<A, PUB, PRIV, C>;
    setup(config: C, players: PlayerId[], seed: number): StateWithFx<S>;
    reduce(state: S, action: A, ctx: ReduceCtx): StateWithFx<S> | GameError;
    viewFor(state: S, who: PlayerId): PlayerView<PUB, PRIV>;
    /** bot 专用视图(主机侧哑客户端,不出主机):可携带不进传输的全量数据(如完整 log)。
     * 缺省回落 viewFor;实现它 = 声明 bot 需要比出网视图更多的信息 */
    viewForBot?(state: S, who: PlayerId): PlayerView<PUB, PRIV>;
    status(state: S): GameStatus;
    /** 主机节拍(docs/FX.md §6):返回距下一次 dispatchTick 的 ms;null/缺省 = 不需要节拍。
     * 快照逐步推进的游戏(nimmt 结算)用它把节奏收在主机手里;纯函数,主机每次 onChange 后查询。
     * now = 调用时刻(主机墙钟),限时类游戏用它算剩余;不需要的忽略即可 */
    nextTickIn?(state: S, now: number): number | null;
}
export interface TickAction {
    type: 'tick';
    now: number;
}
export type BotDifficulty = 'weak' | 'normal';
export interface BotCtx {
    /** 自己的座位身份(view 不携带 who,与 UI 侧 myRid 同理) */
    rid: PlayerId;
    difficulty: BotDifficulty;
    /** 跨招记忆,由 driver 按座位保管回传,bot 本体无状态;暂没游戏用到,契约预留 */
    memory: unknown;
    /** 取消信号:async think(LLM)应把它透传给 fetch;driver 在 dispose/换局时中断在途请求 */
    signal?: AbortSignal;
}
export interface BotMove<A> {
    action: A;
    memory?: unknown;
}
/** 返回 null = 本拍无需行动(没轮到我/无事可做);返回 Promise = 异步思考(LLM bot),driver 挂起到 settle */
export type BotThink<PUB, PRIV, A> = (view: PlayerView<PUB, PRIV>, ctx: BotCtx) => BotMove<A> | null | Promise<BotMove<A> | null>;
export type HintT = (key: I18nKey, vars?: I18nVars) => string;
/** 把 bot 算出的 action 翻译成一句给玩家看的话;view = 发起者当时的两段视图(目标行/牌面等从 view 取) */
export type BotDescribe<PUB, PRIV, A> = (action: A, view: PlayerView<PUB, PRIV>, t: HintT) => string;
export interface SetupLogEntry<C = unknown> {
    type: '$setup';
    saveVersion?: string;
    config: C;
    players: PlayerId[];
    seed: number;
}
export interface ActionLogEntry<A = unknown> {
    by: PlayerId | '$engine';
    action: A;
}
