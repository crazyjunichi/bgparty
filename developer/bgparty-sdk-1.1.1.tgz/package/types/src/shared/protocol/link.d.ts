export declare const JOIN_ROUTE = "/join";
export declare const ROOM_ID_LENGTH = 12;
export declare const ROOM_KEY_LENGTH = 16;
export interface JoinLinkPayload {
    room: string;
    key: string;
    v: number;
    /** 'qr' = 无网扫码配对(qr-manual,transport/qr-signaling);缺省走 relay */
    sig?: 'qr';
}
export declare function encodeJoinLink(payload: JoinLinkPayload): string;
export declare function absoluteJoinLink(payload: JoinLinkPayload): string;
export declare function decodeJoinLink(search: string): JoinLinkPayload | null;
