import { type ReactNode } from 'react';
import type { SheetRect } from './sheet-geometry';
/** 连锁变化焦点:key 变化时若 rect 不在视口内则平滑平移过去(用户任何手势立即打断) */
export interface SheetFocus {
    rect: SheetRect;
    key: number;
    /** 划线模式:fire 时刻 +该毫秒数回弹到链首视口(与闪烁结束对齐);缺省 = 平移后停留 */
    returnAfterMs?: number;
}
/** 合法格:世界坐标 rect + 稳定 key(命中回传用) */
export interface EligibleCell {
    key: string;
    rect: SheetRect;
}
/** 格内写字原语(填数类纸笔游戏用):居中、字号随格高、白色描边垫底,彩色底图上保可读 */
export declare function SheetText({ r, text }: {
    r: SheetRect;
    text: string;
}): ReactNode;
/** 计分表 SVG 格子的 fx 锚点桥:probe 播放时现量(元素坐标随 pan/zoom 变,缓存会错) */
export declare function SheetFxProbe({ name, r }: {
    name: string;
    r: SheetRect;
}): ReactNode;
export declare function SheetView({ image, sheetW, sheetH, eligible, onTapEligible, readOnly, fitKey, clampToSheet, focus, highlight, children, }: {
    /** 底图 href(相对 base,如 'games/qwixx/sheet.webp');缺省 = 底图全由 children 程序生成(bravo) */
    image?: string;
    /** 虚拟空间尺寸,与 sheet-layout.ts 标注一致 */
    sheetW: number;
    sheetH: number;
    /** 合法格(交互模式);空/缺省 = 只读 */
    eligible?: readonly EligibleCell[];
    onTapEligible?: (key: string) => void;
    readOnly?: boolean;
    /** 变更时重新 fit(如「回全景」/切换偷看对象) */
    fitKey: string;
    /** 将平移限制在纸面内;默认关闭,避免改变现有游戏的手势行为 */
    clampToSheet?: boolean;
    /** 连锁变化焦点:key 变化时平移过去(细节见 SheetFocus) */
    focus?: SheetFocus | null;
    /** 合法格高亮形态:outer(默认,外扩压印刷线)/ inset(收进格内沿,密集小格防相邻互叠)/ off(只命中不高亮——全盘皆可点时白框闪屏无信息量) */
    highlight?: 'outer' | 'inset' | 'off';
    /** 游戏自家叠层,画在世界坐标系内(合法格高亮之下) */
    children?: ReactNode;
}): ReactNode;
