/** 轮到我了:可切换提示音。入口在首页设置弹层,持久化于 bgparty:sfx */
export type TurnSoundId = 'soft' | 'wood' | 'pop' | 'chime';
interface SfxSettings {
    turn: TurnSoundId;
    muted: boolean;
    setTurn: (turn: TurnSoundId) => void;
    setMuted: (muted: boolean) => void;
}
export declare const useSfxSettings: import("zustand").UseBoundStore<Omit<import("zustand").StoreApi<SfxSettings>, "setState" | "persist"> & {
    setState(partial: SfxSettings | Partial<SfxSettings> | ((state: SfxSettings) => SfxSettings | Partial<SfxSettings>), replace?: false | undefined): unknown;
    setState(state: SfxSettings | ((state: SfxSettings) => SfxSettings), replace: true): unknown;
    persist: {
        setOptions: (options: Partial<import("zustand/middleware").PersistOptions<SfxSettings, SfxSettings, unknown>>) => void;
        clearStorage: () => void;
        rehydrate: () => Promise<void> | void;
        hasHydrated: () => boolean;
        onHydrate: (fn: (state: SfxSettings) => void) => () => void;
        onFinishHydration: (fn: (state: SfxSettings) => void) => () => void;
        getOptions: () => Partial<import("zustand/middleware").PersistOptions<SfxSettings, SfxSettings, unknown>>;
    };
}>;
/** 试听指定提示音(设置弹层用),不影响当前选择 */
export declare function previewTurn(id: TurnSoundId): void;
export declare function playTurn(): void;
/** 进入结算:两声脆响快速上行 */
export declare function playSettle(): void;
/** 游戏结束:三声上行钟,终止感 */
export declare function playGameOver(): void;
/** durian 摇铃:双击铃响(叮-叮),实铃的单手摇感 */
export declare function playBell(): void;
/** 提示音边沿触发:cond 由假变真时响一次。给渲染层组件用(PhaseBanner/终局接管分支),避免在 render 里直接发音 */
export declare function useSoundEdge(cond: boolean, play: () => void): void;
export {};
