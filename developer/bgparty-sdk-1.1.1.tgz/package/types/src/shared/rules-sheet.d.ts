import type { ComponentType, ReactNode } from 'react';
import type { GameMeta } from './protocol';
type RulesUrl = NonNullable<GameMeta['rulesUrl']>;
/** 行内图标组件契约:游戏登记进 games/views.ts 的 RULE_ICON_LOADERS;
 *  size 由 RulesBody 给(跟随正文字号),SVG 内部按 viewBox 等比缩放即可 */
export type RuleIcon = ComponentType<{
    size?: number;
}>;
/** 游戏规则说明弹层(FLOWS §3.2 ⓘ 入口):纯展示,文案来自游戏 meta.rulesKey。
 *  游戏有补充图解(棋子行为/混色表等)时经 GUIDE_LOADERS 登记,从 children 槽插入。
 *  常驻挂载:关闭时调用方只翻 open,内容 props 保留到下次打开覆盖(退场动画防闪空) */
export declare function RulesSheet({ open, icon, name, rules, ruleIcons, rulesUrl, children, onClose, }: {
    open: boolean;
    icon: ReactNode;
    name: string;
    rules: string;
    ruleIcons?: Record<string, RuleIcon>;
    rulesUrl?: RulesUrl;
    children?: ReactNode;
    onClose: () => void;
}): import("react").JSX.Element;
export {};
