export type TextureKind = 'sheen' | 'dots' | 'hatch' | 'diamond';
export declare function Texture({ kind, base, line, className }: {
    kind: TextureKind;
    base: string;
    line?: string;
    className?: string;
}): import("react").JSX.Element;
