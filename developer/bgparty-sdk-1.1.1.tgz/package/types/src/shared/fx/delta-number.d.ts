/**
 * 数值滚动(docs/FX.md §1):增减是唯一走 diff 的动画——Δ 即前后差值,多步合并滚动反而自然。
 * reduced-motion 直跳终值。
 */
export declare function DeltaNumber({ value, className }: {
    value: number;
    className?: string;
}): import("react").JSX.Element;
