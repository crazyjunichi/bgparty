import { type ReactNode } from 'react';
import type { FxEntry } from '../protocol';
import { type AnchorBox } from './anchors';
/** 一个 fx 条目的演出:node 挂 overlay;hide = 演出期间自隐的锚点(落点抑制,docs/FX.md §6) */
export interface FxScene {
    ms: number;
    node: ReactNode;
    hide?: string[];
}
/** renderer 需要的座位信息(主人色描边/头像小标);结构子集,LobbyMemberView 可直接传入 */
export interface FxMember {
    rid: string;
    name: string;
    colorIndex: number;
    avatar: number;
}
export interface FxRenderCtx {
    /** 播放时现量;null = 锚点已不存在,renderer 应返回 null 静默跳过 */
    anchor(name: string): AnchorBox | null;
    /** 按 rid 查座位;未传 members 时恒 undefined */
    member(rid: string): FxMember | undefined;
    myRid: string;
    /** 本场开播时队列里还压着的条目数;>0 = 快照已跑在演出前面(连点/bot 快进,或本场是
     * 等上一幕播完才开播的迟到场),renderer 应缩短时长追赶并放弃落点抑制——真身早已落地,
     * 回藏会读作「牌消失又重飞」 */
    queued: number;
}
/** renderer 是纯编排:读 fx 负载 + 锚点,返回场景;不做副作用(震动/音效例外,见 docs/FX.md §7) */
export type FxRenderer = (fx: FxEntry, ctx: FxRenderCtx) => FxScene | null;
export type FxRenderers = Record<string, FxRenderer>;
export declare const FxFrameContext: import("react").Context<{
    fx: readonly FxEntry[];
    resetKey: unknown;
}>;
/**
 * 对局演出舞台:包在游戏视图外,提供锚点坐标系 + overlay 播放器。
 * fx 是「到达批次」的只增队列(父组件 append,resetKey 变化时清空),本组件按引用切片消费;
 * resetKey 建议用会话身份(主机:liveGame;玩家:连接 epoch)——重连/换局 = 清队直呈终态。
 */
export declare function FxStage({ renderers, fx, resetKey, myRid, members, children, }: {
    renderers?: FxRenderers;
    /** 只增批次队列;resetKey 变化时父组件应同时清空 */
    fx: readonly FxEntry[];
    resetKey: unknown;
    myRid: string;
    /** 座位名单(可选):renderer 经 ctx.member 取主人色/头像 */
    members?: readonly FxMember[];
    children: ReactNode;
}): import("react").JSX.Element;
