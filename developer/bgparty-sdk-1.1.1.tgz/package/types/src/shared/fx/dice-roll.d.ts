import { type ReactNode } from 'react';
import type { FxRenderer } from './stage';
export { DICE_ROLL_MS } from './dice-roll-ms';
/**
 * 共享掷骰 fx renderer(docs/FX.md §8 骰子行)。
 *
 * fx 契约:`{ kind: 'diceRoll', rid: 掷骰者, data: { dice, banner?, target? } }`
 * - dice: unknown[] — 原始结果项;默认按 d6 点数(1-6)解释,异构骰(大小/颜色)由工厂 parse 归一化
 * - banner: true — 全员焦点掷骰:屏幕中央横幅(头像+名字+3D 翻滚),定格后飞向落点
 * - target: 落点锚点名,缺省 'dice';锚点缺失 → banner 原地淡出 / 就地模式整场跳过
 * - 面内容不进 fx(JsonValue 跨网):异面骰在工厂静态传 faces,与 slotOf 配套
 *
 * 交接是 trick 不是无缝变形(拍板):立方体定格时已是正面朝向,此刻换成同位 2D 面精灵
 * 飞向落点,真身靠 hide 落点抑制在抵达后显形。
 *
 * 节奏常量 DICE_ROLL_MS 在 dice-roll-ms.ts(纯模块,rules 的节拍常量从那里取,同源)。
 */
/** 归一化后的单颗骰:value = 结果值(经 slotOf 映射槽位),scale = 尺寸倍率(默认 1) */
export interface DiceSpec {
    value: number;
    scale?: number;
}
/** fx data.dice 原始项 → DiceSpec;返回 null = 该项无法解释(整场跳过) */
export type DiceParse = (raw: unknown) => DiceSpec | null;
/** 创建 'diceRoll' renderer;异面骰传 faces(槽位序 正/背/右/左/顶/底)+ slotOf(结果值→槽位),
 *  异构骰(大小等)传 parse,tintByPlayer = 骰面染掷骰者的玩家色(如 lasvegas-royale) */
export declare function createDiceRollRenderer(opts?: {
    faces?: ReactNode[];
    slotOf?: (value: number) => number;
    parse?: DiceParse;
    tintByPlayer?: boolean;
}): FxRenderer;
