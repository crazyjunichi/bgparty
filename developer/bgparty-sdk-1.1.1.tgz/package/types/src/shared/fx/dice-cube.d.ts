import { type ReactNode } from 'react';
/** d6 点数 → 槽位下标(对面和为 7:正 1 背 6、右 3 左 4、顶 2 底 5) */
export declare const D6_SLOT: Record<number, number>;
/** 面壳样式:立方体面与 2D 飞行精灵(dice-roll)共用,定格→交接视觉必须一致 */
export declare const DICE_FACE_CLASS = "overflow-hidden rounded-[16%] border-3 border-ink bg-surface";
/** 取某槽位的 2D 面内容(飞行精灵/压扁交接用,与立方体共用同一份面);tinted = 染底版(白点) */
export declare function diceFaceContent(face: number, faces?: ReactNode[], tinted?: boolean): ReactNode;
export declare function DiceCube({ face, faces, faceBg, size, ms, delay, }: {
    /** 定格后朝向观察者的面 = faces 下标;d6 用 D6_SLOT[点数] */
    face: number;
    /** 6 面内容,槽位顺序 正/背/右/左/顶/底;缺省 d6 点阵(faceBg 染色时自动换白点版) */
    faces?: ReactNode[];
    /** 面底色(玩家染色);缺省 surface 白底 */
    faceBg?: string;
    size?: number;
    /** 翻滚总时长(含落地弹跳) */
    ms?: number;
    delay?: number;
}): import("react").JSX.Element;
