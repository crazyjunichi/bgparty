import { type ReactNode } from 'react';
import type { AnchorBox } from './anchors';
/**
 * fx 精灵原语(docs/FX.md §5):纯 WAAPI,无 rAF 循环。全部是 overlay 里的绝对定位元素,
 * 坐标系 = FxStage 容器(anchors.tsx)。delay 用于场景内编排(收行先落牌再飞走)。
 */
/** 飞行:from → to,中段轻微上挑出弧线;起止框与内容不等大时平滑缩放(等比则不缩放) */
export declare function FlySprite({ from, to, ms, delay, children }: {
    from: AnchorBox;
    to: AnchorBox;
    ms: number;
    delay?: number;
    children: ReactNode;
}): import("react").JSX.Element;
/** 浮字:在锚点上方浮现、上飘、淡出(+8 🐮 这类) */
export declare function Floater({ at, ms, delay, children }: {
    at: AnchorBox;
    ms: number;
    delay?: number;
    children: ReactNode;
}): import("react").JSX.Element;
/** 满屏色闪:爆掉/坍塌这类全场事件的背景闪(精灵层内,不遮挡交互) */
export declare function Flash({ ms, className }: {
    ms: number;
    className?: string;
}): import("react").JSX.Element;
/** 呼吸框:在锚点上连续脉动两拍(「等这个人操作」的注意引导)。
 *  振幅固定约 4px 外扩——大框按同一比例缩会抖成残影;首尾透明度归零,全程无跳变 */
export declare function PulseBox({ at, ms, delay }: {
    at: AnchorBox;
    ms: number;
    delay?: number;
}): import("react").JSX.Element;
