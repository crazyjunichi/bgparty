import { type ReactNode, type RefCallback } from 'react';
/** 相对 FxStage 容器的盒子:renderer 与精灵都摆在这个坐标系里 */
export interface AnchorBox {
    x: number;
    y: number;
    w: number;
    h: number;
}
interface AnchorsValue {
    register(name: string, el: HTMLElement | null): void;
    /** 3D 场景等非 DOM 锚点:播放时调 probe 现量,契约与元素锚点一致;同名片后注册生效 */
    registerProbe(name: string, probe: (() => AnchorBox | null) | null): void;
    /** 播放时现量,不缓存:手牌横滚后注册时的坐标已失效;元素已卸载返回 null = 该条目静默跳过 */
    measure(name: string): AnchorBox | null;
    setBusy(name: string, on: boolean): void;
    isBusy(name: string): boolean;
}
/** 对局页容器:建立锚点坐标系(relative)并托管 busy 状态。无 Provider 时 useFxAnchor 退化为无操作 */
export declare function FxAnchorsProvider({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
/** FxOverlay 内部用:取注册表(必须在 Provider 下) */
export declare function useFxAnchors(): AnchorsValue;
/** 3D 场景等非 DOM 侧用:取注册表,无 Provider 时返回 null(调用方退化为不注册) */
export declare function useFxAnchorsMaybe(): AnchorsValue | null;
/** 给可动元素标锚点(docs/FX.md §5);hidden = 落点抑制中,元素自隐但保留布局。
 * name 传 null = 不注册(通用组件按可选锚点用)。无 Provider(如 lab 单独渲染)时退化为无操作 ref + 永不隐藏 */
export declare function useFxAnchor<T extends HTMLElement>(name: string | null): {
    ref: RefCallback<T>;
    hidden: boolean;
};
export {};
