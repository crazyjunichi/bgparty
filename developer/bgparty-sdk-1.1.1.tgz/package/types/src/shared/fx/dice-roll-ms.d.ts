/**
 * 共享掷骰演出的节奏常量(dice-roll.tsx 的场景时长真源)。
 * 独立成纯模块:rules.ts 的节拍常量(nextTickIn)必须与场景时长同源,
 * 而 rules 不许引 React——只能引这个无依赖的文件。
 */
export declare const DICE_ROLL_MS: {
    /** 多颗骰的错峰间隔 */
    stagger: number;
    /** 3D 翻滚(含落地弹跳) */
    tumble: number;
    /** 定格后展示 */
    hold: number;
    /** 飞向落点锚点 */
    fly: number;
    /** banner 模式整场时长(颗数) */
    banner: (n: number) => number;
    /** 就地模式整场时长(颗数) */
    inplace: (n: number) => number;
};
