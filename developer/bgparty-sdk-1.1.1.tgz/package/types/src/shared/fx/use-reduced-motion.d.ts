/** UI.md 动效基线:reduced-motion 下 fx 播放器整体跳过、DeltaNumber 直跳终值 */
export declare function usePrefersReducedMotion(): boolean;
