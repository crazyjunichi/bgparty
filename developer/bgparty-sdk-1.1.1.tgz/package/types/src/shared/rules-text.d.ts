export declare const RULE_ICON_RE: RegExp;
/** 剥掉占位符:有回退文字留回退文字,没有则删整个 token */
export declare function stripRuleIcons(text: string): string;
