import { type ReactNode } from 'react';
interface ConfirmButtonProps {
    label: ReactNode;
    confirmLabel: string;
    onConfirm: () => void;
    className?: string;
    compact?: boolean;
    ariaLabel?: string;
}
export declare function ConfirmButton({ label, confirmLabel, onConfirm, className, compact, ariaLabel }: ConfirmButtonProps): import("react").JSX.Element;
export {};
