import type { ReactNode } from 'react';
/**
 * 页面骨架三段式(FLOWS §5):顶条(可选)/ 内容区 / 底部动作条。
 * - 内容区 flex-1 min-h-0;scroll 控制是否页面级滚动(对局页/Join 不传)
 * - 底条贴 safe-b;条内顺序约定:次级/危险在上,主操作贴底(由调用方按序排)
 * - safe-b 只在一处:有底条归底条,没底条归外壳
 */
export declare function PageShell({ top, actions, scroll, children, className, }: {
    top?: ReactNode;
    actions?: ReactNode;
    scroll?: boolean;
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;
