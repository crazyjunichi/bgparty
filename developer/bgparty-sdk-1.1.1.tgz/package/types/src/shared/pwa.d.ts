/** 更新管线阶段:仅驱动状态行/进度条展示,不参与换版逻辑 */
export type PwaCheckStage = 'idle' | 'checking' | 'downloading' | 'uptodate' | 'failed';
interface PwaState {
    needRefresh: boolean;
    /** 检测/下载阶段;后台轮询不置 checking(避免状态行周期性闪烁),只有手动检查才置 */
    stage: PwaCheckStage;
    /** 下载进度(本次实际需下载的文件数口径,未变更文件不计入);无计数能力或不在下载中为 null */
    progress: {
        done: number;
        total: number;
    } | null;
    /** 当前是否在对局中(host/join 页维护,含终局屏):全局更新 toast 据此回避对局 */
    inGame: boolean;
    /** 捕获的 beforeinstallprompt(已 preventDefault);为 null 表示浏览器没给或已安装 */
    installPrompt: InstallPromptEvent | null;
    /** 确认更新:新 SW 接管并刷新页面(只在首页暴露入口) */
    applyUpdate: () => void;
    /** 手动检查更新(首页状态行入口);注册完成前为空操作 */
    checkNow: () => void;
}
export interface InstallPromptEvent extends Event {
    prompt: () => void;
    userChoice: Promise<{
        outcome: 'accepted' | 'dismissed';
    }>;
}
export declare const usePwaUpdate: import("zustand").UseBoundStore<import("zustand").StoreApi<PwaState>>;
export declare function setPwaInGame(on: boolean): void;
export declare function isStandalone(): boolean;
export declare function isIos(): boolean;
export declare function initPwa(): void;
export declare function waitForOfflineReady(): Promise<void>;
export {};
