/** 变换后的形状格偏移:flip 先左右翻面,再顺时针旋转 rot 次 90°(官方 FAQ 允许翻面) */
export declare function cellsOf(shape: number[][], rot: number, flip: boolean): [number, number][];
