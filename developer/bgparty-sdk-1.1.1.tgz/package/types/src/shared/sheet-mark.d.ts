import type { ReactNode } from 'react';
import type { MarkStyle, SheetRect } from './sheet-geometry';
interface SheetMarkProps {
    mark: MarkStyle;
    rect: SheetRect;
    /** 缺省墨色(笔迹);语义色场景显式传 */
    color?: string;
    /** 缺省 min(w,h)×0.14(随格大小缩放,预览与游戏一致);特殊取值显式传(如 qwixx 固定 10) */
    strokeWidth?: number;
    /** 格内四向内缩比例,默认 0.2;负值 = 外扩(圈住图形用) */
    inset?: number;
}
export declare function SheetMark({ mark, rect, color, strokeWidth, inset }: SheetMarkProps): ReactNode;
export {};
