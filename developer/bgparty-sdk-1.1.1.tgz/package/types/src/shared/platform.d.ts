import type { ComponentProps, ReactNode } from 'react';
import { PageShell } from './page-shell';
import './platform.css';
export type PlatformScene = 'home' | 'online' | 'offline' | 'hotseat' | 'join';
export declare function PartyBrand({ className }: {
    className?: string;
}): import("react").JSX.Element;
export declare function PlatformShell({ scene, ...props }: ComponentProps<typeof PageShell> & {
    scene?: PlatformScene;
}): import("react").JSX.Element;
export declare function PlatformHeader({ scene, title, close, onBack }: {
    scene?: PlatformScene;
    title?: string;
    close?: ReactNode;
    onBack?: () => void;
}): import("react").JSX.Element;
