import { type InstalledGame, type GameData } from './storage';
export declare function migrateLegacyGameStorage(game: InstalledGame): Promise<GameData>;
