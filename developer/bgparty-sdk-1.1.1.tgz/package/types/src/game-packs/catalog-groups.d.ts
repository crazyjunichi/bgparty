export declare function defaultCatalogGames<T extends {
    metadata: {
        id: string;
    };
    source: string;
}>(games: T[], sources: string[], subscribed?: string[]): T[];
