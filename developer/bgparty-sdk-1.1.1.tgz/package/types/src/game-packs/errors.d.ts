export declare function gamePackErrorKey(error: unknown): 'packs.updateRequired' | 'packs.unavailable' | 'packs.loadFailed';
