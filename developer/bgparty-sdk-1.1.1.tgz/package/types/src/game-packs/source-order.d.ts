export declare function orderSources<T extends {
    url: string;
}>(sources: T[]): T[];
export declare function rememberSourceOrder(sources: {
    url: string;
}[]): void;
export declare function moveSource(url: string, offset: -1 | 1, sources: {
    url: string;
}[]): void;
