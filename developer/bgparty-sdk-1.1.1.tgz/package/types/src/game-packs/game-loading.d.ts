import { type ReactNode } from 'react';
import { type I18nKey } from '../shared/i18n';
import { type GameDownloadJob } from './download-progress';
import './game-loading.css';
export declare function GameDownloadProgress({ job, compact }: {
    job: GameDownloadJob;
    compact?: boolean;
}): import("react").JSX.Element;
export declare function GameLoadingScreen({ gameId, job, statusKey, error, detail, actions, onClose, overlay }: {
    gameId: string | null | undefined;
    job?: GameDownloadJob | null;
    statusKey?: I18nKey;
    error?: string | null;
    detail?: string;
    actions?: ReactNode;
    onClose?: () => void;
    overlay?: boolean;
}): import("react").JSX.Element;
export declare function GameLoadingInline({ statusKey, failed, onRetry }: {
    statusKey?: I18nKey;
    failed?: boolean;
    onRetry?: () => void;
}): import("react").JSX.Element;
