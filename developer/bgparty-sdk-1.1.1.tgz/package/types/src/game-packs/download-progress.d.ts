export type GameDownloadPhase = 'checkingUpdates' | 'checkingFiles' | 'downloading' | 'saving';
export interface GameDownloadJob {
    id: string;
    phase: GameDownloadPhase;
    bytes: number;
    total: number | null;
}
export type GameDownloadListener = (job: GameDownloadJob) => void;
export declare const usePackDownloads: import("zustand").UseBoundStore<import("zustand").StoreApi<{
    jobs: Record<string, GameDownloadJob>;
    foreground: Record<string, number>;
}>>;
export declare function beginGameDownload(id: string, phase?: GameDownloadPhase, onProgress?: GameDownloadListener): {
    report(phase: GameDownloadPhase, bytes: number, total: number | null): void;
    finish(): void;
};
export declare function gameDownloadJob(jobs: Record<string, GameDownloadJob>, id: string | null | undefined): GameDownloadJob | undefined;
export declare function claimGameDownload(id: string): () => void;
