import { type GameMetadata, type PackReference, type RuntimeReference } from './format';
import { type InstalledGame } from './storage';
export { withPackStorageLock } from './storage';
import { type GameDownloadListener } from './download-progress';
export { usePackDownloads } from './download-progress';
export { officialSource } from './config';
export interface CatalogGame {
    id: string;
    identity: string;
    source: string;
    sourceName: string;
    metadata: GameMetadata;
    release: PackReference;
}
export declare const usePackCatalog: import("zustand").UseBoundStore<import("zustand").StoreApi<{
    revision: number;
    games: CatalogGame[];
    defaultGames: CatalogGame[];
    sources: string[];
    error: boolean;
}>>;
export declare function reloadCatalog(): Promise<void>;
export declare function initializeCatalog(): Promise<void>;
export declare function refreshCatalog(force?: boolean): Promise<void>;
export declare function catalogGame(id: string): CatalogGame | undefined;
export declare function catalogVariants(id: string): CatalogGame[];
export declare function defaultCatalogGame(id: string): CatalogGame | undefined;
export declare function gameInstallationAvailable(): boolean;
export declare function ensureGameInstalled(id: string, onProgress?: (bytes: number) => void, allowFallback?: boolean, onStatus?: GameDownloadListener): Promise<InstalledGame>;
export declare function downloadCatalogGame(id: string): Promise<InstalledGame>;
export declare function prepareNewGame(id: string, requireOnline?: boolean, onStatus?: GameDownloadListener): Promise<InstalledGame>;
export declare function ensureRuntimeInstalled(input: RuntimeReference, onStatus?: GameDownloadListener): Promise<InstalledGame>;
