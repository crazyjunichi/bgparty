export declare function migrateOfficialSources(): Promise<void>;
