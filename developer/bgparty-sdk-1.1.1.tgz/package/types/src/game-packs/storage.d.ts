import type { PackManifest, PackReference, SourceCatalog } from './format';
export interface GameSource {
    url: string;
    name: string;
    catalog: SourceCatalog;
    checkedAt: number;
    subscribed?: boolean;
}
export interface InstalledPack {
    hash: string;
    manifest: PackManifest;
    source: string;
    installedAt: number;
    reference?: PackReference;
}
export interface InstalledGame {
    identity: string;
    source: string;
    gameId: string;
    release: PackReference;
    sdkHash: string;
    sdkReference?: PackReference;
    storage: Record<string, string>;
}
export interface GameData {
    identity: string;
    source: string;
    gameId: string;
    revision: number;
    values: Record<string, string>;
    clearedAtRevision?: number;
    legacyImported?: boolean;
}
interface Tables {
    sources: GameSource;
    packs: InstalledPack;
    games: InstalledGame;
    data: GameData;
}
export declare function withPackStorageLock<T>(run: () => Promise<T>): Promise<T>;
export declare function readRows<K extends keyof Tables>(table: K): Promise<Tables[K][]>;
export declare function readRow<K extends keyof Tables>(table: K, key: string): Promise<Tables[K] | undefined>;
export declare function writeRow<K extends keyof Tables>(table: K, value: Tables[K]): Promise<void>;
export declare function deleteRow(table: keyof Tables, key: string): Promise<void>;
export declare function migrateCatalogStorage(transform: (sources: GameSource[], games: InstalledGame[], data: GameData[]) => {
    sources: GameSource[];
    games: InstalledGame[];
    data: GameData[];
}): Promise<void>;
export {};
