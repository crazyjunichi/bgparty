export declare function randomAt(seed: number, cursor: number): number;
/** [0, n) 整数:抽牌/洗牌下标用 */
export declare function randomIntAt(seed: number, cursor: number, n: number): number;
