import type { GameHandle } from '../lobby/host-lobby';
import type { GameDefinition, GameError } from '../shared/protocol';
export type AnyDef = GameDefinition<any, any, any, any, any>;
export declare const TICK_SENDER = "$engine";
export interface GameSession extends GameHandle {
    /** 实时游戏的时钟唯一入口:喂 {type:'tick', now} 进 reduce 与 log;调频归调用方,engine 不内置定时器 */
    dispatchTick(now: number): void;
    /** 当前 state 只读引用(主机节拍器喂 nextTickIn 用);别在热路径用 debugDump,那是全量 dump */
    peekState(): unknown;
    /** dev 重放验证用(docs/ENGINE.md §6) */
    debugDump(): {
        version: number;
        log: unknown[];
        state: unknown;
    };
}
export interface LocalGameSession extends GameSession {
    handleAction(rid: string, data: unknown, opts?: {
        auto?: boolean;
    }): GameError | null;
}
/**
 * 对局会话(docs/ENGINE.md):收动作 → zod 卡形状 → reduce → 版本+1 → onChange 通知重推。
 * 非法动作分层(§5):schema 不过 / 非本局 rid 静默丢;GameError 返回给 lobby 回 {ok:false}。
 * (rid,seq) 幂等与 hello 水位由 transport 兜住,这里不重复做。
 * fx(docs/FX.md §4):reduce/setup 的演出提示,累积进 pendingFx,由 lobby 推送时 takeFx 取走并
 * 按接收者裁剪;engine 不解释不透明。恢复路径重放时逐条 drain 丢弃——历史不重演。
 */
export declare function createGameSession(opts: {
    def: AnyDef;
    players: string[];
    onChange(): void;
    /** 恢复路径用原 seed 重建;缺省由 crypto 生成(新开一局) */
    seed?: number;
    /** 开局选项(大堂配置/恢复档的 $setup.config);缺省或形状坏 → configSchema.parse(undefined) 的默认值 */
    config?: unknown;
}): LocalGameSession;
/**
 * 对局恢复(2026-09-07 拍板):主机刷新/杀进程后从持久化的 action log replay 重建会话。
 * players/seed 取 log 的 $setup 快照,与 lobby 当前座位解耦(进出不进 log,§1)。
 * 恢复即重放,顺带实战检验 reduce 纯函数承诺。任何一步失败(log 损坏/规则升级/schema 拒收)
 * 返回 null 时调用方保留原始记录，不把部分重放当成恢复成功。
 * fx 压制(docs/FX.md §4):重放每步 drain 丢弃,历史不重演。
 */
export declare function restoreGameSession(opts: {
    def: AnyDef;
    log: unknown[];
    onChange(): void;
}): LocalGameSession | null;
