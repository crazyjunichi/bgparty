import type { GameHandle } from '../lobby/host-lobby';
import type { BotDifficulty, BotThink } from '../shared/protocol';
export type AnyBotThink = BotThink<any, any, any>;
export interface BotSeat {
    rid: string;
    difficulty: BotDifficulty;
    /** 每座位独立 think(LLM bot 用);缺省用 driver 级 think(规则 bot) */
    think?: AnyBotThink;
}
export interface BotDriver {
    /** state 每次变化后由装配方(onChange)调用:为有待行动作且未排程的 bot 排程 */
    poke(): void;
    /** 托管座位动态增删(2026-09-18,局内随时开关):只影响 auto 座位,建 driver 时的 bot 座位不受影响;
     * 已在列的托管座位保留 memory;调用方负责随后 poke 让新托管座位立刻接拍 */
    setAutopilot(seats: BotSeat[]): void;
    dispose(): void;
}
/**
 * 机器人调度器:bot 是主机侧的哑客户端,只认 GameHandle 接缝(viewFor/handleAction),
 * 不认识 lobby/transport;think 由装配方按游戏/座位注入,driver 不知道自己在玩什么。
 * 延迟固定一拍(像人又不拖);setTimeout 排程天然串行,不产生递归。
 * think 允许返回 Promise(LLM bot):pending 从发起思考起挂到 settle,期间 poke 不重复排程;
 * dispose 经 AbortSignal 中断在途请求,晚到的结果直接丢弃。
 * 已知边界:只在 poke(状态变化)时思考——实时(tick)游戏需要主动节拍的 bot,契约暂不支持。
 */
export declare function createBotDriver(opts: {
    handle: GameHandle;
    think: AnyBotThink;
    bots: BotSeat[];
    /** 拍与拍之间的固定延迟,默认 800ms */
    delayMs?: number;
}): BotDriver;
