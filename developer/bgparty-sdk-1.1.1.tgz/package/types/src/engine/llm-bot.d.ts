import type { AnyBotThink } from './bot-driver';
import type { BotCtx, PlayerView } from '../shared/protocol';
/**
 * 游戏侧登记的 LLM bot 规格(games/<id>/llm-bot.ts):
 * 把裁剪后视图讲给模型听、告诉它 action 长什么样、验它交回来的答案。
 * 与规则 bot 同一契约,只多这三件;view 已过 viewFor 裁剪,不会泄露秘密。
 */
export interface LlmBotSpec<PUB, PRIV, A> {
    /** 视图 → 自然语言局面描述(给模型的 user 消息主体) */
    describeView(view: PlayerView<PUB, PRIV>, ctx: BotCtx): string | Promise<string>;
    /** action 的 JSON Schema(手写,塞进 prompt 约束输出形状;试点期不引 zod-to-json-schema) */
    actionJsonSchema: Record<string, unknown>;
    /** 模型输出 → action;非法返回 null(触发重试/回落)。注意要拒绝 tick 等引擎注入类 action;
     * 给视图与座位身份是为了能预检规则合法性(如 azul 的行/色约束),把非法出招拦在提交前 */
    parseAction(raw: unknown, view: PlayerView<PUB, PRIV>, ctx: BotCtx): A | null | Promise<A | null>;
    /** 零成本预判「这拍要不要我行动」:false 直接 return null,不发请求。
     * 强烈建议实现——driver 每次状态变化都 poke(含 tick 节拍与他人回合),没有它每拍都白烧一次 API */
    needsAction?(view: PlayerView<PUB, PRIV>, ctx: BotCtx): boolean | Promise<boolean>;
}
export type AnyLlmBotSpec = LlmBotSpec<any, any, any>;
/**
 * LLM bot 工厂:返回一个 async BotThink,与规则 bot 同契约、同入口。
 * 可靠性三段:未配置/请求失败/输出非法 → 带错误反馈重试一次 → 仍不行,这一招静默回落规则 bot
 * (逐招回落,不做永久降级——网络恢复后下一招自动再用 AI)。onDegrade 供主机 UI 给一句人话提示。
 */
export declare function createLlmThink(opts: {
    spec: AnyLlmBotSpec;
    /** 游戏规则文本(主机界面语言的 rulesKey 译文),作 system 消息 */
    rulesText: string;
    /** 游戏名,告诉模型它在玩什么 */
    gameName: string;
    /** 用量归因(单局单 bot 均值统计) */
    gameId: string;
    fallback: AnyBotThink;
    onDegrade?: (reason: string) => void;
}): AnyBotThink;
