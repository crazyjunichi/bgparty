import type { Signaling } from './signaling';
/**
 * qr-manual 信令(docs/DESIGN.md §2):完全无外网时 SDP 经摄像头扫码交换,
 * 配对后业务数据走 WebRTC DataChannel,信封协议与 relay 路径完全一致。
 * 星形拓扑(玩家只连主机),与 trystero passive 档同构。
 * 已知限制:无 rendezvous,断线只能重新扫码配对;两侧配对面板常驻可及,
 * 玩家侧通道断开会自动重生成 offer 码,主机重扫即恢复。
 */
export type QrPairingPhase = 
/** 主机待扫(出示入场码由页面负责);玩家还没生成 offer 的准备间隙也落在这 */
'idle'
/** 玩家:出示 offer 配对码 */
 | 'offering'
/** 主机:已扫入 offer,出示 answer 配对码 */
 | 'answering'
/** 玩家:已扫入 answer,等 DataChannel 打开 */
 | 'connecting';
/** 配对 UI 与信令的接缝:页面订阅状态渲染同屏扫码+出示面板,扫码/粘贴结果经 submitScanned 喂回 */
export interface QrPairing {
    phase(): QrPairingPhase;
    /** 当前应出示的配对码文本;idle/connecting 为 null */
    qrText(): string | null;
    /** 非本协议、别的房间、角色不期望的码一律静默忽略 */
    submitScanned(text: string): void;
    /** 主机从 answering 手动切回 idle(出示入场码接下一位);其余相位调用无效 */
    dismiss(): void;
    onChange(cb: () => void): () => void;
}
export declare function createQrSignaling(opts: {
    role: 'host' | 'player';
}): Signaling & QrPairing;
