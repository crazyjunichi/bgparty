export declare function tlog(scope: string, event: string, detail?: Record<string, unknown>): void;
/** 需要从 DevTools 导出/复制的结构化诊断用单行 JSON，避免对象显示成省略号。 */
export declare function tlogJson(scope: string, event: string, detail?: Record<string, unknown>): void;
