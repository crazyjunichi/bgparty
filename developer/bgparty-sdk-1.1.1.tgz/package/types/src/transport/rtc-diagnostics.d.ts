import type { JsonValue } from '../shared/protocol';
/**
 * 只记录 ICE 时序/类型/错误码，不记录 SDP、candidate 原文、IP 或端口。
 * 最近一条真正完成 local+remote description 的记录会随玩家 hello 回传给主机。
 */
declare const PeerConnectionBase: {
    new (configuration?: RTCConfiguration): RTCPeerConnection;
    prototype: RTCPeerConnection;
    generateCertificate(keygenAlgorithm: AlgorithmIdentifier): Promise<RTCCertificate>;
};
export declare class BgPartyPeerConnection extends PeerConnectionBase {
    constructor(configuration?: RTCConfiguration);
    createOffer(options?: RTCOfferOptions): Promise<RTCSessionDescriptionInit>;
    createOffer(successCallback: RTCSessionDescriptionCallback, failureCallback: RTCPeerConnectionErrorCallback, options?: RTCOfferOptions): Promise<void>;
}
/**
 * 返回最近一条实际协商记录。优先取已经 connected 的 PC，避免连续重连时把一条
 * 较新的失败协商误当成当前 DataChannel；20 条只有 local offer 的预热连接不会入选。
 *
 * 没选到时也返回带 tag 的 unavailable 摘要，主机端不能静默漏掉诊断失败本身。
 */
export declare function rtcDiagnosticForHello(): JsonValue;
export {};
