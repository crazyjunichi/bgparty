import { type DownMsg, type UpMsg } from '../shared/protocol';
import { type Signaling } from './signaling';
/**
 * 主机侧会话。主机即权威:玩家手机是哑终端,游戏数据默认走 WebRTC DataChannel,
 * 直连失败时回退 relay 数据通道(仅密文,docs/RELAY-FALLBACK.md)。本层只做信封级工作:
 * kind 分流给上层、(rid,seq) 幂等、rid↔通道绑定、版本比对 —— 不解释 data/view。
 */
export interface HostHooks {
    /** 过校验(形状/版本/幂等)的上行消息;hello 也原样上抛,回推视图是 lobby 的事 */
    onUp(rid: string, msg: UpMsg): void;
    /** 在线 rid 集合变化(hello 绑定 / peer 掉线删绑定) */
    onOnlineChange?(online: string[]): void;
}
export interface HostSession {
    readonly roomId: string;
    /** 未知/离线 rid 静默丢弃 */
    sendTo(rid: string, msg: DownMsg): void;
    broadcast(msg: DownMsg): void;
    onlineRids(): string[];
    diagnostics(): {
        relaysOpen: number;
        peers: number;
        hellos: number;
    };
    close(): void;
}
export declare class TransportError extends Error {
    readonly code: 'insecure-context';
    constructor(code: 'insecure-context');
}
export declare function createHostSession(opts: {
    roomId: string;
    key: string;
    hooks: HostHooks;
    signaling?: Signaling;
}): Promise<HostSession>;
