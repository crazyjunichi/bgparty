import type { JsonValue } from '../shared/protocol';
export interface RoomHandle {
    /** 本端 peerId,页面生命周期内稳定;跨刷新/稳定业务身份使用信封里的 rid */
    readonly peerId: string;
    /** targetPeerId 省略 = 广播 */
    send(data: JsonValue, targetPeerId?: string): void;
    /** 传 null 解除;单handler,后赋盖前赋 */
    onMessage(cb: ((data: JsonValue, fromPeerId: string) => void) | null): void;
    onPeerJoin(cb: ((peerId: string) => void) | null): void;
    onPeerLeave(cb: ((peerId: string) => void) | null): void;
    leave(): Promise<void>;
    /** relay 数据通道(docs/RELAY-FALLBACK.md):直连失败时的兜底,仅密文;qr/local 无 relay 不提供 */
    readonly relay?: RelayDataChannel;
}
export interface RelayDataChannel {
    /** reliable = QoS 1(断线期 mqtt.js 内存队列补投);缺省 QoS 0(最新即胜,离线丢弃) */
    send(data: JsonValue, targetPeerId?: string, opts?: {
        reliable?: boolean;
    }): void;
    onMessage(cb: ((data: JsonValue, fromPeerId: string) => void) | null): void;
}
export interface Signaling {
    join(roomId: string, key: string): Promise<RoomHandle>;
}
export interface RelaySocketsCapable {
    relaySockets(): Record<string, WebSocket>;
}
export declare function relaySocketsOf(s: Signaling): Record<string, WebSocket>;
export declare function relayStatesOf(s: Signaling): Record<string, string>;
