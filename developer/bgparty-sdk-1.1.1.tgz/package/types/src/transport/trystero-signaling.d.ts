import type { RelaySocketsCapable, Signaling } from './signaling';
export declare function createTrysteroSignaling(opts?: {
    passive?: boolean;
    diagnosticContext?: () => Record<string, unknown>;
}): Signaling & RelaySocketsCapable;
