import { type StoreApi } from 'zustand/vanilla';
import { type EnvelopeKind, type FxEntry, type JsonValue } from '../shared/protocol';
import { type Signaling } from './signaling';
/**
 * 玩家侧会话(手机,哑终端)。状态机:connecting → ready | rejected | failed。
 * 直连预算耗尽或局中 DC 死亡时先回退 relay 数据通道(docs/RELAY-FALLBACK.md,单向不回切),
 * relay 仍无回音才进 failed。failed 带三阶段诊断(archive §4):无 relay=网络问题;
 * 有 relay 无 peer=主机不在线;有 peer 无回音=主机侧的锅。rejected 是终态(座位满等,
 * 不自动重试);failed 8s 自动重试。
 */
export type PlayerFault = 'insecure' | 'network' | 'host-offline' | 'host-fault';
/**
 * 连接子步骤(FLOWS §4):0 加载组件 → 1 连服务器(relay OPEN)→ 2 找到主机(peerJoin)→ 3 接入中(hello 已发等视图)。
 * stepAt 供 UI 计时出「卡住了」小字(如第 3 步 15s)。
 */
export type ConnectStep = 0 | 1 | 2 | 3;
export type PlayerConn = {
    stage: 'connecting';
    step: ConnectStep;
    stepAt: number;
    relay?: boolean;
} | {
    stage: 'ready';
    view: JsonValue;
    fx?: FxEntry[];
} | {
    stage: 'rejected';
    reason?: string;
} | {
    stage: 'failed';
    fault: PlayerFault;
    retryAt?: number;
};
/** 局中动作被拒(docs/ENGINE.md §5):非致命,UI toast 一句人话;at 用于连发相同错误也能触发 */
export interface ActionRejection {
    reason?: string;
    params?: Record<string, string | number>;
    at: number;
}
export interface PlayerSessionState {
    conn: PlayerConn;
    actionError?: ActionRejection;
}
export interface PlayerSession {
    readonly rid: string;
    readonly store: StoreApi<PlayerSessionState>;
    /** 未 ready 时静默丢弃:动作入口由 UI 按状态门控 */
    send(kind: EnvelopeKind, data: JsonValue): void;
    /** failed 状态的立即重试入口(自动重试计时取消) */
    retryNow(): void;
    /** 手动切 relay 低速通道(connecting 界面的逃生门):直连卡住时用户自助;已切/已就绪/不可用则忽略 */
    switchToRelay(): void;
    close(): void;
}
export declare function createPlayerSession(opts: {
    roomId: string;
    key: string;
    rid: string;
    signaling?: Signaling;
    /** qr-manual 等人工配对:节奏在人,关掉连接预算与 relay 轮询,失败态不出现 */
    manualPairing?: boolean;
}): PlayerSession;
