import { selfId, type JoinRoomConfig } from '@trystero-p2p/core';
import type { JsonValue } from '../shared/protocol';
export type MqttRoomConfig = JoinRoomConfig;
export declare const joinRoom: import("@trystero-p2p/core").JoinRoom<JoinRoomConfig>;
export declare const getRelaySockets: () => Record<string, WebSocket>;
export { selfId };
export declare const defaultRelayUrls: string[];
export interface RelayDataChannel {
    /** reliable = QoS 1(断线期 mqtt.js 内存队列补投);缺省 QoS 0(最新即胜,离线丢弃) */
    send(data: JsonValue, targetPeerId?: string, opts?: {
        reliable?: boolean;
    }): void;
    onMessage(cb: ((data: JsonValue, fromPeerId: string) => void) | null): void;
    close(): void;
}
/**
 * 房间级数据通道:topic 与密钥都由房间凭据派生,relay 只见随机 topic 与密文。
 * 隐私边界:房间口令共享 → 同桌懂技术的人理论上可解他人私有视图(一期接受,二期可加逐对 ECDH)。
 * 必须在 joinRoom 之后调用(relay client 才已建好);创建失败由调用方兜底(通道缺省即无回退)。
 */
export declare function createRelayChannel(opts: {
    roomId: string;
    key: string;
}): Promise<RelayDataChannel>;
