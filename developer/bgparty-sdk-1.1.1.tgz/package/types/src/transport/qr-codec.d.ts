import { z } from 'zod';
/** 面板据此把超限载荷换成一句人话,而不是让 QR 库抛错(EC-M 字节模式上限 2331) */
export declare const QR_MAX_CHARS = 2200;
declare const pairingPayloadSchema: z.ZodObject<{
    v: z.ZodLiteral<1>;
    role: z.ZodEnum<{
        answer: "answer";
        offer: "offer";
    }>;
    id: z.ZodString;
    room: z.ZodString;
    sdp: z.ZodString;
}, z.core.$strip>;
export type PairingPayload = z.infer<typeof pairingPayloadSchema>;
/**
 * 裁 SDP 到 DataChannel 必需行:删 ice-options/extmap,candidate 只留 host 类且封顶 4 条
 * (多网卡设备会带 VPN/虚拟网卡候选,不裁会爆二维码容量)。裁完仍是合法 SDP,可直接
 * setRemoteDescription;局域网场景 host candidate 已够,srflx 本来也拿不到(无 STUN)。
 */
export declare function pruneSdp(sdp: string): string;
/** 压缩只在更小且运行环境支持(Safari 16.4+)时启用;prefix 区分两种形态 */
export declare function encodePairingPayload(payload: PairingPayload): Promise<string>;
/** 非本协议(前缀不对)/编码坏/形状坏一律 null,调用方静默忽略继续扫 */
export declare function decodePairingPayload(text: string): Promise<PairingPayload | null>;
export {};
