/** 订阅「JS 冻结后恢复」事件,返回退订函数 */
export declare function onResume(cb: () => void): () => void;
