export declare function validateRelease(gameHash: string, sdkHash: string, id: string): Promise<void>;
