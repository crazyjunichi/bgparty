export declare function sandboxDocument(nonce: string): string;
