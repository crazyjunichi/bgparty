import type { InstalledGame } from '../game-packs/storage';
import { type SandboxRuntime } from './client';
export declare function withAnalysisRuntime<T>(installed: InstalledGame, run: (runtime: SandboxRuntime) => Promise<T>): Promise<T>;
