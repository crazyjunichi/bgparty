import type { AnyDef, GameSession } from '../engine/game-session';
import type { InstalledGame } from '../game-packs/storage';
export declare function bindInstalledDefinition(def: AnyDef, installed: InstalledGame): void;
export declare function installationForDefinition(def: AnyDef): InstalledGame | undefined;
export declare function installationForSession(session: GameSession): InstalledGame | undefined;
export declare function closeRemoteSession(session: GameSession): void;
export declare function createRemoteGameSession(options: {
    def: AnyDef;
    players?: string[];
    config?: unknown;
    seed?: number;
    log?: unknown[];
    onChange(): void;
    hostCall?(method: string, args: unknown): Promise<unknown>;
}): Promise<GameSession>;
