import type { AnyDef } from '../engine/game-session';
type Props = Record<string, unknown>;
export declare function PackSurface({ def, mode, props }: {
    def: AnyDef;
    mode: 'game' | 'over' | 'options' | 'guide' | 'menu';
    props: Props;
}): import("react").JSX.Element;
export {};
