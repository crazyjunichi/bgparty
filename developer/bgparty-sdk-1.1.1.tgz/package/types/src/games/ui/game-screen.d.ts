import type { ReactNode } from 'react';
import './game-screen.css';
/**
 * 对局页布局壳:「上下操作条高度恒定」红线(CLAUDE.md)的框架实现,新游戏对局页必须套它(game-check 机检项)。
 * 三段骨架:顶部 banner 槽(flex-none)/ 中央区(flex-1 min-h-0,默认内部滚动)/ 底部操作区(固定高常驻)。
 * - 底部操作区高度由游戏按「最常用相位的内容」定死(actionsHeight),槽常驻:没动作的相位游戏自己放占位,只换内容不换槽
 * - 底部内容超出固定高会被 overflow-hidden 裁掉——故意的:相位性额外信息(结算读数/骰面/确认条)必须走 overlay,不许撑压中央区
 * - overlay 盖在中央区底部,不占文档流;wrapper 是 pointer-events-none,要交互的浮层内容自己加 pointer-events-auto
 * - safe-b 由外层 PageShell 处理(playing 相位外壳无底条、根节点已带),本壳不重复加
 */
export declare function GameScreen({ banner, actions, actionsHeight, overlay, scroll, adaptive, className, children, }: {
    /** 顶部常驻区:PhaseBanner + PlayerStrip 等,flex-none 不伸缩 */
    banner?: ReactNode;
    /** 底部操作区内容;槽位有无由 actionsHeight 决定,actions 为空时槽仍占位 */
    actions?: ReactNode;
    /** 底部操作区固定高度类(如 'h-24'),按最常用相位的内容定;全程无底部操作区的游戏(画板类)不传 */
    actionsHeight?: string;
    /** 相位性提示/读数:absolute 盖在中央区底部,不占文档流 */
    overlay?: ReactNode;
    /** 中央区内部滚动(默认开);自带 pan/zoom 视口的版图游戏关掉 */
    scroll?: boolean;
    /** 主动接入宽敞横屏的尺寸容器与通用信息条适配，默认保持原布局 */
    adaptive?: boolean;
    className?: string;
    children: ReactNode;
}): ReactNode;
