import type { ReactNode } from 'react';
import { type LobbyMemberView } from '../../lobby/protocol';
import type { GameResult } from '../../shared/protocol';
export declare function GameOverChime(): null;
export declare function GameOverScreen({ result, members, myRid, accent, onPlayAgain, onBackToLobby, renderRowExtra, hintCount, }: {
    result: GameResult;
    members: LobbyMemberView[];
    myRid: string;
    /** 获胜者高亮与主按钮实底,取本局游戏 meta.accent */
    accent: string;
    /** 以下两个回调都缺省 = 玩家侧:不画按钮,出等待提示 */
    onPlayAgain?: () => void;
    onBackToLobby?: () => void;
    /** 行内扩展(ROW_LOADERS 派发):每个玩家条目分数行之下追加游戏自定义明细 */
    renderRowExtra?: (rid: string) => ReactNode;
    /** 本局「帮我想一步」求助次数;仅主机单机 vs bot 局且用过才传入(0 次不加信息),联机/玩家侧省略即不显示 */
    hintCount?: number;
}): import("react").JSX.Element;
