export declare function Confetti(): null;
