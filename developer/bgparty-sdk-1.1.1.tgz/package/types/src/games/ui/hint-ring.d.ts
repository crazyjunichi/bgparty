import type { ReactNode } from 'react';
/** 可选目标提示环:滚动蚂蚁线 + hint-flash 闪烁。SMIL 驱动 stroke-dashoffset(CSS 动画真机不生效);
 *  父元素需 relative;radius 传被覆盖元素的圆角(plate=10 / card=18 / 小牌=4 / 正圆=999),环外扩 4px 后圆角随之 +4。
 *  dur 控制蚂蚁线流速(秒/周期);flash=false 关掉明暗闪烁——大面积密集格子(投注板)只留蚂蚁线,避免整片呼吸 */
export declare function HintRing({ radius, dur, flash }: {
    radius?: number;
    dur?: number;
    flash?: boolean;
}): ReactNode;
