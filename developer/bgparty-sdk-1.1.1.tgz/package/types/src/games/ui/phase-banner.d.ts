import type { ReactNode } from 'react';
export type PhaseTone = 'info' | 'warn' | 'done' | 'accent';
export declare function PhaseBanner({ tone, text, sub, chip, accent, }: {
    tone: PhaseTone;
    text: string;
    /** 次级说明(如正在等谁),可选 */
    sub?: string;
    /** 左侧元信息小标(轮次/回合数等),与提示文案分离;ReactNode 以便游戏包锚点(如 catan 骰子落点) */
    chip?: ReactNode;
    /** tone='accent' 时的实底色值,取游戏 meta.accent */
    accent?: string;
}): ReactNode;
