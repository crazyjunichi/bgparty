import { type ReactNode } from 'react';
import { useT, type I18nKey } from '../../shared/i18n';
/**
 * 日志行富文本:槽位先以哨兵占位插进 t() 模板,再拆回 JSX 段。
 * 保留各语言模板语序,不必为每种语言拆连接词 key。
 */
export declare function rich(t: ReturnType<typeof useT>, key: I18nKey, slots: [string, ReactNode][]): ReactNode;
/**
 * 通用对局历史(GAME-GUIDE §6 共享件),两件套:
 * - LogTicker:常驻单行,显示最近一条,整行可点点开 LogSheet;自管弹层开合,游戏侧一行接入
 * - LogSheet:全量历史弹层(遮罩/标题/滚动/空态/关闭)
 * 壳通用,行渲染归游戏——各游戏 state 内的 log 形状不同(判别联合),传 line 闭包进来。
 * 日志数据源是游戏规则 state 内的 log 数组(进 view、可重放、断线恢复完整),
 * 不走 fx 流(恢复即丢)也不下发 action log(暗选类 action 有泄露风险)。
 * 会消失的元素一律 onClick(红线);ticker 常驻固定高度,不随日志有无伸缩。
 */
export declare function LogTicker<T>({ log, line }: {
    log: T[];
    line: (l: T, index: number) => React.ReactNode;
}): import("react").JSX.Element;
export declare function LogSheet<T>({ log, line, onClose, rowClassName }: {
    log: T[];
    line: (l: T, index: number) => React.ReactNode;
    onClose: () => void; /** 行容器类名(如对话式排版要去掉默认分隔线);缺省保持原分隔线样式 */
    rowClassName?: string;
}): import("react").JSX.Element;
