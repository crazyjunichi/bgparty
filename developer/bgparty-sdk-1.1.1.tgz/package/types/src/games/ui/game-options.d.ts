import type { ReactNode } from 'react';
type ChoiceProps = {
    name: string;
    value: string;
    checked: boolean;
    label: ReactNode;
    hint?: ReactNode;
    disabled?: boolean;
    title?: string;
    accent?: string;
    onChange(): void;
};
export declare function OptionSection({ title, count, children, columns }: {
    title: ReactNode;
    count?: ReactNode;
    children: ReactNode;
    columns?: 2 | 3;
}): import("react").JSX.Element;
export declare function OptionRadio({ name, value, checked, label, hint, disabled, title, accent, onChange }: ChoiceProps): import("react").JSX.Element;
export declare function OptionCheckbox({ name, value, checked, label, hint, disabled, title, accent, onChange }: ChoiceProps): import("react").JSX.Element;
export declare function OptionSwitch({ checked, label, hint, disabled, accent, onChange }: {
    checked: boolean;
    label: ReactNode;
    hint?: ReactNode;
    disabled?: boolean;
    accent?: string;
    onChange(): void;
}): import("react").JSX.Element;
export {};
