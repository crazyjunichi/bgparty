import type { ReactNode } from 'react';
import { type LobbyMemberView } from '../../lobby/protocol';
import { type Locale } from '../../shared/i18n';
export type PlayerStripVariant = 'medal' | 'plate' | 'mini';
export declare function PlayerStrip({ members, myRid, variant, status, trailing, action, onPick, picked, anchorOf, dimmed, scroll, adaptive, }: {
    members: LobbyMemberView[];
    myRid: string;
    variant?: PlayerStripVariant;
    /** 游戏扩展槽:按 rid 渲染计分、已出牌✓ 等,返回 null 表示该成员不在局中 */
    status?: (rid: string) => ReactNode;
    /** 右端槽(仅 plate):当轮大筹码等主操作,游戏自由填 */
    trailing?: (rid: string) => ReactNode;
    /** 行动进度槽:'pending' 思考中(动画省略号)/ 'done' 已行动(✓)/ null 不显示 */
    action?: (rid: string) => 'pending' | 'done' | null;
    /** 点名名牌回调(如切换查看该玩家的版图)。给了它名牌才可点 */
    onPick?: (rid: string) => void;
    /** 当前被选中的名牌(与 onPick 配套) */
    picked?: (rid: string) => boolean;
    /** fx 锚点名(可选):返回 null/undefined 不注册 */
    anchorOf?: (rid: string) => string | null;
    /** 整体淡出的座位(如已回营地/已退出当前阶段),与离线灰态可叠加 */
    dimmed?: (rid: string) => boolean;
    /** 单行横向滚动(人多不折行);角标/硬阴影出头部分由容器 padding 兜住不被裁。
        仅配 medal/mini:flex 宽度自适应 w-max。plate 勿用——auto-fill 在不定宽容器里只能算出单列 */
    scroll?: boolean;
    /** mini 在主动接入的宽敞横屏中展开名牌，手机仍保持原尺寸 */
    adaptive?: boolean;
}): import("react").JSX.Element;
export declare function seatName(m: LobbyMemberView, locale: Locale): string;
/** 行内嵌版座位头像:徽章(离线/你/bot/行动进度)与 fx 座位锚点同名牌条一套,离线头像灰态;
 *  给把座位折进版图行的游戏用(如 faraway 旅程行)——名牌 pill/状态 chips 归调用方按行布局自摆 */
export declare function SeatBadgedAvatar({ m, myRid, action, anchorName, box, img, }: {
    m: LobbyMemberView;
    myRid: string;
    action: 'pending' | 'done' | null;
    anchorName: string | null;
    box: string;
    img: string;
}): import("react").JSX.Element;
