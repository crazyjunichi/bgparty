import { type ComponentType } from 'react';
import type { RuleIcon } from '../shared/rules-sheet';
import type { LobbyMemberView } from '../lobby/protocol';
import type { FxRenderers } from '../shared/fx/stage';
import type { GameResult } from '../shared/protocol';
import { type AnyGame } from './registry';
import type { AnyBotThink } from '../engine/bot-driver';
import type { RuntimeReference } from '../game-packs/format';
import { gamePackErrorKey } from '../game-packs/errors';
import type { GameDownloadJob, GameDownloadListener } from '../game-packs/download-progress';
export interface GameViewProps {
    public: unknown;
    private?: unknown;
    members: LobbyMemberView[];
    myRid: string;
    /** 上行动作:玩家侧走 session.send('game', ·),主机侧直接喂 session.handleAction */
    send(action: unknown): void;
}
/**
 * 终局屏派发(可选):游戏要复盘/定制终局时登记自己的终局组件,host/join 检测到 result 段优先用它,
 * 缺省回落通用结算屏(games/ui/game-over-screen)。public 给游戏终局视图(复盘数据在 finalKey 等字段),
 * 边界已按游戏 schema 卡过形状;onPlayAgain/onBackToLobby 缺省 = 玩家侧,组件自画等待提示
 */
export interface GameOverViewProps {
    result: GameResult;
    public: unknown;
    /** 终局时刻的本人私有视图(未卡形状,游戏自卡):专属终局页画计分纸复盘等用 */
    private?: unknown;
    members: LobbyMemberView[];
    myRid: string;
    /** 本局已使用的求助次数；沿用默认终局的主机单机可见条件。 */
    hintCount?: number;
    onPlayAgain?: () => void;
    /** 以本局配置为基础覆盖少量选项后直接重开;仅主机侧提供 */
    onPlayAgainWithConfig?: (patch: Record<string, unknown>) => void;
    onBackToLobby?: () => void;
}
/**
 * 结算行扩展(可选):只想在通用结算屏每个玩家条目下追加明细(逐项得分等)时登记,
 * 比整页覆盖(OVER_LOADERS)轻——排行榜/按钮/等待提示全部沿用通用屏。
 * public 边界已按游戏 schema 卡过形状(玩家侧),rid 是当前行玩家;与 OVER_LOADERS 互斥(整页覆盖优先)
 */
export interface GameOverRowViewProps {
    public: unknown;
    rid: string;
    myRid: string;
}
/**
 * 开局选项组件(可选):游戏有 schemas.config 时在主机大堂提供配置 UI(「选项」弹层内渲染,非常驻)。
 * value 是未卡形状的持久化值(unknown),组件内部按自家 configSchema 恢复具体类型后渲染;
 * onChange 产出新 config,host 页持久化并在 start() 时透传给 setup;
 * offline 标识离线单机房(无外人可入),供「仅离线有意义」的选项(如身份自选)按此显隐
 */
export interface GameOptionsProps {
    value: unknown;
    onChange(config: unknown): void;
    offline?: boolean;
}
/**
 * 对局菜单游戏自定义项(可选,menu-items.tsx):渲染平台菜单(shared/game-menu)里的游戏专属行
 * (如武将一览/积分榜查阅),插在「规则」之后。行样式用 GameMenuAction;组件在 GameMenu keepMounted
 * 下常驻,菜单关闭状态不丢——弹层一律 createPortal 到 document.body(菜单容器有 transform,
 * fixed 子孙会相对它定位),参考 games/ui/bot-hint 的 menu 模式。无 view 注入:需要局内状态的项不可放这里
 */
export interface GameMenuItemsProps {
    /** 关闭平台菜单(打开自家弹层前调用) */
    close(): void;
}
export interface GameBundle {
    def: AnyGame;
    View: ComponentType<GameViewProps>;
    fx?: FxRenderers;
    OverView?: ComponentType<GameOverViewProps>;
    RowView?: ComponentType<GameOverRowViewProps>;
    Guide?: ComponentType;
    MenuItems?: ComponentType<GameMenuItemsProps>;
    ruleIcons?: Record<string, RuleIcon>;
}
export declare function useGameLoadError(id: string | null | undefined, reference?: RuntimeReference): ReturnType<typeof gamePackErrorKey> | null;
export declare function useGameLoadProgress(id: string | null | undefined, reference?: RuntimeReference): GameDownloadJob | null;
export declare const HAS_OPTIONS: Set<string>;
export declare function loadGameBundle(id: string, reference?: RuntimeReference, onProgress?: GameDownloadListener): Promise<GameBundle | null>;
export declare const getLoadedBundle: (id: string) => GameBundle | undefined;
export declare function useGameBundle(id: string | null | undefined, reference?: RuntimeReference): GameBundle | null;
type GameOptionsSurfaceProps = GameOptionsProps & {
    onReady?(): void;
    onError?(): void;
};
export declare function useGameOptionsComponent(id: string | null | undefined): ComponentType<GameOptionsSurfaceProps> | null;
export declare function useGameGuide(id: string | null | undefined): ComponentType | null;
export declare function useGameRuleIcons(id: string | null | undefined): Record<string, RuleIcon> | null;
export declare function useGamePlayerRange(id: string | null | undefined, config: unknown): {
    min: number;
    max: number;
} | null;
export declare function useBotThink(id: string | null | undefined): AnyBotThink | null;
export {};
