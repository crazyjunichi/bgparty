//#region node_modules/fflate/esm/browser.js
var e = Uint8Array, t = Uint16Array, n = Int32Array, r = new e([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), i = new e([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), a = new e([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), o = function(e, r) {
	for (var i = new t(31), a = 0; a < 31; ++a) i[a] = r += 1 << e[a - 1];
	for (var o = new n(i[30]), a = 1; a < 30; ++a) for (var s = i[a]; s < i[a + 1]; ++s) o[s] = s - i[a] << 5 | a;
	return {
		b: i,
		r: o
	};
}, s = o(r, 2), c = s.b, l = s.r;
c[28] = 258, l[258] = 28;
var u = o(i, 0), d = u.b;
u.r;
for (var f = new t(32768), p = 0; p < 32768; ++p) {
	var m = (p & 43690) >> 1 | (p & 21845) << 1;
	m = (m & 52428) >> 2 | (m & 13107) << 2, m = (m & 61680) >> 4 | (m & 3855) << 4, f[p] = ((m & 65280) >> 8 | (m & 255) << 8) >> 1;
}
for (var h = (function(e, n, r) {
	for (var i = e.length, a = 0, o = new t(n); a < i; ++a) e[a] && ++o[e[a] - 1];
	var s = new t(n);
	for (a = 1; a < n; ++a) s[a] = s[a - 1] + o[a - 1] << 1;
	var c;
	if (r) {
		c = new t(1 << n);
		var l = 15 - n;
		for (a = 0; a < i; ++a) if (e[a]) for (var u = a << 4 | e[a], d = n - e[a], p = s[e[a] - 1]++ << d, m = p | (1 << d) - 1; p <= m; ++p) c[f[p] >> l] = u;
	} else for (c = new t(i), a = 0; a < i; ++a) e[a] && (c[a] = f[s[e[a] - 1]++] >> 15 - e[a]);
	return c;
}), g = new e(288), p = 0; p < 144; ++p) g[p] = 8;
for (var p = 144; p < 256; ++p) g[p] = 9;
for (var p = 256; p < 280; ++p) g[p] = 7;
for (var p = 280; p < 288; ++p) g[p] = 8;
for (var _ = new e(32), p = 0; p < 32; ++p) _[p] = 5;
var ee = /*#__PURE__*/ h(g, 9, 1), te = /*#__PURE__*/ h(_, 5, 1), ne = function(e) {
	for (var t = e[0], n = 1; n < e.length; ++n) e[n] > t && (t = e[n]);
	return t;
}, v = function(e, t, n) {
	var r = t / 8 | 0;
	return (e[r] | e[r + 1] << 8) >> (t & 7) & n;
}, re = function(e, t) {
	var n = t / 8 | 0;
	return (e[n] | e[n + 1] << 8 | e[n + 2] << 16) >> (t & 7);
}, ie = function(e) {
	return (e + 7) / 8 | 0;
}, ae = function(t, n, r) {
	return (n == null || n < 0) && (n = 0), (r == null || r > t.length) && (r = t.length), new e(t.subarray(n, r));
}, y = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
], b = function(e, t, n) {
	var r = Error(t || y[e]);
	if (r.code = e, Error.captureStackTrace && Error.captureStackTrace(r, b), !n) throw r;
	return r;
}, x = function(t, n, o, s) {
	var l = t.length, u = s ? s.length : 0;
	if (!l || n.f && !n.l) return o || new e(0);
	var f = !o, p = f || n.i != 2, m = n.i;
	f && (o = new e(l * 3));
	var g = function(t) {
		var n = o.length;
		if (t > n) {
			var r = new e(Math.max(n * 2, t));
			r.set(o), o = r;
		}
	}, _ = n.f || 0, y = n.p || 0, x = n.b || 0, oe = n.l, S = n.d, C = n.m, se = n.n, ce = l * 8;
	do {
		if (!oe) {
			_ = v(t, y, 1);
			var le = v(t, y + 1, 3);
			if (y += 3, !le) {
				var w = ie(y) + 4, ue = t[w - 4] | t[w - 3] << 8, de = w + ue;
				if (de > l) {
					m && b(0);
					break;
				}
				p && g(x + ue), o.set(t.subarray(w, de), x), n.b = x += ue, n.p = y = de * 8, n.f = _;
				continue;
			}
			if (le == 1) oe = ee, S = te, C = 9, se = 5;
			else if (le == 2) {
				var fe = v(t, y, 31) + 257, pe = v(t, y + 10, 15) + 4, me = fe + v(t, y + 5, 31) + 1;
				y += 14;
				for (var he = new e(me), ge = new e(19), T = 0; T < pe; ++T) ge[a[T]] = v(t, y + T * 3, 7);
				y += pe * 3;
				for (var _e = ne(ge), ve = (1 << _e) - 1, ye = h(ge, _e, 1), T = 0; T < me;) {
					var be = ye[v(t, y, ve)];
					y += be & 15;
					var w = be >> 4;
					if (w < 16) he[T++] = w;
					else {
						var E = 0, D = 0;
						for (w == 16 ? (D = 3 + v(t, y, 3), y += 2, E = he[T - 1]) : w == 17 ? (D = 3 + v(t, y, 7), y += 3) : w == 18 && (D = 11 + v(t, y, 127), y += 7); D--;) he[T++] = E;
					}
				}
				var xe = he.subarray(0, fe), Se = he.subarray(fe);
				C = ne(xe), se = ne(Se), oe = h(xe, C, 1), S = h(Se, se, 1);
			} else b(1);
			if (y > ce) {
				m && b(0);
				break;
			}
		}
		p && g(x + 131072);
		for (var Ce = (1 << C) - 1, we = (1 << se) - 1, Te = y;; Te = y) {
			var E = oe[re(t, y) & Ce], O = E >> 4;
			if (y += E & 15, y > ce) {
				m && b(0);
				break;
			}
			if (E || b(2), O < 256) o[x++] = O;
			else if (O == 256) {
				Te = y, oe = null;
				break;
			} else {
				var Ee = O - 254;
				if (O > 264) {
					var T = O - 257, De = r[T];
					Ee = v(t, y, (1 << De) - 1) + c[T], y += De;
				}
				var k = S[re(t, y) & we], A = k >> 4;
				k || b(3), y += k & 15;
				var Se = d[A];
				if (A > 3) {
					var De = i[A];
					Se += re(t, y) & (1 << De) - 1, y += De;
				}
				if (y > ce) {
					m && b(0);
					break;
				}
				p && g(x + 131072);
				var j = x + Ee;
				if (x < Se) {
					var Oe = u - Se, ke = Math.min(Se, j);
					for (Oe + x < 0 && b(3); x < ke; ++x) o[x] = s[Oe + x];
				}
				for (; x < j; ++x) o[x] = o[x - Se];
			}
		}
		n.l = oe, n.p = Te, n.b = x, n.f = _, oe && (_ = 1, n.m = C, n.d = S, n.n = se);
	} while (!_);
	return x != o.length && f ? ae(o, 0, x) : o.subarray(0, x);
}, oe = /*#__PURE__*/ new e(0), S = function(e, t) {
	return e[t] | e[t + 1] << 8;
}, C = function(e, t) {
	return (e[t] | e[t + 1] << 8 | e[t + 2] << 16 | e[t + 3] << 24) >>> 0;
}, se = function(e, t) {
	return C(e, t) + C(e, t + 4) * 4294967296;
};
function ce(e, t) {
	return x(e, { i: 2 }, t && t.out, t && t.dictionary);
}
var le = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder();
try {
	le.decode(oe, { stream: !0 });
} catch {}
var w = function(e) {
	for (var t = "", n = 0;;) {
		var r = e[n++], i = (r > 127) + (r > 223) + (r > 239);
		if (n + i > e.length) return {
			s: t,
			r: ae(e, n - 1)
		};
		i ? i == 3 ? (r = ((r & 15) << 18 | (e[n++] & 63) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) - 65536, t += String.fromCharCode(55296 | r >> 10, 56320 | r & 1023)) : i & 1 ? t += String.fromCharCode((r & 31) << 6 | e[n++] & 63) : t += String.fromCharCode((r & 15) << 12 | (e[n++] & 63) << 6 | e[n++] & 63) : t += String.fromCharCode(r);
	}
};
function ue(e, t) {
	if (t) {
		for (var n = "", r = 0; r < e.length; r += 16384) n += String.fromCharCode.apply(null, e.subarray(r, r + 16384));
		return n;
	}
	if (le) return le.decode(e);
	var i = w(e), a = i.s, n = i.r;
	return n.length && b(8), a;
}
var de = function(e, t) {
	return t + 30 + S(e, t + 26) + S(e, t + 28);
}, fe = function(e, t, n) {
	var r = S(e, t + 28), i = S(e, t + 30), a = ue(e.subarray(t + 46, t + 46 + r), !(S(e, t + 8) & 2048)), o = t + 46 + r, s = pe(e, o, i, n, C(e, t + 20), C(e, t + 24), C(e, t + 42)), c = s[0], l = s[1], u = s[2];
	return [
		S(e, t + 10),
		c,
		l,
		a,
		o + i + S(e, t + 32),
		u
	];
}, pe = function(e, t, n, r, i, a, o) {
	var s = i == 4294967295, c = a == 4294967295, l = o == 4294967295, u = t + n, d = s + c + l;
	if (r && d) {
		for (; t + 4 < u; t += 4 + S(e, t + 2)) if (S(e, t) == 1) return [
			s ? se(e, t + 4 + 8 * c) : i,
			c ? se(e, t + 4) : a,
			l ? se(e, t + 4 + 8 * (c + s)) : o,
			1
		];
		r < 2 && b(13);
	}
	return [
		i,
		a,
		o,
		0
	];
};
function me(t, n) {
	for (var r = {}, i = t.length - 22; C(t, i) != 101010256; --i) (!i || t.length - i > 65558) && b(13);
	var a = S(t, i + 8);
	if (!a) return {};
	var o = C(t, i + 16), s = C(t, i - 20) == 117853008;
	if (s) {
		var c = C(t, i - 12);
		s = C(t, c) == 101075792, s && (a = C(t, c + 32), o = C(t, c + 48));
	}
	for (var l = n && n.filter, u = 0; u < a; ++u) {
		var d = fe(t, o, s), f = d[0], p = d[1], m = d[2], h = d[3], g = d[4], _ = d[5], ee = de(t, _);
		o = g, (!l || l({
			name: h,
			size: p,
			originalSize: m,
			compression: f
		})) && (f ? f == 8 ? r[h] = ce(t.subarray(ee, ee + p), { out: new e(m) }) : b(14, "unknown compression type " + f) : r[h] = ae(t, ee, ee + p));
	}
	return r;
}
//#endregion
//#region node_modules/zod/v4/core/util.js
function he(e) {
	let t = Object.values(e).filter((e) => typeof e == "number");
	return Object.entries(e).filter(([e, n]) => t.indexOf(+e) === -1).map(([e, t]) => t);
}
function ge(e, t = "|") {
	return e.map((e) => Oe(e)).join(t);
}
function T(e, t) {
	return typeof t == "bigint" ? t.toString() : t;
}
function _e(e) {
	return { get value() {
		{
			let t = e();
			return Object.defineProperty(this, "value", { value: t }), t;
		}
	} };
}
function ve(e) {
	return e == null;
}
function ye(e) {
	let t = +!!e.startsWith("^"), n = e.endsWith("$") ? e.length - 1 : e.length;
	return e.slice(t, n);
}
function be(e, t) {
	let n = e / t, r = Math.round(n), i = 4 * 2 ** -52 * Math.max(Math.abs(n), 1);
	return Math.abs(n - r) < i ? 0 : n - r;
}
function E(e, t, n) {
	Object.defineProperty(e, t, {
		value: n,
		writable: !0,
		enumerable: !0,
		configurable: !0
	});
}
function D(...e) {
	let t = {};
	for (let n of e) {
		let e = Object.getOwnPropertyDescriptors(n);
		Object.assign(t, e);
	}
	return Object.defineProperties({}, t);
}
function xe(e) {
	return JSON.stringify(e);
}
function Se(e) {
	return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var Ce = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {};
function we(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var Te = /* @__PURE__*/ _e(() => {
	if (P.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare")) return !1;
	try {
		return Function(""), !0;
	} catch {
		return !1;
	}
});
function O(e) {
	if (we(e) === !1) return !1;
	let t = e.constructor;
	if (t === void 0 || typeof t != "function") return !0;
	let n = t.prototype;
	return we(n) !== !1 && Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") !== !1;
}
function Ee(e) {
	return O(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
var De = /* @__PURE__*/ new Set([
	"string",
	"number",
	"symbol"
]);
function k(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function A(e, t, n) {
	let r = new e._zod.constr(t ?? e._zod.def);
	return (!t || n?.parent) && (r._zod.parent = e), r;
}
function j(e) {
	let t = e;
	if (!t) return {};
	if (typeof t == "string") return { error: () => t };
	if (t?.message !== void 0) {
		if (t?.error !== void 0) throw Error("Cannot specify both `message` and `error` params");
		t.error = t.message;
	}
	return delete t.message, typeof t.error == "string" ? {
		...t,
		error: () => t.error
	} : t;
}
function Oe(e) {
	return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
function ke(e) {
	return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
var Ae = {
	safeint: [-(2 ** 53 - 1), 2 ** 53 - 1],
	int32: [-2147483648, 2147483647],
	uint32: [0, 4294967295],
	float32: [-34028234663852886e22, 34028234663852886e22],
	float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
};
function je(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".pick() cannot be used on object schemas containing refinements");
	return A(e, D(e._zod.def, {
		get shape() {
			let e = {};
			for (let r of Reflect.ownKeys(t)) {
				if (!Object.prototype.hasOwnProperty.call(n.shape, r)) throw Error(`Unrecognized key: "${String(r)}"`);
				t[r] && E(e, r, n.shape[r]);
			}
			return E(this, "shape", e), e;
		},
		checks: []
	}));
}
function Me(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".omit() cannot be used on object schemas containing refinements");
	return A(e, D(e._zod.def, {
		get shape() {
			let r = { ...e._zod.def.shape };
			for (let e of Reflect.ownKeys(t)) {
				if (!Object.prototype.hasOwnProperty.call(n.shape, e)) throw Error(`Unrecognized key: "${String(e)}"`);
				t[e] && delete r[e];
			}
			return E(this, "shape", r), r;
		},
		checks: []
	}));
}
function Ne(e, t) {
	if (!O(t)) throw Error("Invalid input to extend: expected a plain object");
	let n = e._zod.def.checks;
	if (n && n.length > 0) {
		let n = e._zod.def.shape;
		for (let e of Reflect.ownKeys(t)) if (Object.getOwnPropertyDescriptor(n, e) !== void 0) throw Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
	}
	return A(e, D(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return E(this, "shape", n), n;
	} }));
}
function Pe(e, t) {
	if (!O(t)) throw Error("Invalid input to safeExtend: expected a plain object");
	return A(e, D(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return E(this, "shape", n), n;
	} }));
}
function Fe(e, t) {
	if (!t?._zod?.def) throw Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
	if (e._zod.def.checks?.length) throw Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
	return A(e, D(e._zod.def, {
		get shape() {
			let n = {
				...e._zod.def.shape,
				...t._zod.def.shape
			};
			return E(this, "shape", n), n;
		},
		get catchall() {
			return t._zod.def.catchall;
		},
		checks: t._zod.def.checks ?? []
	}));
}
function Ie(e, t, n, r = "partial") {
	let i = t._zod.def.checks;
	if (i && i.length > 0) throw Error(`.${r}() cannot be used on object schemas containing refinements`);
	return A(t, D(t._zod.def, {
		get shape() {
			let r = t._zod.def.shape, i = { ...r };
			if (n) for (let t of Reflect.ownKeys(n)) {
				if (!Object.prototype.hasOwnProperty.call(r, t)) throw Error(`Unrecognized key: "${String(t)}"`);
				n[t] && (i[t] = e ? new e({
					type: "optional",
					innerType: r[t]
				}) : r[t]);
			}
			else for (let t of Reflect.ownKeys(r)) i[t] = e ? new e({
				type: "optional",
				innerType: r[t]
			}) : r[t];
			return E(this, "shape", i), i;
		},
		checks: []
	}));
}
function Le(e, t, n) {
	return A(t, D(t._zod.def, { get shape() {
		let r = t._zod.def.shape, i = { ...r };
		if (n) for (let t of Reflect.ownKeys(n)) {
			if (!Object.prototype.hasOwnProperty.call(i, t)) throw Error(`Unrecognized key: "${String(t)}"`);
			n[t] && (i[t] = new e({
				type: "nonoptional",
				innerType: r[t]
			}));
		}
		else for (let t of Reflect.ownKeys(r)) i[t] = new e({
			type: "nonoptional",
			innerType: r[t]
		});
		return E(this, "shape", i), i;
	} }));
}
function Re(e, t = 0) {
	if (e.aborted === !0) return !0;
	for (let n = t; n < e.issues.length; n++) if (e.issues[n]?.continue !== !0) return !0;
	return !1;
}
function ze(e, t = 0) {
	if (e.aborted === !0) return !0;
	for (let n = t; n < e.issues.length; n++) if (e.issues[n]?.continue === !1) return !0;
	return !1;
}
function Be(e, t) {
	return t.map((t) => {
		var n;
		return (n = t).path ?? (n.path = []), t.path.unshift(e), t;
	});
}
function Ve(e) {
	return typeof e == "string" ? e : e?.message;
}
function He(e, t, n) {
	var r;
	for (let i = t; i < e.length; i++) (r = e[i]).schema ?? (r.schema = n);
}
function Ue(e, t, n) {
	var r;
	let i = e.inst?._zod?.traits;
	i?.has("$ZodType") && (i.has("$ZodCheck") ? (r = e).schema ?? (r.schema = e.inst) : e.schema = e.inst);
	let a = e.schema === e.inst ? void 0 : e.schema?._zod.def?.error, o = e.message ? e.message : Ve(e.inst?._zod.def?.error?.(e)) ?? Ve(a?.(e)) ?? Ve(t?.error?.(e)) ?? Ve(n.customError?.(e)) ?? Ve(n.localeError?.(e)) ?? "Invalid input", { inst: s, schema: c, continue: l, input: u, ...d } = e;
	return d.path ??= [], d.message = o, t?.reportInput && (d.input = u), d;
}
var We = /[\uD800-\uDBFF]/;
function Ge(e) {
	let t = e.length;
	if (!We.test(e)) return t;
	let n = t;
	for (let r = 0; r < t - 1; r++) (e.charCodeAt(r) & 64512) == 55296 && (e.charCodeAt(r + 1) & 64512) == 56320 && (n--, r++);
	return n;
}
function Ke(e) {
	return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function qe(e) {
	let t = typeof e;
	switch (t) {
		case "number": return Number.isNaN(e) ? "nan" : "number";
		case "object": {
			if (e === null) return "null";
			if (Array.isArray(e)) return "array";
			let t = e;
			if (t && Object.getPrototypeOf(t) !== Object.prototype && "constructor" in t && t.constructor) return t.constructor.name;
		}
	}
	return t;
}
function Je(...e) {
	let [t, n, r] = e;
	return typeof t == "string" ? {
		message: t,
		code: "custom",
		input: n,
		inst: r
	} : { ...t };
}
function Ye(e, t) {
	for (let n in t) {
		let r = Object.getOwnPropertyDescriptor(t, n);
		r.get ? Object.defineProperty(e, n, {
			...r,
			enumerable: !1
		}) : Qe(e, n, r.value);
	}
}
function Xe(e, t, n, r = !0) {
	return Object.defineProperty(e, t, {
		configurable: !0,
		writable: !0,
		enumerable: r,
		value: n
	}), n;
}
function Ze(e, t, n) {
	return Xe(e, t, n, !1);
}
function Qe(e, t, n) {
	Object.defineProperty(e, t, {
		configurable: !0,
		get() {
			return this == null ? n : Xe(this, t, n.bind(this));
		},
		set(e) {
			Xe(this, t, e);
		}
	});
}
function $e(e, t) {
	let n = Object.getPrototypeOf(e);
	return t in n ? void 0 : n;
}
var et, tt = !1, nt = {
	configurable: !0,
	get() {
		tt = !0;
	}
};
function M(e, t, n) {
	let r = Object.getPrototypeOf(e._zod);
	if (t in r && et !== e._zod) {
		et = void 0;
		return;
	}
	et = e._zod, Object.defineProperty(r, t, {
		configurable: !0,
		get() {
			Object.defineProperty(this, t, nt);
			let e = tt;
			tt = !1;
			try {
				let r = n(this);
				return tt ? delete this[t] : Object.defineProperty(this, t, {
					configurable: !0,
					writable: !0,
					value: r
				}), tt ||= e, r;
			} catch (n) {
				throw delete this[t], tt ||= e, n;
			}
		},
		set(e) {
			Object.defineProperty(this, t, {
				configurable: !0,
				writable: !0,
				value: e
			});
		}
	});
}
function rt(e, t, n, r) {
	let i = $e(e, t);
	i && Object.defineProperty(i, t, {
		configurable: !0,
		get() {
			let e = {
				configurable: !0,
				writable: !0,
				enumerable: r,
				value: void 0
			};
			return Object.defineProperty(this, t, e), e.value = n(this), Object.defineProperty(this, t, e), e.value;
		},
		set(e) {
			Object.defineProperty(this, t, {
				configurable: !0,
				writable: !0,
				enumerable: r,
				value: e
			});
		}
	});
}
var it = "~constantCatch";
function at(e) {
	let t = () => e;
	return t[it] = !0, t;
}
//#endregion
//#region node_modules/zod/v4/core/core.js
var ot, st = {
	value: void 0,
	enumerable: !1
}, ct = "captureStackTrace" in Error ? Error : null;
function lt(e) {
	let t = ct;
	if (t) {
		let n = t.stackTraceLimit;
		if (typeof n == "number") {
			try {
				t.stackTraceLimit = 0;
			} catch {
				return ct = null, new e();
			}
			try {
				return new e();
			} finally {
				t.stackTraceLimit = n;
			}
		}
	}
	return new e();
}
function N(e, t, n, r) {
	let i = {};
	function a(e) {
		this.def = e, this.constr = d, this.traits = /* @__PURE__ */ new Set();
	}
	a.prototype = i;
	let o = n, s = o && /* @__PURE__ */ new WeakSet();
	function c(n, r) {
		if (!n._zod) {
			st.value = new a(r);
			try {
				Object.defineProperty(n, "_zod", st);
			} finally {
				st.value = void 0;
			}
		}
		if (n._zod.traits.has(e)) return;
		if (n._zod.traits.add(e), t(n, r), s) {
			let e = Object.getPrototypeOf(n), t = n._zod.constr.prototype, r = e;
			for (; r && r !== t;) r = Object.getPrototypeOf(r);
			let i = r ?? e;
			s.has(i) || (s.add(i), Ye(i, o));
		}
		let i = d.prototype;
		for (let e in i) Object.prototype.hasOwnProperty.call(i, e) && (e in n || (n[e] = i[e].bind(n)));
	}
	let l = r?.Parent ?? Object;
	class u extends l {}
	Object.defineProperty(u, "name", { value: e });
	function d(e) {
		let t = r?.Parent ? lt(u) : this;
		c(t, e);
		let n = t._zod.deferred;
		if (n) {
			for (let e of n) e();
			t._zod.deferred = void 0;
		}
		let i = globalThis.__zod_globalConfig?.postProcessor;
		return i && i(t), t;
	}
	return Object.defineProperty(d, "init", { value: c }), Object.defineProperty(d, Symbol.hasInstance, { value: (t) => r?.Parent && t instanceof r.Parent ? !0 : t?._zod?.traits?.has(e) }), Object.defineProperty(d, "name", { value: e }), d;
}
var ut = class extends Error {
	constructor() {
		super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
	}
}, dt = class extends Error {
	constructor(e) {
		super(`Encountered unidirectional transform during encode: ${e}`), this.name = "ZodEncodeError";
	}
};
(ot = globalThis).__zod_globalConfig ?? (ot.__zod_globalConfig = {});
var P = globalThis.__zod_globalConfig;
function F(e) {
	return e && Object.assign(P, e), P;
}
//#endregion
//#region node_modules/zod/v4/core/errors.js
function ft() {
	let e = this._zod;
	return e.message ??= JSON.stringify(e.def, T, 2), e.message;
}
function pt(e) {
	this._zod.message = e;
}
var mt = {
	get: ft,
	set: pt,
	enumerable: !0,
	configurable: !0
}, ht = {
	value: void 0,
	enumerable: !1
}, gt = {
	value: void 0,
	enumerable: !1
}, _t = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), vt = (e, t) => {
	e.name = "$ZodError", ht.value = e._zod, Object.defineProperty(e, "_zod", ht), gt.value = t, Object.defineProperty(e, "issues", gt), ht.value = void 0, gt.value = void 0, Object.defineProperty(e, "message", mt);
	let n = Object.getPrototypeOf(e);
	_t.has(n) || (_t.add(n), Object.defineProperty(n, "toString", {
		configurable: !0,
		enumerable: !1,
		get() {
			let e = () => this.message;
			return Object.defineProperty(this, "toString", {
				value: e,
				configurable: !0,
				writable: !0
			}), e;
		},
		set(e) {
			Object.defineProperty(this, "toString", {
				value: e,
				configurable: !0,
				writable: !0
			});
		}
	}));
}, yt = N("$ZodError", vt), bt = N("$ZodError", vt, void 0, { Parent: Error });
function xt(e, t, n) {
	return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, {
		value: n(),
		writable: !0,
		enumerable: !0,
		configurable: !0
	}) : e[t] = n()), e[t];
}
function St(e, t = (e) => e.message) {
	let n = {}, r = [];
	for (let i of e.issues) i.path.length > 0 ? xt(n, i.path[0], () => []).push(t(i)) : r.push(t(i));
	return {
		formErrors: r,
		fieldErrors: n
	};
}
function Ct(e, t = (e) => e.message) {
	let n = { _errors: [] }, r = (e, i = []) => {
		for (let a of e.issues) if (a.code === "invalid_union" && a.errors.length) a.errors.map((e) => r({ issues: e }, [...i, ...a.path]));
		else if (a.code === "invalid_key") r({ issues: a.issues }, [...i, ...a.path]);
		else if (a.code === "invalid_element") r({ issues: a.issues }, [...i, ...a.path]);
		else {
			let e = [...i, ...a.path];
			if (e.length === 0) n._errors.push(t(a));
			else {
				let r = n, i = 0;
				for (; i < e.length;) {
					let n = e[i], o = i === e.length - 1;
					if (n === "_errors") {
						o && r._errors.push(t(a)), i++;
						continue;
					}
					Object.prototype.hasOwnProperty.call(r, n) || Object.defineProperty(r, n, {
						value: { _errors: [] },
						enumerable: !0,
						writable: !0,
						configurable: !0
					});
					let s = r[n];
					o && s._errors.push(t(a)), r = s, i++;
				}
			}
		}
	};
	return r(e), n;
}
//#endregion
//#region node_modules/zod/v4/core/parse.js
function wt(e, t) {
	return {
		callee: t?.callee ?? e,
		Err: t?.Err
	};
}
var Tt = (e) => {
	let t = (n, r, i, a) => {
		let o = i ? {
			...i,
			async: !1
		} : { async: !1 }, s = n._zod.run({
			value: r,
			issues: []
		}, o);
		if (s instanceof Promise) throw new ut();
		if (s.issues.length) {
			let n = new ((a?.Err) ?? e)(s.issues.map((e) => Ue(e, o, F())));
			throw Ce(n, a?.callee ?? t), n;
		}
		return s.value;
	};
	return t;
}, Et = (e) => {
	let t = async (n, r, i, a) => {
		let o = i ? {
			...i,
			async: !0
		} : { async: !0 }, s = n._zod.run({
			value: r,
			issues: []
		}, o);
		if (s instanceof Promise && (s = await s), s.issues.length) {
			let n = new ((a?.Err) ?? e)(s.issues.map((e) => Ue(e, o, F())));
			throw Ce(n, a?.callee ?? t), n;
		}
		return s.value;
	};
	return t;
}, Dt = (e) => (t, n, r) => {
	let i = r ? {
		...r,
		async: !1
	} : { async: !1 }, a = t._zod.run({
		value: n,
		issues: []
	}, i);
	if (a instanceof Promise) throw new ut();
	return a.issues.length ? {
		success: !1,
		error: new (e ?? yt)(a.issues.map((e) => Ue(e, i, F())))
	} : {
		success: !0,
		data: a.value
	};
}, Ot = /* @__PURE__*/ Dt(bt), kt = (e) => async (t, n, r) => {
	let i = r ? {
		...r,
		async: !0
	} : { async: !0 }, a = t._zod.run({
		value: n,
		issues: []
	}, i);
	return a instanceof Promise && (a = await a), a.issues.length ? {
		success: !1,
		error: new e(a.issues.map((e) => Ue(e, i, F())))
	} : {
		success: !0,
		data: a.value
	};
}, At = /* @__PURE__*/ kt(bt), jt = (e) => {
	let t = Tt(e), n = (e, r, i, a) => {
		let o = i ? {
			...i,
			direction: "backward"
		} : { direction: "backward" };
		return t(e, r, o, wt(n, a));
	};
	return n;
}, Mt = (e) => {
	let t = Tt(e), n = (e, r, i, a) => t(e, r, i, wt(n, a));
	return n;
}, Nt = (e) => {
	let t = Et(e), n = async (e, r, i, a) => {
		let o = i ? {
			...i,
			direction: "backward"
		} : { direction: "backward" };
		return await t(e, r, o, wt(n, a));
	};
	return n;
}, Pt = (e) => {
	let t = Et(e), n = async (e, r, i, a) => await t(e, r, i, wt(n, a));
	return n;
}, Ft = (e) => (t, n, r) => {
	let i = r ? {
		...r,
		direction: "backward"
	} : { direction: "backward" };
	return Dt(e)(t, n, i);
}, It = (e) => (t, n, r) => Dt(e)(t, n, r), Lt = (e) => async (t, n, r) => {
	let i = r ? {
		...r,
		direction: "backward"
	} : { direction: "backward" };
	return kt(e)(t, n, i);
}, Rt = (e) => async (t, n, r) => kt(e)(t, n, r), zt = /^[cC][0-9a-z]{6,}$/, Bt = /^[0-9a-z]+$/, Vt = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, Ht = /^[0-9a-vA-V]{20}$/, Ut = /^[A-Za-z0-9]{27}$/, Wt = /^[a-zA-Z0-9_-]{21}$/;
function Gt(e) {
	return RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
var Kt = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, qt = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, Jt = (e) => e ? RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, Yt = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Xt = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function Zt() {
	return new RegExp(Xt, "u");
}
var Qt = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, $t = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, en = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, tn = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, nn = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, rn = /^[A-Za-z0-9_-]*$/, an = /^https?$/, on = /^\+[1-9]\d{6,14}$/, sn = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function cn(e) {
	return RegExp(`^${e}$`);
}
var ln = /*@__PURE__*/ cn(sn);
function un(e) {
	let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
	return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function dn(e) {
	return RegExp(`^${un(e)}$`);
}
function fn(e) {
	let t = ["Z"];
	e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
	let n = `${un({
		precision: e.precision,
		seconds: !0
	})}(?:${t.join("|")})`, r = e.local ? `${n}|${un({ precision: e.precision })}` : n;
	return RegExp(`^${sn}T(?:${r})$`);
}
var pn = (e) => {
	let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
	return RegExp(`^${t}$`);
}, mn = /^-?\d+$/, hn = /^-?\d+(?:\.\d+)?$/, gn = /^(?:true|false)$/i, _n = /^[^A-Z]*$/, vn = /^[^a-z]*$/, I = /*@__PURE__*/ N("$ZodCheck", (e, t) => {
	var n;
	e._zod ??= {}, e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), yn = (e) => {
	let t = e.value;
	return !ve(t) && t.length !== void 0;
}, bn = {
	number: "number",
	bigint: "bigint",
	object: "date"
}, xn = /*@__PURE__*/ N("$ZodCheckLessThan", (e, t) => {
	I.init(e, t);
	let n = bn[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.maximum : n.exclusiveMaximum) ?? Infinity;
		t.value < r && (t.inclusive ? n.maximum = t.value : n.exclusiveMaximum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value <= t.value : r.value < t.value) || r.issues.push({
			origin: bn[typeof r.value] ?? n,
			code: "too_big",
			maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), Sn = /*@__PURE__*/ N("$ZodCheckGreaterThan", (e, t) => {
	I.init(e, t);
	let n = bn[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.minimum : n.exclusiveMinimum) ?? -Infinity;
		t.value > r && (t.inclusive ? n.minimum = t.value : n.exclusiveMinimum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value >= t.value : r.value > t.value) || r.issues.push({
			origin: bn[typeof r.value] ?? n,
			code: "too_small",
			minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), Cn = /*@__PURE__*/ N("$ZodCheckMultipleOf", (e, t) => {
	I.init(e, t), e._zod.onattach.push((e) => {
		var n;
		(n = e._zod.bag).multipleOf ?? (n.multipleOf = t.value);
	}), e._zod.check = (n) => {
		if (typeof n.value != typeof t.value) throw Error("Cannot mix number and bigint in multiple_of check.");
		(typeof n.value == "bigint" ? t.value !== BigInt(0) && n.value % t.value === BigInt(0) : be(n.value, t.value) === 0) || n.issues.push({
			origin: typeof n.value,
			code: "not_multiple_of",
			divisor: t.value,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), wn = /*@__PURE__*/ N("$ZodCheckNumberFormat", (e, t) => {
	I.init(e, t), t.format = t.format || "float64";
	let n = t.format?.includes("int"), r = n ? "int" : "number", [i, a] = Ae[t.format];
	e._zod.onattach.push((e) => {
		let r = e._zod.bag;
		r.format = t.format, r.minimum = i, r.maximum = a, n && (r.pattern = mn);
	}), e._zod.check = (o) => {
		let s = o.value;
		if (n) {
			if (!Number.isInteger(s)) {
				o.issues.push({
					expected: r,
					format: t.format,
					code: "invalid_type",
					continue: !1,
					input: s,
					inst: e
				});
				return;
			}
			if (!Number.isSafeInteger(s)) {
				s > 0 ? o.issues.push({
					input: s,
					code: "too_big",
					maximum: 2 ** 53 - 1,
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				}) : o.issues.push({
					input: s,
					code: "too_small",
					minimum: -(2 ** 53 - 1),
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				});
				return;
			}
		}
		s < i && o.issues.push({
			origin: "number",
			input: s,
			code: "too_small",
			minimum: i,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		}), s > a && o.issues.push({
			origin: "number",
			input: s,
			code: "too_big",
			maximum: a,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		});
	};
}), Tn = /*@__PURE__*/ N("$ZodCheckMaxLength", (e, t) => {
	var n;
	I.init(e, t), (n = e._zod.def).when ?? (n.when = yn), e._zod.onattach.push((e) => {
		let n = e._zod.bag.maximum ?? Infinity;
		t.maximum < n && (e._zod.bag.maximum = t.maximum);
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length;
		if ((typeof r == "string" && i > t.maximum ? Ge(r) : i) <= t.maximum) return;
		let a = Ke(r);
		n.issues.push({
			origin: a,
			code: "too_big",
			maximum: t.maximum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), En = /*@__PURE__*/ N("$ZodCheckMinLength", (e, t) => {
	var n;
	I.init(e, t), (n = e._zod.def).when ?? (n.when = yn), e._zod.onattach.push((e) => {
		let n = e._zod.bag.minimum ?? -Infinity;
		t.minimum > n && (e._zod.bag.minimum = t.minimum);
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length;
		if ((typeof r == "string" && i >= t.minimum && i < t.minimum * 2 ? Ge(r) : i) >= t.minimum) return;
		let a = Ke(r);
		n.issues.push({
			origin: a,
			code: "too_small",
			minimum: t.minimum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), Dn = /*@__PURE__*/ N("$ZodCheckLengthEquals", (e, t) => {
	var n;
	I.init(e, t), (n = e._zod.def).when ?? (n.when = yn), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.minimum = t.length, n.maximum = t.length, n.length = t.length;
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length, a = typeof r == "string" && i >= t.length && i <= t.length * 2 ? Ge(r) : i;
		if (a === t.length) return;
		let o = Ke(r), s = a > t.length;
		n.issues.push({
			origin: o,
			...s ? {
				code: "too_big",
				maximum: t.length
			} : {
				code: "too_small",
				minimum: t.length
			},
			inclusive: !0,
			exact: !0,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), On = /*@__PURE__*/ N("$ZodCheckStringFormat", (e, t) => {
	var n, r;
	I.init(e, t), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.format = t.format, t.pattern && (n.patterns ??= /* @__PURE__ */ new Set(), n.patterns.add(t.pattern));
	}), t.pattern ? (n = e._zod).check ?? (n.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: t.format,
			input: n.value,
			...t.pattern ? { pattern: t.pattern.toString() } : {},
			inst: e,
			continue: !t.abort
		});
	}) : (r = e._zod).check ?? (r.check = () => {});
}), kn = /*@__PURE__*/ N("$ZodCheckRegex", (e, t) => {
	On.init(e, t), e._zod.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "regex",
			input: n.value,
			pattern: t.pattern.toString(),
			inst: e,
			continue: !t.abort
		});
	};
}), An = /*@__PURE__*/ N("$ZodCheckLowerCase", (e, t) => {
	t.pattern ??= _n, On.init(e, t);
}), jn = /*@__PURE__*/ N("$ZodCheckUpperCase", (e, t) => {
	t.pattern ??= vn, On.init(e, t);
}), Mn = /*@__PURE__*/ N("$ZodCheckIncludes", (e, t) => {
	I.init(e, t);
	let n = k(t.includes), r = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
	t.pattern = r, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(r);
	}), e._zod.check = (n) => {
		n.value.includes(t.includes, t.position) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "includes",
			includes: t.includes,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Nn = /*@__PURE__*/ N("$ZodCheckStartsWith", (e, t) => {
	I.init(e, t);
	let n = RegExp(`^${k(t.prefix)}.*`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.startsWith(t.prefix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "starts_with",
			prefix: t.prefix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Pn = /*@__PURE__*/ N("$ZodCheckEndsWith", (e, t) => {
	I.init(e, t);
	let n = RegExp(`.*${k(t.suffix)}$`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.endsWith(t.suffix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "ends_with",
			suffix: t.suffix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Fn = /*@__PURE__*/ N("$ZodCheckOverwrite", (e, t) => {
	I.init(e, t), e._zod.check = (e) => {
		e.value = t.tx(e.value);
	};
}), In = class {
	constructor(e = [], t = {}) {
		this.content = [], this.indent = 0, this.args = e, this.closed = t;
	}
	indented(e) {
		this.indent += 1, e(this), --this.indent;
	}
	write(e) {
		if (typeof e == "function") {
			e(this, { execution: "sync" }), e(this, { execution: "async" });
			return;
		}
		let t = e.split("\n").filter((e) => e), n = Math.min(...t.map((e) => e.length - e.trimStart().length)), r = t.map((e) => e.slice(n)).map((e) => " ".repeat(this.indent * 2) + e);
		for (let e of r) this.content.push(e);
	}
	compile() {
		let e = Function, t = this?.content ?? [""];
		return new e(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {\n${t.join("\n")}\n};`)(...Object.values(this.closed));
	}
}, Ln = {
	major: 4,
	minor: 5,
	patch: 4
}, L = /*@__PURE__*/ N("$ZodType", (e, t) => {
	var n;
	e ??= {}, e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Ln;
	let r = e._zod.def.checks, i = e._zod.traits.has("$ZodCheck") ? [e, ...r ?? []] : r?.length ? [...r] : [];
	for (let t of i) for (let n of t._zod.onattach) n(e);
	if (i.length === 0) (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
		e._zod.run = e._zod.parse;
	});
	else {
		let t = (t, n, r) => {
			if (t.memo) return t;
			let i = Re(t), a;
			for (let o of n) {
				if (o._zod.def.when) {
					if (ze(t) || !o._zod.def.when(t)) continue;
				} else if (i) continue;
				let n = t.issues.length, s = o._zod.check(t);
				if (s instanceof Promise && r?.async === !1) throw new ut();
				if (a || s instanceof Promise) a = (a ?? Promise.resolve()).then(async () => {
					await s, t.issues.length !== n && (He(t.issues, n, e), i ||= Re(t, n));
				});
				else {
					if (t.issues.length === n) continue;
					He(t.issues, n, e), i ||= Re(t, n);
				}
			}
			return a ? a.then(() => t) : t;
		}, n = (n, r, a) => {
			if (Re(n)) return n.aborted = !0, n;
			let o = t(r, i, a);
			if (o instanceof Promise) {
				if (a.async === !1) throw new ut();
				return o.then((t) => e._zod.parse(t, a));
			}
			return e._zod.parse(o, a);
		};
		e._zod.run = (r, a) => {
			if (a.skipChecks) return e._zod.parse(r, a);
			if (a.direction === "backward") {
				let t = e._zod.parse({
					value: r.value,
					issues: []
				}, {
					...a,
					skipChecks: !0
				});
				return t instanceof Promise ? t.then((e) => n(e, r, a)) : n(t, r, a);
			}
			let o = e._zod.parse(r, a);
			if (o instanceof Promise) {
				if (a.async === !1) throw new ut();
				return o.then((e) => t(e, i, a));
			}
			return t(o, i, a);
		};
	}
}, {
	get "~standard"() {
		return Ze(this, "~standard", zn(this));
	},
	set "~standard"(e) {
		Xe(this, "~standard", e);
	}
}), Rn = (e) => e.success ? { value: e.data } : { issues: e.error?.issues };
function zn(e) {
	return {
		validate: (t) => {
			try {
				return Rn(Ot(e, t));
			} catch {
				return At(e, t).then(Rn);
			}
		},
		vendor: "zod",
		version: 1
	};
}
var Bn = /*@__PURE__*/ N("$ZodString", (e, t) => {
	L.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? pn(e._zod.bag), e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = String(n.value);
		} catch {}
		return typeof n.value == "string" || n.issues.push({
			expected: "string",
			code: "invalid_type",
			input: n.value,
			inst: e
		}), n;
	};
}), R = /*@__PURE__*/ N("$ZodStringFormat", (e, t) => {
	On.init(e, t), Bn.init(e, t);
}), Vn = /*@__PURE__*/ N("$ZodGUID", (e, t) => {
	t.pattern ??= qt, R.init(e, t);
}), Hn = /*@__PURE__*/ N("$ZodUUID", (e, t) => {
	if (t.version) {
		let e = {
			v1: 1,
			v2: 2,
			v3: 3,
			v4: 4,
			v5: 5,
			v6: 6,
			v7: 7,
			v8: 8
		}[t.version];
		if (e === void 0) throw Error(`Invalid UUID version: "${t.version}"`);
		t.pattern ??= Jt(e);
	} else t.pattern ??= Jt();
	R.init(e, t);
}), Un = /*@__PURE__*/ N("$ZodEmail", (e, t) => {
	t.pattern ??= Yt, R.init(e, t);
});
function Wn(e, t) {
	if (!t.normalize && t.protocol?.source === an.source && !/^https?:\/\//i.test(e)) return 1;
	try {
		return new URL(e);
	} catch {
		return 2;
	}
}
var Gn = /[\t\n\r]/g;
function Kn(e) {
	return e.replace(Gn, "");
}
function qn(e, t) {
	return t.lastIndex = 0, t.test(e.hostname);
}
function Jn(e, t) {
	return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
var Yn = /*@__PURE__*/ N("$ZodURL", (e, t) => {
	R.init(e, t), e._zod.check = (n) => {
		try {
			let r = n.value.trim(), i = Wn(r, t);
			if (i === 1) {
				n.issues.push({
					code: "invalid_format",
					format: "url",
					note: "Invalid URL format",
					input: n.value,
					inst: e,
					continue: !t.abort
				});
				return;
			}
			if (i === 2) {
				n.issues.push({
					code: "invalid_format",
					format: "url",
					input: n.value,
					inst: e,
					continue: !t.abort
				});
				return;
			}
			t.hostname && !qn(i, t.hostname) && n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid hostname",
				pattern: t.hostname.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			}), t.protocol && !Jn(i, t.protocol) && n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid protocol",
				pattern: t.protocol.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			}), n.value = t.normalize ? i.href : Kn(r);
			return;
		} catch {
			n.issues.push({
				code: "invalid_format",
				format: "url",
				input: n.value,
				inst: e,
				continue: !t.abort
			});
		}
	};
}), Xn = /*@__PURE__*/ N("$ZodEmoji", (e, t) => {
	t.pattern ??= Zt(), R.init(e, t);
}), Zn = /*@__PURE__*/ N("$ZodNanoID", (e, t) => {
	if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1)) throw Error(`Invalid nanoid length: ${t.length}`);
	t.pattern ??= t.length === void 0 ? Wt : Gt(t.length), R.init(e, t);
}), Qn = /*@__PURE__*/ N("$ZodCUID", (e, t) => {
	t.pattern ??= zt, R.init(e, t);
}), $n = /*@__PURE__*/ N("$ZodCUID2", (e, t) => {
	t.pattern ??= Bt, R.init(e, t);
}), er = /*@__PURE__*/ N("$ZodULID", (e, t) => {
	t.pattern ??= Vt, R.init(e, t);
}), tr = /*@__PURE__*/ N("$ZodXID", (e, t) => {
	t.pattern ??= Ht, R.init(e, t);
}), nr = /*@__PURE__*/ N("$ZodKSUID", (e, t) => {
	t.pattern ??= Ut, R.init(e, t);
}), rr = /*@__PURE__*/ N("$ZodISODateTime", (e, t) => {
	t.pattern ??= fn(t), R.init(e, t), (t.local || t.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((e) => {
		e._zod.bag.laxFormat = !0;
	}));
}), ir = /*@__PURE__*/ N("$ZodISODate", (e, t) => {
	t.pattern ??= ln, R.init(e, t);
}), ar = /*@__PURE__*/ N("$ZodISOTime", (e, t) => {
	t.pattern ??= dn(t), R.init(e, t);
}), or = /*@__PURE__*/ N("$ZodISODuration", (e, t) => {
	t.pattern ??= Kt, R.init(e, t);
}), sr = /*@__PURE__*/ N("$ZodIPv4", (e, t) => {
	t.pattern ??= Qt, R.init(e, t), e._zod.bag.format = "ipv4";
}), cr = /^[0-9a-fA-F:.]+$/;
function lr(e) {
	if (!cr.test(e)) return !1;
	try {
		return new URL(`http://[${e}]`), !0;
	} catch {
		return !1;
	}
}
var ur = /*@__PURE__*/ N("$ZodIPv6", (e, t) => {
	t.pattern ??= $t, R.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
		lr(n.value) || n.issues.push({
			code: "invalid_format",
			format: "ipv6",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), dr = /*@__PURE__*/ N("$ZodCIDRv4", (e, t) => {
	t.pattern ??= en, R.init(e, t);
});
function fr(e) {
	let t = e.split("/");
	if (t.length !== 2) return !1;
	let [n, r] = t;
	if (!r) return !1;
	let i = Number(r);
	return `${i}` !== r || i < 0 || i > 128 ? !1 : lr(n);
}
var pr = /*@__PURE__*/ N("$ZodCIDRv6", (e, t) => {
	t.pattern ??= tn, R.init(e, t), e._zod.check = (n) => {
		fr(n.value) || n.issues.push({
			code: "invalid_format",
			format: "cidrv6",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function mr(e) {
	if (e === "") return !0;
	if (/\s/.test(e) || e.length % 4 != 0) return !1;
	try {
		return atob(e), !0;
	} catch {
		return !1;
	}
}
var hr = /*@__PURE__*/ N("$ZodBase64", (e, t) => {
	t.pattern ??= nn, R.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
		mr(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function gr(e) {
	if (!rn.test(e)) return !1;
	let t = e.replace(/[-_]/g, (e) => e === "-" ? "+" : "/");
	return mr(t.padEnd(Math.ceil(t.length / 4) * 4, "="));
}
var _r = /*@__PURE__*/ N("$ZodBase64URL", (e, t) => {
	t.pattern ??= rn, R.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
		gr(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64url",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), vr = /*@__PURE__*/ N("$ZodE164", (e, t) => {
	t.pattern ??= on, R.init(e, t);
});
function yr(e, t = null) {
	try {
		let n = e.split(".");
		if (n.length !== 3) return !1;
		let [r] = n;
		if (!r) return !1;
		let i = JSON.parse(atob(r));
		return !("typ" in i && i?.typ !== "JWT" || !i.alg || t && (!("alg" in i) || i.alg !== t));
	} catch {
		return !1;
	}
}
var br = /*@__PURE__*/ N("$ZodJWT", (e, t) => {
	R.init(e, t), e._zod.check = (n) => {
		yr(n.value, t.alg) || n.issues.push({
			code: "invalid_format",
			format: "jwt",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), xr = /*@__PURE__*/ N("$ZodNumber", (e, t) => {
	L.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? hn, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = Number(n.value);
		} catch {}
		let i = n.value;
		if (typeof i == "number" && !Number.isNaN(i) && Number.isFinite(i)) return n;
		let a = typeof i == "number" ? Number.isNaN(i) ? "NaN" : Number.isFinite(i) ? void 0 : String(i) : void 0;
		return n.issues.push({
			expected: "number",
			code: "invalid_type",
			input: i,
			inst: e,
			...a ? { received: a } : {}
		}), n;
	};
}), Sr = /*@__PURE__*/ N("$ZodNumberFormat", (e, t) => {
	wn.init(e, t), xr.init(e, t);
}), Cr = /*@__PURE__*/ N("$ZodBoolean", (e, t) => {
	L.init(e, t), e._zod.pattern = gn, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = !!n.value;
		} catch {}
		let i = n.value;
		return typeof i == "boolean" || n.issues.push({
			expected: "boolean",
			code: "invalid_type",
			input: i,
			inst: e
		}), n;
	};
}), wr = /*@__PURE__*/ N("$ZodUnknown", (e, t) => {
	L.init(e, t), e._zod.parse = (e) => e;
}), Tr = /*@__PURE__*/ N("$ZodNever", (e, t) => {
	L.init(e, t), e._zod.parse = (t, n) => (t.issues.push({
		expected: "never",
		code: "invalid_type",
		input: t.value,
		inst: e
	}), t);
});
function Er(e, t, n) {
	e.issues.length && t.issues.push(...Be(n, e.issues)), t.value[n] = e.value;
}
var Dr = /*@__PURE__*/ N("$ZodArray", (e, t) => {
	L.init(e, t);
	let n = P.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!Array.isArray(a)) return r.issues.push({
			expected: "array",
			code: "invalid_type",
			input: a,
			inst: e
		}), r;
		r.value = n ? n.alloc(e, r, Array(a.length), i) : Array(a.length);
		let o = [];
		for (let e = 0; e < a.length; e++) {
			let n = a[e], s = t.element._zod.run({
				value: n,
				issues: []
			}, i);
			s instanceof Promise ? o.push(s.then((t) => Er(t, r, e))) : Er(s, r, e);
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
});
function Or(e, t, n, r, i, a) {
	let o = n in r, s = a === "optional";
	if (o || !s || i !== "optional") {
		if (e.issues.length) {
			if (i !== void 0 && s && !o) return;
			t.issues.push(...Be(n, e.issues));
		}
		if (!o && i === void 0) {
			e.issues.length || t.issues.push({
				code: "invalid_type",
				expected: "nonoptional",
				input: void 0,
				path: [n]
			});
			return;
		}
		e.value === void 0 ? o && (t.value[n] = void 0) : t.value[n] = e.value;
	}
}
var kr = [];
function Ar(e) {
	let t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), r = n.length ? n : kr, i = r.length ? [...t, ...r] : t;
	for (let t of i) if (!e.shape?.[t]?._zod?.traits?.has("$ZodType")) throw Error(`Invalid element at key "${String(t)}": expected a Zod schema`);
	let a = ke(e.shape);
	return {
		...e,
		allKeys: i,
		symbolKeys: r,
		keySet: new Set(t),
		numKeys: t.length,
		optionalKeys: new Set(a)
	};
}
function jr(e, t, n, r, i, a) {
	let o = [], s = i.keySet, c = i.catchall._zod, l = c.def.type, u = c.optin, d = c.optout;
	for (let i in t) {
		if (s.has(i)) continue;
		if (i === "__proto__") {
			l === "never" && o.push(i);
			continue;
		}
		if (l === "never") {
			o.push(i);
			continue;
		}
		let a = c.run({
			value: t[i],
			issues: []
		}, r);
		a instanceof Promise ? e.push(a.then((e) => Or(e, n, i, t, u, d))) : Or(a, n, i, t, u, d);
	}
	return o.length && n.issues.push({
		code: "unrecognized_keys",
		keys: o,
		input: t,
		inst: a,
		continue: !0
	}), e.length ? Promise.all(e).then(() => n) : n;
}
var Mr = /* @__PURE__ */ new WeakMap(), Nr = /*@__PURE__*/ N("$ZodObject", (e, t) => {
	if (L.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
		let e = t.shape;
		Mr.set(t, e), Object.defineProperty(t, "shape", { get: () => {
			let n = { ...e };
			return Object.defineProperty(t, "shape", { value: n }), Mr.set(t, n), n;
		} });
	}
	let n = _e(() => Ar(t));
	M(e, "propValues", (e) => {
		let t = e.def.shape, n = {};
		for (let e in t) {
			let r = t[e]._zod;
			if (r.values) {
				Object.prototype.hasOwnProperty.call(n, e) || E(n, e, /* @__PURE__ */ new Set());
				for (let t of r.values) n[e].add(t);
				r.optin !== void 0 && n[e].add(void 0);
			}
		}
		return n;
	});
	let r = we, i = t.catchall, a, o = P.memoizer;
	o?.attach(e), e._zod.parse = (t, s) => {
		a ??= n.value;
		let c = t.value;
		if (!r(c)) return t.issues.push({
			expected: "object",
			code: "invalid_type",
			input: c,
			inst: e
		}), t;
		t.value = o ? o.alloc(e, t, {}, s) : {};
		let l = [], u = a.shape;
		for (let e of a.allKeys) {
			if (e === "__proto__") continue;
			let n = u[e], r = n._zod.optin, i = n._zod.optout, a = n._zod.run({
				value: c[e],
				issues: []
			}, s);
			a instanceof Promise ? l.push(a.then((n) => Or(n, t, e, c, r, i))) : Or(a, t, e, c, r, i);
		}
		return i ? jr(l, c, t, s, n.value, e) : l.length ? Promise.all(l).then(() => t) : t;
	};
}), Pr = /*@__PURE__*/ N("$ZodObjectJIT", (e, t) => {
	Nr.init(e, t);
	let n = e._zod.parse, r = _e(() => Ar(t)), i = P.memoizer, a = (t) => {
		let n = r.value, a = n.symbolKeys, o = new In(["payload", "ctx"], {
			shape: t,
			inst: e,
			memo: i,
			syms: a
		}), s = (e) => `shape[${e}]._zod.run({ value: input[${e}], issues: [] }, ctx)`, c = (e, t) => `
          for (let i = 0; i < ${e}.issues.length; i++) {
            const iss = ${e}.issues[i];
            iss.path = iss.path ? [${t}, ...iss.path] : [${t}];
            payload.issues.push(iss);
          }`;
		o.write("const input = payload.value;");
		let l = Object.create(null), u = 0;
		for (let e of n.allKeys) l[e] = `key_${u++}`;
		o.write(i ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
		for (let e of n.allKeys) {
			if (e === "__proto__") continue;
			let n = l[e], r = typeof e == "symbol" ? `syms[${a.indexOf(e)}]` : xe(e), i = `${r} in input`, u = t[e], d = u?._zod?.optin, f = d !== void 0, p = u?._zod?.optout === "optional";
			if (o.write(`const ${n} = ${s(r)};`), f && p) {
				let e = d === "optional" ? `${n}_present` : `${n}.value !== undefined || ${n}_present`;
				o.write(`
        const ${n}_present = ${i};
        if (!${n}.issues.length || ${n}_present) {
          if (${n}.issues.length) {${c(n, r)}
          }

          if (${e}) {
            newResult[${r}] = ${n}.value;
          }
        }

      `);
			} else f ? o.write(`
        if (${n}.issues.length) {${c(n, r)}
        }
        
        if (${n}.value === undefined) {
          if (${i}) {
            newResult[${r}] = undefined;
          }
        } else {
          newResult[${r}] = ${n}.value;
        }

      `) : o.write(`
        const ${n}_present = ${i};
        if (${n}.issues.length) {${c(n, r)}
        }
        if (!${n}_present && !${n}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${r}]
          });
        }

        if (${n}_present) {
          newResult[${r}] = ${n}.value;
        }

      `);
		}
		return o.write("payload.value = newResult;"), o.write("return payload;"), o.compile();
	}, o, s = we, c = !P.jitless, l = c && Te.value, u = t.catchall, d;
	e._zod.parse = (i, f) => {
		d ??= r.value;
		let p = i.value;
		return s(p) ? c && l && f?.async === !1 && f.jitless !== !0 ? (o ||= a(t.shape), i = o(i, f), u ? jr([], p, i, f, d, e) : i) : n(i, f) : (i.issues.push({
			expected: "object",
			code: "invalid_type",
			input: p,
			inst: e
		}), i);
	};
});
function Fr(e, t, n, r) {
	for (let n of e) if (n.issues.length === 0) return t.value = n.value, t;
	let i = e.filter((e) => !Re(e));
	return i.length === 1 ? (t.value = i[0].value, i[0]) : (t.issues.push({
		code: "invalid_union",
		input: t.value,
		inst: n,
		errors: e.map((e) => e.issues.map((e) => Ue(e, r, F())))
	}), t);
}
var Ir = /*@__PURE__*/ N("$ZodUnion", (e, t) => {
	L.init(e, t), M(e, "optin", (e) => e.def.options.some((e) => e._zod.optin === "defaulted") ? "defaulted" : e.def.options.some((e) => e._zod.optin !== void 0) ? "optional" : void 0), M(e, "optout", (e) => e.def.options.some((e) => e._zod.optout === "optional") ? "optional" : void 0), M(e, "values", (e) => {
		if (e.def.options.every((e) => e._zod.values)) return new Set(e.def.options.flatMap((e) => Array.from(e._zod.values)));
	}), M(e, "pattern", (e) => {
		if (e.def.options.every((e) => e._zod.pattern)) {
			let t = e.def.options.map((e) => e._zod.pattern);
			return RegExp(`^(${t.map((e) => ye(e.source)).join("|")})$`);
		}
	});
	let n = t.options.length === 1 ? t.options[0]._zod.run : null;
	e._zod.parse = (r, i) => {
		if (n) return n(r, i);
		let a = !1, o = [];
		for (let e of t.options) {
			let t = e._zod.run({
				value: r.value,
				issues: []
			}, i);
			if (t instanceof Promise) o.push(t), a = !0;
			else {
				if (t.issues.length === 0) return t;
				o.push(t);
			}
		}
		return a ? Promise.all(o).then((t) => Fr(t, r, e, i)) : Fr(o, r, e, i);
	};
}), Lr = /*@__PURE__*/ N("$ZodIntersection", (e, t) => {
	L.init(e, t), e._zod.parse = (e, n) => {
		let r = e.value, i = t.left._zod.run({
			value: r,
			issues: []
		}, n), a = t.right._zod.run({
			value: r,
			issues: []
		}, n);
		return i instanceof Promise || a instanceof Promise ? Promise.all([i, a]).then(([t, n]) => zr(e, t, n)) : zr(e, i, a);
	};
});
function Rr(e, t) {
	if (e === t || e instanceof Date && t instanceof Date && +e == +t) return {
		valid: !0,
		data: e
	};
	if (O(e) && O(t)) {
		let n = Object.keys(t), r = Object.keys(e).filter((e) => n.indexOf(e) !== -1), i = {
			...e,
			...t
		};
		Object.prototype.hasOwnProperty.call(i, "__proto__") && delete i.__proto__;
		for (let n of r) {
			if (n === "__proto__") continue;
			let r = Rr(e[n], t[n]);
			if (!r.valid) return {
				valid: !1,
				mergeErrorPath: [n, ...r.mergeErrorPath]
			};
			i[n] = r.data;
		}
		return {
			valid: !0,
			data: i
		};
	}
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return {
			valid: !1,
			mergeErrorPath: []
		};
		let n = [];
		for (let r = 0; r < e.length; r++) {
			let i = e[r], a = t[r], o = Rr(i, a);
			if (!o.valid) return {
				valid: !1,
				mergeErrorPath: [r, ...o.mergeErrorPath]
			};
			n.push(o.data);
		}
		return {
			valid: !0,
			data: n
		};
	}
	return {
		valid: !1,
		mergeErrorPath: []
	};
}
function zr(e, t, n) {
	let r = /* @__PURE__ */ new Map(), i, a = /* @__PURE__ */ new Map(), o = (e, t) => {
		let n;
		if (e.code === "unrecognized_keys" && !e.path?.length) i ??= e, n = e.keys;
		else if (e.code === "invalid_key" && e.origin === "record" && e.path?.length === 1) {
			let t = String(e.path[0]);
			a.has(t) || a.set(t, e), n = [t];
		} else return !1;
		for (let e of n) r.has(e) || r.set(e, {}), r.get(e)[t] = !0;
		return !0;
	};
	for (let n of t.issues) o(n, "l") || e.issues.push(n);
	for (let t of n.issues) o(t, "r") || e.issues.push(t);
	let s = [...r].filter(([, e]) => e.l && e.r).map(([e]) => e);
	if (s.length) {
		let t = i ? s.filter((e) => i.keys.includes(e)) : [];
		t.length && e.issues.push({
			...i,
			keys: t
		});
		for (let n of s) !t.includes(n) && a.has(n) && e.issues.push(a.get(n));
	}
	let c = Rr(t.value, n.value);
	if (!c.valid) {
		if (Re(e)) return e;
		throw Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
	}
	return e.value = c.data, e;
}
var Br = /*@__PURE__*/ N("$ZodRecord", (e, t) => {
	L.init(e, t);
	let n = P.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!O(a)) return r.issues.push({
			expected: "record",
			code: "invalid_type",
			input: a,
			inst: e
		}), r;
		let o = [], s = t.keyType._zod.values;
		if (s && !t.partial) {
			r.value = n ? n.alloc(e, r, {}, i) : {};
			let c = /* @__PURE__ */ new Set();
			for (let n of s) if (typeof n == "string" || typeof n == "number" || typeof n == "symbol") {
				if (c.add(typeof n == "number" ? n.toString() : n), n === "__proto__") continue;
				let s = t.keyType._zod.run({
					value: n,
					issues: []
				}, i);
				if (s instanceof Promise) throw Error("Async schemas not supported in object keys currently");
				if (s.issues.length) {
					r.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: s.issues.map((e) => Ue(e, i, F())),
						input: n,
						path: [n],
						inst: e
					});
					continue;
				}
				let l = s.value;
				if (l === "__proto__") continue;
				let u = t.valueType._zod.run({
					value: a[n],
					issues: []
				}, i);
				u instanceof Promise ? o.push(u.then((e) => {
					e.issues.length && r.issues.push(...Be(n, e.issues)), r.value[l] = e.value;
				})) : (u.issues.length && r.issues.push(...Be(n, u.issues)), r.value[l] = u.value);
			}
			let l;
			for (let e in a) if (!c.has(e)) {
				if (t.mode === "loose") {
					if (e === "__proto__") continue;
					r.value[e] = a[e];
				} else l ??= [], l.push(e);
			}
			l && l.length > 0 && r.issues.push({
				code: "unrecognized_keys",
				input: a,
				inst: e,
				keys: l,
				continue: !0
			});
		} else {
			r.value = n ? n.alloc(e, r, {}, i) : {};
			let c;
			for (let n of Reflect.ownKeys(a)) {
				if (n === "__proto__" || !Object.prototype.propertyIsEnumerable.call(a, n)) continue;
				let l = t.keyType._zod.run({
					value: n,
					issues: []
				}, i);
				if (l instanceof Promise) throw Error("Async schemas not supported in object keys currently");
				if (typeof n == "string" && hn.test(n) && l.issues.length) {
					let e = t.keyType._zod.run({
						value: Number(n),
						issues: []
					}, i);
					if (e instanceof Promise) throw Error("Async schemas not supported in object keys currently");
					e.issues.length === 0 && (l = e);
				}
				if (l.issues.length) {
					t.mode === "loose" ? r.value[n] = a[n] : s ? (c ??= [], c.push(n)) : r.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: l.issues.map((e) => Ue(e, i, F())),
						input: n,
						path: [n],
						inst: e
					});
					continue;
				}
				let u = l.value;
				if (u === "__proto__") continue;
				let d = t.valueType._zod.run({
					value: a[n],
					issues: []
				}, i);
				d instanceof Promise ? o.push(d.then((e) => {
					e.issues.length && r.issues.push(...Be(n, e.issues)), r.value[u] = e.value;
				})) : (d.issues.length && r.issues.push(...Be(n, d.issues)), r.value[u] = d.value);
			}
			c && c.length > 0 && r.issues.push({
				code: "unrecognized_keys",
				input: a,
				inst: e,
				keys: c,
				continue: !0
			});
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
}), Vr = /*@__PURE__*/ N("$ZodEnum", (e, t) => {
	L.init(e, t);
	let n = he(t.entries), r = new Set(n);
	e._zod.values = r;
	let i = n.filter((e) => De.has(typeof e));
	e._zod.pattern = RegExp(i.length ? `^(${i.map((e) => k(e.toString())).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (t, i) => {
		let a = t.value;
		return r.has(a) || t.issues.push({
			code: "invalid_value",
			values: n,
			input: a,
			inst: e
		}), t;
	};
}), Hr = /*@__PURE__*/ N("$ZodLiteral", (e, t) => {
	L.init(e, t);
	let n = new Set(t.values);
	e._zod.values = n, e._zod.pattern = RegExp(t.values.length ? `^(${t.values.map((e) => typeof e == "string" ? k(e) : e ? k(e.toString()) : String(e)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (r, i) => {
		let a = r.value;
		return n.has(a) || r.issues.push({
			code: "invalid_value",
			values: t.values,
			input: a,
			inst: e
		}), r;
	};
}), Ur = /*@__PURE__*/ N("$ZodTransform", (e, t) => {
	L.init(e, t), e._zod.optin = "optional", P.memoizer?.guard(e), e._zod.parse = (n, r) => {
		if (r.direction === "backward") throw new dt(e.constructor.name);
		let i = t.transform(n.value, n);
		if (r.async) return (i instanceof Promise ? i : Promise.resolve(i)).then((e) => (n.value = e, n));
		if (i instanceof Promise) throw new ut();
		return n.value = i, n;
	};
});
function Wr(e, t) {
	return e.value = t.issues.length ? void 0 : t.value, e;
}
var Gr = /*@__PURE__*/ N("$ZodOptional", (e, t) => {
	L.init(e, t), M(e, "optin", (e) => e.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", M(e, "values", (e) => {
		let t = e.def.innerType._zod.values;
		return t ? /* @__PURE__ */ new Set([...t, void 0]) : void 0;
	}), M(e, "pattern", (e) => {
		let t = e.def.innerType._zod.pattern;
		return t ? RegExp(`^(${ye(t.source)})?$`) : void 0;
	}), e._zod.parse = (e, n) => {
		if (e.value === void 0) {
			if (t.innerType._zod.optin !== "defaulted") return e;
			let r = t.innerType._zod.run({
				value: e.value,
				issues: []
			}, n);
			return r instanceof Promise ? r.then((t) => Wr(e, t)) : Wr(e, r);
		}
		return t.innerType._zod.run(e, n);
	};
}), Kr = /*@__PURE__*/ N("$ZodExactOptional", (e, t) => {
	Gr.init(e, t), M(e, "values", (e) => e.def.innerType._zod.values), M(e, "pattern", (e) => e.def.innerType._zod.pattern), e._zod.parse = (e, n) => t.innerType._zod.run(e, n);
}), qr = /*@__PURE__*/ N("$ZodNullable", (e, t) => {
	L.init(e, t), M(e, "optin", (e) => e.def.innerType._zod.optin), M(e, "optout", (e) => e.def.innerType._zod.optout), M(e, "pattern", (e) => {
		let t = e.def.innerType._zod.pattern;
		return t ? RegExp(`^(${ye(t.source)}|null)$`) : void 0;
	}), M(e, "values", (e) => e.def.innerType._zod.values ? /* @__PURE__ */ new Set([...e.def.innerType._zod.values, null]) : void 0), e._zod.parse = (e, n) => e.value === null ? e : t.innerType._zod.run(e, n);
}), Jr = /*@__PURE__*/ N("$ZodDefault", (e, t) => {
	L.init(e, t), e._zod.optin = "defaulted", M(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		if (e.value === void 0) return e.value = t.defaultValue, e;
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => Yr(e, t)) : Yr(r, t);
	};
});
function Yr(e, t) {
	return e.value === void 0 && (e.value = t.defaultValue), e;
}
var Xr = /*@__PURE__*/ N("$ZodPrefault", (e, t) => {
	L.init(e, t), e._zod.optin = "defaulted", M(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => (n.direction === "backward" || e.value === void 0 && (e.value = t.defaultValue), t.innerType._zod.run(e, n));
}), Zr = /*@__PURE__*/ N("$ZodNonOptional", (e, t) => {
	L.init(e, t), M(e, "values", (e) => {
		let t = e.def.innerType._zod.values;
		return t ? new Set([...t].filter((e) => e !== void 0)) : void 0;
	}), e._zod.parse = (n, r) => {
		let i = t.innerType._zod.run(n, r);
		return i instanceof Promise ? i.then((t) => Qr(t, e)) : Qr(i, e);
	};
});
function Qr(e, t) {
	return !e.issues.length && e.value === void 0 && e.issues.push({
		code: "invalid_type",
		expected: "nonoptional",
		input: e.value,
		inst: t
	}), e;
}
function $r(e, t, n, r) {
	return t.issues.length ? (e.value = n.catchValue({
		...t,
		value: e.value,
		error: { issues: t.issues.map((e) => Ue(e, r, F())) },
		input: e.value
	}), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
var ei = /*@__PURE__*/ N("$ZodCatch", (e, t) => {
	L.init(e, t), M(e, "optin", (e) => e.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), M(e, "optout", (e) => e.def.innerType._zod.optout), M(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run({
			value: e.value,
			issues: []
		}, n);
		return r instanceof Promise ? r.then((r) => $r(e, r, t, n)) : $r(e, r, t, n);
	};
}), ti = /*@__PURE__*/ N("$ZodPipe", (e, t) => {
	L.init(e, t), M(e, "values", (e) => e.def.in._zod.values), M(e, "optin", (e) => e.def.in._zod.optin), M(e, "optout", (e) => e.def.out._zod.optout), M(e, "propValues", (e) => e.def.in._zod.propValues), e._zod.parse = (e, n) => {
		if (n.direction === "backward") {
			let r = t.out._zod.run(e, n);
			return r instanceof Promise ? r.then((e) => ni(e, t.in, n)) : ni(r, t.in, n);
		}
		let r = t.in._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => ni(e, t.out, n)) : ni(r, t.out, n);
	};
});
function ni(e, t, n) {
	return e.issues.some((e) => e.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({
		value: e.value,
		issues: e.issues
	}, n);
}
var ri = /*@__PURE__*/ N("$ZodReadonly", (e, t) => {
	L.init(e, t), M(e, "propValues", (e) => e.def.innerType._zod.propValues), M(e, "values", (e) => e.def.innerType._zod.values), M(e, "optin", (e) => e.def.innerType?._zod?.optin), M(e, "optout", (e) => e.def.innerType?._zod?.optout), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then(ii) : ii(r);
	};
});
function ii(e) {
	return e.memo || (e.value = Object.freeze(e.value)), e;
}
var ai = /*@__PURE__*/ N("$ZodCustom", (e, t) => {
	I.init(e, t), L.init(e, t), e._zod.parse = (e, t) => e, e._zod.check = (n) => {
		let r = n.value, i = t.fn(r);
		if (i instanceof Promise) return i.then((t) => oi(t, n, r, e));
		oi(i, n, r, e);
	};
});
function oi(e, t, n, r) {
	if (!e) {
		let e = {
			code: "custom",
			input: n,
			inst: r,
			path: [...r._zod.def.path ?? []],
			continue: !r._zod.def.abort
		};
		r._zod.def.params && (e.params = r._zod.def.params), t.issues.push(Je(e));
	}
}
//#endregion
//#region node_modules/zod/v4/core/memoizer.js
var si = class extends Error {
	constructor() {
		super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
	}
}, ci = "~memo", li = [];
function ui(e) {
	return e.map((e) => e.path ? {
		...e,
		path: e.path.slice()
	} : { ...e });
}
var di = /*@__PURE__*/ new WeakMap();
function fi(e, t) {
	let n = di.get(e);
	if (n !== void 0) return n;
	if (t.has(e)) return !0;
	t.add(e);
	let r = !1, i = (e) => {
		!r && e?._zod && fi(e, t) && (r = !0);
	}, a = e._zod.def;
	switch (a.type) {
		case "object":
			for (let e of Reflect.ownKeys(a.shape)) i(a.shape[e]);
			i(a.catchall);
			break;
		case "array":
			i(a.element);
			break;
		case "tuple":
			for (let e of a.items) i(e);
			i(a.rest);
			break;
		case "record":
		case "map":
			i(a.keyType), i(a.valueType);
			break;
		case "set":
			i(a.valueType);
			break;
		case "union":
			for (let e of a.options) i(e);
			break;
		case "intersection":
			i(a.left), i(a.right);
			break;
		case "optional":
		case "nullable":
		case "default":
		case "prefault":
		case "catch":
		case "readonly":
		case "nonoptional":
		case "promise":
		case "success":
			i(a.innerType);
			break;
		case "pipe":
			i(a.in), i(a.out);
			break;
		case "function":
			i(a.input), i(a.output);
			break;
		case "lazy":
			i(e._zod.innerType);
			break;
		case "template_literal":
		case "string":
		case "number":
		case "int":
		case "boolean":
		case "bigint":
		case "symbol":
		case "undefined":
		case "null":
		case "void":
		case "never":
		case "any":
		case "unknown":
		case "date":
		case "nan":
		case "enum":
		case "literal":
		case "file":
		case "transform":
		case "custom": break;
		default: for (let e in a) {
			let t = Object.getOwnPropertyDescriptor(a, e);
			if (!t || t.get) continue;
			let n = t.value;
			if (n && typeof n == "object") {
				if (n._zod) i(n);
				else if (Array.isArray(n)) for (let e of n) i(e);
			}
		}
	}
	return t.delete(e), di.set(e, r), r;
}
function pi(e, t) {
	let n = e.buckets.get(t);
	return n || (n = /* @__PURE__ */ new Map(), e.buckets.set(t, n)), n;
}
var mi, hi = [], gi = {
	alloc(e, t, n) {
		let r = mi;
		if (!r) return n;
		mi = void 0;
		let i = {
			value: n,
			issues: null
		};
		return r.set(t.value, i), hi.push(i), n;
	},
	guard(e) {
		var t;
		(t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
			let t = e._zod.parse, n = (e, n) => {
				if (n.direction !== "backward" && vi(n, e.value)) throw new si();
				return t(e, n);
			};
			e._zod.parse = n, e._zod.run === t && (e._zod.run = n);
		});
	},
	attach(e) {
		var t;
		let n, r, i;
		(t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
			let t = e._zod.parse, a = (o, s) => {
				if (n === void 0 && (n = fi(e, /* @__PURE__ */ new Set()), !n)) return e._zod.parse = t, e._zod.run === a && (e._zod.run = t), t(o, s);
				let c = o.value;
				if (typeof c != "object" || !c) return t(o, s);
				let l = s[ci];
				l || (l = {
					buckets: /* @__PURE__ */ new Map(),
					backEdges: void 0
				}, s[ci] = l);
				let u;
				r === s ? u = i : (u = pi(l, e), r = s, i = u);
				let d = u.get(c);
				if (d) return o.value = d.value, d.issues ? d.issues.length && o.issues.push(...ui(d.issues)) : (o.memo = !0, l.backEdges ?? (l.backEdges = /* @__PURE__ */ new Set()), l.backEdges.add(d.value)), o;
				mi = u;
				let f = hi.length, p = t(o, s);
				mi = void 0;
				let m = hi.length > f ? hi.pop() : void 0;
				return p instanceof Promise ? p.then((e) => (m && (m.issues = e.issues.length ? ui(e.issues) : li), e)) : (m && (m.issues = p.issues.length ? ui(p.issues) : li), p);
			};
			e._zod.parse = a, e._zod.run === t && (e._zod.run = a);
		});
	}
};
function _i() {
	return gi;
}
function vi(e, t) {
	let n = e[ci]?.backEdges;
	return n !== void 0 && typeof t == "object" && !!t && n.has(t);
}
//#endregion
//#region node_modules/zod/v4/locales/en.js
var yi = () => {
	let e = {
		string: {
			unit: "characters",
			verb: "to have"
		},
		file: {
			unit: "bytes",
			verb: "to have"
		},
		array: {
			unit: "items",
			verb: "to have"
		},
		set: {
			unit: "items",
			verb: "to have"
		},
		map: {
			unit: "entries",
			verb: "to have"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		credit_card: "credit card number",
		jwt: "JWT",
		template_literal: "input"
	}, r = { nan: "NaN" };
	function i(e, t) {
		return e === "number" && typeof t == "number" && !Number.isFinite(t) ? String(t) : r[e] ?? e;
	}
	return (e) => {
		switch (e.code) {
			case "invalid_type": return `Invalid input: expected ${i(e.expected)}, received ${i(qe(e.input), e.input)}`;
			case "invalid_value": return e.values.length === 1 ? `Invalid input: expected ${Oe(e.values[0])}` : `Invalid option: expected one of ${ge(e.values, "|")}`;
			case "too_big": {
				let n = e.exact ? "exactly " : e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Too big: expected ${e.origin ?? "value"} to have ${n}${e.maximum.toString()} ${r.unit ?? "elements"}` : `Too big: expected ${e.origin ?? "value"} to be ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.exact ? "exactly " : e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Too small: expected ${e.origin} to have ${n}${e.minimum.toString()} ${r.unit}` : `Too small: expected ${e.origin} to be ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Invalid string: must start with "${t.prefix}"` : t.format === "ends_with" ? `Invalid string: must end with "${t.suffix}"` : t.format === "includes" ? `Invalid string: must include "${t.includes}"` : t.format === "regex" ? `Invalid string: must match pattern ${t.pattern}` : `Invalid ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Invalid number: must be a multiple of ${e.divisor}`;
			case "unrecognized_keys": return `Unrecognized key${e.keys.length > 1 ? "s" : ""}: ${ge(e.keys, ", ")}`;
			case "invalid_key": return `Invalid key in ${e.origin}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `Invalid discriminator value. Expected ${e.options.map((e) => `'${e}'`).join(" | ")}` : e.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
			case "invalid_element": return `Invalid value in ${e.origin}`;
			default: return "Invalid input";
		}
	};
};
function bi() {
	return { localeError: yi() };
}
//#endregion
//#region node_modules/zod/v4/core/registries.js
var xi, Si = class {
	constructor() {
		this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
	}
	add(e, ...t) {
		let n = t[0];
		return this._map.set(e, n), n && typeof n == "object" && "id" in n && this._idmap.set(n.id, e), this;
	}
	clear() {
		return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
	}
	remove(e) {
		let t = this._map.get(e);
		return t && typeof t == "object" && "id" in t && this._idmap.delete(t.id), this._map.delete(e), this;
	}
	get(e) {
		let t = e._zod.parent;
		if (t) {
			let n = { ...this.get(t) ?? {} };
			delete n.id;
			let r = {
				...n,
				...this._map.get(e)
			};
			return Object.keys(r).length ? r : void 0;
		}
		return this._map.get(e);
	}
	has(e) {
		return this._map.has(e);
	}
};
function Ci() {
	return new Si();
}
(xi = globalThis).__zod_globalRegistry ?? (xi.__zod_globalRegistry = Ci());
var wi = globalThis.__zod_globalRegistry;
//#endregion
//#region node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function Ti(e, t) {
	return new e({
		type: "string",
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ei(e, t) {
	return new e({
		type: "string",
		format: "email",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Di(e, t) {
	return new e({
		type: "string",
		format: "guid",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Oi(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ki(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v4",
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ai(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v6",
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ji(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v7",
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Mi(e, t) {
	return new e({
		type: "string",
		format: "url",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ni(e, t) {
	return new e({
		type: "string",
		format: "emoji",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Pi(e, t) {
	return new e({
		type: "string",
		format: "nanoid",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Fi(e, t) {
	return new e({
		type: "string",
		format: "cuid",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ii(e, t) {
	return new e({
		type: "string",
		format: "cuid2",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Li(e, t) {
	return new e({
		type: "string",
		format: "ulid",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ri(e, t) {
	return new e({
		type: "string",
		format: "xid",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function zi(e, t) {
	return new e({
		type: "string",
		format: "ksuid",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Bi(e, t) {
	return new e({
		type: "string",
		format: "ipv4",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Vi(e, t) {
	return new e({
		type: "string",
		format: "ipv6",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Hi(e, t) {
	return new e({
		type: "string",
		format: "cidrv4",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ui(e, t) {
	return new e({
		type: "string",
		format: "cidrv6",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Wi(e, t) {
	return new e({
		type: "string",
		format: "base64",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Gi(e, t) {
	return new e({
		type: "string",
		format: "base64url",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ki(e, t) {
	return new e({
		type: "string",
		format: "e164",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function qi(e, t) {
	return new e({
		type: "string",
		format: "jwt",
		check: "string_format",
		abort: !1,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ji(e, t) {
	return new e({
		type: "string",
		format: "datetime",
		check: "string_format",
		offset: !1,
		local: !1,
		precision: null,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Yi(e, t) {
	return new e({
		type: "string",
		format: "date",
		check: "string_format",
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Xi(e, t) {
	return new e({
		type: "string",
		format: "time",
		check: "string_format",
		precision: null,
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Zi(e, t) {
	return new e({
		type: "string",
		format: "duration",
		check: "string_format",
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Qi(e, t) {
	return new e({
		type: "number",
		checks: [],
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function $i(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "safeint",
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ea(e, t) {
	return new e({
		type: "boolean",
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ta(e) {
	return new e({ type: "unknown" });
}
// @__NO_SIDE_EFFECTS__
function na(e, t) {
	return new e({
		type: "never",
		...j(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ra(e, t) {
	return new xn({
		check: "less_than",
		...j(t),
		value: e,
		inclusive: !1
	});
}
// @__NO_SIDE_EFFECTS__
function ia(e, t) {
	return new xn({
		check: "less_than",
		...j(t),
		value: e,
		inclusive: !0
	});
}
// @__NO_SIDE_EFFECTS__
function aa(e, t) {
	return new Sn({
		check: "greater_than",
		...j(t),
		value: e,
		inclusive: !1
	});
}
// @__NO_SIDE_EFFECTS__
function oa(e, t) {
	return new Sn({
		check: "greater_than",
		...j(t),
		value: e,
		inclusive: !0
	});
}
// @__NO_SIDE_EFFECTS__
function sa(e, t) {
	return new Cn({
		check: "multiple_of",
		...j(t),
		value: e
	});
}
// @__NO_SIDE_EFFECTS__
function ca(e, t) {
	return new Tn({
		check: "max_length",
		...j(t),
		maximum: e
	});
}
// @__NO_SIDE_EFFECTS__
function la(e, t) {
	return new En({
		check: "min_length",
		...j(t),
		minimum: e
	});
}
// @__NO_SIDE_EFFECTS__
function ua(e, t) {
	return new Dn({
		check: "length_equals",
		...j(t),
		length: e
	});
}
// @__NO_SIDE_EFFECTS__
function da(e, t) {
	return new kn({
		check: "string_format",
		format: "regex",
		...j(t),
		pattern: e
	});
}
// @__NO_SIDE_EFFECTS__
function fa(e) {
	return new An({
		check: "string_format",
		format: "lowercase",
		...j(e)
	});
}
// @__NO_SIDE_EFFECTS__
function pa(e) {
	return new jn({
		check: "string_format",
		format: "uppercase",
		...j(e)
	});
}
// @__NO_SIDE_EFFECTS__
function ma(e, t) {
	return new Mn({
		check: "string_format",
		format: "includes",
		...j(t),
		includes: e
	});
}
// @__NO_SIDE_EFFECTS__
function ha(e, t) {
	return new Nn({
		check: "string_format",
		format: "starts_with",
		...j(t),
		prefix: e
	});
}
// @__NO_SIDE_EFFECTS__
function ga(e, t) {
	return new Pn({
		check: "string_format",
		format: "ends_with",
		...j(t),
		suffix: e
	});
}
// @__NO_SIDE_EFFECTS__
function _a(e) {
	return new Fn({
		check: "overwrite",
		tx: e
	});
}
// @__NO_SIDE_EFFECTS__
function va(e) {
	return /* @__PURE__ */ _a((t) => t.normalize(e));
}
// @__NO_SIDE_EFFECTS__
function ya() {
	return /* @__PURE__ */ _a((e) => e.trim());
}
// @__NO_SIDE_EFFECTS__
function ba() {
	return /* @__PURE__ */ _a((e) => e.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function xa() {
	return /* @__PURE__ */ _a((e) => e.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function Sa() {
	return /* @__PURE__ */ _a((e) => Se(e));
}
// @__NO_SIDE_EFFECTS__
function Ca(e, t, n) {
	return new e({
		type: "array",
		element: t,
		...j(n)
	});
}
// @__NO_SIDE_EFFECTS__
function wa(e, t, n) {
	return new e({
		type: "custom",
		check: "custom",
		fn: t,
		...j(n)
	});
}
// @__NO_SIDE_EFFECTS__
function Ta(e, t) {
	let n = /* @__PURE__ */ Ea((t) => (t.addIssue = (e) => {
		if (typeof e == "string") t.issues.push(Je(e, t.value, n._zod.def));
		else {
			let r = e;
			r.fatal && (r.continue = !1), r.code ??= "custom", "input" in r || (r.input = t.value), r.inst ??= n, r.continue ??= !n._zod.def.abort, t.issues.push(Je(r));
		}
	}, e(t.value, t)), t);
	return n;
}
// @__NO_SIDE_EFFECTS__
function Ea(e, t) {
	let n = new I({
		check: "custom",
		...j(t)
	});
	return n._zod.check = e, n;
}
//#endregion
//#region node_modules/zod/v4/core/to-json-schema.js
function Da(e, ...t) {
	for (let n of t) for (let t of Reflect.ownKeys(n)) Object.prototype.propertyIsEnumerable.call(n, t) && E(e, t, n[t]);
	return e;
}
function Oa(e) {
	let t = e?.target ?? "draft-2020-12";
	return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
		processors: e.processors ?? {},
		metadataRegistry: e?.metadata ?? wi,
		target: t,
		unrepresentable: e?.unrepresentable ?? "throw",
		override: e?.override ?? (() => {}),
		io: e?.io ?? "output",
		counter: 0,
		seen: /* @__PURE__ */ new Map(),
		sharedDefsExtractedFor: void 0,
		sharedEmitDoneFor: void 0,
		cycles: e?.cycles ?? "ref",
		reused: e?.reused ?? "inline",
		intersections: [],
		deferred: [],
		external: e?.external ?? void 0
	};
}
function ka(e, t, n, r, i) {
	let a = typeof t.unrepresentable == "function" ? t.unrepresentable({
		zodSchema: e,
		path: r.path,
		message: i
	}) : t.unrepresentable;
	if (a === "any") return !1;
	if (a === void 0 || a === "throw") throw Error(i);
	return Object.assign(n, a), !0;
}
function z(e, t, n = {
	path: [],
	schemaPath: []
}) {
	var r;
	let i = e._zod.def, a = t.seen.get(e);
	if (a) return a.count++, n.schemaPath.includes(e) && (a.cycle = n.path), a.schema;
	let o = {
		schema: {},
		count: 1,
		cycle: void 0,
		path: n.path
	};
	t.seen.set(e, o), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
	let s = e._zod.toJSONSchema?.();
	if (s) o.schema = s;
	else {
		let r = {
			...n,
			schemaPath: [...n.schemaPath, e],
			path: n.path
		};
		if (e._zod.processJSONSchema) e._zod.processJSONSchema(t, o.schema, r);
		else {
			let n = o.schema, a = t.processors[i.type];
			if (!a) throw Error(`[toJSONSchema]: Non-representable type encountered: ${i.type}`);
			a(e, t, n, r);
		}
		let a = e._zod.parent;
		a && (o.ref ||= a, z(a, t, r), t.seen.get(a).isParent = !0);
	}
	let c = t.metadataRegistry.get(e);
	return c && Da(o.schema, c), t.io === "input" && B(e) && (delete o.schema.examples, delete o.schema.default), t.io === "input" && "_prefault" in o.schema && ((r = o.schema).default ?? (r.default = o.schema._prefault)), delete o.schema._prefault, t.seen.get(e).schema;
}
function Aa(e) {
	return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
function ja(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	if (e.external && e.sharedDefsExtractedFor === e.external) return;
	let r = /* @__PURE__ */ new Map();
	for (let t of e.seen.entries()) {
		let n = e.metadataRegistry.get(t[0])?.id;
		if (n) {
			let e = r.get(n);
			if (e && e !== t[0]) throw Error(`Duplicate schema id "${n}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
			r.set(n, t[0]);
		}
	}
	let i = (t) => {
		let r = e.target === "draft-2020-12" ? "$defs" : "definitions";
		if (e.external) {
			let n = e.external.registry.get(t[0])?.id, i = e.external.uri ?? ((e) => e);
			if (n) return { ref: i(n) };
			let a = t[1].defId ?? t[1].schema.id ?? `schema${e.counter++}`;
			return t[1].defId = a, {
				defId: a,
				ref: `${i("__shared")}#/${r}/${Aa(a)}`
			};
		}
		let i = `#/${r}/`;
		if (t[1] === n && !t[1].schema.id) return { ref: "#" };
		let a = t[1].schema.id ?? `__schema${e.counter++}`;
		return {
			defId: a,
			ref: i + Aa(a)
		};
	}, a = (e) => {
		if (e[1].schema.$ref) return;
		let t = e[1], { ref: n, defId: r } = i(e);
		t.def = { ...t.schema }, r && (t.defId = r);
		let a = t.schema;
		for (let e in a) delete a[e];
		a.$ref = n;
	};
	if (e.cycles === "throw") for (let t of e.seen.entries()) {
		let e = t[1];
		if (e.cycle) throw Error(`Cycle detected: #/${e.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
	}
	for (let n of e.seen.entries()) {
		let r = n[1];
		if (t === n[0]) {
			a(n);
			continue;
		}
		if (e.external) {
			let r = e.external.registry.get(n[0])?.id;
			if (t !== n[0] && r) {
				a(n);
				continue;
			}
		}
		if (e.metadataRegistry.get(n[0])?.id) {
			a(n);
			continue;
		}
		if (r.cycle) {
			a(n);
			continue;
		}
		if (r.count > 1 && e.reused === "ref") {
			a(n);
			continue;
		}
	}
	e.external && (e.sharedDefsExtractedFor = e.external);
}
function Ma(e) {
	let t = e.anyOf;
	if (!Array.isArray(t) || t.length === 0 || e.type !== void 0) return;
	let n = [];
	for (let e of t) {
		if (!e || typeof e != "object") return;
		Ma(e);
		let t = Object.keys(e);
		if (t.length !== 1 || t[0] !== "type") return;
		let r = e.type;
		for (let e of Array.isArray(r) ? r : [r]) {
			if (typeof e != "string") return;
			n.includes(e) || n.push(e);
		}
	}
	delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
var Na = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties"
]), Pa = ["oneOf", "anyOf"];
function Fa(e) {
	let t = e.additionalProperties;
	return t === void 0 || t === !1 || typeof t != "object" || !t ? null : Object.keys(t).length ? t : null;
}
function Ia(e) {
	let t = [];
	for (let n of e) {
		if (typeof n != "object" || n.type !== "object") return null;
		for (let e in n) if (!Na.has(e)) return null;
		t.push(n);
	}
	let n = {}, r = /* @__PURE__ */ new Set();
	for (let e of t) {
		for (let r in e.properties) {
			if (Object.prototype.hasOwnProperty.call(n, r)) continue;
			let e = [];
			for (let n of t) {
				let t = n.properties?.[r] ?? Fa(n);
				t != null && (e.some((e) => JSON.stringify(e) === JSON.stringify(t)) || e.push(t));
			}
			E(n, r, e.length === 1 ? e[0] : Ia(e) ?? { allOf: e });
		}
		for (let t of e.required ?? []) r.add(t);
	}
	let i = {
		type: "object",
		properties: n
	};
	if (r.size && (i.required = [...r]), t.every((e) => e.additionalProperties === !1)) i.additionalProperties = !1;
	else {
		let e = [];
		for (let n of t) {
			let t = Fa(n);
			t && !e.some((e) => JSON.stringify(e) === JSON.stringify(t)) && e.push(t);
		}
		e.length === 1 ? i.additionalProperties = e[0] : e.length > 1 && (i.additionalProperties = { allOf: e });
	}
	return i;
}
function La(e) {
	let t = e.allOf;
	if (!Array.isArray(t) || t.length < 2) return;
	for (let t of Na) if (t in e) return;
	let n = t.filter((e) => Pa.some((t) => Array.isArray(e[t]))), r = null;
	if (!n.length) r = Ia(t);
	else {
		let e = n[0], i = Pa.find((t) => Array.isArray(e[t]));
		if (Object.keys(e).length !== 1) return;
		let a = t.filter((t) => t !== e), o = e[i].map((e) => Ia([...a, e]));
		if (o.some((e) => !e)) return;
		r = { [i]: o };
	}
	r && (delete e.allOf, Da(e, r));
}
function Ra(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	let r = (t) => {
		let n = e.seen.get(t);
		if (n.ref === null) return;
		let i = n.def ?? n.schema, a = { ...i }, o = n.ref;
		if (n.ref = null, o) {
			r(o);
			let n = e.seen.get(o), s = n.schema;
			if (s.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (i.allOf = i.allOf ?? [], i.allOf.push(s)) : Da(i, s), Da(i, a), t._zod.parent === o) for (let e in i) e !== "$ref" && e !== "allOf" && (e in a || delete i[e]);
			if (s.$ref && n.def) for (let e in i) e !== "$ref" && e !== "allOf" && e in n.def && JSON.stringify(i[e]) === JSON.stringify(n.def[e]) && delete i[e];
		}
		let s = t._zod.parent;
		if (s && s !== o) {
			r(s);
			let t = e.seen.get(s);
			if (t?.schema.$ref && (i.$ref = t.schema.$ref, t.def)) for (let e in i) e !== "$ref" && e !== "allOf" && e in t.def && JSON.stringify(i[e]) === JSON.stringify(t.def[e]) && delete i[e];
		}
		e.override({
			zodSchema: t,
			jsonSchema: i,
			path: n.path ?? []
		});
	};
	if (!e.external || e.sharedEmitDoneFor !== e.external) {
		for (let t of [...e.seen.entries()].reverse()) r(t[0]);
		if (e.target !== "openapi-3.0") for (let t of e.seen.entries()) Ma(t[1].def ?? t[1].schema);
		for (let t of e.deferred) t();
		if (e.intersections.length) {
			let t = /* @__PURE__ */ new Map();
			for (let n of e.seen.values()) for (let e of [n.schema, n.def]) {
				let n = e?.allOf;
				if (!Array.isArray(n)) continue;
				let r = t.get(n);
				r ? r.push(e) : t.set(n, [e]);
			}
			for (let n of e.intersections) for (let e of t.get(n) ?? []) La(e);
		}
	}
	let i = {};
	if (e.target === "draft-2020-12" ? i.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? i.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? i.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
		let n = e.external.registry.get(t)?.id;
		if (!n) throw Error("Schema is missing an `id` property");
		i.$id = e.external.uri(n);
	}
	Da(i, n.defId ? n.schema : n.def ?? n.schema);
	let a = e.metadataRegistry.get(t)?.id;
	a !== void 0 && i.id === a && delete i.id;
	let o = e.external?.defs ?? {};
	if (!e.external || e.sharedEmitDoneFor !== e.external) for (let t of e.seen.entries()) {
		let e = t[1];
		e.def && e.defId && (e.def.id === e.defId && delete e.def.id, E(o, e.defId, e.def));
	}
	e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(o).length > 0 && (e.target === "draft-2020-12" ? i.$defs = o : i.definitions = o);
	try {
		let n = JSON.parse(JSON.stringify(i));
		return Object.defineProperty(n, "~standard", {
			value: {
				...t["~standard"],
				jsonSchema: {
					input: Ba(t, "input", e.processors),
					output: Ba(t, "output", e.processors)
				}
			},
			enumerable: !1,
			writable: !1
		}), n;
	} catch {
		throw Error("Error converting schema to JSON.");
	}
}
function B(e, t) {
	let n = t ?? { seen: /* @__PURE__ */ new Set() };
	if (n.seen.has(e)) return !1;
	n.seen.add(e);
	let r = e._zod.def;
	if (r.type === "transform") return !0;
	if (r.type === "array") return B(r.element, n);
	if (r.type === "set") return B(r.valueType, n);
	if (r.type === "lazy") return B(r.getter(), n);
	if (r.type === "promise" || r.type === "optional" || r.type === "nonoptional" || r.type === "nullable" || r.type === "readonly" || r.type === "default" || r.type === "prefault" || r.type === "catch") return B(r.innerType, n);
	if (r.type === "intersection") return B(r.left, n) || B(r.right, n);
	if (r.type === "record" || r.type === "map") return B(r.keyType, n) || B(r.valueType, n);
	if (r.type === "pipe") return e._zod.traits.has("$ZodCodec") ? !0 : B(r.in, n) || B(r.out, n);
	if (r.type === "object") {
		for (let e in r.shape) if (B(r.shape[e], n)) return !0;
		return !1;
	}
	if (r.type === "union") {
		for (let e of r.options) if (B(e, n)) return !0;
		return !1;
	}
	if (r.type === "tuple") {
		for (let e of r.items) if (B(e, n)) return !0;
		return !!(r.rest && B(r.rest, n));
	}
	return !1;
}
var za = (e, t = {}) => (n) => {
	let r = Oa({
		...n,
		processors: t
	});
	return z(e, r), ja(r, e), Ra(r, e);
}, Ba = (e, t, n = {}) => (r) => {
	let { libraryOptions: i, target: a } = r ?? {}, o = Oa({
		...i ?? {},
		target: a,
		io: t,
		processors: n
	});
	return z(e, o), ja(o, e), Ra(o, e);
}, Va = {
	guid: "uuid",
	url: "uri",
	datetime: "date-time",
	json_string: "json-string",
	regex: ""
}, Ha = (e, t, n, r) => {
	let i = n;
	i.type = "string";
	let { minimum: a, maximum: o, format: s, patterns: c, contentEncoding: l, laxFormat: u } = e._zod.bag;
	if (typeof a == "number" && (i.minLength = a), typeof o == "number" && (i.maxLength = o), s && (i.format = Va[s] ?? s, i.format === "" && delete i.format, (s === "time" || u) && delete i.format), l && (i.contentEncoding = l), c && c.size > 0) {
		let e = [...c];
		e.length === 1 ? i.pattern = e[0].source : e.length > 1 && (i.allOf = [...e.map((e) => ({
			...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
			pattern: e.source
		}))]);
	}
}, Ua = (e, t, n, r) => {
	let i = n, { minimum: a, maximum: o, format: s, multipleOf: c, exclusiveMaximum: l, exclusiveMinimum: u } = e._zod.bag;
	i.type = typeof s == "string" && s.includes("int") ? "integer" : "number";
	let d = typeof u == "number" && u >= (a ?? -Infinity), f = typeof l == "number" && l <= (o ?? Infinity), p = t.target === "draft-04" || t.target === "openapi-3.0";
	d ? p ? (i.minimum = u, i.exclusiveMinimum = !0) : i.exclusiveMinimum = u : typeof a == "number" && (i.minimum = a), f ? p ? (i.maximum = l, i.exclusiveMaximum = !0) : i.exclusiveMaximum = l : typeof o == "number" && (i.maximum = o), typeof c == "number" && (Number.isFinite(c) && c !== 0 ? i.multipleOf = Math.abs(c) : ka(e, t, i, r, `A multipleOf divisor of ${c} cannot be represented in JSON Schema`));
}, Wa = (e, t, n, r) => {
	n.type = "boolean";
}, Ga = (e, t, n, r) => {
	n.not = {};
}, Ka = (e, t, n, r) => {
	let i = e._zod.def, a = he(i.entries);
	if (a.length === 0) {
		n.not = {};
		return;
	}
	a.every((e) => typeof e == "number") && (n.type = "number"), a.every((e) => typeof e == "string") && (n.type = "string"), n.enum = a;
}, qa = (e, t, n, r) => {
	let i = e._zod.def;
	if (i.values.length === 0) {
		n.not = {};
		return;
	}
	let a = [];
	for (let o of i.values) if (o === void 0) {
		if (ka(e, t, n, r, "Literal `undefined` cannot be represented in JSON Schema")) return;
	} else if (typeof o == "bigint") {
		if (ka(e, t, n, r, "BigInt literals cannot be represented in JSON Schema")) return;
		a.push(Number(o));
	} else a.push(o);
	if (a.length !== 0) {
		if (a.length === 1) {
			let e = a[0];
			n.type = e === null ? "null" : typeof e, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [e] : n.const = e;
		} else a.every((e) => typeof e == "number") && (n.type = "number"), a.every((e) => typeof e == "string") && (n.type = "string"), a.every((e) => typeof e == "boolean") && (n.type = "boolean"), a.every((e) => e === null) && (n.type = "null"), n.enum = a;
	}
}, Ja = (e, t, n, r) => {
	ka(e, t, n, r, "Custom types cannot be represented in JSON Schema");
}, Ya = (e, t, n, r) => {
	ka(e, t, n, r, "Transforms cannot be represented in JSON Schema");
}, Xa = (e, t, n, r) => {
	let i = n, a = e._zod.def, { minimum: o, maximum: s } = e._zod.bag;
	typeof o == "number" && (i.minItems = o), typeof s == "number" && (i.maxItems = s), i.type = "array", i.items = z(a.element, t, {
		...r,
		path: [...r.path, "items"]
	});
};
function Za(e) {
	let t = e._zod.def;
	return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? Za(t.out) : t.type === "catch" ? Za(t.innerType) : e._zod.optin;
}
var Qa = (e, t, n, r) => {
	let i = n, a = e._zod.def, o = a.shape;
	if (Object.getOwnPropertySymbols(o).length && ka(e, t, i, r, "Symbol keys cannot be represented in JSON Schema")) return;
	i.type = "object", i.properties = {};
	for (let e in o) E(i.properties, e, z(o[e], t, {
		...r,
		path: [
			...r.path,
			"properties",
			e
		]
	}));
	let s = new Set(Object.keys(o)), c = new Set([...s].filter((e) => {
		let n = a.shape[e];
		return t.io === "input" ? Za(n) === void 0 : n._zod.optout === void 0;
	}));
	c.size > 0 && (i.required = Array.from(c)), a.catchall?._zod.def.type === "never" ? i.additionalProperties = !1 : a.catchall ? a.catchall && (i.additionalProperties = z(a.catchall, t, {
		...r,
		path: [...r.path, "additionalProperties"]
	})) : t.io === "output" && (i.additionalProperties = !1);
}, $a = (e, t, n, r) => {
	let i = e._zod.def, a = i.inclusive === !1, o = i.options.map((e, n) => z(e, t, {
		...r,
		path: [
			...r.path,
			a ? "oneOf" : "anyOf",
			n
		]
	}));
	a ? n.oneOf = o : n.anyOf = o;
}, eo = (e, t, n, r) => {
	let i = e._zod.def, a = z(i.left, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			0
		]
	}), o = z(i.right, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			1
		]
	}), s = (e) => "allOf" in e && Object.keys(e).length === 1, c = [...s(a) ? a.allOf : [a], ...s(o) ? o.allOf : [o]];
	n.allOf = c, t.intersections.push(c);
};
function to(e, t, n) {
	if (t.$ref) {
		if (n.has(t)) return t;
		n.add(t);
		let r = e.get(t)?.def;
		if (!r) return t;
		let i = to(e, r, n);
		return i === r ? t : i;
	}
	for (let r of ["anyOf", "oneOf"]) {
		let i = t[r];
		if (!Array.isArray(i)) continue;
		let a = i.map((t) => to(e, t, n));
		a.some((e, t) => e !== i[t]) && (t = {
			...t,
			[r]: a
		});
	}
	let r = Array.isArray(t.type) ? t.type : [t.type], i = !r.includes("string") && r.some((e) => e === "number" || e === "integer"), a = t.enum ?? (t.const === void 0 ? void 0 : [t.const]);
	if (!i && !a?.some((e) => typeof e == "number")) return t;
	let { minimum: o, maximum: s, exclusiveMinimum: c, exclusiveMaximum: l, multipleOf: u, format: d, id: f, ...p } = t;
	return p.enum ? p.enum = p.enum.map((e) => typeof e == "number" ? String(e) : e) : typeof p.const == "number" && (p.const = String(p.const)), i ? (p.type = "string", a || (p.pattern = (r.includes("number") ? hn : mn).source), p) : p;
}
var no = /* @__PURE__ */ new WeakMap();
function ro(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.seen.values()) n.def && !t.has(n.schema) && t.set(n.schema, n);
	let n = /* @__PURE__ */ new Map();
	for (let r of no.get(e) ?? []) {
		let i = e.seen.get(r), a = (i?.def ?? i?.schema)?.propertyNames;
		if (!a || a === !0 || n.has(a)) continue;
		let o = to(t, a, /* @__PURE__ */ new Set());
		o !== a && n.set(a, o);
	}
	if (n.size) for (let t of e.seen.values()) for (let e of [t.schema, t.def]) {
		let t = e && n.get(e.propertyNames);
		t && (e.propertyNames = t);
	}
}
var io = (e, t, n, r) => {
	let i = n, a = e._zod.def;
	i.type = "object";
	let o = a.keyType, s = o._zod.bag?.patterns;
	if (a.mode === "loose" && s && s.size > 0) {
		let e = z(a.valueType, t, {
			...r,
			path: [
				...r.path,
				"patternProperties",
				"*"
			]
		});
		i.patternProperties = {};
		for (let t of s) E(i.patternProperties, t.source, e);
	} else {
		if (t.target === "draft-07" || t.target === "draft-2020-12") {
			i.propertyNames = z(a.keyType, t, {
				...r,
				path: [...r.path, "propertyNames"]
			});
			let n = no.get(t);
			n || (n = [], no.set(t, n), t.deferred.push(() => ro(t))), n.push(e);
		}
		i.additionalProperties = z(a.valueType, t, {
			...r,
			path: [...r.path, "additionalProperties"]
		});
	}
	let c = o._zod.values, l = t.io === "input" && Za(a.valueType) !== void 0;
	if (c && !a.partial && !l) {
		let e = [...c].filter((e) => typeof e == "string" || typeof e == "number");
		e.length > 0 && (i.required = e.map(String));
	}
}, ao = (e, t, n, r) => {
	let i = e._zod.def, a = z(i.innerType, t, r), o = t.seen.get(e);
	t.target === "openapi-3.0" ? (o.ref = i.innerType, n.nullable = !0) : n.anyOf = [a, { type: "null" }];
}, oo = (e, t, n, r) => {
	let i = e._zod.def;
	z(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, so = Symbol();
function co(e, t, n, r, i) {
	let a = !1, o = JSON.stringify(e, (e, t) => typeof t == "bigint" ? (a = !0, null) : t);
	return a ? (ka(t, n, r, i, "BigInt defaults cannot be represented in JSON Schema"), so) : JSON.parse(o);
}
var lo = (e, t, n, r) => {
	let i = e._zod.def;
	z(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
	let o = co(i.defaultValue, e, t, n, r);
	o !== so && (n.default = o);
}, uo = (e, t, n, r) => {
	let i = e._zod.def;
	z(i.innerType, t, r);
	let a = t.seen.get(e);
	if (a.ref = i.innerType, t.io !== "input") return;
	let o = co(i.defaultValue, e, t, n, r);
	o !== so && (n._prefault = o);
}, fo = (e, t, n, r) => {
	let i = e._zod.def;
	z(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
	let o;
	try {
		o = i.catchValue(void 0);
	} catch {
		ka(e, t, n, r, "Dynamic catch values are not supported in JSON Schema");
		return;
	}
	n.default = o;
}, po = (e, t, n, r) => {
	let i = e._zod.def, a = i.in._zod.traits.has("$ZodTransform"), o = t.io === "input" ? a ? i.out : i.in : i.out;
	z(o, t, r);
	let s = t.seen.get(e);
	s.ref = o;
}, mo = (e, t, n, r) => {
	let i = e._zod.def;
	z(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType, n.readOnly = !0;
}, ho = (e, t, n, r) => {
	let i = e._zod.def;
	z(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, go = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function _o(e, t, n) {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		get() {
			let e = n(this);
			return Object.defineProperty(this, t, {
				value: e,
				configurable: !0,
				writable: !0
			}), e;
		},
		set(e) {
			Object.defineProperty(this, t, {
				value: e,
				configurable: !0,
				writable: !0
			});
		}
	});
}
var V = /*@__PURE__*/ N("ZodError", (e, t) => {
	yt.init(e, t), e.name = "ZodError";
	let n = Object.getPrototypeOf(e);
	go.has(n) || (go.add(n), _o(n, "format", (e) => (t) => Ct(e, t)), _o(n, "flatten", (e) => (t) => St(e, t)), _o(n, "addIssue", (e) => (t) => {
		e.issues.push(t), e.message = JSON.stringify(e.issues, T, 2);
	}), _o(n, "addIssues", (e) => (t) => {
		e.issues.push(...t), e.message = JSON.stringify(e.issues, T, 2);
	}), Object.defineProperty(n, "isEmpty", {
		configurable: !0,
		enumerable: !1,
		get() {
			return this.issues.length === 0;
		}
	}));
}, void 0, { Parent: Error }), vo = /* @__PURE__ */ Tt(V), yo = /* @__PURE__ */ Et(V), bo = /* @__PURE__ */ Dt(V), xo = /* @__PURE__ */ kt(V), So = /* @__PURE__ */ jt(V), Co = /* @__PURE__ */ Mt(V), wo = /* @__PURE__ */ Nt(V), To = /* @__PURE__ */ Pt(V), Eo = /* @__PURE__ */ Ft(V), Do = /* @__PURE__ */ It(V), Oo = /* @__PURE__ */ Lt(V), ko = /* @__PURE__ */ Rt(V);
//#endregion
//#region node_modules/zod/v4/classic/schemas.js
function Ao() {
	P.localeError || F(bi());
}
function jo() {
	P.memoizer || F({ memoizer: _i() });
}
var H = /*@__PURE__*/ N("ZodType", (e, t) => (Ao(), L.init(e, t), e.def = t, e.type = t.type, e), {
	check(...e) {
		let t = this.def;
		return this.clone(D(t, { checks: [...t.checks ?? [], ...e.map((e) => typeof e == "function" ? { _zod: {
			check: e,
			def: { check: "custom" },
			onattach: []
		} } : e)] }), { parent: !0 });
	},
	with(...e) {
		return this.check(...e);
	},
	clone(e, t) {
		return A(this, e, t);
	},
	brand() {
		return this;
	},
	register(e, t) {
		return e.add(this, t), this;
	},
	refine(e, t) {
		return this.check(Js(e, t));
	},
	superRefine(e, t) {
		return this.check(Ys(e, t));
	},
	overwrite(e) {
		return this.check(/* @__PURE__ */ _a(e));
	},
	optional() {
		return As(this);
	},
	exactOptional() {
		return Ms(this);
	},
	nullable() {
		return Ps(this);
	},
	nullish() {
		return As(Ps(this));
	},
	nonoptional(e) {
		return Bs(this, e);
	},
	array() {
		return ms(this);
	},
	or(e) {
		return _s([this, e]);
	},
	and(e) {
		return ys(this, e);
	},
	transform(e) {
		return Ws(this, Os(e));
	},
	default(e) {
		return Is(this, e);
	},
	prefault(e) {
		return Rs(this, e);
	},
	catch(e) {
		return Hs(this, e);
	},
	pipe(e) {
		return Ws(this, e);
	},
	readonly() {
		return Ks(this);
	},
	describe(e) {
		let t = this.clone();
		return wi.add(t, { description: e }), t;
	},
	meta(...e) {
		if (e.length === 0) return wi.get(this);
		let t = this.clone();
		return wi.add(t, e[0]), t;
	},
	isOptional() {
		return this.safeParse(void 0).success;
	},
	isNullable() {
		return this.safeParse(null).success;
	},
	apply(e, ...t) {
		return t.length === 0 ? e(this) : e(this, ...t);
	},
	get "~standard"() {
		return Ze(this, "~standard", {
			...zn(this),
			jsonSchema: {
				input: Ba(this, "input"),
				output: Ba(this, "output")
			}
		});
	},
	set "~standard"(e) {
		Xe(this, "~standard", e);
	},
	parse: function e(t, n) {
		return vo(this, t, n, { callee: e });
	},
	parseAsync: async function e(t, n) {
		return await yo(this, t, n, { callee: e });
	},
	safeParse(e, t) {
		return bo(this, e, t);
	},
	async safeParseAsync(e, t) {
		return xo(this, e, t);
	},
	get spa() {
		return this?.safeParseAsync;
	},
	set spa(e) {
		Xe(this, "spa", e);
	},
	encode: function e(t, n) {
		return So(this, t, n, { callee: e });
	},
	decode: function e(t, n) {
		return Co(this, t, n, { callee: e });
	},
	encodeAsync: async function e(t, n) {
		return await wo(this, t, n, { callee: e });
	},
	decodeAsync: async function e(t, n) {
		return await To(this, t, n, { callee: e });
	},
	safeEncode(e, t) {
		return Eo(this, e, t);
	},
	safeDecode(e, t) {
		return Do(this, e, t);
	},
	async safeEncodeAsync(e, t) {
		return Oo(this, e, t);
	},
	async safeDecodeAsync(e, t) {
		return ko(this, e, t);
	},
	toJSONSchema(e) {
		return za(this, {})(e);
	},
	get description() {
		return wi.get(this)?.description;
	},
	get _def() {
		return this._zod.def;
	}
}), Mo = /*@__PURE__*/ N("_ZodString", (e, t) => {
	Bn.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ha(e, t, n, r);
	let n = e._zod.bag;
	e.format = n.format ?? null, e.minLength = n.minimum ?? null, e.maxLength = n.maximum ?? null;
}, {
	regex(...e) {
		return this.check(/* @__PURE__ */ da(...e));
	},
	includes(...e) {
		return this.check(/* @__PURE__ */ ma(...e));
	},
	startsWith(...e) {
		return this.check(/* @__PURE__ */ ha(...e));
	},
	endsWith(...e) {
		return this.check(/* @__PURE__ */ ga(...e));
	},
	min(...e) {
		return this.check(/* @__PURE__ */ la(...e));
	},
	max(...e) {
		return this.check(/* @__PURE__ */ ca(...e));
	},
	length(...e) {
		return this.check(/* @__PURE__ */ ua(...e));
	},
	nonempty(...e) {
		return this.check(/* @__PURE__ */ la(1, ...e));
	},
	lowercase(e) {
		return this.check(/* @__PURE__ */ fa(e));
	},
	uppercase(e) {
		return this.check(/* @__PURE__ */ pa(e));
	},
	trim() {
		return this.check(/* @__PURE__ */ ya());
	},
	normalize(...e) {
		return this.check(/* @__PURE__ */ va(...e));
	},
	toLowerCase() {
		return this.check(/* @__PURE__ */ ba());
	},
	toUpperCase() {
		return this.check(/* @__PURE__ */ xa());
	},
	slugify() {
		return this.check(/* @__PURE__ */ Sa());
	}
}), No = /*@__PURE__*/ N("ZodString", (e, t) => {
	Bn.init(e, t), Mo.init(e, t);
}, {
	email(e) {
		return this.check(/* @__PURE__ */ Ei(Ro, e));
	},
	url(e) {
		return this.check(/* @__PURE__ */ Mi(Vo, e));
	},
	jwt(e) {
		return this.check(/* @__PURE__ */ qi(rs, e));
	},
	emoji(e) {
		return this.check(/* @__PURE__ */ Ni(Uo, e));
	},
	guid(e) {
		return this.check(/* @__PURE__ */ Di(zo, e));
	},
	uuid(e) {
		return this.check(/* @__PURE__ */ Oi(Bo, e));
	},
	uuidv4(e) {
		return this.check(/* @__PURE__ */ ki(Bo, e));
	},
	uuidv6(e) {
		return this.check(/* @__PURE__ */ Ai(Bo, e));
	},
	uuidv7(e) {
		return this.check(/* @__PURE__ */ ji(Bo, e));
	},
	nanoid(e) {
		return this.check(/* @__PURE__ */ Pi(Wo, e));
	},
	cuid(e) {
		return this.check(/* @__PURE__ */ Fi(Go, e));
	},
	cuid2(e) {
		return this.check(/* @__PURE__ */ Ii(Ko, e));
	},
	ulid(e) {
		return this.check(/* @__PURE__ */ Li(qo, e));
	},
	base64(e) {
		return this.check(/* @__PURE__ */ Wi(es, e));
	},
	base64url(e) {
		return this.check(/* @__PURE__ */ Gi(ts, e));
	},
	xid(e) {
		return this.check(/* @__PURE__ */ Ri(Jo, e));
	},
	ksuid(e) {
		return this.check(/* @__PURE__ */ zi(Yo, e));
	},
	ipv4(e) {
		return this.check(/* @__PURE__ */ Bi(Xo, e));
	},
	ipv6(e) {
		return this.check(/* @__PURE__ */ Vi(Zo, e));
	},
	cidrv4(e) {
		return this.check(/* @__PURE__ */ Hi(Qo, e));
	},
	cidrv6(e) {
		return this.check(/* @__PURE__ */ Ui($o, e));
	},
	e164(e) {
		return this.check(/* @__PURE__ */ Ki(ns, e));
	},
	datetime(e) {
		return this.check(/* @__PURE__ */ Ji(Po, e));
	},
	date(e) {
		return this.check(/* @__PURE__ */ Yi(Fo, e));
	},
	time(e) {
		return this.check(/* @__PURE__ */ Xi(Io, e));
	},
	duration(e) {
		return this.check(/* @__PURE__ */ Zi(Lo, e));
	}
});
function U(e) {
	return /* @__PURE__ */ Ti(No, e);
}
var W = /*@__PURE__*/ N("ZodStringFormat", (e, t) => {
	R.init(e, t), Mo.init(e, t);
}), Po = /*@__PURE__*/ N("ZodISODateTime", (e, t) => {
	rr.init(e, t), W.init(e, t);
}), Fo = /*@__PURE__*/ N("ZodISODate", (e, t) => {
	ir.init(e, t), W.init(e, t);
}), Io = /*@__PURE__*/ N("ZodISOTime", (e, t) => {
	ar.init(e, t), W.init(e, t);
}), Lo = /*@__PURE__*/ N("ZodISODuration", (e, t) => {
	or.init(e, t), W.init(e, t);
}), Ro = /*@__PURE__*/ N("ZodEmail", (e, t) => {
	Un.init(e, t), W.init(e, t);
}), zo = /*@__PURE__*/ N("ZodGUID", (e, t) => {
	Vn.init(e, t), W.init(e, t);
}), Bo = /*@__PURE__*/ N("ZodUUID", (e, t) => {
	Hn.init(e, t), W.init(e, t);
}), Vo = /*@__PURE__*/ N("ZodURL", (e, t) => {
	Yn.init(e, t), W.init(e, t);
});
function Ho(e) {
	return /* @__PURE__ */ Mi(Vo, e);
}
var Uo = /*@__PURE__*/ N("ZodEmoji", (e, t) => {
	Xn.init(e, t), W.init(e, t);
}), Wo = /*@__PURE__*/ N("ZodNanoID", (e, t) => {
	Zn.init(e, t), W.init(e, t);
}), Go = /*@__PURE__*/ N("ZodCUID", (e, t) => {
	Qn.init(e, t), W.init(e, t);
}), Ko = /*@__PURE__*/ N("ZodCUID2", (e, t) => {
	$n.init(e, t), W.init(e, t);
}), qo = /*@__PURE__*/ N("ZodULID", (e, t) => {
	er.init(e, t), W.init(e, t);
}), Jo = /*@__PURE__*/ N("ZodXID", (e, t) => {
	tr.init(e, t), W.init(e, t);
}), Yo = /*@__PURE__*/ N("ZodKSUID", (e, t) => {
	nr.init(e, t), W.init(e, t);
}), Xo = /*@__PURE__*/ N("ZodIPv4", (e, t) => {
	sr.init(e, t), W.init(e, t);
}), Zo = /*@__PURE__*/ N("ZodIPv6", (e, t) => {
	ur.init(e, t), W.init(e, t);
}), Qo = /*@__PURE__*/ N("ZodCIDRv4", (e, t) => {
	dr.init(e, t), W.init(e, t);
}), $o = /*@__PURE__*/ N("ZodCIDRv6", (e, t) => {
	pr.init(e, t), W.init(e, t);
}), es = /*@__PURE__*/ N("ZodBase64", (e, t) => {
	hr.init(e, t), W.init(e, t);
}), ts = /*@__PURE__*/ N("ZodBase64URL", (e, t) => {
	_r.init(e, t), W.init(e, t);
}), ns = /*@__PURE__*/ N("ZodE164", (e, t) => {
	vr.init(e, t), W.init(e, t);
}), rs = /*@__PURE__*/ N("ZodJWT", (e, t) => {
	br.init(e, t), W.init(e, t);
}), is = /*@__PURE__*/ N("ZodNumber", (e, t) => {
	xr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ua(e, t, n, r);
	let n = e._zod.bag;
	e.minValue = Math.max(n.minimum ?? -Infinity, n.exclusiveMinimum ?? -Infinity) ?? null, e.maxValue = Math.min(n.maximum ?? Infinity, n.exclusiveMaximum ?? Infinity) ?? null, e.isInt = (n.format ?? "").includes("int") || Number.isSafeInteger(n.multipleOf ?? .5), e.isFinite = !0, e.format = n.format ?? null;
}, {
	gt(e, t) {
		return this.check(/* @__PURE__ */ aa(e, t));
	},
	gte(e, t) {
		return this.check(/* @__PURE__ */ oa(e, t));
	},
	min(e, t) {
		return this.check(/* @__PURE__ */ oa(e, t));
	},
	lt(e, t) {
		return this.check(/* @__PURE__ */ ra(e, t));
	},
	lte(e, t) {
		return this.check(/* @__PURE__ */ ia(e, t));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ ia(e, t));
	},
	int(e) {
		return this.check(os(e));
	},
	safe(e) {
		return this.check(os(e));
	},
	positive(e) {
		return this.check(/* @__PURE__ */ aa(0, e));
	},
	nonnegative(e) {
		return this.check(/* @__PURE__ */ oa(0, e));
	},
	negative(e) {
		return this.check(/* @__PURE__ */ ra(0, e));
	},
	nonpositive(e) {
		return this.check(/* @__PURE__ */ ia(0, e));
	},
	multipleOf(e, t) {
		return this.check(/* @__PURE__ */ sa(e, t));
	},
	step(e, t) {
		return this.check(/* @__PURE__ */ sa(e, t));
	},
	finite() {
		return this;
	}
});
function G(e) {
	return /* @__PURE__ */ Qi(is, e);
}
var as = /*@__PURE__*/ N("ZodNumberFormat", (e, t) => {
	Sr.init(e, t), is.init(e, t);
});
function os(e) {
	return /* @__PURE__ */ $i(as, e);
}
var ss = /*@__PURE__*/ N("ZodBoolean", (e, t) => {
	Cr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => Wa(e, t, n, r);
});
function cs(e) {
	return /* @__PURE__ */ ea(ss, e);
}
var ls = /*@__PURE__*/ N("ZodUnknown", (e, t) => {
	wr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (e, t, n) => void 0;
});
function us() {
	return /* @__PURE__ */ ta(ls);
}
var ds = /*@__PURE__*/ N("ZodNever", (e, t) => {
	Tr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ga(e, t, n, r);
});
function fs(e) {
	return /* @__PURE__ */ na(ds, e);
}
var ps = /*@__PURE__*/ N("ZodArray", (e, t) => {
	jo(), Dr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => Xa(e, t, n, r), e.element = t.element;
}, {
	min(e, t) {
		return this.check(/* @__PURE__ */ la(e, t));
	},
	nonempty(e) {
		return this.check(/* @__PURE__ */ la(1, e));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ ca(e, t));
	},
	length(e, t) {
		return this.check(/* @__PURE__ */ ua(e, t));
	},
	unwrap() {
		return this.element;
	}
});
function ms(e, t) {
	return /* @__PURE__ */ Ca(ps, e, t);
}
var hs = /*@__PURE__*/ N("ZodObject", (e, t) => {
	jo(), Pr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => Qa(e, t, n, r), rt(e, "shape", (e) => e._zod.def.shape, !1);
}, {
	keyof() {
		return ws(Object.keys(this._zod.def.shape));
	},
	catchall(e) {
		return this.clone({
			...this._zod.def,
			catchall: e
		});
	},
	passthrough() {
		return this.clone({
			...this._zod.def,
			catchall: us()
		});
	},
	loose() {
		return this.clone({
			...this._zod.def,
			catchall: us()
		});
	},
	strict() {
		return this.clone({
			...this._zod.def,
			catchall: fs()
		});
	},
	strip() {
		return this.clone({
			...this._zod.def,
			catchall: void 0
		});
	},
	extend(e) {
		return Ne(this, e);
	},
	safeExtend(e) {
		return Pe(this, e);
	},
	merge(e) {
		return Fe(this, e);
	},
	pick(e) {
		return je(this, e);
	},
	omit(e) {
		return Me(this, e);
	},
	partial(...e) {
		return Ie(ks, this, e[0]);
	},
	exactPartial(...e) {
		return Ie(js, this, e[0], "exactPartial");
	},
	required(...e) {
		return Le(zs, this, e[0]);
	}
});
function K(e, t) {
	return new hs({
		type: "object",
		shape: e ?? {},
		...j(t)
	});
}
var gs = /*@__PURE__*/ N("ZodUnion", (e, t) => {
	Ir.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => $a(e, t, n, r), e.options = t.options;
});
function _s(e, t) {
	return new gs({
		type: "union",
		options: e,
		...j(t)
	});
}
var vs = /*@__PURE__*/ N("ZodIntersection", (e, t) => {
	Lr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => eo(e, t, n, r);
});
function ys(e, t) {
	return new vs({
		type: "intersection",
		left: e,
		right: t
	});
}
var bs = /*@__PURE__*/ N("ZodRecord", (e, t) => {
	jo(), Br.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => io(e, t, n, r), e.keyType = t.keyType, e.valueType = t.valueType;
});
function xs(e, t, n) {
	return !t || !t._zod ? new bs({
		type: "record",
		keyType: U(),
		valueType: e,
		...j(t)
	}) : new bs({
		type: "record",
		keyType: e,
		valueType: t,
		...j(n)
	});
}
function Ss(e, t, n) {
	return new bs({
		type: "record",
		keyType: e,
		valueType: t,
		...j(n),
		partial: !0
	});
}
var Cs = /*@__PURE__*/ N("ZodEnum", (e, t) => {
	Vr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ka(e, t, n, r), e.enum = t.entries, e.options = Object.values(t.entries);
	let n = new Set(Object.keys(t.entries));
	e.extract = (e, r) => {
		let i = {};
		for (let r of e) if (n.has(r)) i[r] = t.entries[r];
		else throw Error(`Key ${r} not found in enum`);
		return new Cs({
			...t,
			checks: [],
			...j(r),
			entries: i
		});
	}, e.exclude = (e, r) => {
		let i = { ...t.entries };
		for (let t of e) if (n.has(t)) delete i[t];
		else throw Error(`Key ${t} not found in enum`);
		return new Cs({
			...t,
			checks: [],
			...j(r),
			entries: i
		});
	};
});
function ws(e, t) {
	return new Cs({
		type: "enum",
		entries: Array.isArray(e) ? Object.fromEntries(e.map((e) => [e, e])) : e,
		...j(t)
	});
}
var Ts = /*@__PURE__*/ N("ZodLiteral", (e, t) => {
	Hr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => qa(e, t, n, r), e.values = new Set(t.values), Object.defineProperty(e, "value", { get() {
		if (t.values.length > 1) throw Error("This schema contains multiple valid literal values. Use `.values` instead.");
		return t.values[0];
	} });
});
function Es(e, t) {
	return new Ts({
		type: "literal",
		values: Array.isArray(e) ? e : [e],
		...j(t)
	});
}
var Ds = /*@__PURE__*/ N("ZodTransform", (e, t) => {
	jo(), Ur.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ya(e, t, n, r), e._zod.parse = (n, r) => {
		if (r.direction === "backward") throw new dt(e.constructor.name);
		n.addIssue = (r) => {
			if (typeof r == "string") n.issues.push(Je(r, n.value, t));
			else {
				let t = r;
				t.fatal && (t.continue = !1), t.code ??= "custom", "input" in t || (t.input = n.value), t.inst ??= e, n.issues.push(Je(t));
			}
		};
		let i = t.transform(n.value, n);
		return i instanceof Promise ? i.then((e) => (n.value = e, n)) : (n.value = i, n);
	};
});
function Os(e) {
	return new Ds({
		type: "transform",
		transform: e
	});
}
var ks = /*@__PURE__*/ N("ZodOptional", (e, t) => {
	Gr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => ho(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function As(e) {
	return new ks({
		type: "optional",
		innerType: e
	});
}
var js = /*@__PURE__*/ N("ZodExactOptional", (e, t) => {
	Kr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => ho(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Ms(e) {
	return new js({
		type: "optional",
		innerType: e
	});
}
var Ns = /*@__PURE__*/ N("ZodNullable", (e, t) => {
	qr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => ao(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Ps(e) {
	return new Ns({
		type: "nullable",
		innerType: e
	});
}
var Fs = /*@__PURE__*/ N("ZodDefault", (e, t) => {
	Jr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => lo(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Is(e, t) {
	return new Fs({
		type: "default",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : Ee(t);
		}
	});
}
var Ls = /*@__PURE__*/ N("ZodPrefault", (e, t) => {
	Xr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => uo(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Rs(e, t) {
	return new Ls({
		type: "prefault",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : Ee(t);
		}
	});
}
var zs = /*@__PURE__*/ N("ZodNonOptional", (e, t) => {
	Zr.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => oo(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Bs(e, t) {
	return new zs({
		type: "nonoptional",
		innerType: e,
		...j(t)
	});
}
var Vs = /*@__PURE__*/ N("ZodCatch", (e, t) => {
	ei.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => fo(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Hs(e, t) {
	return new Vs({
		type: "catch",
		innerType: e,
		catchValue: typeof t == "function" ? t : at(t)
	});
}
var Us = /*@__PURE__*/ N("ZodPipe", (e, t) => {
	ti.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => po(e, t, n, r), e.in = t.in, e.out = t.out;
});
function Ws(e, t) {
	return new Us({
		type: "pipe",
		in: e,
		out: t
	});
}
var Gs = /*@__PURE__*/ N("ZodReadonly", (e, t) => {
	ri.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => mo(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Ks(e) {
	return new Gs({
		type: "readonly",
		innerType: e
	});
}
var qs = /*@__PURE__*/ N("ZodCustom", (e, t) => {
	ai.init(e, t), H.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ja(e, t, n, r);
});
function Js(e, t = {}) {
	return /* @__PURE__ */ wa(qs, e, t);
}
function Ys(e, t) {
	return /* @__PURE__ */ Ta(e, t);
}
//#endregion
//#region src/game-packs/format.ts
var Xs = "bgparty.pack@1", Zs = "bgparty.source@1", Qs = {
	compressedBytes: 100663296,
	unpackedBytes: 268435456,
	fileBytes: 67108864,
	files: 4096
}, $s = U().regex(/^[a-f0-9]{64}$/), ec = U().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100), tc = U().regex(/^[a-zA-Z0-9][a-zA-Z0-9.+_-]{0,99}$/);
function nc(e) {
	return e.length > 0 && e.length <= 300 && !/[\\%?#:]/.test(e) && !Array.from(e).some((e) => e.charCodeAt(0) < 32) && e.split("/").every((e) => e.length > 0 && e !== "." && e !== "..");
}
var rc = U().refine(nc), ic = K({
	sha256: $s,
	bytes: G().int().min(0).max(Qs.fileBytes),
	mime: U().max(100).regex(/^[a-z0-9.+-]+\/[a-z0-9.+-]+(?:;charset=utf-8)?$/)
}).strict(), ac = K({
	name: U().min(1).max(150),
	desc: U().max(1e3),
	rules: U().max(1e5)
}).strict(), oc = K({
	id: ec,
	labels: K({
		zh: ac,
		en: ac
	}).strict(),
	icon: U().max(30),
	iconPath: rc.optional(),
	minPlayers: G().int().min(1).max(128),
	maxPlayers: G().int().min(1).max(128),
	bestPlayers: ms(G().int().min(1).max(128)).max(128).optional(),
	rulesUrl: Ss(ws([
		"zh",
		"en",
		"de",
		"fr",
		"es",
		"it",
		"ru",
		"ja"
	]), Ho().refine((e) => e.startsWith("https://"))).optional(),
	botDelayMs: G().int().min(0).max(6e4).optional(),
	accent: U().regex(/^#[a-fA-F0-9]{6}$/),
	hotseat: ws([
		"open",
		"cover",
		"off"
	]),
	tier: ws([
		"dev",
		"alpha",
		"beta",
		"released"
	]),
	releasedAt: U().max(40),
	mechanics: ms(ec).max(32),
	interactionTags: ms(ec).max(16),
	search: K({
		py: U().max(1e3),
		init: U().max(100)
	}).strict(),
	capabilities: K({
		bot: cs(),
		ai: cs(),
		options: cs(),
		guide: cs()
	}).strict()
}).strict().refine((e) => e.maxPlayers >= e.minPlayers), sc = K({
	url: U().min(1).max(2048),
	sha256: $s,
	bytes: G().int().positive().max(Qs.compressedBytes),
	id: ec,
	version: tc,
	sdkMajor: G().int().positive(),
	sdkApi: G().int().min(1).max(1e5).optional()
}).strict(), cc = K({
	format: Es(Xs),
	kind: ws([
		"game",
		"sdk",
		"resource"
	]),
	id: ec,
	version: tc,
	bridge: Es(1),
	sdkMajor: G().int().min(1).max(1e3),
	sdkApi: G().int().min(1).max(1e5).optional(),
	platformApi: G().int().min(1).max(1e5).optional(),
	entry: rc,
	exports: xs(U().max(200), rc),
	assets: xs(U().max(500), rc),
	css: ms(rc).max(128),
	files: xs(rc, ic),
	dependencies: ms(sc).max(32).default([]),
	game: oc.optional()
}).strict().superRefine((e, t) => {
	let n = Object.keys(e.files);
	(n.length === 0 || n.length > Qs.files || !e.files[e.entry]) && t.addIssue({
		code: "custom",
		message: "Invalid package entry or file count"
	}), Object.values(e.files).reduce((e, t) => e + t.bytes, 0) > Qs.unpackedBytes && t.addIssue({
		code: "custom",
		message: "Package is too large"
	});
	for (let n of [
		...Object.values(e.exports),
		...Object.values(e.assets),
		...e.css,
		...e.game?.iconPath ? [e.game.iconPath] : []
	]) e.files[n] || t.addIssue({
		code: "custom",
		message: "Missing package file"
	});
	e.kind === "game" && (!e.game || e.game.id !== e.id) && t.addIssue({
		code: "custom",
		message: "Missing game metadata"
	});
	for (let n of Object.keys(e.exports)) e.kind === "game" && !n.startsWith("@bgparty/game/") && t.addIssue({
		code: "custom",
		message: "Reserved module namespace"
	});
	e.kind === "resource" && (Object.keys(e.exports).length || e.dependencies.length || e.css.length) && t.addIssue({
		code: "custom",
		message: "Resource packages cannot contain executable modules or dependencies"
	});
});
K({
	format: Es("bgparty.sdk@1"),
	releases: ms(sc).max(1e4)
}).strict(), K({
	source: U().max(2048),
	game: sc,
	sdk: sc
}).strict(), K({
	format: Es(Zs),
	name: U().min(1).max(150),
	games: ms(K({
		metadata: oc,
		release: sc
	}).strict()).max(1e4)
}).strict().superRefine((e, t) => {
	let n = /* @__PURE__ */ new Set();
	for (let r of e.games) (n.has(r.metadata.id) || r.metadata.id !== r.release.id) && t.addIssue({
		code: "custom",
		message: "Duplicate or inconsistent game identity"
	}), n.add(r.metadata.id);
});
var lc = class extends Error {
	constructor() {
		super("This game requires a newer platform release");
	}
};
function uc(e, t) {
	if (e.kind !== "game" || t.kind !== "sdk" || e.sdkMajor !== t.sdkMajor || (e.sdkApi ?? 1) > (t.sdkApi ?? 1) || (t.platformApi ?? 1) > 2) throw new lc();
}
async function dc(e) {
	let t = await crypto.subtle.digest("SHA-256", new Uint8Array(e));
	return Array.from(new Uint8Array(t), (e) => e.toString(16).padStart(2, "0")).join("");
}
//#endregion
//#region src/game-packs/archive.ts
var fc = new TextDecoder("utf-8", { fatal: !0 });
function pc(e) {
	let t = new DataView(e.buffer, e.byteOffset, e.byteLength), n = e.length - 22, r = Math.max(0, n - 65535);
	for (; n >= r && t.getUint32(n, !0) !== 101010256; n--);
	if (n < r || n + 22 + t.getUint16(n + 20, !0) !== e.length) throw Error("Invalid ZIP directory");
	let i = t.getUint16(n + 10, !0), a = t.getUint32(n + 12, !0), o = t.getUint32(n + 16, !0), s = o;
	if (t.getUint16(n + 4, !0) || t.getUint16(n + 6, !0) || t.getUint16(n + 8, !0) !== i || i > Qs.files + 1 || o + a !== n) throw Error("Unsupported ZIP layout");
	let c = /* @__PURE__ */ new Set(), l = [], u = 0;
	for (let r = 0; r < i; r++) {
		if (o + 46 > n || t.getUint32(o, !0) !== 33639248) throw Error("Invalid ZIP entry");
		let r = t.getUint16(o + 8, !0), i = t.getUint16(o + 10, !0), a = t.getUint32(o + 24, !0), d = t.getUint32(o + 20, !0), f = t.getUint16(o + 28, !0), p = o + 46 + f + t.getUint16(o + 30, !0) + t.getUint16(o + 32, !0);
		if (p > n || r & -2057 || t.getUint16(o + 34, !0) !== 0 || i !== 0 && i !== 8 || a > Qs.fileBytes) throw Error("Unsupported ZIP entry");
		let m = fc.decode(e.subarray(o + 46, o + 46 + f));
		if (!nc(m) || c.has(m)) throw Error("Invalid ZIP filename");
		if (c.add(m), m === "pack.json" && a > 2097152) throw Error("Package manifest is too large");
		if (u += a, u > Qs.unpackedBytes) throw Error("ZIP expands beyond the allowed size");
		let h = t.getUint32(o + 42, !0);
		if (h + 30 > s || t.getUint32(h, !0) !== 67324752) throw Error("Invalid ZIP local entry");
		let g = t.getUint16(h + 26, !0), _ = h + 30 + g + t.getUint16(h + 28, !0) + d;
		if (_ > s || g !== f || t.getUint16(h + 6, !0) !== r) throw Error("Invalid ZIP file range");
		if (!(r & 8) && (t.getUint32(h + 18, !0) !== d || t.getUint32(h + 22, !0) !== a)) throw Error("Inconsistent ZIP entry sizes");
		if (fc.decode(e.subarray(h + 30, h + 30 + g)) !== m || t.getUint16(h + 8, !0) !== i) throw Error("Inconsistent ZIP directory");
		l.push([h, _]), o = p;
	}
	if (o !== n) throw Error("Invalid ZIP directory length");
	l.sort(([e], [t]) => e - t);
	for (let e = 1; e < l.length; e++) if (l[e][0] < l[e - 1][1]) throw Error("Overlapping ZIP entries");
}
async function mc(e, t) {
	if (e.length > Qs.compressedBytes || e.length < 22) throw Error("Invalid ZIP size");
	if (t && await dc(e) !== t) throw Error("ZIP digest does not match");
	pc(e);
	let n = me(e), r = n["pack.json"];
	if (!r || r.length > 2097152) throw Error("Missing package manifest");
	let i = cc.parse(JSON.parse(fc.decode(r))), a = Object.keys(i.files);
	if (Object.keys(n).length !== a.length + 1) throw Error("Undeclared package files");
	for (let e of a) {
		let t = n[e], r = i.files[e];
		if (!t || t.length !== r.bytes || await dc(t) !== r.sha256) throw Error("Package file does not match its manifest");
	}
	return delete n["pack.json"], {
		manifest: i,
		files: n
	};
}
//#endregion
//#region src/game-runtime/bootstrap.ts
function hc(e) {
	for (let e of [
		"RTCPeerConnection",
		"webkitRTCPeerConnection",
		"mozRTCPeerConnection"
	]) Object.defineProperty(globalThis, e, {
		value: void 0,
		writable: !1,
		configurable: !1
	});
	let t = document.getElementById("game-root"), n = !1;
	window.addEventListener("message", async (r) => {
		if (n || r.source !== parent || r.data?.type !== "bgparty:connect" || r.ports.length !== 1) return;
		n = !0;
		let i = r.ports[0], a = [], o = /* @__PURE__ */ new Map(), s, c = 0, l, u = (e, t) => i.postMessage({
			type: "event",
			name: e,
			data: t
		}), d = (e, t) => new Promise((n, r) => {
			let a = ++c, s = setTimeout(() => {
				o.delete(a) && r(/* @__PURE__ */ Error("Platform request timed out"));
			}, 3e4);
			o.set(a, {
				method: e,
				timer: s,
				resolve: n,
				reject: r
			}), i.postMessage({
				type: "host-call",
				id: a,
				method: e,
				args: t
			});
		});
		i.onmessage = async ({ data: n }) => {
			if (n?.type === "host-result") {
				let e = o.get(n.id);
				if (!e) return;
				o.delete(n.id), clearTimeout(e.timer), n.ok ? (e.method === "storage.read" && s?.(n.value), e.method === "storage.write" && s?.(n.value?.snapshot), e.resolve(n.value)) : e.reject(/* @__PURE__ */ Error("Platform request was rejected"));
				return;
			}
			if (n?.type === "call" && Number.isSafeInteger(n.id) && typeof n.method == "string") try {
				if (n.method === "initialize") {
					if (l) throw Error("Already initialized");
					let r = n.args, o = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map();
					for (let e of r.files) {
						let t = URL.createObjectURL(new Blob([e.bytes], { type: e.mime }));
						a.push(t), c.set(e.key, t);
					}
					for (let [e, t] of Object.entries(r.assets)) {
						let n = c.get(t);
						n && o.set(e, n);
					}
					let f = (e) => {
						if (e.startsWith("#") || e.startsWith("blob:") && a.includes(e) || e.startsWith("data:")) return e;
						let t = e.replace(/^(?:\.\/|\/)+/, ""), n = o.get(e) ?? o.get(t);
						if (!n) throw Error("Resource is not part of the installed game: " + e.slice(0, 160));
						return n;
					};
					Object.defineProperty(globalThis, "__bgpartyAssetUrl", { value: f });
					let p = new Map(Object.entries(r.storage ?? {}));
					s = (e) => {
						let t = e;
						p.clear();
						for (let [e, n] of Object.entries(t.values)) p.set(e, n);
					};
					let m = {
						get length() {
							return p.size;
						},
						key: (e) => [...p.keys()][e] ?? null,
						getItem: (e) => p.get(String(e)) ?? null,
						setItem(e, t) {
							if ([...new Map(p).set(String(e), String(t))].reduce((e, [t, n]) => e + t.length + n.length, 0) > 524288) throw new DOMException("Game storage is full", "QuotaExceededError");
							p.set(String(e), String(t)), u("storage", Object.fromEntries(p));
						},
						removeItem(e) {
							p.delete(String(e)), u("storage", Object.fromEntries(p));
						},
						clear() {
							p.clear(), u("storage", {});
						}
					};
					Object.defineProperty(window, "localStorage", { value: m }), Object.defineProperty(window, "sessionStorage", { value: m });
					let h = (e) => String(e ?? "").replace(/url\(\s*(['"]?)([^'"\s)]+)\1\s*\)/g, (e, t, n) => `url("${f(n)}")`), g = /* @__PURE__ */ new Map(), _ = (e) => {
						let t = e.lastIndexOf("#");
						if (t <= 0) return e;
						let n = e.slice(0, t), i = g.get(n);
						if (!i) {
							let e;
							if (n.startsWith("data:image/svg+xml")) {
								let t = n.indexOf(",");
								e = n.slice(0, t).endsWith(";base64") ? atob(n.slice(t + 1)) : decodeURIComponent(n.slice(t + 1));
							} else {
								let t = f(n), i = r.files.find((e) => c.get(e.key) === t);
								if (!i) throw Error("SVG sprite is not available");
								e = new TextDecoder().decode(i.bytes);
							}
							let t = new DOMParser().parseFromString(e, "image/svg+xml").documentElement;
							if (t.localName !== "svg") throw Error("Invalid SVG sprite");
							i = `bgparty-sprite-${g.size}-`;
							for (let e of [t, ...t.querySelectorAll("*")]) for (let t of [...e.attributes]) t.name === "id" ? t.value = i + t.value : (t.value = t.value.replace(/url\(#([^)]+)\)/g, `url(#${i}$1)`), t.localName === "href" && t.value.startsWith("#") && (t.value = "#" + i + t.value.slice(1)));
							t.setAttribute("width", "0"), t.setAttribute("height", "0"), t.setAttribute("aria-hidden", "true"), t.setAttribute("style", "position:absolute;pointer-events:none;overflow:hidden"), document.body.append(document.importNode(t, !0)), g.set(n, i);
						}
						return "#" + i + e.slice(t + 1);
					}, ee = Element.prototype.setAttribute;
					Element.prototype.setAttribute = function(e, t) {
						return ["src", "poster"].includes(e) && /^(IMG|SOURCE|AUDIO|VIDEO)$/.test(this.tagName) && t && (t = f(t)), e === "href" && this.localName === "image" && t && (t = f(t)), e === "href" && this.localName === "use" && t && (t = _(String(t))), e === "style" && (t = h(t)), ee.call(this, e, t);
					};
					let te = Element.prototype.setAttributeNS;
					Element.prototype.setAttributeNS = function(e, t, n) {
						return this.localName === "image" && /(?:^|:)href$/.test(t) && n && (n = f(String(n))), this.localName === "use" && /(?:^|:)href$/.test(t) && n && (n = _(String(n))), te.call(this, e, t, n);
					};
					for (let e of [
						HTMLImageElement.prototype,
						HTMLMediaElement.prototype,
						HTMLSourceElement.prototype
					]) {
						let t = Object.getOwnPropertyDescriptor(e, "src");
						t?.set && Object.defineProperty(e, "src", {
							...t,
							set(e) {
								t.set.call(this, e ? f(String(e)) : "");
							}
						});
					}
					let ne = /* @__PURE__ */ new WeakMap();
					for (let e of [HTMLElement.prototype, SVGElement.prototype]) {
						let t = Object.getOwnPropertyDescriptor(e, "style");
						t?.get && Object.defineProperty(e, "style", {
							...t,
							get() {
								let e = t.get.call(this), n = ne.get(e);
								return n || (n = new Proxy(e, {
									get(e, t) {
										let n = Reflect.get(e, t, e);
										return typeof n == "function" ? n.bind(e) : n;
									},
									set(e, t, n) {
										return Reflect.set(e, t, typeof n == "string" && n.includes("url(") ? h(n) : n, e);
									}
								}), ne.set(e, n)), n;
							}
						});
					}
					let v = CSSStyleDeclaration.prototype.setProperty;
					CSSStyleDeclaration.prototype.setProperty = function(e, t, n) {
						return v.call(this, e, t && h(t), n);
					}, window.fetch = async (e) => {
						let t = typeof e == "string" ? e : e instanceof URL ? e.href : e.url, n = f(t), i = r.files.find((e) => c.get(e.key) === n);
						if (!i) throw Error("Resource is not available");
						return new Response(i.bytes, { headers: { "Content-Type": i.mime } });
					};
					let re = {};
					for (let [e, t] of Object.entries(r.modules)) {
						let n = c.get(t);
						if (!n) throw Error("Missing module");
						re[e] = n;
					}
					let ie = document.createElement("script");
					ie.type = "importmap", ie.setAttribute("nonce", r.nonce), ie.textContent = JSON.stringify({ imports: re }), document.head.append(ie);
					for (let e of r.css) {
						let t = document.createElement("style");
						t.textContent = h(e), document.head.append(t);
					}
					re.zod && (await e(re.zod)).config?.({ jitless: !0 });
					let ae = await e(re["@bgparty/sdk/runtime"]), y = await e(re[r.entry]);
					l = ae.connectRuntime(y.default, {
						root: t,
						host: d,
						emit: u,
						assetUrl: f,
						locale: r.locale
					}), i.postMessage({
						type: "result",
						id: n.id,
						ok: !0,
						value: { ready: !0 }
					});
					return;
				}
				if (!l) throw Error("Game is not ready");
				let r = await l(n.method, n.args);
				i.postMessage({
					type: "result",
					id: n.id,
					ok: !0,
					value: r
				});
			} catch (e) {
				i.postMessage({
					type: "result",
					id: n.id,
					ok: !1,
					error: e instanceof Error ? e.message.slice(0, 300) : "Game failed"
				});
			}
		}, i.start(), i.postMessage({ type: "connected" }), window.addEventListener("unload", () => {
			for (let e of a) URL.revokeObjectURL(e);
			i.close();
		}, { once: !0 });
	});
}
function gc(e) {
	return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${`default-src 'none'; script-src 'nonce-${e}' 'wasm-unsafe-eval' blob:; style-src 'unsafe-inline'; img-src blob: data:; font-src blob: data:; media-src blob:; connect-src 'none'; worker-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-src 'none'`}"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body,#game-root{margin:0;width:100%;height:100%;overflow:hidden}</style></head><body><div id="game-root"></div><script nonce="${e}">(${hc.toString()})(url => import(url));<\/script></body></html>`;
}
//#endregion
//#region src/game-packs/storage.ts
var _c;
function vc() {
	return _c || (_c = new Promise((e, t) => {
		let n = indexedDB.open("bgparty:game-packs", 4);
		n.onupgradeneeded = () => {
			let e = n.result;
			for (let [t, n] of [
				["sources", "url"],
				["packs", "hash"],
				["games", "identity"]
			]) e.objectStoreNames.contains(t) || e.createObjectStore(t, { keyPath: n });
			if (!e.objectStoreNames.contains("data")) {
				let t = e.createObjectStore("data", { keyPath: "identity" }), r = n.transaction.objectStore("games").openCursor();
				r.onsuccess = () => {
					let e = r.result;
					if (!e) return;
					let n = e.value;
					t.put({
						identity: n.identity,
						source: n.source,
						gameId: n.gameId,
						revision: 0,
						values: n.storage ?? {}
					}), e.continue();
				};
			}
			for (let t of ["pins", "archives"]) e.objectStoreNames.contains(t) && e.deleteObjectStore(t);
		}, n.onsuccess = () => {
			n.result.onversionchange = () => {
				n.result.close(), _c = void 0;
			}, e(n.result);
		}, n.onerror = () => {
			_c = void 0, t(n.error);
		}, n.onblocked = () => {
			_c = void 0, t(/* @__PURE__ */ Error("Game storage is in use by another version"));
		};
	}), _c);
}
async function yc(e) {
	if (!navigator.locks) throw Error("This browser cannot safely install games");
	return navigator.locks.request("bgparty:pack-storage", { mode: "exclusive" }, e);
}
async function bc(e, t) {
	let n = await vc();
	return new Promise((r, i) => {
		let a = n.transaction(e, "readonly").objectStore(e).get(t);
		a.onsuccess = () => r(a.result), a.onerror = () => i(a.error);
	});
}
async function xc(e, t) {
	let n = await vc();
	await new Promise((r, i) => {
		let a = n.transaction(e, "readwrite");
		a.objectStore(e).put(t), a.oncomplete = () => r(), a.onerror = () => i(a.error), a.onabort = () => i(a.error ?? /* @__PURE__ */ Error("Game storage write was interrupted"));
	});
}
//#endregion
//#region src/game-packs/game-data.ts
var Sc = 524288, Cc = xs(U(), U()).refine((e) => Object.entries(e).reduce((e, [t, n]) => e + t.length + n.length, 0) <= Sc), wc = K({
	revision: G().int().nonnegative(),
	values: Cc
}).strict(), Tc = (e, t) => Object.hasOwn(e, t) ? e[t] : void 0, Ec = (e) => ({
	revision: e.revision,
	values: e.values
});
async function Dc(e) {
	let t = await bc("data", e.identity);
	if (t) return t;
	let n = {
		identity: e.identity,
		source: e.source,
		gameId: e.gameId,
		revision: 0,
		values: e.storage ?? {}
	};
	return await xc("data", n), n;
}
async function Oc(e, t, n) {
	let r = t === "storage.write" ? wc.parse(n) : void 0;
	if (t !== "storage.read" && t !== "storage.write") throw Error("Unknown game storage operation");
	return yc(async () => {
		let t = await bc("data", e);
		if (!t) throw Error("Game data is unavailable");
		if (!r) return Ec(t);
		if (t.revision !== r.revision) return {
			status: "conflict",
			snapshot: Ec(t)
		};
		let n = {
			...t,
			revision: t.revision + 1,
			values: r.values
		};
		return await xc("data", n), {
			status: "saved",
			snapshot: Ec(n)
		};
	});
}
async function kc(e, t, n, r = 0) {
	let i = Cc.parse(n), a = [.../* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(i)])].filter((e) => Tc(t, e) !== Tc(i, e));
	if (a.length) return yc(async () => {
		let n = await bc("data", e);
		if (!n) throw Error("Game data is unavailable");
		if (r < (n.clearedAtRevision ?? 0)) throw Error("Game data was cleared");
		if (a.some((e) => Tc(n.values, e) !== Tc(t, e))) throw Error("Game data changed in another page");
		let o = { ...n.values };
		for (let e of a) Object.hasOwn(i, e) ? Object.defineProperty(o, e, {
			value: i[e],
			enumerable: !0,
			configurable: !0,
			writable: !0
		}) : delete o[e];
		return Cc.parse(o), await xc("data", {
			...n,
			revision: n.revision + 1,
			values: o
		}), n.revision + 1;
	});
}
//#endregion
//#region src/game-runtime/client.ts
var Ac = class extends Error {}, jc = /* @__PURE__ */ new Set([
	"describe",
	"start",
	"restore",
	"resume",
	"action",
	"tick",
	"render",
	"configure",
	"snapshot",
	"bot",
	"validate",
	"nextTick",
	"locale",
	"dispose",
	"llm.needsAction",
	"llm.describeView",
	"llm.parseAction"
]);
async function Mc(e) {
	let t = Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(18)), (e) => e.toString(16).padStart(2, "0")).join(""), n = document.createElement("iframe");
	n.setAttribute("sandbox", "allow-scripts"), n.setAttribute("allow", "camera 'none'; microphone 'none'; geolocation 'none'; clipboard-read 'none'; clipboard-write 'none'"), n.referrerPolicy = "no-referrer", n.title = e.title, n.style.cssText = "display:block;border:0;width:100%;height:100%;min-height:0", n.srcdoc = gc(t);
	let r = new MessageChannel(), i = /* @__PURE__ */ new Map(), a = 0, o = !1, s = { ...e.payload.storage }, c = e.payload.storageRevision ?? 0, l = Promise.resolve(), u = (e) => {
		let t = l.then(e);
		return l = t.catch(() => {}), t;
	}, d, f = () => {
		if (!o) {
			o = !0;
			for (let e of i.values()) clearTimeout(e.timer), e.reject(new Ac("Game runtime was closed"));
			i.clear(), r.port1.close(), n.remove();
		}
	};
	r.port1.onmessage = ({ data: t }) => {
		if (!o && t && typeof t == "object") {
			if (t.type === "connected") {
				d?.(), d = void 0;
				return;
			}
			if (t.type === "result") {
				let e = i.get(t.id);
				if (!e || typeof t.ok != "boolean") return;
				i.delete(t.id), clearTimeout(e.timer), t.ok ? e.resolve(t.value) : e.reject(new Ac(typeof t.error == "string" ? t.error.slice(0, 300) : "Game failed"));
			} else if (t.type === "event" && [
				"action",
				"config",
				"storage",
				"notice",
				"play-again",
				"back",
				"resize"
			].includes(t.name)) t.name === "storage" && e.storageIdentity ? u(async () => {
				c = await kc(e.storageIdentity, s, t.data, c) ?? c, s = { ...t.data }, e.onEvent?.("storage", t.data);
			}).catch(() => console.warn("Legacy game data could not be saved")) : e.onEvent?.(t.name, t.data);
			else if (t.type === "host-call" && Number.isSafeInteger(t.id)) {
				let n = e.hostCall;
				(e.storageIdentity && ["storage.read", "storage.write"].includes(t.method) ? u(async () => {
					let n = await Oc(e.storageIdentity, t.method, t.args), r = "snapshot" in n ? n.snapshot : n;
					return s = { ...r.values }, c = r.revision, n;
				}) : Promise.resolve().then(() => {
					if (!n || t.method !== "ai.complete") throw Error("Capability is not available");
					return n(t.method, t.args);
				})).then((e) => {
					o || r.port1.postMessage({
						type: "host-result",
						id: t.id,
						ok: !0,
						value: e
					});
				}, () => {
					o || r.port1.postMessage({
						type: "host-result",
						id: t.id,
						ok: !1
					});
				});
			}
		}
	};
	let p = (e, t) => {
		if (o || e !== "initialize" && !jc.has(e)) return Promise.reject(new Ac("Invalid runtime request"));
		let n = ++a;
		return new Promise((a, o) => {
			let s = setTimeout(() => {
				i.delete(n), o(new Ac("Game runtime did not respond"));
			}, 3e4);
			i.set(n, {
				resolve: (e) => a(e),
				reject: o,
				timer: s
			}), r.port1.postMessage({
				type: "call",
				id: n,
				method: e,
				args: t
			});
		});
	};
	try {
		let i = new Promise((e, t) => {
			let n = setTimeout(() => t(new Ac("Game runtime did not start")), 15e3);
			d = () => {
				clearTimeout(n), e();
			};
		});
		return n.addEventListener("load", () => n.contentWindow?.postMessage({ type: "bgparty:connect" }, "*", [r.port2]), { once: !0 }), e.container.append(n), await i, await p("initialize", {
			...e.payload,
			nonce: t
		}), {
			frame: n,
			call: p,
			close: f
		};
	} catch (e) {
		throw f(), e;
	}
}
//#endregion
//#region tools/acceptance-motion.ts
function Nc(e) {
	return e.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\(\s*prefers-reduced-motion\s*(?::\s*(reduce|no-preference)\s*)?\)/gi, (e, t) => t?.toLowerCase() === "no-preference" ? "(min-width: 0px)" : "(width < 0px)");
}
function Pc(e) {
	if (!/prefers-reduced-motion/i.test(e)) return e;
	let t = new CSSStyleSheet();
	t.replaceSync(e);
	let n = (e) => {
		for (let t of e) (t instanceof CSSMediaRule || t instanceof CSSImportRule) && (t.media.mediaText = Nc(t.media.mediaText)), "cssRules" in t && n(t.cssRules);
	};
	return n(t.cssRules), [...t.cssRules].map((e) => e.cssText).join("\n");
}
function Fc(e) {
	let t = 0;
	for (let n of e.files) {
		if (!["image/svg+xml", "text/css"].includes(n.mime)) continue;
		let e = new TextDecoder().decode(n.bytes);
		if (!/prefers-reduced-motion/i.test(e)) continue;
		let r;
		if (n.mime === "text/css") r = Pc(e);
		else {
			let t = new DOMParser().parseFromString(e, "image/svg+xml");
			if (t.querySelector("parsererror")) throw Error("Motion SVG could not be parsed: " + n.key);
			for (let e of t.querySelectorAll("style")) e.textContent = Pc(e.textContent || "");
			for (let e of t.querySelectorAll("[media]")) e.setAttribute("media", Nc(e.getAttribute("media")));
			r = new XMLSerializer().serializeToString(t);
		}
		n.bytes = new TextEncoder().encode(r), t++;
	}
	return t;
}
function Ic(e, t, n) {
	let r = window.matchMedia.bind(window), i = [], a = (e) => {
		if (!e) return;
		let t = (e) => {
			for (let r of e) {
				if (r instanceof CSSMediaRule || r instanceof CSSImportRule) {
					let e = r.media.mediaText, t = n(e);
					e !== t && (r.media.mediaText = t);
				}
				"cssRules" in r && t(r.cssRules);
			}
		};
		try {
			let r = e.media.mediaText, i = n(r);
			r !== i && (e.media.mediaText = i), t(e.cssRules);
		} catch {
			i.push("A stylesheet could not be adapted");
		}
	};
	if (t === "normal") {
		window.matchMedia = (e) => {
			let t = String(e), i = n(t), a = r(i);
			return t !== i && Object.defineProperty(a, "media", { value: t }), a;
		};
		let e = (e) => {
			if ((e instanceof HTMLStyleElement || e instanceof HTMLLinkElement) && a(e.sheet), e instanceof Element || e instanceof DocumentFragment) for (let t of e.querySelectorAll("style,link[rel~=\"stylesheet\"]")) a(t.sheet);
		};
		for (let t of [
			Element.prototype,
			Document.prototype,
			DocumentFragment.prototype
		]) for (let n of [
			"append",
			"prepend",
			"replaceChildren"
		]) {
			let r = t[n];
			t[n] = function(...t) {
				r.apply(this, t), this instanceof HTMLStyleElement && a(this.sheet);
				for (let n of t) n instanceof Node && e(n);
			};
		}
		for (let t of [
			"appendChild",
			"insertBefore",
			"replaceChild"
		]) {
			let n = Node.prototype[t];
			Object.defineProperty(Node.prototype, t, {
				configurable: !0,
				writable: !0,
				value: function(...t) {
					let r = Reflect.apply(n, this, t);
					this instanceof HTMLStyleElement && a(this.sheet);
					for (let n of t) n instanceof Node && e(n);
					return r;
				}
			});
		}
		let t = Object.getOwnPropertyDescriptor(Node.prototype, "textContent");
		Object.defineProperty(Node.prototype, "textContent", {
			...t,
			set(e) {
				t.set.call(this, e), this instanceof HTMLStyleElement && a(this.sheet);
			}
		});
		let i = CSSStyleSheet.prototype.insertRule;
		CSSStyleSheet.prototype.insertRule = function(e, t) {
			let n = i.call(this, e, t);
			return a(this), n;
		};
		let o = CSSStyleSheet.prototype.replaceSync;
		CSSStyleSheet.prototype.replaceSync = function(e) {
			o.call(this, e), a(this);
		};
		let s = CSSStyleSheet.prototype.replace;
		CSSStyleSheet.prototype.replace = async function(e) {
			let t = await s.call(this, e);
			return a(this), t;
		};
		let c = Object.getOwnPropertyDescriptor(MediaList.prototype, "mediaText");
		Object.defineProperty(MediaList.prototype, "mediaText", {
			...c,
			set(e) {
				c.set.call(this, n(String(e)));
			}
		});
		let l = MediaList.prototype.appendMedium;
		MediaList.prototype.appendMedium = function(e) {
			l.call(this, n(String(e)));
		}, new MutationObserver((t) => {
			for (let n of t) {
				n.target instanceof HTMLStyleElement ? a(n.target.sheet) : n.target.parentElement instanceof HTMLStyleElement && a(n.target.parentElement.sheet), n.type === "attributes" && e(n.target);
				for (let t of n.addedNodes) e(t);
			}
		}).observe(document, {
			subtree: !0,
			childList: !0,
			characterData: !0,
			attributes: !0,
			attributeFilter: ["media"]
		});
		for (let e of document.styleSheets) a(e);
	}
	window.addEventListener("message", (n) => {
		n.source === parent && n.data?.type === "bgparty:motion-probe" && n.data.runId === e && (async () => {
			let n = "bgparty-motion-probe-" + crypto.randomUUID(), a = document.createElement("div"), o = document.createElement("style");
			a.id = n, a.style.cssText = "position:fixed;left:-10000px;width:1px;height:1px;pointer-events:none;opacity:0", o.textContent = `#${n}{--reduce:0;--normal:0;--bare:0;--negated:0;--combined:0}
        @media(prefers-reduced-motion:reduce){#${n}{--reduce:1}}
        @media(prefers-reduced-motion:no-preference){#${n}{--normal:1;animation:${n} 1s linear infinite}}
        @media(prefers-reduced-motion){#${n}{--bare:1}}
        @media not (prefers-reduced-motion:reduce){#${n}{--negated:1}}
        @media (min-width:0px) and (prefers-reduced-motion:no-preference){#${n}{--combined:1}}
        @keyframes ${n}{from{transform:translateX(0)}to{transform:translateX(100px)}}`, document.head.append(o), document.body.append(a);
			try {
				let n = getComputedStyle(a), o = {
					reduce: n.getPropertyValue("--reduce").trim() === "1",
					noPreference: n.getPropertyValue("--normal").trim() === "1",
					bare: n.getPropertyValue("--bare").trim() === "1",
					negated: n.getPropertyValue("--negated").trim() === "1",
					combined: n.getPropertyValue("--combined").trim() === "1"
				}, s = a.getAnimations()[0], c = typeof s?.currentTime == "number" ? s.currentTime : null, l = n.transform;
				await new Promise((e) => setTimeout(e, 100));
				let u = typeof s?.currentTime == "number" ? s.currentTime : null, d = s?.playState === "running" && c !== null && u !== null && u > c && n.transform !== l, f = {
					reduce: matchMedia("(prefers-reduced-motion:reduce)").matches,
					noPreference: matchMedia("(prefers-reduced-motion:no-preference)").matches
				}, p = !f.reduce && f.noPreference && !o.reduce && !o.bare && o.noPreference && o.negated && o.combined && d && i.length === 0;
				parent.postMessage({
					type: "bgparty:motion-observation",
					runId: e,
					report: {
						adapter: "bgparty.acceptance-motion@1",
						requested: t,
						native: {
							reduce: r("(prefers-reduced-motion:reduce)").matches,
							noPreference: r("(prefers-reduced-motion:no-preference)").matches
						},
						effective: f,
						css: o,
						animation: {
							advancing: d,
							before: c,
							after: u
						},
						ready: p,
						failures: [...new Set(i)]
					}
				}, "*");
			} catch (t) {
				parent.postMessage({
					type: "bgparty:motion-error",
					runId: e,
					error: String(t)
				}, "*");
			} finally {
				a.remove(), o.remove();
			}
		})();
	});
}
function Lc(e, t, n) {
	return new Proxy(e, { get(e, r) {
		if (r === "append") return (...r) => {
			for (let e of r) if (e instanceof HTMLIFrameElement) {
				if (!/<script nonce="[^"]+">/.test(e.srcdoc)) throw Error("Acceptance motion bootstrap is unavailable");
				e.srcdoc = e.srcdoc.replace(/(<script nonce="[^"]+">)/, (e, r) => r + `(${Ic.toString()})(${JSON.stringify(t)},${JSON.stringify(n)},(${Nc.toString()}));`);
			}
			e.append(...r);
		};
		let i = Reflect.get(e, r, e);
		return typeof i == "function" ? i.bind(e) : i;
	} });
}
function Rc(e, t) {
	return new Promise((n, r) => {
		let i = () => {
			clearTimeout(o), window.removeEventListener("message", a);
		}, a = (a) => {
			a.source === e.contentWindow && a.data?.runId === t && (a.data.type === "bgparty:motion-error" && (i(), r(Error(a.data.error))), a.data.type === "bgparty:motion-observation" && (i(), n(a.data.report)));
		}, o = setTimeout(() => {
			i(), r(/* @__PURE__ */ Error("Acceptance motion probe did not respond"));
		}, 5e3);
		window.addEventListener("message", a), e.contentWindow.postMessage({
			type: "bgparty:motion-probe",
			runId: t
		}, "*");
	});
}
//#endregion
//#region tools/game-dev-preview.ts
var zc = document.getElementById("game"), Bc = document.getElementById("status"), Vc = document.getElementById("seat"), Hc = document.getElementById("bot-seat"), q, Uc, J, Wc = [], Gc = [], Kc, Y = 0, qc = 0, Jc = Promise.resolve(), X = "zh", Z = new URLSearchParams(location.search).get("acceptance"), Yc, Xc, Zc = 0, Q = {
	zh: {
		players: "人数",
		start: "重新开局",
		play: "返回对局",
		options: "选项",
		guide: "规则",
		bot: "机器人行动",
		ready: "已就绪",
		noAction: "当前没有可用的机器人行动",
		player: "玩家",
		restore: "恢复日志",
		prepared: "载入准备日志",
		export: "导出当前日志",
		tools: "验收记录与日志",
		log: "合法动作日志 JSON"
	},
	en: {
		players: "Players",
		start: "New game",
		play: "Back to game",
		options: "Options",
		guide: "Rules",
		bot: "Bot action",
		ready: "Ready",
		noAction: "No available bot action",
		player: "Player",
		restore: "Restore log",
		prepared: "Load prepared log",
		export: "Export current log",
		tools: "Acceptance and logs",
		log: "Legal action log JSON"
	}
};
function Qc() {
	document.documentElement.lang = X;
	for (let e of [
		"start",
		"play",
		"options",
		"guide",
		"bot",
		"restore",
		"prepared",
		"export"
	]) document.getElementById(e).textContent = Q[X][e];
	document.getElementById("tools-label").textContent = Q[X].tools, document.getElementById("log-label").textContent = Q[X].log, document.getElementById("players-label").textContent = Q[X].players, Bc.textContent = Q[X].ready, $c();
}
function $c() {
	let e = document.getElementById("motion-status");
	Xc && (e.textContent = X === "zh" ? `动效环境：${Xc.ready ? "正常动效已就绪" : "正常动效未就绪"}；系统偏好：${Xc.native.reduce ? "减少动效" : "正常动效"}；验收模式：${Yc === "normal" ? "强制正常动效" : "跟随系统"}` : `Motion environment: ${Xc.ready ? "normal motion ready" : "normal motion NOT ready"}; system: ${Xc.native.reduce ? "reduced" : "normal"}; acceptance: ${Yc === "normal" ? "force normal" : "follow system"}`, document.getElementById("motion-observation").textContent = JSON.stringify({
		...Xc,
		adaptedAssets: Zc
	}, null, 2));
}
async function el() {
	if (Z && Yc) {
		if (Xc = await Rc(q.frame, Z), $c(), !(await fetch("/acceptance-motion", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				...Xc,
				adaptedAssets: Zc
			})
		})).ok) throw Error("Motion observation could not be saved");
		if (Yc === "normal" && !Xc.ready) throw Error("Normal motion is not ready; motion acceptance is incomplete");
	}
}
async function tl(e) {
	if (J && e.version <= J.version) return;
	let t = !J;
	if (t && (Wc = []), J = e, Wc = [...Wc, ...e.fx.flat()], clearTimeout(Kc), await al(t), nl(), J !== e || e.nextTick === null) return;
	let n = Y;
	Kc = setTimeout(() => {
		q.call("tick", { now: Date.now() }).then((e) => n === Y ? tl(e) : void 0).catch($);
	}, Math.max(16, e.nextTick));
}
function nl() {
	document.getElementById("preview-state").textContent = JSON.stringify({
		runId: Z,
		version: J?.version,
		status: J?.status,
		players: Gc,
		locale: X,
		seat: Vc.value,
		botSeat: Hc.value || Vc.value
	}, null, 2);
}
function rl(e) {
	Gc = e, Vc.replaceChildren(...Gc.map((e, t) => Object.assign(document.createElement("option"), {
		value: e,
		textContent: `${Q[X].player} ${t + 1}`
	}))), Hc.replaceChildren(Object.assign(document.createElement("option"), {
		value: "",
		textContent: X === "zh" ? "跟随观察座位" : "Follow viewing seat"
	}), ...Gc.map((e, t) => Object.assign(document.createElement("option"), {
		value: e,
		textContent: `${Q[X].player} ${t + 1}`
	}))), document.getElementById("count").value = String(Gc.length);
}
function il(e, t) {
	return e.flatMap((e) => {
		let { secret: n, for: r, ...i } = e;
		return r?.includes(t) ? n === void 0 ? [i] : [{
			...i,
			secret: n
		}] : e.rid !== void 0 || e.data !== void 0 ? [i] : [];
	});
}
function al(e = !1) {
	if (!J) return Promise.resolve();
	let t = J, n = Vc.value, r = `${Y}:${qc}`, i = {
		props: {
			...t.views[n],
			members: Gc.map((e, t) => ({
				rid: e,
				name: `Player ${t + 1}`,
				avatar: t,
				colorIndex: t
			})),
			myRid: n
		},
		fx: il(Wc, n),
		epoch: r,
		result: t.status.winner && t.status.ranking ? t.status : void 0,
		host: !0
	}, a = () => r === `${Y}:${qc}` && n === Vc.value, o = Jc.then(async () => {
		a() && (e && (await q.call("render", {
			...i,
			fx: []
		}), await new Promise((e) => requestAnimationFrame(() => requestAnimationFrame(() => e())))), a() && J === t && await q.call("render", i));
	});
	return Jc = o.catch(() => {}), o;
}
async function ol() {
	let e = ++Y;
	clearTimeout(Kc);
	let t = await q.call("describe", { config: Uc });
	if (e !== Y) return;
	document.getElementById("options").disabled = !t.options, document.getElementById("guide").disabled = !t.guide, document.getElementById("bot").disabled = !t.bot;
	let n = Math.min(t.range.max, Math.max(t.range.min, Number(document.getElementById("count").value)));
	rl(Array.from({ length: n }, (e, t) => `preview-${t}`)), J = void 0;
	let r = await q.call("start", {
		players: Gc,
		config: Uc,
		seed: 1
	});
	e === Y && await tl(r);
}
async function sl() {
	if (Z) {
		let e = await fetch("/acceptance.json");
		if (!e.ok) throw Error("Acceptance identity is unavailable");
		let t = await e.json();
		if (t.id !== Z) throw Error("Acceptance identity changed");
		if (!["normal", "system"].includes(t.settings?.motion) || t.settings.motionAdapter !== "bgparty.acceptance-motion@1") throw Error("Acceptance motion settings are unavailable");
		Yc = t.settings.motion, document.getElementById("motion-status").hidden = !1, document.getElementById("motion-check").hidden = !1, document.getElementById("identity").textContent = JSON.stringify(t, null, 2), document.getElementById("prepared").disabled = !t.inputs.some((e) => e.route === "/prepared-log.json");
	}
	let e = await Promise.all(["/sdk.zip", "/game.zip"].map(async (e) => mc(new Uint8Array(await (await fetch(e)).arrayBuffer()))));
	uc(e[1].manifest, e[0].manifest);
	let t = [];
	for (let [n, r] of e.entries()) for (let e of r.manifest.dependencies) t.push(await mc(new Uint8Array(await (await fetch((n === 0 ? "/runtime/" : "/release/") + e.url)).arrayBuffer()), e.sha256));
	let n = {
		files: [],
		modules: {},
		assets: {},
		css: [],
		entry: "@bgparty/game/entry",
		locale: "zh"
	};
	for (let [r, { manifest: i, files: a }] of [...t, ...e].entries()) {
		for (let [e, t] of Object.entries(a)) n.files.push({
			key: `${r}/${e}`,
			bytes: t,
			mime: i.files[e].mime
		});
		for (let [e, t] of Object.entries(i.exports)) n.modules[e] = `${r}/${t}`;
		for (let [e, t] of Object.entries(i.assets)) n.assets[e] = `${r}/${t}`;
		for (let e of i.css) n.css.push(new TextDecoder().decode(a[e]));
	}
	let r = new URL("/game.zip", location.href).href, i = e[1].manifest.id, a = JSON.stringify(Z ? [
		r,
		i,
		Z
	] : [r, i]), o = await yc(() => Dc({
		identity: a,
		source: r,
		gameId: i,
		storage: {}
	}));
	n.storage = o.values, n.storageRevision = o.revision, Yc === "normal" && (Zc = Fc(n)), q = await Mc({
		container: Z && Yc ? Lc(zc, Z, Yc) : zc,
		payload: n,
		storageIdentity: a,
		title: "Game preview",
		onEvent(e, t) {
			if (e === "config" && (Uc = t, q.call("configure", {
				value: Uc,
				offline: !0
			}).catch($)), e === "play-again" && ol().catch($), e === "back" && ol().catch($), e === "action") {
				let e = Y, n = Vc.value;
				q.call("action", {
					rid: n,
					action: t
				}).then(async (t) => {
					e === Y && (t.error && (Bc.textContent = JSON.stringify(t.error)), await tl(t.snapshot));
				}).catch($);
			}
		}
	}), await el(), await ol(), Qc();
}
function $(e) {
	Bc.textContent = e instanceof Error ? e.message : String(e), console.error(e);
}
document.getElementById("start").onclick = () => {
	ol().catch($);
}, document.getElementById("motion-check").onclick = () => {
	el().catch($);
}, document.getElementById("play").onclick = () => {
	al().catch($);
}, document.getElementById("options").onclick = () => {
	q.call("configure", {
		value: Uc,
		offline: !0
	}).catch($);
}, document.getElementById("guide").onclick = () => {
	q.call("configure", { mode: "guide" }).catch($);
}, document.getElementById("locale").onchange = (e) => {
	X = e.target.value === "en" ? "en" : "zh", q.call("locale", { locale: X }).then(async () => {
		Qc(), await al(), nl();
	}).catch($);
}, Vc.onchange = () => {
	qc++, Wc = [], al(!0).then(nl).catch($);
};
async function cl(e) {
	if (!Array.isArray(e)) throw Error("Expected a JSON action log array");
	let t = ++Y;
	clearTimeout(Kc);
	let n = await q.call("restore", { log: e });
	t === Y && (Uc = e[0].config, rl(Object.keys(n.views)), J = void 0, await tl(n), Bc.textContent = Q[X].ready);
}
document.getElementById("restore").onclick = () => {
	(async () => {
		await cl(JSON.parse(document.getElementById("log").value));
	})().catch($);
}, document.getElementById("prepared").onclick = () => {
	(async () => {
		let e = await fetch("/prepared-log.json");
		if (!e.ok) throw Error("Prepared log is unavailable");
		let t = await e.json();
		document.getElementById("log").value = JSON.stringify(t), await cl(t);
	})().catch($);
}, document.getElementById("export").onclick = () => {
	if (!J) return;
	let e = JSON.stringify(J.log, null, 2);
	document.getElementById("log").value = e;
	let t = URL.createObjectURL(new Blob([e], { type: "application/json" }));
	Object.assign(document.createElement("a"), {
		href: t,
		download: `game-log-${Z || "preview"}.json`
	}).click(), setTimeout(() => URL.revokeObjectURL(t), 1e3);
}, document.getElementById("bot").onclick = () => {
	(async () => {
		if (!J) return;
		let e = Y, t = Hc.value || Vc.value, n = J.version, { move: r } = await q.call("bot", {
			rid: t,
			view: J.botViews[t]
		});
		if (e !== Y || J?.version !== n) return;
		if (!r) {
			Bc.textContent = Q[X].noAction;
			return;
		}
		let i = await q.call("action", {
			rid: t,
			action: r.action
		});
		e === Y && (i.error && (Bc.textContent = JSON.stringify(i.error)), await tl(i.snapshot));
	})().catch($);
}, sl().catch($);
//#endregion
