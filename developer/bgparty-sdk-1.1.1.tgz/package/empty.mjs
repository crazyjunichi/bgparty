throw new Error("BGParty SDK modules run inside the game sandbox. Use bgparty-game preview.");
