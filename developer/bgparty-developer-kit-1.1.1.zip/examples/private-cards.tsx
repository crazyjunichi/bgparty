import 'bgparty:game-utilities'
import { z } from 'zod'
import { defineGame, randomIntAt, type GameDefinition, type BotThink } from '@bgparty/sdk/core'
import { useT } from '@bgparty/sdk/i18n'
import { gameAssetUrl } from '@bgparty/sdk/assets'
import { GameScreen, type GameOptionsProps, type GameOverViewProps } from '@bgparty/sdk/ui'
import specification from '../game.json'
import { locales } from '../src/messages'

const configSchema = z.object({ maximum: z.union([z.literal(6), z.literal(9)]).default(9) }).default({ maximum: 9 })
const publicSchema = z.object({ players: z.array(z.string()), turn: z.string(), revealed: z.record(z.string(), z.number()) })
const privateSchema = z.object({ card: z.number().int() })
const actionSchema = z.object({ type: z.literal('reveal') }).strict()
type Public = z.infer<typeof publicSchema>
type Private = z.infer<typeof privateSchema>
type Action = z.infer<typeof actionSchema>
type Config = z.infer<typeof configSchema>
interface State extends Public { cards: Record<string, number> }

const definition = defineGame<GameDefinition<State, Action, Public, Private, Config>>({
  meta: { ...specification.metadata, mechanics: ['hand-management'], interactionTags: [], hotseat: 'cover', tier: 'alpha', nameKey: 'games.demo.name', descKey: 'games.demo.desc', rulesKey: 'games.demo.rules' },
  saveCompatibility: { version: '1' },
  schemas: { action: actionSchema, publicView: publicSchema, privateView: privateSchema, config: configSchema },
  setup(config, players, seed) {
    return { state: { players, turn: players[0], revealed: {}, cards: Object.fromEntries(players.map((rid, i) => [rid, randomIntAt(seed, i, config.maximum) + 1])) } }
  },
  reduce(state, _action, { by }) {
    if (by !== state.turn || by in state.revealed) return { code: 'games.demo.invalid' }
    const revealed = { ...state.revealed, [by]: state.cards[by] }
    const next = state.players.find((rid) => !(rid in revealed))
    return { state: { ...state, revealed, turn: next ?? '' } }
  },
  viewFor({ players, turn, revealed, cards }, rid) { return { public: { players, turn, revealed }, private: { card: cards[rid] } } },
  status(state) {
    if (state.turn) return { phase: 'play' }
    const ranking = [...state.players].sort((a, b) => state.revealed[b] - state.revealed[a])
    return { phase: 'done', ranking, winner: ranking.filter((rid) => state.revealed[rid] === state.revealed[ranking[0]]), scores: state.revealed }
  },
})

function View({ public: view, private: own, myRid, members, send }: { public: Public; private: Private; myRid: string; members: { rid: string; name: string }[]; send(action: Action): void }) {
  const t = useT()
  return <GameScreen adaptive actionsHeight="h-20" actions={<div className="flex h-full items-center justify-center"><button className="btn-base min-h-12 bg-platform-green px-6 text-white disabled:opacity-40" disabled={view.turn !== myRid} onClick={() => send({ type: 'reveal' })}>{t('games.demo.reveal')}</button></div>}>
    <main className="mx-auto flex max-w-lg flex-col items-center gap-4 p-4 text-ink">
      <h1 className="text-2xl font-bold">{t('games.demo.name')}</h1>
      <img src={gameAssetUrl('token.svg')} width="80" height="80" alt="" />
      <p className="text-xl font-bold">{t('games.demo.card', { n: own.card })}</p>
      <ul className="w-full space-y-2">{view.players.map((rid, index) => <li key={rid} className="plate flex justify-between gap-3 p-3"><span>{members.find((member) => member.rid === rid)?.name ?? t('games.demo.player', { n: index + 1 })}</span><span>{view.revealed[rid] ?? t('games.demo.hidden')}</span></li>)}</ul>
    </main>
  </GameScreen>
}
function Options({ value, onChange }: GameOptionsProps) {
  const t = useT()
  const config = configSchema.parse(value)
  return <label className="flex items-center justify-between gap-4 p-4">{t('games.demo.maximum')}<select className="min-h-11 rounded-lg border-2 border-ink p-2" value={config.maximum} onChange={(event) => onChange({ maximum: Number(event.target.value) })}><option value="6">6</option><option value="9">9</option></select></label>
}
function Guide() { const t = useT(); return <p className="p-4">{t('games.demo.privateRules')}</p> }
function OverView({ result, members, onPlayAgain, onBackToLobby }: GameOverViewProps) {
  const t = useT()
  return <main className="mx-auto flex max-w-lg flex-col gap-4 p-4 text-ink"><h1 className="text-2xl font-bold">{t('games.demo.result')}</h1><ol>{result.ranking.map((rid) => <li key={rid} className="plate my-2 flex justify-between p-3"><span>{members.find((member) => member.rid === rid)?.name}</span><strong>{result.scores?.[rid]}</strong></li>)}</ol>{onPlayAgain && <button className="btn-base min-h-12 bg-platform-green text-white" onClick={onPlayAgain}>{t('games.demo.again')}</button>}{onBackToLobby && <button className="btn-quiet min-h-11" onClick={onBackToLobby}>{t('games.demo.back')}</button>}</main>
}
const bot: BotThink<Public, Private, Action> = (view, ctx) => view.public.turn === ctx.rid ? { action: { type: 'reveal' } } : null
export default { definition, View, locales, bot, Options, Guide, OverView }
