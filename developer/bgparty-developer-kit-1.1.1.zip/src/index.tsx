import 'bgparty:game-utilities'
import { z } from 'zod'
import { defineGame, type GameDefinition } from '@bgparty/sdk/core'
import { useT } from '@bgparty/sdk/i18n'
import { GameScreen } from '@bgparty/sdk/ui'
import specification from '../game.json'
import { locales } from './messages'

const viewSchema = z.object({ total: z.number().int(), turn: z.string(), players: z.array(z.string()) })
const actionSchema = z.object({ add: z.union([z.literal(1), z.literal(2)]) })
type View = z.infer<typeof viewSchema>
type Action = z.infer<typeof actionSchema>
interface State extends View { winner?: string }

const definition = defineGame<GameDefinition<State, Action, View, Record<string, never>>>({
  saveCompatibility: { version: '1' },
  meta: { ...specification.metadata, mechanics: ['race'], interactionTags: [], hotseat: 'open', tier: 'alpha', nameKey: 'games.demo.name', descKey: 'games.demo.desc', rulesKey: 'games.demo.rules' },
  schemas: { action: actionSchema, publicView: viewSchema, privateView: z.object({}) },
  setup(_config, players) { return { state: { total: 0, players, turn: players[0] } } },
  reduce(state, action, ctx) {
    if (state.winner || ctx.by !== state.turn || state.total + action.add > 10) return { code: 'games.demo.invalid' }
    const total = state.total + action.add
    return { state: { ...state, total, turn: state.players[(state.players.indexOf(state.turn) + 1) % state.players.length], winner: total === 10 ? ctx.by : undefined } }
  },
  viewFor({ total, turn, players }) { return { public: { total, turn, players } } },
  status(state) { return { phase: state.winner ? 'done' : 'play', ...(state.winner ? { winner: [state.winner], ranking: [state.winner, ...state.players.filter((rid) => rid !== state.winner)] } : {}) } },
})

function GameView({ public: view, myRid, send }: { public: View; myRid: string; send(action: Action): void }) {
  const t = useT()
  return <GameScreen adaptive actionsHeight="h-20" actions={
    <div className="flex h-full items-center justify-center gap-4">{([1, 2] as const).map((add) => <button key={add} className="btn-base min-h-12 bg-platform-green px-6 text-white disabled:opacity-40" disabled={view.turn !== myRid || view.total + add > 10} onClick={() => send({ add })}>{t('games.demo.add', { n: add })}</button>)}</div>
  }><main className="flex h-full flex-col items-center justify-center gap-4 bg-paper p-4 text-ink">
    <h1 className="text-3xl font-bold">{t('games.demo.name')}</h1>
    <p className="text-xl">{t('games.demo.total', { n: view.total })}</p>
  </main></GameScreen>
}
const bot = (view: { public: View }, ctx: { rid: string }) => view.public.turn === ctx.rid && view.public.total < 10 ? { action: { add: view.public.total === 9 ? 1 : 2 } } : null
export default { definition, View: GameView, locales, bot }
