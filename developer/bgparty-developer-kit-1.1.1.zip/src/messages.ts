import specification from '../game.json'

export const zh = {
  ...specification.metadata.labels.zh,
  total: '当前总数：{{n}}', add: '加 {{n}}', invalid: '请在轮到你时选择有效操作。',
  privateName: '密牌比大小', privateDesc: '轮流亮出密牌，数值最高的玩家获胜。',
  privateRules: '每人获得一张密牌。轮到你时亮牌，所有人亮牌后，数值最高的玩家获胜；相同数值并列获胜。',
  card: '你的密牌：{{n}}', reveal: '亮出密牌', hidden: '尚未亮牌',
  maximum: '牌面上限', result: '本局结果', again: '再来一局', back: '返回',
  player: '玩家 {{n}}', waiting: '等待其他玩家亮牌',
}
export const en: typeof zh = {
  ...specification.metadata.labels.en,
  total: 'Total: {{n}}', add: 'Add {{n}}', invalid: 'Choose a valid action on your turn.',
  privateName: 'Secret Cards', privateDesc: 'Reveal your secret card. The highest value wins.',
  privateRules: 'Each player receives a secret card. Reveal it on your turn. After all cards are revealed, the highest value wins; tied players share the win.',
  card: 'Your secret card: {{n}}', reveal: 'Reveal card', hidden: 'Not revealed',
  maximum: 'Maximum card value', result: 'Results', again: 'Play again', back: 'Back',
  player: 'Player {{n}}', waiting: 'Waiting for other players to reveal',
}
declare module '@bgparty/sdk/messages' { interface GameMessages { demo: typeof zh } }
export const locales = { zh, en }
