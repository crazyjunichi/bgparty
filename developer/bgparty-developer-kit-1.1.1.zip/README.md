# 制作你的游戏 / Create your game

完整开发包已包含配套的 `bgparty-sdk.tgz`。安装 Node.js 22.18 或更高版本，在本目录执行 `npm install`，再执行 `npm run dev` 即可试玩。首次安装需要访问 npm 获取依赖，无需 BGParty 主工程。若从源码仓库直接复制此目录，请先运行仓库的 `npm run developers:build` 获取完整开发包，不要自行猜测 SDK 文件名。

Start with [Quick start](docs/quickstart.en.md). 中文从[快速开始](docs/quickstart.zh.md)阅读；接下来可以[使用 AI 制作](docs/ai.zh.md) / [Create with AI](docs/ai.en.md)，也可以[编写游戏代码](docs/development.zh.md) / [Code your game](docs/development.en.md)。完成后按指南[发布你的游戏](docs/publishing.zh.md) / [Publish your game](docs/publishing.en.md)。查询接口时查看 [SDK 接口索引](docs/API.md)；与 AI 协作前让它阅读 [AGENTS.md](AGENTS.md)。

使用 `npm run rename -- my-game` 统一修改游戏 ID 和翻译键；使用 `npm run example -- private-cards` 体验包含私有信息、SVG 素材、开局选项、机器人、规则页和终局页的示例。`npm run example -- basic` 切回基础示例。切换示例会替换示例元数据，开始制作自己的游戏后不要再切换。正式制作前先改 ID，发布后保持不变。

`npm run check` 检查类型、元数据与封面文件，不等同于实际游玩通过。`npm run dev` 启动本机随机端口的严格沙箱预览，Ctrl+C 退出；修改代码后在另一个终端运行 `npm run build`，再刷新预览，或退出后重新运行 `npm run dev`。预览提供换座位、选项、规则、中英文、机器人单步与重新开局，不包含多人联机；实际联机、安装更新、离线和续玩需在 BGParty 验收。

修改 `game.json` 的稳定游戏 ID、元数据和入口，在 `src/` 实现规则和 React 视图。双语消息通过 `@bgparty/sdk/messages` 扩展，仍有完整的翻译键类型检查。包内素材放 `public/`。

构建产物为 `.bgparty/release/games.json` 与 `games/<游戏ID>/` 下平铺的游戏 ZIP、可选素材/数据卷及封面，文件名包含内容版本或摘要。封面在 `game.json` 的 `metadata.iconPath` 声明，例如 `resources/cover.svg` 对应 `public/cover.svg`；工具自动生成清单中的发布路径。将整个发布目录放到支持 CORS 的 HTTPS 静态站，再把 `games.json` 地址添加为游戏源；主站不导入或代发外部游戏 ZIP。更新同一个游戏时保持 ID 不变，不覆盖同地址的字节，发布完整当前快照并撤下旧路径。

模板从首个版本声明 `saveCompatibility: { version: '1' }`。这是独立的存档版本，不跟随 ZIP 内容版本、SDK 版本或发布次数递增；纯画面、布局、文案和展示素材修改保持不变。规则、配置、动作、初始化、种子随机序列或玩法数据修改须检查旧记录的含义，Bug 修复不自动视为兼容。

兼容更新保持存档版本；直接接受其他旧版本时列入 `compatibleWith`。需要转换时升级版本并提供 `migrate({ version, log })`，返回新日志或用 `null` 明确拒绝；需要转换的版本不要列入 `compatibleWith`，否则迁移不会执行。无法安全兼容时升级版本并明确需要重新开局，已发布存档版本不能改作其他含义或回退复用。既有无 `saveVersion` 的记录会以 `version: undefined` 交给迁移；当前迁移接口不提供旧游戏包摘要，须明确其兼容前提。BGParty 的 2026-10-27 存量过渡按当前游戏兼容既有旧档的前提补版本 `'1'`（已有声明保留），通过 `version === undefined ? log : null` 原样接纳无版本日志并继续恢复校验；该过渡分支仅用于存量游戏，不必加入从此模板新建的游戏。后续破坏兼容时须重新处理此分支。

除上述已确定兼容前提的存量过渡外，发布前使用对应旧发布版本留下的代表性记录，在候选版本中验证恢复或转换，核对进度、关键资源和结果；发布记录注明当前存档版本、接受的旧版本或无版本记录范围、游戏/SDK 摘要、判断依据、验证结果及未验项。平台兼容检查只处理原档副本，并实际校验恢复；结构不变或重放不报错均不能单独证明规则含义兼容。当前版本自身重放及游戏/SDK 冒烟也不能代替跨发布版本核验，没有相应证据就不能声称旧档兼容已验证通过；存量基线的兼容前提不写作逐款实测结果。

开发预览支持换座位、开局选项、重新开局与执行规则机器人一步。完整平台验收还包括联机、续玩、离线、移除、更新和四浏览器兼容。

新增跨局成长使用 `@bgparty/sdk/storage` 的 `readGameStorage()` 与 `writeGameStorage({ revision, values })`，并声明 `sdkApi: 2`。读取最新快照后计算奖励，将成长数据与对局/玩家去重记录同次提交；`saved` 表示主站数据库事务已提交，`conflict` 返回最新快照，须重新计算，异常或重试耗尽则提示失败并允许重试。游戏维护独立的数据版本与迁移，不直接打开原生 IndexedDB。旧游戏的代理 `localStorage` 继续可用，但同步返回不表示写盘完成。移除下载保留游戏数据，独立清除需二次确认；浏览器清理网站数据仍会丢失本机进度。

预览根据构建结果运行，修改源码后重新构建并刷新或重启预览。`bgparty:game-utilities` 提供当前游戏使用的 Tailwind 样式；公共主题和工具类由 SDK 提供。
