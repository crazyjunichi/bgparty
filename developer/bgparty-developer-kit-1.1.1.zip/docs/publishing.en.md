# Publish your game

Once you upload your finished game, you and your friends can download and play it in BGParty. Follow this guide to upload the right files, add your game and troubleshoot common problems.

## Upload your game files

```sh
npm run check
npm run build
```

Upload the contents of the complete .bgparty/release/ directory to your static host, including games.json, game ZIPs, every asset/data volume and covers. Do not upload source code, node_modules or bgparty-sdk.tgz. Game sources do not publish runtime SDKs.

Use public HTTPS with browser cross-origin access (CORS), without authentication, cookies or redirects. Public object storage/CDN files can use Access-Control-Allow-Origin: *. Verify the catalog, ZIPs and covers. File-sharing pages and expiring download links are usually unsuitable.

In BGParty, open Settings → Game sources and downloads and add the full URL, such as https://example.com/my-games/games.json. Find the game, install and start it, then verify networking from another device. Test offline use after installation. Opening a file directly does not prove CORS is correct.

Keep the ID and source URL stable for updates. Upload the full new snapshot, new ZIPs/resources before games.json, then withdraw obsolete paths. Never change bytes at published content-addressed paths. For multiple games, maintain a complete combined catalog; do not overwrite it with another independent project's single-game catalog.

## Troubleshooting

- Missing bgparty-sdk.tgz: obtain the complete kit, retain the root archive, and do not substitute runtime sdk.zip. When upgrading an existing project, replace the matching SDK archive and reinstall dependencies.
- Installation or Node errors: check node --version, npm connectivity/proxy and the full error. Windows users can try npm.cmd.
- Visible games.xxx keys: rename consistently and check GameMessages, key prefixes and the registered locales ID.
- Edits do not appear: dev has no watcher; rebuild and refresh, or stop and rerun dev.
- Phone cannot reach local preview: it binds only 127.0.0.1. Use an HTTPS BGParty platform and published source for real-device networking.
- Blank images: check public/ files, aliases relative to public/, case and gameAssetUrl; omit the resources/ prefix and do not use /public/ or remote URLs.
- Missing options/rules/bot: align capabilities with actual exports, then rebuild.
- Source cannot load: check HTTPS, CORS, no redirects, full uploads, sizes and hashes for both catalog and ZIPs.
- Unsupported SDK/API: check sdkApi and platform version. Upgrade the platform or SDK, not just the requirement number.
- Save cannot resume: review saveCompatibility and old-version logs. If incompatible, start a new match; do not rewrite the original save to force acceptance.

## Release record

Record game ID, SDK/save versions, changes, tested counts/options/languages/browsers, networking/offline results and untested cases. To claim compatibility, restore representative logs from the previous published version and compare progress, resources and results. Current-version self-tests are insufficient.
