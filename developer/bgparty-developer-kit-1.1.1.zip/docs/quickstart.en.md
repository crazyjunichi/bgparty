# Quick start

Run a playable example first, then turn it into your own board game. The complete kit includes the SDK, examples and guides. Follow the steps below to begin.

## 1. Install and play

Install Node.js >=22.18 with npm. Extract the kit and open a terminal in the directory containing package.json.

```sh
node --version
npm --version
npm install
npm run check
npm run dev
```

Initial installation downloads dependencies from npm; node_modules is not included. On Windows, use npm.cmd if PowerShell blocks npm.ps1. Do not double-click HTML or open game ZIPs directly.

Open the random 127.0.0.1 URL printed in the terminal. Ctrl+C stops the preview. The real sandbox provides seat switching, player counts, one bot action, Chinese/English, rules and restart. The basic example has no options or custom guide, so those buttons are disabled.

## 2. Project files

- game.json: entry, stable ID, labels, rules, player counts, cover and capabilities.
- src/index.tsx: playable Count to Ten rules, view and bot.
- src/messages.ts: shared example translations and message type augmentation.
- examples/private-cards.tsx: private information, options, SVG assets, rules and results.
- public/cover.svg and public/token.svg: replaceable original sample artwork.
- bgparty-sdk.tgz: matching SDK npm archive; keep it in the project root.
- docs/ and AGENTS.md: manual and AI development guidance.
- .bgparty/release/: generated publishable source, separate from code.

## 3. Try the advanced example

Stop the current preview first:

```sh
npm run example -- private-cards
npm run dev
```

Each seat sees only its own card. Switch seats and reveal, or use bot actions, until results appear. Select a maximum in Options and click New game to apply it. Rules opens the guide. Switching language returns to gameplay; reopen options/rules when needed.

Use npm run example -- basic to return. Selection replaces sample entry, labels, rules, hotseat policy and capability flags; choose before customizing. The examples share a development identity but are different games, not compatible published updates.

## 4. Make it yours

```sh
npm run rename -- my-game
npm run check
```

Rename updates the ID, translation keys and GameMessages together. Use lowercase letters, digits and hyphens. Keep the ID stable once published. Edit both language labels, rules, counts, search aliases and releasedAt in game.json; use a complete zoned timestamp such as 2026-10-28T12:00:00+08:00. Do not change only the JSON ID.

Keep bgparty-sdk.tgz when moving the project. Its actual version is recorded in developer-kit.json and node_modules/@bgparty/sdk/package.json.

## 5. Iterate

```sh
npm run check
npm run build
```

check validates types, metadata and cover presence, not gameplay. dev builds once and starts a preview, without a file watcher. After edits, build in another terminal and refresh, or stop and rerun dev. Refresh starts a new match. Preview is not a multiplayer, installation or save-resume test; its random port is unsuitable for persistence across restarts.

Next, [create with AI](ai.en.md) or [code your game](development.en.md). Use the [SDK API index](API.md) to look up interfaces, then [publish your game](publishing.en.md) when it is ready.

For fixed-package acceptance and legal log restoration, see the [development guide](development.en.md#fixed-packages-and-log-restoration).
