# BGParty independent game / 独立游戏

Read `README.md`, then `docs/quickstart.en.md`, `docs/development.en.md`, `docs/API.md` and `docs/ai.en.md`. 中文对应 `.zh.md` 文档。

- This project is standalone. Do not ask for or import the BGParty main repository. The included `bgparty-sdk.tgz` supplies the compiler, declarations and sandbox preview.
- First confirm the intended rules, player counts, public/private information and acceptance criteria. Build a playable rules prototype before expanding visuals.
- Run `npm run rename -- my-game` to change identity and translation keys together. Keep that ID stable after publication. Choose an example before customizing: `npm run example -- basic|private-cards` replaces sample metadata.
- Implement pure `setup`, `reduce`, `viewFor`, `status`; validate actions and views with zod. Check turn/permission inside `reduce`, not only in disabled buttons. Randomness uses `randomIntAt(seed, cursor, n)`; retain/increment the cursor in state after setup. Time enters through tick actions.
- Never expose other players' secrets in the public view. Bots receive cropped views. Return `{ code: 'games.<id>.<error>' }` for rejected actions. End a game with both `winner` and complete `ranking`.
- Import public modules from `@bgparty/sdk/*`; React and zod use standard package names. Do not import the SDK's placeholder empty.mjs or private types/src paths. Let the provided build tool externalize host modules.
- Put assets in `public/`; use `gameAssetUrl('<file>')` with the path relative to public, without a resources/ prefix. metadata.iconPath uses the separate package path resources/cover.svg. Do not assume website-root paths. Game code cannot access the network, parent window, native IndexedDB, room credentials or AI keys.
- Use `GameScreen`, stable action slots, touch targets >=44px and responsive layouts. Keep UI strings in matching zh/en locales. Game CSS classes use a unique game prefix. Prefer SVG for project-created art.
- Keep `game.json` labels, player range, hotseat policy and capabilities consistent with the exported plugin. Optional exports are listed in the development guide.
- Maintain `saveCompatibility.version` independently of SDK/package versions. Rules/config/random sequence changes require compatibility review; visual-only changes normally keep the version. Never claim cross-version compatibility without old-version evidence.
- Persistent progress uses `@bgparty/sdk/storage` and `sdkApi: 2`; write with the latest revision, recompute on conflict, only show saved after `status: 'saved'`. Rewards and deduplication records are committed together. See the development guide.
- Run `npm run check` and `npm run build`. Browser preview uses a random localhost port and Ctrl+C to exit; ask the project owner before starting a listener if their policy requires it. Document which runtime scenarios were actually verified. A type check is not a gameplay test.
- For fixed-package acceptance use `bgparty-game accept` with explicit game/SDK ZIPs and catalog roots, following docs/development.en.md. Each run fixes all input bytes and owns its origin, storage identity and record. Restore legal logs through normal page controls; use your own connected-browser tab and short accept-lock/accept-unlock leases only for shared browser controls. Never launch an independent browser or claim networking/persistence was verified in this preview.
- Upload only the full `.bgparty/release/` snapshot, with HTTPS/CORS and no redirect/auth dependency. Developers host their own game source; the BGParty platform provides runtime SDKs.

Report changed files, commands/results and unverified cases. Do not deploy, publish, send messages or change Git history without the owner's authorization.
