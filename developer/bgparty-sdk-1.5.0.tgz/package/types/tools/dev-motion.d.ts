import type { RuntimePayload } from '../src/game-runtime/client';
export declare function installDevMotion(): void;
export declare function devMotionContainer(container: HTMLElement, payload: RuntimePayload): HTMLElement;
