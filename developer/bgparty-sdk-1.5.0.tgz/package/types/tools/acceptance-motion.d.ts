import type { RuntimePayload } from '../src/game-runtime/client';
export type AcceptanceMotion = 'normal' | 'system';
export interface MotionObservation {
    adapter: 'bgparty.acceptance-motion@1';
    requested: AcceptanceMotion;
    native: {
        reduce: boolean;
        noPreference: boolean;
    };
    effective: {
        reduce: boolean;
        noPreference: boolean;
    };
    css: {
        reduce: boolean;
        noPreference: boolean;
        bare: boolean;
        negated: boolean;
        combined: boolean;
    };
    animation: {
        advancing: boolean;
        before: number | null;
        after: number | null;
    };
    ready: boolean;
    failures: string[];
}
export declare function normalMotionQuery(query: string): string;
export declare function adaptMotionAssets(payload: RuntimePayload): number;
export declare function installMotion(runId: string, requested: AcceptanceMotion, rewrite: (query: string) => string): void;
export declare function motionContainer(container: HTMLElement, runId: string, motion: AcceptanceMotion): HTMLElement;
export declare function observeMotion(frame: HTMLIFrameElement, runId: string): Promise<MotionObservation>;
