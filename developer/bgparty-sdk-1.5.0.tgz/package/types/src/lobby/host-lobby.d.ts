import { type StoreApi } from 'zustand/vanilla';
import { type I18nKey, type I18nVars } from '../shared/i18n';
import { type FxEntry, type GameError, type GameStatus, type JsonValue } from '../shared/protocol';
import type { Signaling } from '../transport/signaling';
import { type BotKind } from './protocol';
import type { RuntimeReference } from '../game-packs/format';
/** 主机自身的 rid:主机不走 transport,engine 的 PlayerId 里它就是这个 */
export declare const HOST_RID = "host";
export interface LobbyMember {
    rid: string;
    name: string;
    colorIndex: number;
    /** 预置头像索引(shared/avatars.ts),join 时上报,主机取模防越界 */
    avatar: number;
    joinedAt: number;
}
export type LobbyPhase = 'lobby' | 'playing';
export interface HostLobbyState {
    phase: LobbyPhase;
    gameId: string | null;
    members: LobbyMember[];
    /** transport 绑定表快照;members 里不在列的座位是离线,保留到房间解散 */
    online: string[];
    /** 托管(bot 代打)中的座位(2026-09-18):瞬时状态不持久化,主机刷新后需重开;
     * 驱动执行归 host 页 bot-driver,这里只记标记并随成员视图广播 */
    autopilot: string[];
}
/**
 * engine 接缝(docs/ENGINE.md §1):lobby 不 import engine,host 页把 GameSession 组装进来。
 * 一局一个 handle,backToLobby 时废弃。
 */
export interface GameHandle {
    readonly runtime?: RuntimeReference;
    /** 转交 kind:'game' 上行。返回 GameError = 形状合法但被规则拒绝,lobby 回 {ok:false};null = 已受理或静默丢弃。
     * opts.auto = 托管代打标记:进 action log,终局占比与重放还原都靠它 */
    handleAction(rid: string, data: unknown, opts?: {
        auto?: boolean;
    }): GameError | null | Promise<GameError | null>;
    /** 按 rid 裁剪的游戏段视图;非本局玩家返回 undefined(中途入座等下局) */
    viewFor(rid: string): JsonValue | undefined;
    /** bot 专用视图(主机侧,不出网):游戏实现了 GameDefinition.viewForBot 时走它,否则回落 viewFor */
    viewForBot(rid: string): JsonValue | undefined;
    /** 终局判定(docs/PROTOCOL.md §4):返回 winner+ranking 时 lobby 在视图 game 段附通用结算段 result */
    status(): GameStatus;
    /** 取走自上次推送以来累积的 fx 组(drain 语义,docs/FX.md §4);无累积返回空数组 */
    takeFx(): FxEntry[][];
    /** 托管占比(2026-09-18):rid → 该玩家动作中 auto 标记的比例,只含 >0 的座位;终局时附加进 result 段广播 */
    autopilotShares(): Record<string, number>;
}
export interface HostLobbyHooks {
    /** Validate the installed runtime before checking its configuration and player range. */
    onPrepare?(gameId: string): Promise<void>;
    /** engine 接管开局;返回 null = 没接住,UI 层据此给「还没接入」。config = 大堂收集的开局选项(游戏的 configSchema 会再卡一道) */
    onStart?(gameId: string, players: string[], config?: unknown, signal?: AbortSignal): GameHandle | null | Promise<GameHandle | null>;
    /** 由 host 页注入随机统计局号；不读取游戏内容或房间身份。 */
    analyticsMatchId?(): string | undefined;
}
export type StartResult = {
    ok: true;
    fx: FxEntry[];
} | {
    ok: false;
    reason: I18nKey;
    params?: I18nVars;
};
export interface HostLobby {
    readonly store: StoreApi<HostLobbyState>;
    selectGame(gameId: string | null): void;
    /** 加机器人:从未被占用的头像里 crypto 随机挑一个入座(头像即身份与名字);头像耗尽返回 false。
     * kind = 'ai' 时rid 用 aibot: 前缀,开局装配时据此换 LLM think——座位本身与规则 bot 同构 */
    addBot(kind?: BotKind): boolean;
    removeBot(rid: string): void;
    /** 热座本地玩家:与 bot 同构(头像即初始身份),差别是座位由本机真人轮流操作,可改名 */
    addLocalPlayer(): boolean;
    removeLocalPlayer(rid: string): void;
    /** 仅 local 座位可改名;trim+截断后为空则忽略 */
    renameLocal(rid: string, name: string): void;
    /** 托管开关(2026-09-18):仅对局中、人类座位、当前游戏有规则 bot 时受理;
     * 玩家上行与主机兜底共用此入口,host 页据 store.autopilot 变化同步 bot driver */
    setAutopilot(rid: string, on: boolean): void;
    start(config?: unknown, fxRid?: string): Promise<StartResult>;
    /** 取消尚未完成的开局/重开，保留现有大堂或终局。 */
    cancelStart(): void;
    /** 再来一局:终局结算屏的入口,不换 phase 直接重开当前游戏(玩家端无大堂闪帧);
     * 与 start 同一套人数校验/开局 fx,玩家取当前座位表(中途入座者从这句起上桌) */
    playAgain(fxRid?: string): Promise<StartResult>;
    /** 终局页带新配置重开当前游戏;失败时保留原配置 */
    playAgainWithConfig(config: unknown, fxRid?: string): Promise<StartResult>;
    /** 对局恢复:host 页用持久化 log 重建 session 后挂回,跳过 start() 的人数校验;
     * players 取 log 的 $setup 快照,其中的 bot:/local: 座位在这里补回(人类玩家走 rejoin 认座) */
    restoreGame(gameId: string, handle: GameHandle, players: string[]): void;
    /** 一局结束回大堂:phase 回 lobby,gameId 保留(换游戏或手动再开都行;同游戏重开走 playAgain) */
    backToLobby(): void;
    /** 推送出口唯一(docs/ENGINE.md §1):engine 的 onChange 也经这里重推。
     * 返回值 = 主机本人视角的 fx(本地演出用,docs/FX.md §4);无 fx 时返回空数组。
     * fxRid:热座模式下传 activeRid——本地演出投影给当前持机人,不是固定主机座位 */
    pushViews(fxRid?: string): FxEntry[];
    /** 传输诊断透传:开房等待页据此把「连接服务器」步骤推进到完成 */
    diagnostics(): {
        relaysOpen: number;
        peers: number;
        hellos: number;
    };
    close(): void;
}
/**
 * 主机侧 lobby(docs/LOBBY.md):座位表、游戏选择、开局校验、视图推送。
 * 规则:无踢人无换座,清场唯一手段是解散房间;无 ready,主机直接开;
 * 对局中途入座者等下一局(lobby 成员与当局 players 解耦,setup 快照取当时座位)。
 */
export declare function createHostLobby(opts: {
    roomId: string;
    key: string;
    hostName: string;
    hostAvatar: number;
    hooks?: HostLobbyHooks;
    /** 离线模式注入 LocalSignaling 空桩;缺省走 trystero mqtt */
    signaling?: Signaling;
}): Promise<HostLobby>;
