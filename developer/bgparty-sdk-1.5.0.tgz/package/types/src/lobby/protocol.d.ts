import { z } from 'zod';
export declare const lobbyUpSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"join">;
    name: z.ZodString;
    avatar: z.ZodInt;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"leave">;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"autopilot">;
    on: z.ZodBoolean;
}, z.core.$strip>], "type">;
export type LobbyUp = z.infer<typeof lobbyUpSchema>;
export declare const lobbyMemberSchema: z.ZodObject<{
    rid: z.ZodString;
    name: z.ZodString;
    colorIndex: z.ZodInt;
    avatar: z.ZodInt;
    online: z.ZodBoolean;
    autopilot: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export type LobbyMemberView = z.infer<typeof lobbyMemberSchema>;
export type BotKind = 'rule' | 'ai';
export declare const botRidOf: (avatar: number, kind?: BotKind) => string;
export declare const botAvatarOf: (rid: string) => number | null;
export declare const isBotRid: (rid: string) => boolean;
export declare const isAiBotRid: (rid: string) => boolean;
export declare const localRidOf: (avatar: number) => string;
export declare const localAvatarOf: (rid: string) => number | null;
export declare const isLocalRid: (rid: string) => boolean;
export declare const gameResultSchema: z.ZodObject<{
    winner: z.ZodArray<z.ZodString>;
    ranking: z.ZodArray<z.ZodString>;
    scores: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodNumber>>;
    autopilot: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodNumber>>;
}, z.core.$strip>;
export type GameResultView = z.infer<typeof gameResultSchema>;
export declare const roomViewSchema: z.ZodObject<{
    lobby: z.ZodObject<{
        phase: z.ZodEnum<{
            lobby: "lobby";
            playing: "playing";
        }>;
        gameId: z.ZodNullable<z.ZodString>;
        runtime: z.ZodOptional<z.ZodObject<{
            source: z.ZodString;
            game: z.ZodObject<{
                url: z.ZodString;
                sha256: z.ZodString;
                bytes: z.ZodNumber;
                id: z.ZodString;
                version: z.ZodString;
                sdkMajor: z.ZodNumber;
                sdkApi: z.ZodOptional<z.ZodNumber>;
            }, z.core.$catchall<z.ZodJSONSchema>>;
            sdk: z.ZodObject<{
                url: z.ZodString;
                sha256: z.ZodString;
                bytes: z.ZodNumber;
                id: z.ZodString;
                version: z.ZodString;
                sdkMajor: z.ZodNumber;
                sdkApi: z.ZodOptional<z.ZodNumber>;
            }, z.core.$catchall<z.ZodJSONSchema>>;
            uuid: z.ZodOptional<z.ZodUUID>;
        }, z.core.$catchall<z.ZodJSONSchema>>>;
        members: z.ZodArray<z.ZodObject<{
            rid: z.ZodString;
            name: z.ZodString;
            colorIndex: z.ZodInt;
            avatar: z.ZodInt;
            online: z.ZodBoolean;
            autopilot: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    game: z.ZodOptional<z.ZodType<import("../shared/protocol").JsonValue, unknown, z.core.$ZodTypeInternals<import("../shared/protocol").JsonValue, unknown>>>;
    analyticsMatchId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type RoomView = z.infer<typeof roomViewSchema>;
