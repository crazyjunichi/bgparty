export interface RuntimeFile {
    key: string;
    mime: string;
    bytes: Uint8Array;
}
export interface RuntimePayload {
    files: RuntimeFile[];
    deferredFiles?: Record<string, {
        mime: string;
        bytes: number;
    }>;
    loadAsset?(key: string): Promise<RuntimeFile>;
    modules: Record<string, string>;
    assets: Record<string, string>;
    entry: string;
    css: string[];
    locale: 'zh' | 'en';
    storage?: Record<string, string>;
    storageRevision?: number;
}
export declare class GameRuntimeError extends Error {
}
export interface SandboxRuntime {
    readonly frame: HTMLIFrameElement;
    call<T = unknown>(method: string, args?: unknown): Promise<T>;
    close(): void;
}
export declare function createSandboxRuntime(options: {
    container: HTMLElement;
    payload: RuntimePayload;
    title: string;
    storageIdentity?: string;
    onEvent?(name: string, value: unknown): void;
    onEscape?(): void;
    hostCall?(method: string, args: unknown): Promise<unknown>;
}): Promise<SandboxRuntime>;
