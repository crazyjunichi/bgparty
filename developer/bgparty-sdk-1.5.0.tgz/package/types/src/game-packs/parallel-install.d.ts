import { type PackReference } from './format';
import { type InstalledPack } from './storage';
export declare class InstallPins {
    private readonly releases;
    add(references: PackReference[]): Promise<void>;
    release(): Promise<void>;
}
export declare function installParallelReference(pins: InstallPins, reference: PackReference, origin: string, onProgress?: (bytes: number) => void, onPhase?: (phase: 'downloading' | 'saving') => void, prefetched?: Uint8Array): Promise<InstalledPack>;
