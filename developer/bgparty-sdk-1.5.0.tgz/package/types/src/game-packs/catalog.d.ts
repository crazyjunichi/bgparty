import { type GameMetadata, type PackReference, type RuntimeReference } from './format';
import { type InstalledGame } from './storage';
export { withPackStorageLock } from './storage';
import { type GameDownloadListener } from './download-progress';
export { usePackDownloads } from './download-progress';
export { officialSource } from './config';
export interface CatalogGame {
    id: string;
    identity: string;
    source: string;
    sourceName: string;
    metadata: GameMetadata;
    release: PackReference;
    releaseRevision?: number;
    conflict?: boolean;
    coverUrl?: string;
    installed?: {
        gameHash: string;
        sdkHash: string;
        releaseRevision?: number;
    };
}
export declare const usePackCatalog: import("zustand").UseBoundStore<import("zustand").StoreApi<{
    revision: number;
    games: CatalogGame[];
    defaultGames: CatalogGame[];
    sources: string[];
    error: boolean;
}>>;
export declare function reloadCatalog(): Promise<void>;
export declare function initializeCatalog(): Promise<void>;
export declare function refreshCatalog(force?: boolean): Promise<void>;
export declare function catalogGame(id: string): CatalogGame | undefined;
export declare function catalogVariants(id: string): CatalogGame[];
export declare function defaultCatalogGame(id: string): CatalogGame | undefined;
export declare function gameInstallationAvailable(): boolean;
export declare function compatibleSdk(release: PackReference): PackReference | undefined;
export declare function catalogGameHasUpdate(game: CatalogGame, installed: InstalledGame): boolean;
export declare function catalogReleaseHasUpdate(game: CatalogGame, installedHash: string, installedRevision?: number): boolean;
export interface DownloadedGameUpdateCheck {
    checked: number;
    unavailable: number;
    failedSources: string[];
    sdkFailed: boolean;
}
export declare function checkDownloadedGameUpdates(): Promise<DownloadedGameUpdateCheck>;
export declare function ensureGameInstalled(id: string, onProgress?: (bytes: number) => void, preferInstalled?: boolean, onStatus?: GameDownloadListener): Promise<InstalledGame>;
export declare function downloadCatalogGame(id: string): Promise<InstalledGame>;
export declare function prepareNewGame(id: string, onStatus?: GameDownloadListener): Promise<InstalledGame>;
export declare function ensureRuntimeInstalled(input: RuntimeReference, onStatus?: GameDownloadListener, expectedGame?: CatalogGame): Promise<InstalledGame>;
