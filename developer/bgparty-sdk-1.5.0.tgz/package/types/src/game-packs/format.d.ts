import { z } from 'zod';
export declare const PACK_FORMAT = "bgparty.pack@1";
export declare const SOURCE_FORMAT = "bgparty.source@1";
export declare const BRIDGE_VERSION = 1;
export declare const PLATFORM_API_REVISION = 4;
export declare const PACK_LIMITS: {
    readonly compressedBytes: number;
    readonly unpackedBytes: number;
    readonly fileBytes: number;
    readonly files: 4096;
};
export declare const digestSchema: z.ZodString;
export declare const idSchema: z.ZodString;
export declare const versionSchema: z.ZodString;
export declare function isPackPath(path: string): boolean;
export declare const packPathSchema: z.ZodString;
export declare const fileSchema: z.ZodObject<{
    sha256: z.ZodString;
    bytes: z.ZodNumber;
    mime: z.ZodString;
}, z.core.$loose>;
export declare const gameMetadataSchema: z.ZodObject<{
    id: z.ZodString;
    uuid: z.ZodOptional<z.ZodUUID>;
    labels: z.ZodObject<{
        zh: z.ZodObject<{
            name: z.ZodString;
            desc: z.ZodString;
            rules: z.ZodString;
        }, z.core.$loose>;
        en: z.ZodObject<{
            name: z.ZodString;
            desc: z.ZodString;
            rules: z.ZodString;
        }, z.core.$loose>;
    }, z.core.$loose>;
    icon: z.ZodString;
    iconPath: z.ZodOptional<z.ZodString>;
    minPlayers: z.ZodNumber;
    maxPlayers: z.ZodNumber;
    bestPlayers: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
    rulesUrl: z.ZodOptional<z.ZodRecord<z.ZodEnum<{
        zh: "zh";
        en: "en";
        de: "de";
        fr: "fr";
        es: "es";
        it: "it";
        ru: "ru";
        ja: "ja";
    }> & z.core.$partial, z.ZodURL>>;
    botDelayMs: z.ZodOptional<z.ZodNumber>;
    accent: z.ZodString;
    hotseat: z.ZodEnum<{
        open: "open";
        off: "off";
        cover: "cover";
    }>;
    tier: z.ZodEnum<{
        released: "released";
        beta: "beta";
        alpha: "alpha";
        dev: "dev";
    }>;
    releasedAt: z.ZodString;
    mechanics: z.ZodArray<z.ZodString>;
    interactionTags: z.ZodArray<z.ZodString>;
    search: z.ZodObject<{
        py: z.ZodString;
        init: z.ZodString;
    }, z.core.$loose>;
    capabilities: z.ZodObject<{
        bot: z.ZodBoolean;
        ai: z.ZodBoolean;
        options: z.ZodBoolean;
        guide: z.ZodBoolean;
    }, z.core.$loose>;
}, z.core.$loose>;
export declare const packReferenceSchema: z.ZodObject<{
    url: z.ZodString;
    sha256: z.ZodString;
    bytes: z.ZodNumber;
    id: z.ZodString;
    version: z.ZodString;
    sdkMajor: z.ZodNumber;
    sdkApi: z.ZodOptional<z.ZodNumber>;
}, z.core.$catchall<z.ZodJSONSchema>>;
export declare const packManifestSchema: z.ZodObject<{
    format: z.ZodLiteral<"bgparty.pack@1">;
    kind: z.ZodEnum<{
        game: "game";
        sdk: "sdk";
        resource: "resource";
    }>;
    id: z.ZodString;
    version: z.ZodString;
    bridge: z.ZodLiteral<1>;
    sdkMajor: z.ZodNumber;
    sdkApi: z.ZodOptional<z.ZodNumber>;
    platformApi: z.ZodOptional<z.ZodNumber>;
    assetLoading: z.ZodOptional<z.ZodLiteral<"deferred-images">>;
    entry: z.ZodString;
    exports: z.ZodRecord<z.ZodString, z.ZodString>;
    assets: z.ZodRecord<z.ZodString, z.ZodString>;
    css: z.ZodArray<z.ZodString>;
    files: z.ZodRecord<z.ZodString, z.ZodObject<{
        sha256: z.ZodString;
        bytes: z.ZodNumber;
        mime: z.ZodString;
    }, z.core.$loose>>;
    dependencies: z.ZodDefault<z.ZodArray<z.ZodObject<{
        url: z.ZodString;
        sha256: z.ZodString;
        bytes: z.ZodNumber;
        id: z.ZodString;
        version: z.ZodString;
        sdkMajor: z.ZodNumber;
        sdkApi: z.ZodOptional<z.ZodNumber>;
    }, z.core.$catchall<z.ZodJSONSchema>>>>;
    game: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        uuid: z.ZodOptional<z.ZodUUID>;
        labels: z.ZodObject<{
            zh: z.ZodObject<{
                name: z.ZodString;
                desc: z.ZodString;
                rules: z.ZodString;
            }, z.core.$loose>;
            en: z.ZodObject<{
                name: z.ZodString;
                desc: z.ZodString;
                rules: z.ZodString;
            }, z.core.$loose>;
        }, z.core.$loose>;
        icon: z.ZodString;
        iconPath: z.ZodOptional<z.ZodString>;
        minPlayers: z.ZodNumber;
        maxPlayers: z.ZodNumber;
        bestPlayers: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
        rulesUrl: z.ZodOptional<z.ZodRecord<z.ZodEnum<{
            zh: "zh";
            en: "en";
            de: "de";
            fr: "fr";
            es: "es";
            it: "it";
            ru: "ru";
            ja: "ja";
        }> & z.core.$partial, z.ZodURL>>;
        botDelayMs: z.ZodOptional<z.ZodNumber>;
        accent: z.ZodString;
        hotseat: z.ZodEnum<{
            open: "open";
            off: "off";
            cover: "cover";
        }>;
        tier: z.ZodEnum<{
            released: "released";
            beta: "beta";
            alpha: "alpha";
            dev: "dev";
        }>;
        releasedAt: z.ZodString;
        mechanics: z.ZodArray<z.ZodString>;
        interactionTags: z.ZodArray<z.ZodString>;
        search: z.ZodObject<{
            py: z.ZodString;
            init: z.ZodString;
        }, z.core.$loose>;
        capabilities: z.ZodObject<{
            bot: z.ZodBoolean;
            ai: z.ZodBoolean;
            options: z.ZodBoolean;
            guide: z.ZodBoolean;
        }, z.core.$loose>;
    }, z.core.$loose>>;
    equivalentTo: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$loose>;
export declare const sdkRegistrySchema: z.ZodObject<{
    format: z.ZodLiteral<"bgparty.sdk@1">;
    releases: z.ZodArray<z.ZodObject<{
        url: z.ZodString;
        sha256: z.ZodString;
        bytes: z.ZodNumber;
        id: z.ZodString;
        version: z.ZodString;
        sdkMajor: z.ZodNumber;
        sdkApi: z.ZodOptional<z.ZodNumber>;
    }, z.core.$catchall<z.ZodJSONSchema>>>;
}, z.core.$loose>;
export declare const runtimeReferenceSchema: z.ZodObject<{
    source: z.ZodString;
    game: z.ZodObject<{
        url: z.ZodString;
        sha256: z.ZodString;
        bytes: z.ZodNumber;
        id: z.ZodString;
        version: z.ZodString;
        sdkMajor: z.ZodNumber;
        sdkApi: z.ZodOptional<z.ZodNumber>;
    }, z.core.$catchall<z.ZodJSONSchema>>;
    sdk: z.ZodObject<{
        url: z.ZodString;
        sha256: z.ZodString;
        bytes: z.ZodNumber;
        id: z.ZodString;
        version: z.ZodString;
        sdkMajor: z.ZodNumber;
        sdkApi: z.ZodOptional<z.ZodNumber>;
    }, z.core.$catchall<z.ZodJSONSchema>>;
    uuid: z.ZodOptional<z.ZodUUID>;
}, z.core.$catchall<z.ZodJSONSchema>>;
export type RuntimeReference = z.infer<typeof runtimeReferenceSchema>;
export declare const sourceCatalogSchema: z.ZodObject<{
    format: z.ZodLiteral<"bgparty.source@1">;
    name: z.ZodString;
    games: z.ZodArray<z.ZodObject<{
        metadata: z.ZodObject<{
            id: z.ZodString;
            uuid: z.ZodOptional<z.ZodUUID>;
            labels: z.ZodObject<{
                zh: z.ZodObject<{
                    name: z.ZodString;
                    desc: z.ZodString;
                    rules: z.ZodString;
                }, z.core.$loose>;
                en: z.ZodObject<{
                    name: z.ZodString;
                    desc: z.ZodString;
                    rules: z.ZodString;
                }, z.core.$loose>;
            }, z.core.$loose>;
            icon: z.ZodString;
            iconPath: z.ZodOptional<z.ZodString>;
            minPlayers: z.ZodNumber;
            maxPlayers: z.ZodNumber;
            bestPlayers: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
            rulesUrl: z.ZodOptional<z.ZodRecord<z.ZodEnum<{
                zh: "zh";
                en: "en";
                de: "de";
                fr: "fr";
                es: "es";
                it: "it";
                ru: "ru";
                ja: "ja";
            }> & z.core.$partial, z.ZodURL>>;
            botDelayMs: z.ZodOptional<z.ZodNumber>;
            accent: z.ZodString;
            hotseat: z.ZodEnum<{
                open: "open";
                off: "off";
                cover: "cover";
            }>;
            tier: z.ZodEnum<{
                released: "released";
                beta: "beta";
                alpha: "alpha";
                dev: "dev";
            }>;
            releasedAt: z.ZodString;
            mechanics: z.ZodArray<z.ZodString>;
            interactionTags: z.ZodArray<z.ZodString>;
            search: z.ZodObject<{
                py: z.ZodString;
                init: z.ZodString;
            }, z.core.$loose>;
            capabilities: z.ZodObject<{
                bot: z.ZodBoolean;
                ai: z.ZodBoolean;
                options: z.ZodBoolean;
                guide: z.ZodBoolean;
            }, z.core.$loose>;
        }, z.core.$loose>;
        release: z.ZodObject<{
            url: z.ZodString;
            sha256: z.ZodString;
            bytes: z.ZodNumber;
            id: z.ZodString;
            version: z.ZodString;
            sdkMajor: z.ZodNumber;
            sdkApi: z.ZodOptional<z.ZodNumber>;
        }, z.core.$catchall<z.ZodJSONSchema>>;
        releaseRevision: z.ZodOptional<z.ZodInt>;
    }, z.core.$loose>>;
}, z.core.$loose>;
export type PackManifest = z.infer<typeof packManifestSchema>;
export type PackReference = z.infer<typeof packReferenceSchema>;
export type SourceCatalog = z.infer<typeof sourceCatalogSchema>;
export type GameMetadata = z.infer<typeof gameMetadataSchema>;
export declare class GameCompatibilityError extends Error {
    constructor();
}
export declare class GameUnavailableError extends Error {
    constructor();
}
export declare function assertRuntimeCompatibility(game: PackManifest, sdk: PackManifest): void;
export declare function sha256(bytes: Uint8Array): Promise<string>;
export declare function sourceUrl(input: string, base?: string): URL;
