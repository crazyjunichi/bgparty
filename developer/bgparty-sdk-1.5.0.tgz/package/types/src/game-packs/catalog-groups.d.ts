export declare function catalogGroupKey(game: {
    metadata: {
        id: string;
        uuid?: string;
    };
    identity?: string;
}): string;
export declare function legacyOfficialUiId(entries: {
    source: string;
    metadata: {
        id: string;
    };
}[], installed: {
    source: string;
    gameId: string;
} | undefined, legacySourceFor: (id: string) => string): string | undefined;
export declare function defaultCatalogGames<T extends {
    metadata: {
        id: string;
        uuid?: string;
    };
    source: string;
    identity?: string;
    releaseRevision?: number;
}>(games: T[], sources: string[], subscribed?: string[]): T[];
