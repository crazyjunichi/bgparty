import { type RuntimeReference } from './format';
import type { CatalogGame } from './catalog';
export declare function runtimeMatchesGame(reference: RuntimeReference, game: CatalogGame): Promise<boolean>;
