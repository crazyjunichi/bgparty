import type { GameMetadata } from './format';
import type { InstalledPack } from './storage';
export declare function publishedGameCover(metadata: GameMetadata, source: string): string | undefined;
export declare class GameCoverUrls {
    private urls;
    installed(pack: InstalledPack): Promise<string | undefined>;
    retain(covers: (string | undefined)[]): void;
}
