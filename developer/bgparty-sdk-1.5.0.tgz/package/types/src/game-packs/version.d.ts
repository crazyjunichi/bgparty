export declare function versionBuildTime(version: string): string | undefined;
export declare function formatVersionTime(iso: string, locale: 'zh' | 'en', compact?: boolean): string;
