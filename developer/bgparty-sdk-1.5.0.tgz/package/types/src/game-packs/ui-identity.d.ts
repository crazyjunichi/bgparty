export declare function stableGameUiId(uuid: string, preferred: string): Promise<string>;
