export declare const localGameSource: () => string;
export declare const officialSource: () => string;
export declare const sdkRegistryUrl: () => string;
export declare function currentOfficialSources(): string[];
export declare function isOfficialSource(url: string): boolean;
export declare function gameSourceFor(id: string): string;
export declare function defaultGameSources(): string[];
export declare function identitySource(source: string): string;
