import { type PackReference } from './format';
export declare const platformSdkOrigin: () => string;
export declare function platformSdkReferences(): PackReference[] | undefined;
export declare function isCurrentPlatformSdk(reference: PackReference): Promise<boolean>;
