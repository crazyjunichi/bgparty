import { type InstalledGame, type InstalledPack, type RuntimeSelection } from './storage';
export declare function selectGameRuntime(game: InstalledGame, runtimes: RuntimeSelection[]): InstalledGame;
export declare function availableRuntimes(): Promise<RuntimeSelection[]>;
export declare function enableRuntime(sdk: InstalledPack): Promise<void>;
