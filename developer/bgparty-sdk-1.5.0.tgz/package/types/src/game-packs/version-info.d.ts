import type { PackReference, RuntimeReference } from './format';
export declare function PackVersionInfo({ label, reference, compact }: {
    label: string;
    reference: PackReference;
    compact?: boolean;
}): import("react").JSX.Element;
export declare function MatchVersionInfo({ runtime, name }: {
    runtime?: RuntimeReference;
    name?: string;
}): import("react").JSX.Element;
