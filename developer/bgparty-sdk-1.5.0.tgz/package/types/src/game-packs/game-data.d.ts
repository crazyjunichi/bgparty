import { type GameData, type InstalledGame } from './storage';
export declare const GAME_STORAGE_LIMIT: number;
export declare const dataSnapshot: (row: GameData) => {
    revision: number;
    values: Record<string, string>;
};
export declare function ensureGameData(game: Pick<InstalledGame, 'identity' | 'source' | 'gameId' | 'storage' | 'uuid' | 'uiId'>): Promise<GameData>;
export declare function callGameStorage(identity: string, method: string, args: unknown): Promise<{
    revision: number;
    values: Record<string, string>;
} | {
    status: "conflict";
    snapshot: {
        revision: number;
        values: Record<string, string>;
    };
} | {
    status: "saved";
    snapshot: {
        revision: number;
        values: Record<string, string>;
    };
}>;
export declare function saveLegacyGameStorage(identity: string, before: Record<string, string>, value: unknown, revision?: number): Promise<number | undefined>;
export declare function clearGameData(identity: string): Promise<void>;
