import type { PackManifest } from './format.ts';
export declare function checkDirectory(bytes: Uint8Array): number;
export declare function readArchive(bytes: Uint8Array, expected?: string): Promise<{
    manifest: PackManifest;
    files: Record<string, Uint8Array>;
}>;
export declare function downloadBytes(url: string, limit: number, signal?: AbortSignal, onProgress?: (bytes: number) => void): Promise<Uint8Array>;
