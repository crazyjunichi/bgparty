import type { PackReference } from './format';
export declare function syncPlatformRuntimes(references: PackReference[]): Promise<boolean>;
