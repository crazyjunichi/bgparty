import { type PackReference } from './format';
export declare function withPackSlot<T>(kind: 'download' | 'unpack', count: number, run: () => Promise<T>): Promise<T>;
export declare function downloadPackBytes(reference: PackReference, origin: string, onProgress?: (bytes: number) => void): Promise<Uint8Array>;
export declare function withUnpackSlot<T>(estimatedBytes: number, run: () => Promise<T>): Promise<T>;
export declare const reserveZip: (bytes: number) => Promise<() => void>;
export declare const reserveUnpacked: (bytes: number) => Promise<() => void>;
