export type AvatarNames = [
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string
];
export declare const zh: {
    developer: {
        title: string;
        subtitle: string;
        back: string;
        kit: string;
        sdk: string;
        includes: string;
        requirement: string;
        version: string;
        loading: string;
        unavailable: string;
        retry: string;
        startTitle: string;
        startText: string;
        startHint: string;
        quickstart: string;
        quickstartDesc: string;
        manual: string;
        manualDesc: string;
        ai: string;
        aiDesc: string;
        publish: string;
        publishDesc: string;
        api: string;
        exampleTitle: string;
        basic: string;
        basicDesc: string;
        advanced: string;
        advancedDesc: string;
        exampleHint: string;
        promptTitle: string;
        copy: string;
        copied: string;
        copyFailed: string;
        prompt: string;
        sdkHint: string;
        verify: string;
        homeHint: string;
    };
    packs: {
        title: string;
        sources: string;
        sourceUrl: string;
        add: string;
        refresh: string;
        removeSource: string;
        installed: string;
        download: string;
        remove: string;
        empty: string;
        savedData: string;
        clearData: string;
        confirmClearData: string;
        clearDataLabel: string;
        dataHint: string;
        noSavedData: string;
        dataCleared: string;
        dataPinned: string;
        addHint: string;
        unsubscribeHint: string;
        resumeIncompatible: string;
        resumeCheckFailed: string;
        resumeCancel: string;
        resumeRetry: string;
        resumeNewVersion: string;
        busy: string;
        failed: string;
        pinned: string;
        official: string;
        manageDownload: string;
        versionInfo: string;
        versionDetails: string;
        versionDigest: string;
        versionInstalled: string;
        versionAvailable: string;
        libraryGames: string;
        libraryCount: string;
        libraryDownloaded: string;
        updateAllShort: string;
        downloadAmountShort: string;
        runtimeFiles: string;
        runtimeUpdate: string;
        runtimeUpdating: string;
        runtimeUpdateAvailable: string;
        runtimeUpdateProgress: string;
        runtimeUpdateFailed: string;
        runtimeUpdated: string;
        versionMatchGame: string;
        versionRuntime: string;
        versionBuiltAt: string;
        versionInstalledGame: string;
        versionInstalledRuntime: string;
        versionAvailableGame: string;
        versionAvailableRuntime: string;
        versionGameName: string;
        versionSource: string;
        versionPlatform: string;
        versionPlatformTime: string;
        versionCopy: string;
        versionCopied: string;
        versionCopyFailed: string;
        offlineHint: string;
        incompatible: string;
        tools: string;
        updateRequired: string;
        unavailable: string;
        checkingUpdates: string;
        checkingFiles: string;
        selectionUpdateAvailable: string;
        selectionRuntimeUpdateAvailable: string;
        selectionCheckFailed: string;
        selectionVersionConflict: string;
        selectionUpdateFailed: string;
        selectionUpdateRetry: string;
        downloadingFiles: string;
        savingFiles: string;
        preparingMatch: string;
        restoringMatch: string;
        openingGame: string;
        loadingOptions: string;
        downloadAmount: string;
        downloadedAmount: string;
        predownloading: string;
        updating: string;
        preparingFiles: string;
        cachedOffline: string;
        offlineAvailable: string;
        notCachedOffline: string;
        notCachedFailed: string;
        loadFailed: string;
        missingSource: string;
        addAndJoin: string;
        retry: string;
        unsupported: string;
        catalogFailed: string;
    };
    avatarNames: AvatarNames;
    platform: {
        onlineRoom: string;
        room: string;
        members: string;
        invite: string;
        scanHint: string;
        collapseInvite: string;
        expandInvite: string;
        viewAll: string;
        previous: string;
        next: string;
        back: string;
        newBadge: string;
        selectedGame: string;
        noSelection: string;
        players: string;
        seated: string;
        start: string;
        recentEmpty: string;
        scanTitle: string;
        scanInstruction: string;
        useScan: string;
        connected: string;
        connecting: string;
    };
    common: {
        appName: string;
        appNameSub: string;
        langSwitch: string;
        close: string;
        qr: {
            starting: string;
            denied: string;
            noCamera: string;
            unsupported: string;
            close: string;
            manual: string;
        };
        draw: {
            undo: string;
            clear: string;
            colorAria: string;
            widthAria: string;
        };
        log: {
            title: string;
            empty: string;
        };
        onlineRules: string;
        onlineRulesIn: string;
        rulesLangZh: string;
        rulesLangEn: string;
        rulesLangDe: string;
        rulesLangFr: string;
        rulesLangEs: string;
        rulesLangIt: string;
        rulesLangRu: string;
        rulesLangJa: string;
    };
    profile: {
        title: string;
        pickAvatar: string;
        avatarOption: string;
        nameLabel: string;
        unnamed: string;
        save: string;
    };
    session: {
        menu: {
            open: string;
            close: string;
        };
        steps: {
            load: string;
            relay: string;
            peer: string;
            join: string;
            stuckHost: string;
            stuckRelay: string;
            relayFallback: string;
            switchRelay: string;
        };
        reconnecting: string;
        qr: {
            hostIdle: string;
            hostAnswer: string;
            playerOffer: string;
            connecting: string;
            preparing: string;
            tooBig: string;
            copy: string;
            copied: string;
            paste: string;
            pasteTitle: string;
            pastePlaceholder: string;
            pasteConfirm: string;
            useQr: string;
            useRelay: string;
        };
        gameLoading: string;
        gameStartFailed: string;
        result: {
            title: string;
            playAgain: string;
            backToLobby: string;
            waitHost: string;
            exportLog: string;
        };
        records: {
            title: string;
            submit: string;
            export: string;
            automatic: string;
            automaticHint: string;
            consentTitle: string;
            consentDescription: string;
            consentDecline: string;
            consentAccept: string;
            purpose: string;
            queued: string;
            sending: string;
            sent: string;
            retry: string;
            storageFailed: string;
            unavailable: string;
            tooLarge: string;
            incomplete: string;
        };
        back: {
            title: string;
            playerDesc: string;
            dissolveTitle: string;
            dissolveDesc: string;
            dissolveConfirm: string;
            endGameTitle: string;
            endGameDesc: string;
            confirm: string;
            cancel: string;
        };
        hint: {
            button: string;
            title: string;
            confirm: string;
            cancel: string;
            noAction: string;
            updated: string;
            usedCount: string;
        };
        autopilot: {
            on: string;
            off: string;
            active: string;
            sheetTitle: string;
            sheetHint: string;
            share: string;
        };
    };
    settings: {
        title: string;
        general: string;
        language: string;
        chinese: string;
        english: string;
        back: string;
        gamesAndAi: string;
        enabled: string;
        disabled: string;
        notConfigured: string;
        sourceCount: string;
        sourceOrderHint: string;
        moveSourceUp: string;
        moveSourceDown: string;
        customSource: string;
        invalidSourceUrl: string;
        sourceAdded: string;
        sourceRefreshed: string;
        sourceUnsubscribed: string;
        sourcesEmpty: string;
        downloads: string;
        downloadsHint: string;
        downloaded: string;
        notDownloaded: string;
        downloading: string;
        savingDownload: string;
        preparingDownload: string;
        downloadWaiting: string;
        downloadFailed: string;
        downloadGameLabel: string;
        downloadAll: string;
        downloadAllHint: string;
        checkGameUpdates: string;
        checkingGameUpdates: string;
        gameUpdatesAvailable: string;
        gamesUpToDate: string;
        gameUpdateAvailable: string;
        updateGame: string;
        updateGameLabel: string;
        updateAll: string;
        gameUpdateFailed: string;
        gameUpdateCheckFailed: string;
        gameUpdateSourcesFailed: string;
        gameUpdatesUnavailable: string;
        stopDownloads: string;
        downloadSummary: string;
        downloadRemaining: string;
        downloadOffline: string;
        noGames: string;
        confirmRemoveDownload: string;
        removeGameLabel: string;
        searchSources: string;
        searchDownloads: string;
        listCount: string;
        noMatches: string;
        recordSubmission: string;
        recordSubmissionHint: string;
        aiSetupHint: string;
        about: string;
        installFailed: string;
        sound: string;
        soundHint: string;
        turnSound: string;
        turnSoundSoft: string;
        turnSoundWood: string;
        turnSoundPop: string;
        turnSoundChime: string;
    };
    pwa: {
        updateAvailable: string;
        updateNow: string;
        later: string;
        updateReadyTitle: string;
        updateReadyBody: string;
        checkUpdate: string;
        checking: string;
        upToDate: string;
        downloading: string;
        checkFailed: string;
        installTitle: string;
        installBody: string;
        installAction: string;
        installIosTitle: string;
        installIosStep1: string;
        installIosStep2: string;
        installIosStep3: string;
    };
    home: {
        title: string;
        buildTime: string;
        labLink: string;
        sheetCalibLink: string;
        createRoom: string;
        startTag: string;
        createHint: string;
        qrRoom: string;
        qrHint: string;
        joinRoom: string;
        joinHint: string;
        otherModes: string;
        offlineRoom: string;
        offlineHint: string;
        hotseat: string;
        hotseatHint: string;
        comingSoon: string;
        newsTitle: string;
        newsItems: {
            uiRefresh: {
                title: string;
                body: string;
            };
        };
    };
    ai: {
        title: string;
        hint: string;
        empty: string;
        add: string;
        edit: string;
        delete: string;
        confirmDelete: string;
        nameLabel: string;
        baseUrlLabel: string;
        apiKeyLabel: string;
        modelLabel: string;
        save: string;
        back: string;
        test: string;
        testing: string;
        testOk: string;
        testFail: string;
        usage: string;
        usageLabel: string;
        usageByGame: string;
        usageByGameAvg: string;
        namePlaceholder: string;
        baseUrlPlaceholder: string;
        apiKeyPlaceholder: string;
        modelPlaceholder: string;
    };
    lobby: {
        colors: {
            blueberry: string;
            tangerine: string;
            grape: string;
            honey: string;
            seasalt: string;
            peach: string;
            avocado: string;
            cocoa: string;
            mint: string;
            sesame: string;
        };
        you: string;
        offline: string;
        bot: string;
        botAi: string;
        thinking: string;
        done: string;
        rules: string;
        memberCount: string;
        namePlaceholder: string;
        waiting: string;
        nextGame: string;
        host: {
            badge: string;
            nameTitle: string;
            open: string;
            opening: string;
            openFailed: string;
            openStale: string;
            refresh: string;
            offlineBadge: string;
            offlineInvite: string;
            hotseatBadge: string;
            hotseatInvite: string;
            addLocal: string;
            removeLocal: string;
            renameLocalTitle: string;
            passTo: string;
            passHint: string;
            passForce: string;
            iAm: string;
            qrLabel: string;
            scanHint: string;
            qrCollapsed: string;
            copyLink: string;
            copied: string;
            pickGame: string;
            searchGames: string;
            searchClear: string;
            filters: {
                trigger: string;
                triggerLabel: string;
                title: string;
                selected: string;
                remove: string;
                clear: string;
                gameplay: string;
                interaction: string;
                matchAny: string;
                all: string;
                less: string;
                viewResults: string;
                resultCount: string;
                mechanics: {
                    handManagement: string;
                    diceRolling: string;
                    drafting: string;
                    tilePlacement: string;
                    setCollection: string;
                    engineBuilding: string;
                    deduction: string;
                    rollAndWrite: string;
                    deckBagBuilding: string;
                    routeBuilding: string;
                    areaControl: string;
                    pushYourLuck: string;
                    trickTaking: string;
                    wordAssociation: string;
                    betting: string;
                    gridMovement: string;
                    actionPoints: string;
                    race: string;
                    workerPlacement: string;
                    auction: string;
                    stockHolding: string;
                    drawing: string;
                    actionProgramming: string;
                };
                interactions: {
                    cooperative: string;
                    communicationLimits: string;
                    teamBased: string;
                    hiddenRoles: string;
                };
            };
            sort: string;
            sortDefault: string;
            sortNew: string;
            sortRecent: string;
            sortPlays: string;
            noGameMatch: string;
            layoutCompact: string;
            layoutCover: string;
            favorite: string;
            unfavorite: string;
            options: string;
            saveOptions: string;
            noGames: string;
            start: string;
            startCount: string;
            needGame: string;
            needPlayers: string;
            noEngine: string;
            addBot: string;
            addAiBot: string;
            botUnsupported: string;
            aiBotUnsupported: string;
            aiDegraded: string;
            removeBot: string;
            endGame: string;
            resumeTitle: string;
            resumeDesc: string;
            resumeContinue: string;
            resumeNew: string;
            resumeBadge: string;
            snapshotSaveFailed: string;
            snapshotRecordFailed: string;
            snapshotBackupUsed: string;
            snapshotExport: string;
            snapshotImport: string;
            snapshotImportFailed: string;
            snapshotImportDone: string;
            snapshotImportConfirm: string;
            snapshotConflictTitle: string;
            snapshotConflictDesc: string;
            snapshotConflictOwnedDesc: string;
            snapshotConflictReplace: string;
            snapshotConflictReplaceConfirm: string;
            snapshotConflictAbandon: string;
            snapshotConflictAbandonConfirm: string;
            snapshotConflictContinue: string;
            gameSource: string;
            defaultSource: string;
            dissolve: string;
            dissolveConfirm: string;
            closed: string;
            reopen: string;
        };
        join: {
            invalid: string;
            manualTitle: string;
            room: string;
            key: string;
            roomPlaceholder: string;
            keyPlaceholder: string;
            go: string;
            versionMismatch: string;
            seating: string;
            failed: string;
            faultInsecure: string;
            faultNetwork: string;
            faultHostOffline: string;
            faultHostFault: string;
            retryHint: string;
            retryNow: string;
            rejected: string;
            naming: string;
            sit: string;
            leave: string;
            leaveConfirm: string;
            left: string;
            rejoin: string;
        };
    };
    games: Record<string, Record<string, unknown>>;
    lab: {
        title: string;
        playTester: string;
        playUnknownGame: string;
        variantsTitle: string;
        variantsHint: string;
        boxWide: string;
        boxShort: string;
        tokensTitle: string;
        touchTitle: string;
        touchPrimary: string;
        touchNormal: string;
        safeTitle: string;
        safeHint: string;
        safeValues: string;
        iconsTitle: string;
        confirmTitle: string;
        confirmIdle: string;
        confirmArmed: string;
        confirmDone: string;
        paletteTitle: string;
        paletteHint: string;
        faviconTitle: string;
        faviconHint: string;
        avatarCardTitle: string;
        avatarCardHint: string;
        avatarA: string;
        avatarB: string;
        avatarC: string;
        avatarD: string;
        demoNameShort: string;
        demoNameLong: string;
        strip: {
            title: string;
            hint: string;
            variantPlate: string;
            variantMedal: string;
            variantMini: string;
        };
        fx: {
            title: string;
            hint: string;
            fly: string;
            chain: string;
            bump: string;
        };
        dice: {
            title: string;
            hint: string;
            roll1: string;
            roll2: string;
            roll3: string;
            fxTitle: string;
            rollBanner: string;
            rollInplace: string;
            rollMiss: string;
        };
        transport: {
            title: string;
            hostStart: string;
            hostRunning: string;
            playerTitle: string;
            room: string;
            key: string;
            link: string;
            qrLabel: string;
            scanBtn: string;
            roomPlaceholder: string;
            keyPlaceholder: string;
            connect: string;
            ping: string;
            echo: string;
            viewLabel: string;
            online: string;
            close: string;
            statusConnecting: string;
            statusReady: string;
            statusRejected: string;
            statusFailed: string;
            faultInsecure: string;
            faultNetwork: string;
            faultHostOffline: string;
            faultHostFault: string;
            retryHint: string;
            retryNow: string;
        };
        engine: {
            title: string;
            hint: string;
            run: string;
            errLimit: string;
            checkValid: string;
            checkBadShape: string;
            checkOutsider: string;
            checkGameError: string;
            checkTick: string;
            checkPrivate: string;
            checkReplay: string;
            checkPrng: string;
            checkFx: string;
        };
        baseline: {
            title: string;
            secSem: string;
            secType: string;
            secFont: string;
            fontZhNote: string;
            gameName: string;
            gameDesc: string;
            gamePlayers: string;
            roomCode: string;
        };
        sheetCalib: {
            title: string;
            hint: string;
            groups: string;
            links: string;
            selAll: string;
            gap: string;
            spread: string;
            save: string;
            saved: string;
            saveFailed: string;
            reset: string;
            dirty: string;
            multiSet: string;
            noCalib: string;
            mark: string;
            markDefault: string;
            markX: string;
            markSlash: string;
            markCircle: string;
        };
    };
};
export type Messages = typeof zh;
