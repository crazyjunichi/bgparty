import { type ReactNode } from 'react';
export type BackScope = {
    parent: BackScope | null;
    order: number;
    active: boolean;
};
type BackHandlers = {
    key: string;
    register(run: () => void, priority: number, exit: boolean, scope: BackScope | null, layer: boolean): () => void;
};
export declare const BackHandlerContext: import("react").Context<BackHandlers | null>;
export declare function BackLayer({ scope, children }: {
    scope: BackScope;
    children: ReactNode;
}): import("react").JSX.Element;
/** SDK 中无主站 Provider 时不接管历史；平台弹层按深度及打开顺序处理。 */
export declare function useBackHandler(active: boolean, onBack: () => void, priority?: number, exit?: boolean, layer?: boolean): BackScope;
export {};
