import { type ReactNode } from 'react';
import type { RuntimeReference } from '../game-packs/format';
/** 对局中的平台操作浮层。按钮和菜单不占游戏视口的布局高度。 */
export declare function GameMenu({ children, notice, quickAction, attention, headerAction, runtime, gameName, }: {
    children: (close: () => void) => ReactNode;
    notice?: ReactNode;
    quickAction?: ReactNode;
    attention?: string;
    headerAction?: ReactNode;
    runtime?: RuntimeReference;
    gameName?: string;
}): import("react").JSX.Element;
export declare function GameMenuAction({ icon, label, onClick, danger, pressed, }: {
    icon: ReactNode;
    label: string;
    onClick: () => void;
    danger?: boolean;
    pressed?: boolean;
}): import("react").JSX.Element;
