import { type ReactNode } from 'react';
import './bottom-sheet.css';
/**
 * 自适应弹层:窄屏贴底、横向空间充足时默认靠右,可选靠左(含矮横屏)。遮罩点击关闭,一律 onClick;不传 onClose = 不可遮罩关闭(结算等必须确认的场态)。
 * 调用方须常驻挂载、用 open 控制——条件渲染会把退场动画一起裁掉。
 * open 转 false 后内容原样渲染到卸载,调用方别在退场期间清空内容 state(防闪空)。
 * keepMounted 用于底部游戏菜单:关闭后保留内部组件状态,其 portal 弹层仍可独立显示。
 * preparing 保留不可见排版供异步内容测量,准备完成后再通过 open 展开。
 */
export declare function BottomSheet({ open, onClose, label, title, headerAction, children, footer, keepMounted, compact, tall, preparing, side }: {
    open: boolean;
    onClose?: () => void;
    label: string;
    title?: ReactNode;
    headerAction?: ReactNode;
    children: ReactNode;
    footer?: ReactNode;
    keepMounted?: boolean;
    compact?: boolean;
    tall?: boolean;
    preparing?: boolean;
    side?: 'left' | 'right';
}): import("react").JSX.Element | null;
