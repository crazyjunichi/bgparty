import { type ReactNode } from 'react';
import { type NavigateFunction } from 'react-router-dom';
export declare function BackNavigationProvider({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
/** 先移除当前哨兵再导航，避免退出后多出一页相同地址的空历史。 */
export declare function useAppNavigate(): NavigateFunction;
export declare function usePreviousPage(): () => void;
export declare function requestRoomExit(): void;
export declare function requestAppBack(): void;
