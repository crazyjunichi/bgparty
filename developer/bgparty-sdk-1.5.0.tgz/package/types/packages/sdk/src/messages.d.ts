export interface GameMessages {
}
