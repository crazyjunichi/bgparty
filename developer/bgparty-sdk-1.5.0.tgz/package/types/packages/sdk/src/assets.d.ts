declare global {
    var __bgpartyAssetUrl: ((path: string) => string) | undefined;
    var __bgpartyLoadAssetUrl: ((path: string) => Promise<string>) | undefined;
}
/** Uses the published asset alias (independent projects: path relative to public/), not its ZIP file path. */
export declare function gameAssetUrl(path: string): string;
export declare const sharedAssetUrl: typeof gameAssetUrl;
/** Resolves an installed asset after verification; no game-side network access. */
export declare function loadGameAssetUrl(path: string): Promise<string>;
