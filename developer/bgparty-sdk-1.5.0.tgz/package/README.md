# BGParty 独立游戏 SDK

此包包含类型声明、构建命令和与正式站点相同的沙箱预览。运行环境为 Node.js 22.18 或更高版本。

新用户请下载平台开发者入口的完整开发包，其中已包含配套 SDK、可玩模板、进阶示例、双语教程与 AI 指引。单独的 SDK tgz 用于已有项目更新；不要用运行时的 sdk.zip 作为 npm 安装包。完整开发包使用稳定的本地依赖文件名 `bgparty-sdk.tgz`，实际版本记录在随包清单和 SDK 的 package.json。

For a new project, download the complete developer kit from the Developers page. It includes this SDK, a playable template, an advanced example, English/Chinese guides and AI instructions. The SDK tgz is for updating existing projects; the runtime sdk.zip is not an npm package. Install dependencies with npm install, run npm run dev, and follow the included docs/quickstart.en.md. Node.js >=22.18 is required. Initial dependency installation needs npm registry access.

在独立游戏目录中安装 SDK 的 npm 压缩包，执行 `npx bgparty-game check`、`npx bgparty-game build`、`npx bgparty-game preview`。预览仅监听自动分配的 `127.0.0.1` 端口，按 Ctrl+C 退出。Git 托管游戏站使用 `npx bgparty-game prepare --site <目录HTTPS地址> --repo <Git仓库> --branch <分支>` 固定候选，随后通过 `verify --candidate <UUID>` 和 `publish --candidate <UUID>` 校验并复用该候选；其他项目也可按静态站格式自行发布。

验收指定成品包时运行 `npx bgparty-game accept --game-zip <游戏ZIP> --sdk-zip <SDK运行ZIP> --game-root <游戏清单目录> --sdk-root <SDK清单目录>`。它不编译源码，启动前校验并固定全部 ZIP、依赖卷和预览客户端；每轮使用独立地址、运行 ID 与存储身份。依赖路径相对对应清单目录，省略 root 时相对 ZIP 所在目录，只读取本地文件。可加 `--log <合法动作日志JSON>`，在页面点击“载入准备日志”；也可粘贴日志后点击“恢复日志”，或导出当前完整日志。日志恢复不证明旧版本存档语义兼容。

运行记录在 `.bgparty/local/acceptance/<UUID>/run.json`，截图和观察放其 `evidence/`。`npx bgparty-game accept-status --run <UUID>` 查询，`accept-stop --run <UUID>` 或 Ctrl+C 只关闭本轮。仅使用内置或已连接浏览器的自己的标签页；多个运行可并存，共享窗口或视口操作前以 `accept-lock --run <UUID> --resource <实际共享控制ID>` 等待短时互斥，完成后 `accept-unlock`。锁最长等待 60 秒，不按超时抢占他人的锁；崩溃遗留锁先核实所有者再处理。服务与端口授权遵守项目约定。

For immutable package acceptance, run `npx bgparty-game accept --game-zip <game ZIP> --sdk-zip <runtime SDK ZIP> --game-root <game catalog directory> --sdk-root <SDK registry directory>`. It validates and freezes all local package, dependency and client bytes before binding a random 127.0.0.1 port, without building source or opening a browser. Each run owns its origin, storage identity and record under `.bgparty/local/acceptance/<UUID>/`. Use your own connected-browser tab, the on-page log restore/export controls, and `accept-status` / `accept-stop --run <UUID>`. Shared browser controls require a short `accept-lock` / `accept-unlock` lease with the same resource identity across users of that control. Follow your project's listener authorization policy.

`game.json` 声明入口与双语元数据，入口导出 `{ definition, View, locales }`，可选 `bot`、`describe`、`Options`、`Guide`、`OverView`、`RowView`、`MenuItems`、`ruleIcons`、`fx`、`llm`。共享模块通过 `@bgparty/sdk/*` 导入，React、zod 等使用标准包名。它们由宿主提供，构建时不打入游戏 ZIP。

本地 `public/` 内容作为包内资源收录，用 `@bgparty/sdk/assets` 的资源接口获取。游戏不直接访问网络、平台存储、房间凭据或 AI 密钥。平台提供的网络能力需要通过 SDK 契约调用。

独立项目的 `public/token.svg` 通过 `gameAssetUrl('token.svg')` 获取，参数相对 public/，不加 resources/ 前缀；`metadata.iconPath: "resources/cover.svg"` 是封面的包内文件路径，不是资源函数别名。For independent assets, pass the path relative to public/ to gameAssetUrl; metadata.iconPath uses the separate ZIP path.

SDK API 4 新增 `loadGameAssetUrl(path): Promise<string>`，路径规则相同。游戏在 `game.json` 顶层声明 `sdkApi: 4` 与 `assetLoading: "deferred-images"` 后，PNG/JPEG/WebP/GIF/AVIF 图片不随启动载荷传入沙箱；显示时 await 此接口，再设置图片、SVG image 或 CSS 背景。仍需完整安装全部包，读取本地资源时验证长度及 SHA-256，游戏不联网。为异步等待、失败重试、快速切图与卸载准备 UI；URL 由沙箱持有并在退出时释放，不自行 revoke。CSS 静态 url() 及旧同步接口不能直接使用尚未读取的图片；SVG、代码、JSON 及 SDK 自带资源继续预载。未启用的游戏与旧同步接口保持原加载方式。

API 4 adds `loadGameAssetUrl(path): Promise<string>`. Opt in with top-level `sdkApi: 4` and `assetLoading: "deferred-images"`. Await the URL before assigning raster image sources or backgrounds; handle waiting/errors/retry and ignore stale results after a path change or unmount. Installation still downloads and verifies every package. Deferred reads stay local and verify the fixed package bytes before delivery. Do not revoke runtime-owned URLs. SDK-owned shared assets stay preloaded for synchronous SDK components. Unchanged games keep synchronous loading; static CSS URLs and synchronous lookups require already loaded assets.

构建输出在 `.bgparty/release/`：根目录为 `games.json`，每款游戏的文件平铺在 `games/<游戏ID>/`：`game-<内容版本>.zip`、可选的 `assets-<卷号>-<内容版本>.zip` / `data-<卷号>-<内容版本>.zip`、`cover-<内容摘要>.<扩展名>`。同仓构建和独立工具采用同一布局。将整个目录发布到支持 CORS 的 HTTPS 静态站即可作为游戏源，玩家在主站添加来源后由浏览器运行时下载。主站发布只包含本地游戏；游戏源不发布 SDK。包地址和字节在发布后必须保持不变。

新构建的游戏包和公共运行库使用 `<20 位内容摘要>-<UTC 构建时间>` 版本，如 `a83f29c1d01ab2cd3ef4-20261109T074200000Z`。主站显示本局实际运行的包摘要及构建时间；旧版或自定义版本没有该时间后缀时只显示摘要。缓存复用和重复发布同一固定产物不改变时间；实际重新编译生成新版本。资源分卷仍只按内容生成版本，不因游戏重建改变。

`metadata.iconPath` 使用包内资源路径，例如 `resources/cover.svg`，对应项目中的 `public/cover.svg`。工具同时将封面收录进游戏 ZIP，并在发布目录生成带摘要的封面，自动写入 `games.json`；不需要手动修改清单或复制封面。

`GameDefinition.saveCompatibility` 提供独立于 ZIP 版本的存档契约：`version`、可选 `compatibleWith` 和可选 `migrate({ version, log })`。迁移返回新动作日志，或返回 `null` 拒绝；输入是原档副本。没有声明时，平台不推断不同游戏包可以兼容续玩。仅 SDK 更新且游戏包不变时仍会验证实际记录。在线房间始终固定本局运行版本。

平台日常只发布一个兼容 SDK 运行版本，新局统一采用；破坏性升级的迁移或并存另行决定。本地续玩不保留旧运行版本，不兼容时提示重开，不生成升级历史备份。

公共模块清单由平台显式维护，迁出本仓游戏不会撤销既有出口。新增功能在同一主版本内提升 API 功能版本；独立游戏用 `game.json` 顶层 `sdkApi` 声明最低要求，未填按 1。无需锁定一个具体 SDK 构建。平台版本不足时提示更新，不替换原完整安装。正式构建清理 `.bgparty/release/` 中无引用的旧 ZIP 与带摘要的封面；线上保留旧版本，供仍在使用该版本的客户端获取。

SDK 1.2.0（`sdkApi: 3`）为 `BottomSheet` 新增可选 `side="left" | "right"`，只控制横屏侧边展开位置，默认仍靠右。窄屏保留底部模式；左右安全区及进退场方向由组件统一处理。采用左侧选项的游戏声明最低 `sdkApi: 3`，不需要升级主站能力要求。

SDK 1.2.0 (`sdkApi: 3`) adds optional `BottomSheet side="left" | "right"` for landscape side panels; the default remains right. Narrow viewports still use a bottom sheet. The component handles the selected edge's safe area and animation direction. Games using the left option declare `sdkApi: 3`; the minimum platform API is unchanged.

SDK 1.1.0 新增 `@bgparty/sdk/storage`（游戏需声明 `sdkApi: 2`，主站需支持 `platformApi: 2`）。`readGameStorage()` 返回 `{ revision, values }`；`writeGameStorage({ revision, values })` 返回 `{ status: 'saved' | 'conflict', snapshot }`，`saved` 只在主站数据库事务提交后返回。遇到冲突以返回的最新快照重新计算，异常或重试耗尽则提示失败并保留重试入口。成长档使用独立的数据版本，奖励及对局/玩家去重记录同次提交，不直接访问原生 IndexedDB。

旧代理 `localStorage` 接口保留，原 ZIP 可直接使用新 SDK，但同步调用返回仍不代表写盘成功。游戏数据独立于安装记录，移除下载保留成长与设置；清除数据在主站单独二次确认，清除后不再次导入旧原生档。数据仅保存在本机浏览器，不提供跨设备同步或永久保存承诺。

成品包 `accept` 默认 `--motion normal`：仅在验收沙箱适配 JS/CSS 媒体条件及声明的 SVG 资源，页面显示原始偏好和实际探针，观察保存至本轮 `evidence/motion-*.json`。先确认正常动效就绪，再触发真实游戏动作；探针通过不等于游戏演出通过。`--motion system` 可对照原环境；普通 `preview` 跟随系统。不会修改系统设置、源码或 ZIP 原件。

Package acceptance defaults to `--motion normal`: the acceptance-only adapter covers JS/CSS media conditions and declared SVG assets. Verify the on-page environment probe and its run-bound `evidence/motion-*.json`, then observe actual game actions. A ready environment is not proof of game animation quality. Use `--motion system` for a baseline comparison; ordinary `preview` follows the system. OS settings, source files and ZIP originals are unchanged.
